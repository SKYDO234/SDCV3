"""
Project-root shim.

The real configuration lives in :mod:`skvm.config` so that the application —
whether it is started by ``install.sh``, ``gunicorn skvm.app:create_app()`` or a
test — always reads the same environment-driven settings.
"""
from skvm.config import *  # noqa: F401,F403
from skvm.config import Config, ensure_dirs  # noqa: F401
