# SKVM — what it is and what everything does

A page-by-page, button-by-button guide to the panel running at
**https://5555-itox8m7s8hk0s1m2qr04w.e2b.app** (sign in with the administrator
account). Every button listed here performs a real action; nothing is a
placeholder.

---

## 0. The 30-second version

SKVM is a **control plane for Linux containers**. You give it a name, a size
and an OS image; it downloads a real image from Docker Hub, unpacks it into its
own root filesystem, starts it in its own PID/mount/UTM/IPC/network namespaces
with kernel-enforced CPU, memory and process limits, gives it a private IP
address with NAT internet access, and then lets you use it through a browser
terminal, a file manager, and a small REST API.

Six words matter:

| Term | Meaning |
|---|---|
| **Instance** | one container: its own root filesystem + namespaces + cgroup |
| **Provider** | the backend that runs it — `namespace`, `lxc` or `docker` (whichever really works on the host) |
| **Plan** | a preset of vCPU / RAM / disk used to prefill the create form |
| **Image** | an OS from an OCI registry (Ubuntu, Debian, …), cached locally |
| **Task** | a background job (provision, stop, backup, image pull…) with a live log |
| **Capability** | a probed fact about the host (is there Docker? `/dev/kvm`? sshd?) |

And one promise: **SKVM never lies about what it can do.** It runs containers,
not virtual machines — it has no `/dev/kvm` here, so it offers no KVM VPS, and
every screen says "container". If a capability is missing, the screen shows the
missing piece and the command that would fix it.

---

## 1. Getting in

**Install and start** (idempotent, safe to re-run):

```bash
cd /home/user/skvm && chmod +x install.sh && ./install.sh
```

It builds `.venv`, writes `.env` (fresh secret key + setup token), creates the
data directories, initialises the database, seeds plans/images/node, starts the
panel on `0.0.0.0:5555`, does a real `/healthz` check and prints the URL it
actually answers on. Add `--stop`, `--restart`, `--status`, `--logs`,
`--foreground`, `--port N` or `--no-start`.

**First run** → `/setup`: the wizard asks for the **setup token** printed by
`install.sh` (stored in `.env` as `SKVM_SETUP_TOKEN`; it is consumed the moment
it is used) plus your username, email, full name and password.
**After that** → `/login`.

### Roles — what each account can do

| | User | Operator | Administrator |
|---|---|---|---|
| See and use own instances | ✅ | ✅ | ✅ |
| Create instances | ❌ | ❌ | ✅ |
| See everyone's instances | ❌ | ✅ | ✅ |
| Plans / Nodes / OS Images | ❌ | ✅ | ✅ |
| Users, Settings, System Info, Logs, Backups, Maintenance, API tokens | ❌ | ❌ | ✅ |

Permissions are re-checked **server-side on every page and API call**, not just
hidden in the UI. A user who guesses another user's instance URL gets a 404,
and the attempt is written to the audit log.

---

## 2. The frame around every page

**Sidebar (left)** — grouped navigation, and it only shows what your role can
use:

* *Overview* → **Dashboard**
* *Instances* → **My VPS / All VPS** (the label depends on your role),
  **Create VPS**, **All Instances**, **Expiring VPS**
* *Infrastructure* (operator+) → **Plans**, **Nodes**, **OS Images**
* *Administration* (admin) → **Users**, **Settings**, **System Information**,
  **Logs**, **Backups**, **Maintenance**, **API Management**
* *Account* → **Profile**, **Account Settings**, **Tasks** (operator+)

Small numbers on the labels are real counts: red = instances in error,
amber = tasks in flight. The footer of the sidebar names the **active runtime**
(e.g. "Namespace container (unprivileged)") or says "No runtime available".

**Top bar** — a menu button on narrow screens, the page title, a spinner badge
when tasks are running, a 🔔 bell (links to Logs), and the account dropdown:
your name, role, last sign-in time and IP, plus links to Profile, Account
settings, the raw Health endpoint, and **Sign out**.

---

## 3. Dashboard — `/`

Your landing page, and it is live.

**What it shows**

* **Capability banner** (top) — if this host cannot provision, this is the
  loudest thing on the page, listing the exact reasons per backend.
* **Stat tiles** — Instances / Running / Stopped / Errors, and for operators
  also Accounts, "OS Images ready" (`ready / total`), Tasks running.
* **Host resources** — CPU %, load average, memory used/total, swap, disk
  used/total, uptime, drawn from the kernel via psutil.
* **Virtualization capability report** — the provider matrix with each
  backend's availability and the reason it is unavailable.
* **Recent instances** — the five newest, each with Open/Console links.
* **Expiring soon** — instances whose expiry is near, with a Manage link.
* **Recent tasks** — the last few background jobs and their status.
* **Audit trail** — the most recent security-relevant events.

**Buttons**

| Button | What it does |
|---|---|
| **Create VPS** | Opens the create wizard (admins only) |
| **Live** | Re-fetches `/api/system/metrics` every 8 s and updates the tiles in place — no page reload |
| **Details** (capability card) | → System Information |
| **View all** | → instance list |
| **Open / Console** (per row) | instance detail / browser terminal |
| **Manage** (expiring) | → Expiring VPS |
| **All tasks / Full log** | → Logs page, tasks or audit tab |

---

## 4. Instances

### 4.1 My VPS / All VPS — `/vps/`

The list of instances you may see (your own for a user, everyone's for an
operator/admin). Shows name, status pill, kind (e.g. `container_namespace`),
resources, address, owner, expiry and utilisation bars.

**Controls:** **Search** box (name, hostname or OS), a **status filter**,
pagination, and per-row **Open** / **Console** buttons.

### 4.2 Create VPS — `/admin/vps/create` (admin only)

The wizard, one page, grouped:

* **Owner** — which account will own the instance.
* **Plan tiles** — clicking one prefills vCPU / memory / disk.
* **Image** — the OS catalogue with cache state; images that are not cached are
  pulled during creation.
* **Resources** — vCPU, memory (MiB), disk (GiB); the page validates them
  against the global ceilings and the owner's quota as you type.
* **Identity** — name, hostname.
* **Networking** — whether to create the namespace/veth/NAT (on by default).
* **SSH** — only offered when the selected image actually has `sshd` *and* the
  backend can publish a port; otherwise the control explains why it is off.
* **Start command** — what to run as PID 1 (auto-detected if left blank).
* **Expiry** — days until suspension.

**Button: Provision instance** → `POST /api/instances` → returns immediately
with a **task id**; you are taken to the instance page where the provisioning
log streams live. The panel never reports success until the container is
verified running.

### 4.3 Instance detail — `/vps/<id>`

**Header buttons** (only those your role and the instance state allow):

| Button | Real action |
|---|---|
| **Console** | Opens the xterm.js terminal (only when running) |
| **Stop** | `POST …/actions {action:"stop"}` → queued task; SIGTERM to the supervisor, SIGKILL after 20 s if it ignores it |
| **Restart** | Stop then start as one task |
| **Start** | Boots the container again from its existing rootfs |
| **Rebuild** | Re-extracts the image layers over the rootfs — the "factory reset" |
| **Backup** | Creates a real `tar.gz` of the rootfs as a background task |
| **Delete** (admin) | Stops, removes netns/cgroup/rootfs and archives the record as `deleted` (needs confirmation) |

**Cards**

* **Specification** — vCPU/RAM/disk limits, provider, kind, isolation label,
  OS, created/expiry dates, uptime.
* **Network & access** — the real internal IP, gateway, netns name, ssh state
  (with the honest reason when it is off).
* **What this isolation provides** — plain-language explainer: shares the host
  kernel, cgroup-enforced limits, own network namespace, *not* a hypervisor.
* **Backups** — every archive for this instance with size, timestamp and a
  **verify** action that really opens the gzip and reads the tar index.
* **Task history** — every job for this instance, with **Log** (opens the
  streaming drawer) and **Cancel** for in-flight jobs.

### 4.4 Console — `/vps/<id>/console`

A **real Linux PTY**, not a fake terminal: you get a shell inside the instance
through the provider (`nsenter`, `lxc-attach` or `docker exec`). Keys, resize
events and output travel over a WebSocket.

| Button | What it does |
|---|---|
| **Reconnect** | Re-establishes the socket after a drop (auto-retries 3× with backoff; 4401/4403/4404 stop retrying and explain) |
| **Clear** | Clears the terminal display only |
| **Copy transcript** | Copies everything printed in the session to the clipboard |
| **Run identity check** | Types a diagnostic command sequence (hostname, kernel, cgroup limits, IP) so you can see the isolation facts for yourself |
| **Back** | Returns to the instance page |

The three cards below the terminal state **What this is**, **Try this** and
**Session rules** — idle timeout, how many sessions you may hold, what gets
audited.

### 4.5 File manager — `/vps/<id>/files`

Two panes: a directory browser and a text editor. All operations happen
**inside the instance**, never on the host.

| Button | What it does |
|---|---|
| **Upload** | Uploads a file into the current directory (size-limited by a setting) |
| **New folder** | Creates a directory |
| **Refresh** | Re-reads the listing and the usage figure |
| **↑ (parent)** | Navigates up |
| **Save** | Writes the edited file back (checks the size limit first) |
| **Download** | Streams the selected file to your browser |
| **Rename** | Renames the selected entry |
| **Permissions** | Changes the mode (chmod) |
| **Delete** | Deletes the entry after confirmation |

Read-only/non-running instances disable the mutations and say why. Symlinks
that would escape the rootfs are refused.

### 4.6 Usage — `/vps/<id>/usage`

Sparklines and counters for **CPU**, **Memory**, **Network** and **cgroup
accounting**, all sampled from the kernel: `cpu.stat` usage, `memory.current`,
`pids.current`, network namespace counters, and filesystem usage.

**Refresh** re-reads immediately. Every measurement names its source; if a
metric cannot be read, the card says which one and why instead of drawing a
flat line at zero.

### 4.7 SSH — `/vps/<id>/ssh`

Either the **real, verified** connection details (host, port, user, host-key
fingerprint, copyable `ssh` command) or a clear explanation of what is missing.
On this host SSH is genuinely unavailable (no `sshd` in the image, no port
publishing on the namespace backend) so the page says exactly that and points
you at the console and file manager. It never invents a hostname, port or
password.

---

## 5. Infrastructure (operator and admin)

### 5.1 Plans — `/admin/plans`

Presets offered in the create wizard: name, slug, vCPU, memory, disk,
bandwidth, monthly price, sort order, description, active flag.

**Buttons:** **New plan** (modal), **Edit** (same modal, prefilled),
**Disable / Enable** (hides the plan from the wizard without losing it),
**Delete** (refused with a 409 if instances still use that plan).

### 5.2 Nodes — `/admin/nodes`

The registry of machines instances can run on. This deployment has one — the
local host — with live metrics pulled from it.

**Buttons:** **Register node** (name, address, hostname, provider hint, notes),
**Probe** (runs the capability probe against that node right now), **Maintenance**
(marks the node as draining so new instances are not scheduled there),
**Remove** (refused while instances reference it).

### 5.3 OS Images — `/admin/images`

The image catalogue, reconciled against what is really in `data/images`.

Columns include the OCI reference, the cached size, the layer count and an
honest status: `not downloaded yet` → `ready · N layer(s), X MiB verified on
disk`, or `error` with the registry's own message.

**Buttons:** **Add image** (name, reference like `library/debian:12`,
version, family, codename, default user), **Download / Re-download** (real OCI
pull with token auth, digest verification and layer caching, streamed to a
task log), **Disable / Enable**, **Delete** (refused while in use; removes that image's cached layers from disk as well as the catalogue row).

---

## 6. Administration (admin only)

### 6.1 Users — `/admin/users`

Every account with role, status, quotas, instance count and last sign-in.

**Buttons:** **New account** → modal with username, email, full name, role and
four quotas (instances, vCPU, memory, disk). **Edit** reuses the modal.
**Suspend / Unsuspend** blocks sign-in immediately. **Unlock** clears a
lockout caused by repeated failed passwords. **Delete** removes the account —
refused for your own account or the last remaining administrator (HTTP 409),
so the panel can never lock itself out.

### 6.2 Settings — `/admin/settings`

21 live settings in six groups, applied without a restart:

* **Branding** — panel name, tagline, support URL
* **Provisioning** — provider preference, overcommit, per-instance vCPU /
  memory / disk ceilings, instances per user, default expiry, suspend-on-expiry
* **Security** — default role, self-registration, failed logins before lockout,
  lockout minutes, session lifetime
* **Console** — idle timeout, file-manager upload limit
* **Monitoring** — metrics interval, audit retention, alert webhook URL
* **Maintenance** — maintenance banner text

**Button: Save all settings** — validates every value, writes them, and the
change takes effect for the next request.

### 6.3 System Information — `/admin/system`

The truth-teller page. Sections: **Host** (kernel, distro, CPU, memory,
uptime, cgroup version, container markers), **Resources**, **Capability matrix**
(every probe with `available`, reason and remedy), **Container providers**
(the three backends and why each is or is not usable), **Diagnostics**, and
**Paths and guardrails** (data dirs, the privileged helper and its allowlist).

**Button: Run housekeeping** — reconciles every instance against its runtime
(dead PIDs become `stopped`), reaps orphan namespaces/veths/cgroups and marks
interrupted tasks as such.

### 6.4 Logs — `/admin/logs`

Three tabs:

* **Application log** — the structured JSON log, filterable.
* **Tasks** — every background job with kind, status, progress, duration,
  retries and the instance it belongs to. Each row has a **Log** button that
  opens a drawer streaming the task's real log lines, **Cancel** for queued or
  running jobs (marks the task cancelled; work already in flight is allowed to
  finish), and **Export JSON**.
* **Audit trail** — every security-relevant event (sign-ins, permission
  denials, instance operations, token creation) with actor, IP and timestamp.

**Reload** re-reads; **Apply** applies the filter.

### 6.5 Backups — `/admin/backups`

Every archive across all instances with its size, age, verification state and
owning instance. **Verify** opens the gzip and reads the tar index; **Delete**
removes the archive file and record. The instance detail page has the same
Verify action. Backups are created from the instance page; unreadable archives
are reported as failed rather than shown as good.

### 6.6 Maintenance — `/admin/maintenance`

| Control | What it really does |
|---|---|
| **Maintenance switch + Apply** | Puts the panel in maintenance mode: non-admins see the banner and are blocked from changes; instances keep running |
| **Close all** (console sessions) | Terminates every attached terminal immediately, audited |
| **Prune logs and login attempts** | Deletes log/login rows older than the retention setting |
| **Re-read every instance from its runtime** | Reconciles the database with reality — this is what makes a crashed container show as `stopped` instead of "running" |
| **Enforce expiry policy now** | Runs the expiry job immediately instead of waiting for the monitor |

### 6.7 API Management — `/admin/api-management`

Create and revoke bearer tokens.

**Buttons:** **Issue token** → modal with name, scopes
(`read`, `write`, `provision`, `admin`) and expiry in days.
The secret (`skvm_…`) is **shown once**; only a SHA-256 hash and a short prefix
are stored. **Copy** copies the new secret. **Revoke** kills a token instantly.

```bash
curl -H "Authorization: Bearer skvm_…" https://…/api/instances
```

Scopes are enforced per request, and every token implicitly gets `read` so it
can inspect or poll what it did. `write` covers power controls, files and the
user's own backups; `provision` is required to create a new instance; `admin`
covers global infrastructure, users, settings, expiry/transfer and destructive
administration. The token's owner role and instance ownership are still checked
on every request, and a browser cookie cannot widen a token's scopes. `GET /api/`
returns the discovery document listing every endpoint and method.

### 6.8 All Instances / Expiring VPS

**All Instances** (`/admin/vps`) is the cross-tenant table with filters by
search, status, owner and provider; per row: **Re-read runtime state** (refresh
one instance), **Start**, **Rebuild**, **Transfer** (moves ownership in a
modal), and **Delete**. Task cancellation marks the task cancelled; work already
in flight is allowed to finish.

**Expiring VPS** (`/admin/expiring`) lists instances approaching expiry with
quick-extend buttons — **+1d**, **+3d**, **+7d**, **+30d** — and **clear** to
remove the expiry entirely. When an expiry passes, the monitor suspends the
instance (stops it) — it never deletes data.

---

## 7. Account

### 7.1 Profile — `/profile/`

Your quota usage (instances / vCPU / memory / disk against your limits), your
**API tokens** with their prefixes and last-used time, your **open console
sessions** with a **Close all** button, and a list of your instances.

### 7.2 Account Settings — `/profile/security`

* **Change password** → **Update password** (verifies the current one, applies
  the password policy, audits the change).
* **Profile details** → **Save profile** (full name, email, notification
  preference). Role and quotas are deliberately not editable here.
* **Recent sign-in attempts** — successes and failures with IP and user agent.
* **Your audit trail** — what your account has done.
* **Danger zone** — **Sign out**, which ends the browser session and closes
  your console sessions; instances keep running.

---

## 8. What happens without you clicking anything

* **Task runner** — a small worker pool executes provisioning, lifecycle,
  backup and image operations. Jobs are persisted, so a task survives a panel
  restart; a task that was interrupted is marked `interrupted`, never left
  "running".
* **Metrics sampler** (every 5 s, configurable) — collects host and per-instance
  figures.
* **Instance monitor** (every 15 s) — re-reads each instance's real state; a
  container whose process died is reconciled to `stopped`.
* **Expiry enforcement** — suspends, never deletes.
* **Orphan sweep** — reaps namespaces, veths and cgroups that outlived their
  supervisor.
* **Logging** — structured JSON to `data/logs/skvm.log` and the panel stdout to
  `data/logs/server.log`.

---

## 9. What SKVM deliberately does not do

* **No KVM virtual machines.** Containers share the host kernel; without
  `/dev/kvm` a hypervisor VPS cannot exist, so none is offered.
* **No fabricated infrastructure.** No placeholder IPs, SSH ports, keys, tmate
  sessions or console output — missing things are shown as missing, with the
  reason.
* **No port publishing on the namespace backend**, so no inbound SSH; the
  console and file manager are the access path.
* **No disk-quota enforcement** by the namespace backend — it applies
  `RLIMIT_FSIZE` and says so, rather than implying a hard limit it cannot keep.
* **No access to the host** for ordinary users — the privileged helper only
  performs an allow-listed set of operations (`chmod`, `ip netns`, cgroup
  writes…) behind `sudo -n`.

---

## 10. Cheat sheet

```bash
cd /home/user/skvm

./install.sh                 # install + start on 0.0.0.0:5555
./install.sh --status        # real health check against the running panel
./install.sh --logs          # tail the panel log
./install.sh --stop|--restart

.venv/bin/python -m pytest tests -q                 # 68 passed
SKVM_E2E=1 .venv/bin/python -m pytest tests -q      # + real provisioning
.venv/bin/python scripts/smoke.py                   # every page/endpoint over HTTP
.venv/bin/python scripts/e2e_http.py                # full lifecycle over HTTP
```

| Path | What lives there |
|---|---|
| `data/skvm.db` | the database (SQLite, WAL) |
| `data/instances/<id>/` | each instance's rootfs, `meta.json`, `state.json`, `runtime.log` |
| `data/images/<slug>/` | cached OCI layers |
| `data/backups/` | `tar.gz` archives |
| `data/logs/` | application and server logs |

Read next: `README.md` (design and install), `VERIFICATION.md` (audit: what was
tested, the ten bugs found and fixed, and the known limitations).
