"""
WSGI entry point.

    gunicorn --bind 0.0.0.0:5555 --worker-class gevent --workers 1 wsgi:app

Note: the interactive console uses WebSocket.  A gevent worker (``pip install
gevent``) serves it; with the default sync/gthread workers the HTTP panel works
but the console endpoint cannot upgrade — ``run.py`` (Werkzeug, threaded) does
support it out of the box.
"""
from __future__ import annotations

from skvm.app import create_app

app = create_app()

# `flask --app wsgi ...` and `gunicorn wsgi:app` both work.
if __name__ == "__main__":  # pragma: no cover
    from skvm.config import Config

    app.run(host=Config.HOST, port=Config.PORT, threaded=True)
