# SKVM full-surface audit

**Date:** 2026-10-15  
**Environment:** live panel at `https://5555-itox8m7s8hk0s1m2qr04w.e2b.app`  
**Result:** **184 checks passed, 0 failed**

## What was checked

I exercised the running panel, not just its source or test client. The audit loaded
all 29 non-API page/entry route variants (including instance-scoped and
authentication pages, plus health/favicon), then drove the real HTTP APIs and
background jobs for the visible workflows. It
also opened two real WebSocket PTY sessions, sent the console's identity-check
command into the container, and read the actual OS-release output back.

Nineteen browser-only handlers (clipboard, local terminal controls, tabs and
form/button wiring) were checked against the actual HTML/JavaScript source. They
were **not** literally clicked in a headless browser; server-side actions behind
them were exercised over HTTP wherever they exist. The API discovery page listed
67 endpoints; this audit is a full UI/workflow audit, not a fuzz test of all 67
routes independently.

| Area | Checks | Result |
|---|---:|---:|
| Browser-only control wiring | 19 | pass |
| Pages, auth gates, dashboard metrics and discovery | 30 | pass |
| Plans | 6 | pass |
| Nodes | 5 | pass |
| OS images | 7 | pass |
| Users | 9 | pass |
| API tokens, CSRF and scope boundaries | 23 | pass |
| Settings | 3 | pass |
| Maintenance, housekeeping, logs and tasks | 18 | pass |
| Instance creation, page renders, filters and live metrics | 14 | pass |
| File manager | 16 | pass |
| Console WebSocket / reconnect | 2 | pass |
| Instance lifecycle, backups, expiry and transfer | 25 | pass |
| Account and sign-out | 7 | pass |
| **Total** | **184** | **184 pass · 0 fail** |

The audit used real, disposable plans, nodes, images, users, tokens, a container,
file operations and backup archives; it removed them on completion. The backup
corruption test damaged only its disposable archive, then verified that SKVM
reported the failure and removed the file. The node probe targeted a deliberately
unreachable address and correctly reported it as unreachable rather than
inventing a successful probe.

## Automated verification

| Command | Result |
|---|---|
| `.venv/bin/python -m pytest tests -q` | **76 passed, 1 skipped** |
| `SKVM_E2E=1 .venv/bin/python -m pytest tests/test_e2e_provision.py -q` | **2 passed** (real OCI pull, Alpine filesystem operations, console capability, lifecycle and retry cleanup) |
| `.venv/bin/python scripts/smoke.py --password …` | **All checks passed** (17 pages and 18 API smoke checks) |
| `.venv/bin/python scripts/e2e_http.py --password …` | **Passed** (created, ran, accounted for, reported, stopped and removed a real container over HTTP) |
| `./install.sh --status` | Health endpoint answered. This preview was started by Arena's supervisor, not the installer's daemon, so the command also reports no installer PID file; the installer-managed path is separately covered by regression tests. |

After cleanup: **0 live instances, 0 backups, 0 network namespaces/veths, and 0
SKVM cgroup directories**. The only cached OCI image left in this project data
directory is the seeded Ubuntu image. Archived deleted-instance rows and audit
records are retained as history.

## Defects found and fixed

1. **Root-level New folder was a false success.** Stripping `/` built a relative
   path, so the button reported success in the shell's current directory while
   later file operations could not find `/folder`. Root uploads had the same
   issue. Both now preserve absolute paths; the regression and Alpine E2E checks
   create, write, read, upload, download and delete at the root.
2. **Alpine file reads failed.** The file manager hard-coded GNU `/usr/bin/stat`,
   which a minimal Alpine image does not have. It now falls back to BusyBox
   `/bin/stat`; search no longer relies on GNU-only `find -printf`, and disk
   usage tries the portable BusyBox form. Alpine E2E now covers stat, chmod,
   search, usage and root upload.
3. **Alpine's real shell was not selected for its console.** The console probe
   omitted `/bin/ash`; the namespace provider now recognizes it.
4. **The console PTY lacked a controlling terminal and clean working directory.**
   Shells connected but printed “no job control”/`getcwd` warnings. The child now
   acquires the PTY as its controlling terminal, sets its foreground process
   group, and enters the target mount namespace's working directory. Two live
   WebSocket sessions passed the identity check without those warnings.
5. **Run identity check did not run.** Its button copied a command to the
   clipboard rather than sending it to the terminal. It now transmits the preset
   command through the live WebSocket to the container PTY.
6. **Backup verification was unreachable.** `BackupService.verify()` existed,
   but no route or button called it. Instance and global backup views now have a
   real Verify action. Tests verify a real archive and require a corrupted one to
   fail with an honest diagnostic.
7. **Plan/node usage counts disagreed with delete guards.** The tables counted
   archived deleted VPS rows while guards counted only live instances. Displayed
   counts now use the same live-row definition as the guard.
8. **Bearer-token writes were blocked by cookie CSRF.** Explicit bearer-token
   requests now bypass CSRF; cookie-authenticated writes still require a CSRF
   token.
9. **API token scope labels and enforcement did not match.** Scopes are now
   aligned: every token implies `read`; `write` covers per-instance operations
   and user-scoped backups; `provision` is required to create instances; `admin`
   covers global and destructive administration. Instance deletion, expiry,
   ownership transfer, task cancellation and closing all consoles are checked
   separately. Role and ownership checks still apply in addition to scopes.
10. **Image slugs could escape the cache directory.** New image slugs are
    validated before they are used as paths. Delete now removes the actual
    cached directory as well as the catalogue row, with a path-containment check.
11. **Maintenance banner text could not be cleared.** An empty submitted message
    used to preserve the old message; blank now means clear, and the audit
    verifies restoration of the previous maintenance state.

## Test-harness false alarms and cleanup

* An early console assertion expected `PRETTY_NAME` in the first three
  `/etc/os-release` lines; Ubuntu's actual `head -3` output contains `NAME`,
  `VERSION`, and `ID`. The check was corrected to match the command the UI
  actually runs.
* Sign-out is a confirmation page on `GET /logout`; the actual sign-out is the
  CSRF-protected form `POST`. The audit now tests that real form action.
* A first-draft stop probe tried to stop an instance while its backup job still
  held the per-instance task lock. The resulting conflict was correct; the
  audit now waits for each background task before starting the next action.
* One first-draft plan probe accidentally selected and deleted the seeded Nano
  plan. The idempotent bootstrap recreated it. The final audit uses only
  audit-prefixed disposable plans and confirmed Nano/Micro/Small/Medium remain.

## Remaining limits on this host

* The active backend is SKVM's **Linux namespace container** provider. It shares
  the host kernel; it is not KVM and is never represented as a virtual machine.
  `/dev/kvm` is absent.
* Docker is unavailable (no daemon socket/`DOCKER_HOST`); LXC is unavailable
  (required binaries are absent). The capability page reports those facts.
* SSH access is not available here: the instance image lacks an `sshd` and this
  host has no configured port publishing. SKVM reports that instead of showing
  fake credentials or a fake session.
* Clipboard and other browser-local controls are source-reviewed, not
  headless-browser-clicked. Their server-backed operations and data were tested
  separately over HTTP/WebSocket.

## Reproduce

```bash
cd /home/user/skvm
.venv/bin/python scripts/audit_everything.py --password '<admin password>'
.venv/bin/python -m pytest tests -q
SKVM_E2E=1 .venv/bin/python -m pytest tests/test_e2e_provision.py -q
.venv/bin/python scripts/smoke.py --password '<admin password>'
.venv/bin/python scripts/e2e_http.py --password '<admin password>'
sudo -n ./helpers/skvm-helper netns-list
```
