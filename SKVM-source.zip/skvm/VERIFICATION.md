# SKVM — verification report

Audit of the panel as it actually runs on this host, not as it reads in
source. Everything below was executed; commands and real output are quoted.

Date: 2026-10-15 · Panel: `https://5555-itox8m7s8hk0s1m2qr04w.e2b.app`

> **Current full-surface result:** see [`AUDIT_REPORT.md`](AUDIT_REPORT.md) —
> 184 checks passed, 0 failed. This file preserves the earlier infrastructure
> audit and its original defect notes.

---

## 1. What SKVM is

A self-hosted VPS hosting panel (Flask + SQLAlchemy + SQLite) that provisions
and manages **Linux containers** on the machine it runs on: it pulls real OCI
images from Docker Hub, materialises a root filesystem, starts the instance in
its own namespaces with kernel-enforced limits, and exposes a genuine PTY
console, a file manager, resource accounting and an admin surface.

It is not a hypervisor and never claims to be one: no `/dev/kvm` here means no
KVM VPS, and the UI says "container" everywhere a lesser panel would say "VPS".

### Backends (probed live on every start, first working one wins)

| Backend | Status on this host | Why |
|---|---|---|
| `docker` | **unavailable** | no Docker daemon socket or `DOCKER_HOST` |
| `lxc` | **unavailable** | missing `lxc-start`, `lxc-info`, `lxc-ls` |
| `namespace` | **available and in use** | passwordless sudo, user/PID/mount/UTS/IPC/net namespaces, cgroup v2, overlayfs |

Also probed and honestly reported as absent: `/dev/kvm` (no hardware
virtualization), LXCFS, sshd, tmate, debootstrap.

### Surface

* **Pages** — dashboard, instances list/detail/console/files/usage/SSH,
  admin (VPS, create, expiring, users, plans, nodes, images, settings, system,
  logs, backups, maintenance, API management), profile, security, setup, login.
* **API** — `/api/{ping,health,info,capabilities,metrics,processes,nodes,
  instances,plans,images,users,settings,tasks,logs,backups,tokens,summary,me}`
  with bearer tokens (`read|write|provision|admin`, SHA-256 at rest, shown once; the current scope contract is documented in `AUDIT_REPORT.md`).
* **WebSockets** — `/ws/console/<id>` (real PTY via xterm.js), `/ws/tasks`,
  `/ws/metrics`.
* **Security** — scrypt password hashing, per-account lockout, CSRF on
  cookie-authenticated state changes (bearer clients use explicit API tokens),
  per-route rate limits with `Retry-After`, CSP and
  `X-Frame-Options`, server-side authorisation on every route, install-time
  setup token (`hmac.compare_digest`, consumed once) gating the first admin.

---

## 2. Evidence that it works

```
$ .venv/bin/python -m pytest tests -q
68 passed, 1 skipped in 77.29s

$ SKVM_E2E=1 .venv/bin/python -m pytest tests/test_e2e_provision.py -q
2 passed in 73.31s

$ .venv/bin/python scripts/smoke.py --password '…'
all checks passed          # 17 pages + 18 API endpoints over real TCP

$ .venv/bin/python scripts/e2e_http.py --password '…'
end-to-end HTTP check passed: the panel really created, ran, accounted for,
reported and removed a container
```

The end-to-end run provisions through the panel's own HTTP API and then
verifies the result through the panel's own endpoints:

```
POST /api/instances -> 202, instance sk41581fe9d951a3e6, task sk73279ea7c3d86faf
task sk73279ea7c3d86faf status=success
  | [06:51:37] using cached image ubuntu-20.04 (26.2 MiB)
  | [06:51:38] cgroup limits applied: memory.max_bytes, memory.high_bytes,
  |            memory.swap.max, cpu.max, pids.max, io.max
  | [06:51:38] creating network namespace skvm-sk41581fe9d951a3e6
  | [06:51:38] instance address 10.89.1.2/30 via vhe9d951a3e6
  | [06:51:39] instance e2e-http-47097 is running
status=running kind=container_namespace is_virtual_machine=False
init process exists (EPERM: it runs as root in its own namespaces)
metrics available=True from 4 real source(s): process accounting, cgroup v2,
        network namespace counters, filesystem accounting
file listing of / -> 21 entries
```

That is a real Ubuntu 20.04 filesystem, a real process, a real address from the
pool, and real kernel counters — not fixtures.

Host after the run:

```
$ sudo -n ./helpers/skvm-helper netns-list
{"netns": [], "veths": [], "count": 0, "ok": true}
```

---

## 3. Problems found — and what happened to them

### Fixed (real defects)

1. **The registry probe reported a working registry as unreachable.**
   `detect_egress()` did a plain `GET https://registry-1.docker.io/v2/` and
   treated HTTP 401 as failure. But 401 + `WWW-Authenticate: Bearer` *is* the
   Docker Registry v2 handshake for anonymous pulls, so the panel refused to
   provision any image that was not already cached:
   `400 the image has not been downloaded and the container registry is
   unreachable (HTTPError: HTTP Error 401: Unauthorized)`.
   It now completes the real token round-trip and reports the token host and
   size on success, or a precise reason on failure.

2. **A retried provision failed forever with ETXTBSY.**
   On retry the task called `create()` again without tearing down the previous
   attempt, so layer extraction died writing over a binary the still-running
   container was executing:
   `layer 1 failed to apply: OSError: [Errno 26] Text file busy:
   '…/rootfs/bin/busybox'` — this was the source of intermittent test failures.
   Retries now destroy the failed attempt (stop → cgroup → netns → rootfs)
   first. Covered by a new test.

3. **Orphan cleanup could not see namespace debris.**
   `cleanup_orphans()` only looked for live `ns-launch` processes, so a
   namespace whose supervisor had died — an interrupted provision, a killed
   panel, a lost sandbox — leaked forever. The privileged helper gained
   `netns-list` and `veth-destroy`, and the sweep now reaps orphan namespaces,
   veths and cgroups while explicitly leaving live instances alone.

4. **`install.sh` printed a URL for the wrong port.**
   `panel_url()` ignored its argument and read `SKVM_PORT`, a variable that
   exists nowhere, so a panel bumped from 5555 to 5556 was advertised at
   5555 — a link that answers nothing. It now honours the port it was given
   (and the runtime summary queries the port the panel really uses).

5. **Bearer tokens were not scope-limited on role-gated routes.**
   `/api/plans`, `/api/users`, `/api/settings` … are protected by
   `require_admin`/`require_operator`, and a token authenticates through the
   login manager, so a read-only token could have performed writes. Scope is
   now derived from method + path and enforced for every `/api` route, and a
   token is no longer widened into full session privileges when a browser
   cookie happens to be present.

6. **The API and the UI disagreed about image state.**
   `/admin/images` reconciled the database against the filesystem; `/api/images`
   did not. Reconciliation now lives in one place (`reconcile_image_cache()`),
   runs at startup and is used by both, so a cached image reports
   `ready · 1 layer(s), 26.2 MiB verified on disk` and a row can never claim a
   cache whose layers are gone.

7. **`/api/tasks/<id>` accepted only the public task id.**
   A caller that kept the numeric `id` from a create/list response got a bare
   `404 no such task`. Both forms are now accepted.

8. **A user could distinguish someone else's instance from a non-existent one.**
   Opening another user's instance URL returned 403, confirming it existed.
   It now returns 404 (and the attempt is still recorded in the audit log),
   matching the API, which keeps 403 for the machine-readable case.

9. **`./install.sh --status` could not run.**
   The early dispatch (`--status`, `--stop`) executes before the helper
   definitions further down the file, so `--status` printed
   `read_env: command not found` instead of reporting the panel's state. The
   helper now sits above the dispatch and falls back to any available python
   when the virtual environment has not been built yet. Covered by a test.

10. **`auth/login.html` never rendered** (missing `{% endblock %}`) — every
    login page was a 500 with `TemplateSyntaxError`. Fixed, and the page now
    shows the real session lifetime.

### Observed, judged acceptable (stated so it is not a hidden surprise)

* **Stop/delete can take ~20 s.** If a guest ignores SIGTERM, the panel waits
  20 s and then escalates to SIGKILL — the task log says exactly that
  (`supervisor did not exit; sending SIGKILL`). Deleting is not instant by design.
* **Deleting archives rather than erases.** Instances keep their record with
  status `deleted` so the audit trail survives; they disappear from the normal
  list.
* **No port publishing / no SSH on this backend.** `supports.ssh = false` and
  the instance page explains why instead of inventing a hostname. Instances are
  reachable through the web console and file manager.
* **Disk quotas are not enforceable** by the namespace backend. The panel
  applies `RLIMIT_FSIZE` and reports the limitation rather than pretending.
* **`/api/system/metrics` takes ~420 ms** because it walks the data directory
  for an accurate on-disk figure. Correct, but the heaviest endpoint.

### Not bugs (checked and cleared)

During the audit several things looked broken and were not — they were mistakes
in my own throwaway probes, listed here so nobody re-investigates:

* `task["status"] == "success"`, not `"succeeded"`; the log lives under
  `logs`, not `log`; the public id is `task_id`, not `id`.
* The metrics endpoint returns values flat (`memory.percent`), not under a
  `host` wrapper — it was fully populated all along.
* `capabilities.providers` is a list, not a dict.
* A 409 from delete while another task holds the instance is deliberate
  concurrency control (`reserve(f"vps:{id}")`), not a failure.
* `os.kill(pid, 0)` on a container init returns EPERM to an unprivileged
  probe — that proves the root-owned process exists.
* The setup wizard rejects `admin@localhost`; use a TLD-ful address.
* The one-off `test_e2e_provision` failure was defect #2 (ETXTBSY), now fixed
  and covered; three consecutive reruns pass.

---

## 4. Known limitations of the product

1. Container isolation shares the host kernel — it is not a hypervisor
   boundary. A KVM VPS cannot be offered without `/dev/kvm`, so none is.
2. On this host provisioning works but Docker and LXC do not; the capability
   report lists the exact missing pieces for each.
3. Without an `sshd` in the image and without port publishing, SSH access is
   genuinely unavailable; the panel says so instead of faking credentials.
4. The WebSocket console needs a server that can upgrade (Werkzeug, or
   gunicorn with the gevent worker). With gunicorn's sync workers the console
   page states the limitation.
5. The installer rewrites `PORT=` in `.env` if the requested port is taken,
   and now prints the URL that actually answers.

---

## 5. Reproducing all of this

```bash
cd /home/user/skvm
chmod +x install.sh && ./install.sh          # idempotent; starts on 0.0.0.0:5555

.venv/bin/python -m pytest tests -q          # latest: 76 passed, 1 skipped
SKVM_E2E=1 .venv/bin/python -m pytest tests/test_e2e_provision.py -q  # 2 passed
.venv/bin/python scripts/smoke.py --password '<admin password>'
.venv/bin/python scripts/e2e_http.py --password '<admin password>'
.venv/bin/python scripts/audit_everything.py --password '<admin password>' # latest: 184/184
```
