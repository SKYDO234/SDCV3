"""
Authorisation, ownership and CSRF tests.

The point of these tests is the boring, load-bearing part of a hosting panel:
a regular user must not be able to reach another user's instance, to create
instances, or to change global settings — no matter what the HTML happens to
render.
"""
from __future__ import annotations

import json

import pytest

from skvm.models import Role, User, VPS, VPSStatus


@pytest.fixture(scope="module")
def users(app, admin):
    """
    One operator and two regular users, all real rows.

    Depends on the `admin` fixture (not just on `app`) because the panel only
    serves `/login` once an administrator exists — it redirects to the setup
    wizard otherwise.
    """
    with app.app_context():
        from skvm.extensions import db
        from skvm.security import hash_password

        made = {}
        for username, role in (("op", Role.OPERATOR), ("alice", Role.USER),
                               ("bob", Role.USER)):
            user = User.query.filter_by(username=username).first()
            if user is None:
                user = User(username=username, email=f"{username}@example.test",
                            role=role, full_name=username.title())
                user.password_hash = hash_password(f"{username}-Passw0rd!")
                db.session.add(user)
            user.must_change_password = False
            made[username] = user.id
        db.session.commit()
        return made


def _login(client, username: str) -> None:
    client.get("/logout")
    response = client.post("/login", data={"username": username,
                                           "password": f"{username}-Passw0rd!"},
                           follow_redirects=False)
    assert response.status_code in (302, 303), (
        f"sign-in for {username} returned {response.status_code}")
    assert "/login" not in response.headers.get("Location", ""), (
        f"sign-in for {username} was rejected")


@pytest.fixture()
def alice_client(app, client, users):
    _login(client, "alice")
    return client


@pytest.fixture()
def operator_client(app, client, users):
    _login(client, "op")
    return client


@pytest.fixture()
def bob_instance(app, users):
    """A real instance row owned by bob (no runtime needed for these checks)."""
    with app.app_context():
        from skvm.extensions import db

        owner = User.query.filter_by(username="bob").first()
        existing = VPS.query.filter_by(name="bob-box").first()
        if existing is None:
            existing = VPS(instance_id="sksec000000000001", name="bob-box",
                           hostname="bob-box", owner_id=owner.id,
                           status=VPSStatus.STOPPED, vcpu=1, memory_mb=256,
                           disk_gb=1, kind="container_namespace",
                           os_name="Test", os_version="1")
            db.session.add(existing)
            db.session.commit()
        return existing.instance_id


# --------------------------------------------------------------- anonymous
@pytest.mark.parametrize("path", ["/", "/vps/", "/admin/users", "/profile/",
                                  "/api/instances", "/api/users", "/api/me"])
def test_anonymous_cannot_read_anything(client, path):
    response = client.get(path, follow_redirects=False)
    if path.startswith("/api/"):
        assert response.status_code == 401, f"{path} -> {response.status_code}"
    else:
        assert response.status_code in (301, 302), f"{path} -> {response.status_code}"
        assert "/login" in response.headers.get("Location", "")


# ------------------------------------------------------------ authorisation
@pytest.mark.parametrize("path", ["/admin/users", "/admin/settings",
                                  "/admin/api-management", "/admin/plans",
                                  "/api/users", "/api/settings", "/api/tokens",
                                  "/api/system/processes"])
def test_regular_user_is_denied_admin_areas(alice_client, path):
    response = alice_client.get(path, follow_redirects=False)
    assert response.status_code == 403, f"{path} -> {response.status_code}"


@pytest.mark.parametrize("payload", [
    {"name": "x", "owner_id": 1, "vcpu": 1, "memory_mb": 128, "disk_gb": 1},
    {},
])
def test_regular_user_cannot_create_instances(alice_client, payload):
    response = alice_client.post("/api/instances", json=payload)
    assert response.status_code in (403, 401), response.get_data(as_text=True)


def test_regular_user_cannot_delete_another_users_instance(alice_client, bob_instance):
    response = alice_client.delete(f"/api/instances/{bob_instance}")
    assert response.status_code == 403, response.get_data(as_text=True)


def test_regular_user_cannot_read_another_users_instance(alice_client, bob_instance):
    response = alice_client.get(f"/api/instances/{bob_instance}")
    assert response.status_code == 403, response.get_data(as_text=True)


def test_regular_user_listing_excludes_other_owners(alice_client):
    data = alice_client.get("/api/instances").get_json()
    names = [row["name"] for row in data["instances"]]
    assert "bob-box" not in names


def test_operator_can_read_infrastructure_but_not_manage_users(operator_client):
    assert operator_client.get("/admin/plans").status_code == 200
    assert operator_client.get("/admin/nodes").status_code == 200
    assert operator_client.get("/api/plans").status_code == 200
    assert operator_client.get("/admin/users", follow_redirects=False).status_code == 403
    assert operator_client.get("/api/users").status_code in (403, 401)


def test_operator_cannot_change_global_settings(operator_client):
    response = operator_client.post("/api/settings", json={"panel_name": "hacked"})
    assert response.status_code in (403, 401)


def test_operator_cannot_create_instances(operator_client):
    response = operator_client.post("/api/instances", json={"name": "x"})
    assert response.status_code in (403, 401)


# --------------------------------------------------------------- admin only
def test_admin_can_reach_the_capability_report(admin_client):
    response = admin_client.get("/admin/system")
    assert response.status_code == 200
    data = admin_client.get("/api/system/capabilities").get_json()
    assert data["ok"] is True
    assert "providers" in data
    if not data["can_provision"]:
        assert data["diagnostics"], "an unusable runtime must explain itself"


def test_regular_user_gets_404_for_a_foreign_instance_page(alice_client,
                                                           bob_instance):
    """The HTML view must not confirm that another user's instance exists."""
    assert alice_client.get(f"/vps/{bob_instance}",
                            follow_redirects=False).status_code == 404
    assert alice_client.get("/api/instances/" + bob_instance).status_code == 403


def test_admin_cannot_delete_the_last_admin(admin_client, admin):
    """An administrator must not be able to lock the panel out of itself."""
    with admin_client.application.app_context():
        me = User.query.filter_by(username=admin).first()
        me_id, me_name = me.id, me.username
        response = admin_client.delete(f"/api/users/{me_id}")
        body = response.get_data(as_text=True).lower()
        assert response.status_code == 409
        assert "cannot delete" in body
        still_there = User.query.filter_by(username=me_name).first()
        assert still_there is not None and still_there.is_admin


def test_admin_cannot_suspend_themselves(admin_client, admin):
    with admin_client.application.app_context():
        me = User.query.filter_by(username=admin).first()
        response = admin_client.patch(f"/api/users/{me.id}", json={"is_active": False})
    assert response.status_code == 409


# ---------------------------------------------------------------------- CSRF
def test_state_changing_request_without_csrf_is_refused(app):
    """CSRF protection is switched off globally for tests, so enable it here."""
    app.config["WTF_CSRF_ENABLED"] = True
    try:
        client = app.test_client()
        with app.app_context():
            from skvm.models import User

            User.query.filter_by(username="alice").first()
        client.post("/login", data={"username": "alice",
                                    "password": "alice-Passw0rd!"})
        response = client.post("/api/plans", json={"name": "csrf-should-fail"})
        assert response.status_code in (400, 401, 403)
    finally:
        app.config["WTF_CSRF_ENABLED"] = False


# ------------------------------------------------------------- bearer tokens
def test_token_scopes_are_enforced(app, admin_client, admin):
    """A read-only token may read but must not write."""
    created = admin_client.post("/api/tokens", json={"name": "pytest-readonly",
                                                     "scopes": ["read"],
                                                     "expires_days": 1})
    assert created.status_code in (200, 201), created.get_data(as_text=True)
    payload = created.get_json()
    raw = payload["secret"]                     # shown exactly once
    assert payload["token"]["prefix"]           # only a prefix is stored
    assert raw.startswith("skvm_")
    assert raw not in json.dumps(payload["token"])

    # A client that sends no cookie at all — token auth only.
    api = app.test_client()
    headers = {"Authorization": f"Bearer {raw}"}
    assert api.get("/api/instances", headers=headers).status_code == 200
    assert api.post("/api/instances", headers=headers,
                    json={"name": "must-not-provision"}).status_code == 403
    denied = api.post("/api/plans", headers=headers,
                      json={"name": "not-allowed", "vcpu": 1,
                            "memory_mb": 128, "disk_gb": 1})
    assert denied.status_code == 403, denied.get_data(as_text=True)
    assert "scope" in denied.get_data(as_text=True)

    # Ordinary write must not be widened into global/destructive admin powers.
    assert api.delete("/api/instances/not-a-real-instance", headers=headers).status_code == 403
    for path, payload in (
            ("/api/instances/not-a-real-instance/expiry", {"days": 7}),
            ("/api/instances/not-a-real-instance/transfer", {"owner_id": 1}),
            ("/api/instances/not-a-real-instance/actions", {"action": "delete"}),
            ("/api/tasks/not-a-real-task/cancel", {})):
        assert api.post(path, headers=headers, json=payload).status_code == 403
    assert api.delete("/api/console/sessions", headers=headers).status_code == 403
    # A token must not be widened into full access by a session cookie.
    cookie_client = admin_client
    still_denied = cookie_client.post("/api/plans", headers=headers,
                                      json={"name": "not-allowed-either",
                                            "vcpu": 1, "memory_mb": 128,
                                            "disk_gb": 1})
    assert still_denied.status_code == 403

    # Unknown or expired tokens are rejected outright, never downgraded.
    assert api.get("/api/instances",
                   headers={"Authorization": "Bearer skvm_deadbeef"}
                   ).status_code == 401
    assert app.test_client().get("/api/instances",
                                 headers={"Authorization": "Bearer skvm_" + "0" * 32}
                                 ).status_code == 401


def test_webhook_style_writes_require_authentication(client):
    assert client.post("/api/plans", json={"name": "nope"}).status_code == 401
    assert client.delete("/api/instances/whatever").status_code == 401
    assert client.post("/api/system/prune").status_code == 401




# ---------------------------------------------------------------- token scopes

def test_write_token_implies_read_but_cannot_manage_global_plans(app, admin_client):
    """write = per-instance actions; admin = global infrastructure changes."""
    created = admin_client.post("/api/tokens", json={"name": "pytest-write-scope",
                                                     "scopes": ["write"],
                                                     "expires_days": 1})
    assert created.status_code in (200, 201), created.get_data(as_text=True)
    token = created.get_json()["secret"]
    api = app.test_client()
    headers = {"Authorization": f"Bearer {token}"}
    assert api.get("/api/instances", headers=headers).status_code == 200
    assert api.post("/api/instances", headers=headers,
                    json={"name": "must-not-provision"}).status_code == 403
    denied = api.post("/api/plans", headers=headers,
                      json={"name": "not-a-global-write", "vcpu": 1})
    assert denied.status_code == 403, denied.get_data(as_text=True)
    assert "admin" in denied.get_json()["error"]
    # The missing record yields 404 only after scope enforcement has admitted
    # this user-scoped backup write.
    assert api.delete("/api/backups/no-such-audit-backup",
                      headers=headers).status_code == 404
    assert api.post("/api/instances/not-a-real-instance/actions",
                    headers=headers, json={"action": "start"}).status_code == 404
    assert api.post("/api/instances/not-a-real-instance/actions",
                    headers=headers, json={"action": "delete"}).status_code == 403


def test_admin_token_can_manage_plans_without_a_csrf_header(app, admin_client):
    created = admin_client.post("/api/tokens", json={"name": "pytest-admin-scope",
                                                     "scopes": ["admin"],
                                                     "expires_days": 1})
    assert created.status_code in (200, 201), created.get_data(as_text=True)
    token = created.get_json()["secret"]
    api = app.test_client()
    headers = {"Authorization": f"Bearer {token}"}
    response = api.post("/api/plans", headers=headers,
                        json={"name": "Token Plan", "slug": "token-plan",
                              "vcpu": 1, "memory_mb": 256, "disk_gb": 1})
    assert response.status_code == 201, response.get_data(as_text=True)
    plan_id = response.get_json()["plan"]["id"]
    assert api.delete(f"/api/plans/{plan_id}", headers=headers).status_code == 200


def test_bearer_requests_skip_csrf_but_cookie_writes_do_not(app, admin_client, admin):
    """CSRF protects ambient cookies, not explicit Authorization credentials."""
    from skvm.extensions import db
    from skvm.security import create_api_token

    old_enabled = app.config.get("WTF_CSRF_ENABLED")
    app.config["WTF_CSRF_ENABLED"] = True
    try:
        with app.app_context():
            user = User.query.filter_by(username=admin).first()
            raw, token = create_api_token(user, "pytest-csrf-admin", ["admin"], 1)
            token_id = token.id

        bearer = app.test_client()
        response = bearer.post(
            "/api/plans", headers={"Authorization": f"Bearer {raw}"},
            json={"name": "CSRF Bearer Plan", "slug": "csrf-bearer-plan",
                  "vcpu": 1, "memory_mb": 256, "disk_gb": 1})
        assert response.status_code == 201, response.get_data(as_text=True)
        plan_id = response.get_json()["plan"]["id"]
        bearer.delete(f"/api/plans/{plan_id}",
                      headers={"Authorization": f"Bearer {raw}"})

        # The existing browser client is cookie-authenticated and intentionally
        # sends no X-CSRFToken here; it must not be allowed to perform a write.
        session_response = admin_client.post(
            "/api/plans", json={"name": "CSRF Session Plan", "vcpu": 1})
        assert session_response.status_code == 400
        assert "CSRF" in session_response.get_data(as_text=True)
        with app.app_context():
            row = db.session.get(__import__("skvm.models", fromlist=["ApiToken"]).ApiToken,
                                 token_id)
            row.revoked = True
            db.session.commit()
    finally:
        app.config["WTF_CSRF_ENABLED"] = old_enabled


def test_deleting_image_removes_its_real_cache_directory(admin_client, app):
    """The Delete image control must remove cached layers, not just its DB row."""
    import secrets
    from pathlib import Path

    slug = f"pytest-cache-{secrets.token_hex(3)}"
    created = admin_client.post("/api/images", json={
        "name": "Cache delete test", "reference": "library/alpine:3.20",
        "slug": slug, "version": "3.20"})
    assert created.status_code == 201, created.get_data(as_text=True)
    image_id = created.get_json()["image"]["id"]
    cache = Path(app.config["IMAGES_DIR"]) / slug
    cache.mkdir(parents=True)
    marker = cache / "real-layer-marker"
    marker.write_bytes(b"real cache bytes")
    deleted = admin_client.delete(f"/api/images/{image_id}")
    assert deleted.status_code == 200, deleted.get_data(as_text=True)
    assert deleted.get_json()["cache_removed"] is True
    assert not cache.exists()
