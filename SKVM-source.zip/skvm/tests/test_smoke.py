"""
Smoke tests: every HTML page must render with real data, not a stack trace.

These tests run the *real* application (no mocks) against a temporary data
directory, so a broken template, a missing context variable or a bad blueprint
fails here rather than in the browser.
"""
from __future__ import annotations

import pytest


PAGES = [
    "/",
    "/vps/",
    "/admin/vps",
    "/admin/vps/create",
    "/admin/expiring",
    "/admin/users",
    "/admin/plans",
    "/admin/nodes",
    "/admin/images",
    "/admin/settings",
    "/admin/system",
    "/admin/logs",
    "/admin/backups",
    "/admin/maintenance",
    "/admin/api-management",
    "/profile/",
    "/profile/security",
]


@pytest.mark.parametrize("path", PAGES)
def test_pages_render(admin_client, path):
    response = admin_client.get(path)
    assert response.status_code in (200, 302), f"{path} -> {response.status_code}"
    if response.status_code != 200:
        return
    body = response.get_data(as_text=True)
    # A rendered page must never contain a raw exception.  The log viewer is
    # exempt: it displays real log lines, and those lines may quote a traceback.
    if path != "/admin/logs":
        assert "jinja2.exceptions" not in body
        assert "UndefinedError" not in body
        assert "werkzeug.routing" not in body


def test_health_endpoint(admin_client):
    response = admin_client.get("/healthz")
    assert response.status_code == 200
    data = response.get_json()
    assert data["ok"] is True
    assert data["database"]["ok"] is True


def test_api_index_lists_endpoints(admin_client):
    data = admin_client.get("/api/").get_json()
    assert data["ok"] is True
    assert any(r["path"] == "/api/instances" for r in data["endpoints"])


ANON_PAGES = ["/login", "/setup", "/register", "/logout"]

# /register answers 403 while self-registration is disabled (the secure default)
ANON_ALLOWED = {"login": (200,), "setup": (200, 302), "register": (200, 403),
                "logout": (200, 302)}


@pytest.mark.parametrize("path", ANON_PAGES)
def test_anonymous_pages_render(client, path):
    """The sign-in flow templates must compile and render (no session needed)."""
    response = client.get(path, follow_redirects=False)
    expected = ANON_ALLOWED[path.strip("/")]
    assert response.status_code in expected, f"{path} -> {response.status_code}"
    if response.status_code == 200:
        body = response.get_data(as_text=True)
        assert "jinja2.exceptions" not in body


def test_login_page_shows_the_form(client):
    body = client.get("/login").get_data(as_text=True)
    assert "name=\"username\"" in body and "name=\"password\"" in body


def test_anonymous_is_redirected(client):
    response = client.get("/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


def test_capabilities_are_honest(admin_client):
    data = admin_client.get("/api/system/capabilities").get_json()
    assert data["ok"] is True
    providers = {p["name"]: p for p in data["providers"]}
    # The runtime probe ran, so every provider carries a verdict and a reason.
    for name in ("docker", "lxc", "namespace"):
        assert name in providers
        assert "available" in providers[name]
    if not data["can_provision"]:
        assert data["diagnostics"], "unavailable runtime must explain itself"
