"""
End-to-end provisioning test — a real container, a real image pull.

It is skipped automatically when the host cannot provision (no usable
runtime), and it is opt-in for slow CI: set ``SKVM_E2E=1`` to always run it.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest


def _runtime(app):
    with app.app_context():
        manager = app.extensions["skvm_manager"]
        provider, diagnostics = manager.provider()
        return manager, provider, diagnostics


@pytest.fixture(scope="module")
def provisioner(e2e_app):
    manager, provider, diagnostics = _runtime(e2e_app)
    if provider is None:
        pytest.skip("no provisioning runtime available: "
                    + "; ".join(f"{d['name']}: {d.get('reason', '')}"
                                for d in diagnostics))
    return manager, provider


@pytest.fixture()
def owner_client(e2e_app, e2e_admin_client):
    """An admin client plus its user row."""
    with e2e_app.app_context():
        from skvm.models import User

        user = User.query.filter_by(username="e2e-admin").first()
        return e2e_admin_client, user


def test_image_pull_and_instance_lifecycle(e2e_app, owner_client, provisioner):
    app = e2e_app
    client, user = owner_client

    # 1. Create an image row pointing at a small real image.
    response = client.post("/api/images", json={
        "name": "Alpine (E2E)", "reference": "alpine:3.20",
        "slug": "alpine-3.20", "description": "test image",
    })
    assert response.status_code in (200, 201), response.get_data(as_text=True)
    image_id = response.get_json()["image"]["id"]

    # 2. Pull it for real (OCI registry v2) and follow the task to completion.
    pull = client.post(f"/api/images/{image_id}/pull")
    assert pull.status_code in (200, 202), pull.get_data(as_text=True)
    task_id = pull.get_json()["task"]["task_id"]
    status, task = _wait_task(client, task_id, timeout=900)
    print("image pull:", status, task.get("message") or task.get("error"))
    assert status == "success", task.get("error") or task.get("logs")

    # 3. Provision an instance and start it.
    create = client.post("/api/instances", json={
        "name": "e2e-web", "owner_id": user.id, "image_id": image_id,
        "vcpu": 1, "memory_mb": 256, "disk_gb": 2,
    })
    assert create.status_code in (200, 201, 202), create.get_data(as_text=True)
    body = create.get_json()
    instance_id = body["instance"]["instance_id"]
    status, task = _wait_task(client, body["task"]["task_id"], timeout=900)
    print("provision:", status, task.get("message") or task.get("error"))
    assert status == "success", task.get("error") or task.get("logs")

    detail = client.get(f"/api/instances/{instance_id}").get_json()["instance"]
    assert detail["status"] == "running", detail
    assert detail["is_virtual_machine"] is False, \
        "a namespace container must never be reported as a VM"
    assert detail["network"]["internal_ip"], "the container should own a real IP"

    # 4. Metrics must be real (a source list, and a numeric memory figure).
    metrics = client.get(f"/api/instances/{instance_id}/metrics").get_json()["metrics"]
    assert metrics["available"] is True, metrics
    assert metrics["source"], "metrics must name their source"

    # 5. The console must resolve to a real exec argv inside the container.
    with app.app_context():
        from skvm.models import VPS

        vps = VPS.query.filter_by(instance_id=instance_id).first()
        argv = app.extensions["skvm_manager"].provider_for(vps).console_argv(vps)
    assert argv, "console_argv must return a real command line"
    with app.app_context():
        provider = app.extensions["skvm_manager"].provider_for(vps)
        shell = argv[-2]
        assert shell in ("/bin/bash", "/usr/bin/bash", "/bin/sh", "/bin/ash", "/usr/bin/ash")
        assert (provider._rootfs(vps) / shell.lstrip("/")).exists(), (
            f"console shell {shell} is not present in the instance rootfs")

    # 6. File operations run inside the instance.
    listing = client.get(f"/api/instances/{instance_id}/files?path=/")
    assert listing.status_code == 200, listing.get_data(as_text=True)
    assert listing.get_json()["entries"], "root filesystem listing must not be empty"

    # A root-level New folder / Upload must preserve the leading slash. A bug
    # stripped it, returned success for a relative `audit-root` directory, and
    # made subsequent writes to `/audit-root/...` fail with ENOENT.
    root_mkdir = client.post(
        f"/api/instances/{instance_id}/files/mkdir",
        json={"path": "/", "name": "audit-root"})
    assert root_mkdir.status_code == 200, root_mkdir.get_data(as_text=True)
    assert root_mkdir.get_json()["path"] == "/audit-root"
    root_write = client.put(
        f"/api/instances/{instance_id}/files/content",
        json={"path": "/audit-root/note.txt", "content": "real root path\n"})
    assert root_write.status_code == 200, root_write.get_data(as_text=True)
    root_read = client.get(
        f"/api/instances/{instance_id}/files/content?path=/audit-root/note.txt")
    assert root_read.status_code == 200, root_read.get_data(as_text=True)
    assert "real root path" in root_read.get_json()["content"]

    # Minimal Alpine uses BusyBox applets at /bin rather than GNU utilities in
    # /usr/bin. Stat/read, chmod, search, and du must still work honestly.
    stat = client.get(
        f"/api/instances/{instance_id}/files/stat?path=/audit-root/note.txt")
    assert stat.status_code == 200, stat.get_data(as_text=True)
    chmod = client.post(
        f"/api/instances/{instance_id}/files/chmod",
        json={"path": "/audit-root/note.txt", "mode": "0640"})
    assert chmod.status_code == 200, chmod.get_data(as_text=True)
    stat = client.get(
        f"/api/instances/{instance_id}/files/stat?path=/audit-root/note.txt")
    assert stat.get_json()["file"]["mode"] in ("640", "0640")

    copied = client.post(
        f"/api/instances/{instance_id}/files/copy",
        json={"path": "/audit-root/note.txt", "destination": "/audit-root/copy.txt"})
    assert copied.status_code == 200, copied.get_data(as_text=True)
    moved = client.post(
        f"/api/instances/{instance_id}/files/move",
        json={"path": "/audit-root/copy.txt", "destination": "/audit-root/moved.txt"})
    assert moved.status_code == 200, moved.get_data(as_text=True)
    search = client.get(
        f"/api/instances/{instance_id}/files/search?path=/audit-root&q=moved")
    assert search.status_code == 200, search.get_data(as_text=True)
    assert any(item["path"] == "/audit-root/moved.txt"
               for item in search.get_json()["results"])
    usage = client.get(
        f"/api/instances/{instance_id}/files/usage?path=/audit-root")
    assert usage.status_code == 200, usage.get_data(as_text=True)
    assert usage.get_json()["usage"]["bytes"] > 0

    # Root upload must be absolute on minimal images too.
    from io import BytesIO
    upload = client.post(
        f"/api/instances/{instance_id}/files/upload",
        data={"path": "/", "file": (BytesIO(b"uploaded in Alpine\n"), "audit-root-upload.txt")},
        content_type="multipart/form-data")
    assert upload.status_code == 200, upload.get_data(as_text=True)
    downloaded = client.get(
        f"/api/instances/{instance_id}/files/content?path=/audit-root-upload.txt&download=1")
    assert downloaded.status_code == 200
    assert downloaded.data == b"uploaded in Alpine\n"
    client.delete(f"/api/instances/{instance_id}/files?path=/audit-root-upload.txt")
    root_delete = client.delete(
        f"/api/instances/{instance_id}/files?path=/audit-root")
    assert root_delete.status_code == 200, root_delete.get_data(as_text=True)

    # 7. Page render with a live instance.
    for path in (f"/vps/{instance_id}", f"/vps/{instance_id}/usage",
                 f"/vps/{instance_id}/files", f"/vps/{instance_id}/ssh"):
        page = client.get(path)
        assert page.status_code == 200, f"{path} -> {page.status_code}"

    # 8. Stop it, verify the state is real, then delete it.
    action = client.post(f"/api/instances/{instance_id}/actions", json={"action": "stop"})
    assert action.status_code in (200, 202), action.get_data(as_text=True)
    status, task = _wait_task(client, action.get_json()["task"]["task_id"], timeout=300)
    assert status == "success", task.get("error")
    detail = client.get(f"/api/instances/{instance_id}").get_json()["instance"]
    assert detail["status"] == "stopped", detail

    delete = client.delete(f"/api/instances/{instance_id}")
    assert delete.status_code in (200, 202), delete.get_data(as_text=True)
    status, task = _wait_task(client, delete.get_json()["task"]["task_id"], timeout=300)
    assert status == "success", task.get("error")


def _wait_task(client, task_id: str, timeout: int = 600):
    deadline = time.time() + timeout
    last = {}
    while time.time() < deadline:
        response = client.get(f"/api/tasks/{task_id}")
        assert response.status_code == 200, response.get_data(as_text=True)
        last = response.get_json()["task"]
        if last["status"] in ("success", "failed", "cancelled", "interrupted"):
            return last["status"], last
        time.sleep(1.0)
    pytest.fail(f"task {task_id} did not finish within {timeout}s: {last}")


def test_retry_after_a_failure_cleans_up_before_recreating(e2e_app, owner_client,
                                                          provisioner):
    """
    Regression: a retried provision used to re-extract the OCI layers into a
    root filesystem that the previous attempt was still running from, which
    fails with ETXTBSY ("Text file busy: .../rootfs/bin/busybox") on every
    retry.

    The manager now destroys the failed attempt first, so creating the same
    instance again must succeed even while the first container is running.
    """
    app = e2e_app
    manager, provider = provisioner
    client, user = owner_client
    from skvm.extensions import db
    from skvm.models import OSImage, VPS, VPSStatus

    with app.app_context():
        image = OSImage.query.filter_by(slug="alpine-3.20").first()
        if image is None:
            pytest.skip("the alpine image is not in this catalogue")

        existing = VPS.query.filter_by(name="e2e-retry").first()
        if existing is not None:
            db.session.delete(existing)
            db.session.commit()

        vps = VPS(instance_id="sk0e2e2retry0001", name="e2e-retry",
                  hostname="e2e-retry", owner_id=user.id, image_id=image.id,
                  status=VPSStatus.PROVISIONING, vcpu=1, memory_mb=256,
                  disk_gb=1, provider=provider.name, kind=provider.kind,
                  os_name=image.name, os_version=image.version)
        db.session.add(vps)
        db.session.commit()

        # The same payload shape the create API hands to the task runner.
        spec = manager._spec_from_payload({
            "image_id": image.id, "vcpu": 1, "memory_mb": 256, "disk_gb": 1,
            "init_command": "/bin/sh -c 'while :; do sleep 3600; done'",
            "want_networking": True, "want_ssh": False,
        }, vps)

        notes: list[str] = []
        record = lambda message, percent=None: notes.append(str(message))  # noqa: E731
        provider.create(vps, spec, record)
        assert provider.inspect(vps).status == "running", notes

        # The container is running now — exactly the state a retry used to
        # walk into. Clean up the failed attempt, then create again.
        manager._cleanup_failed_attempt(provider, vps, record, task=None)
        assert not Path(provider.instance_dir(vps)).exists(), \
            "the failed attempt's rootfs was not removed"

        notes.clear()
        provider.create(vps, spec, record)
        assert provider.inspect(vps).status == "running", notes

        provider.destroy(vps, record)
        db.session.delete(vps)
        db.session.commit()
