"""
Regressions for bugs found while auditing the running panel.

Each test here exists because something was actually broken — the point is that
it cannot silently break again.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

import pytest

PROJECT = Path(__file__).resolve().parent.parent


# --------------------------------------------------------------------- registry
def test_registry_probe_accepts_the_anonymous_bearer_challenge():
    """
    Docker Registry v2 answers an anonymous `GET /v2/` with 401 + a Bearer
    challenge *by design*. Treating that as an outage made the panel refuse to
    provision any image that was not already cached, while `docker pull`-style
    pulls worked fine. The probe must complete the token round-trip instead.
    """
    from skvm.provisioning.detect import detect_egress

    cap = detect_egress()
    if not cap.available:
        pytest.skip(f"registry not reachable from here: {cap.reason}")
    assert cap.available is True
    assert "token" in (cap.detail or "").lower()
    assert "401" not in (cap.detail or "")


def test_registry_probe_explains_a_real_failure():
    """A probe that fails must carry a reason and a remedy, never a bare False."""
    from skvm.provisioning.detect import Capability, _cap

    cap = _cap("registry", "Container registry reachable", False,
               reason="NameResolutionError: no DNS", remedy="fix DNS")
    assert isinstance(cap, Capability)
    assert cap.available is False and cap.reason and cap.remedy


# ------------------------------------------------------------------ token scope
def test_bearer_token_scope_is_derived_from_method_and_path():
    from skvm.security import required_token_scope

    assert required_token_scope("GET", "/api/instances") == "read"
    assert required_token_scope("POST", "/api/instances") == "provision"
    assert required_token_scope("POST", "/api/instances/x/actions") == "write"
    assert required_token_scope("DELETE", "/api/instances/x") == "admin"
    assert required_token_scope("POST", "/api/instances/x/expiry") == "admin"
    assert required_token_scope("POST", "/api/instances/x/transfer") == "admin"
    assert required_token_scope("POST", "/api/instances/x/backups/b/verify") == "write"
    assert required_token_scope("DELETE", "/api/backups/b") == "write"
    assert required_token_scope("POST", "/api/tasks/t/cancel") == "admin"
    assert required_token_scope("DELETE", "/api/console/sessions") == "admin"
    assert required_token_scope("POST", "/api/instances") == "provision"
    assert required_token_scope("POST", "/api/plans") == "admin"
    assert required_token_scope("POST", "/api/images") == "admin"
    assert required_token_scope("POST", "/api/users") == "admin"
    assert required_token_scope("POST", "/api/me/password") == "write"


def test_task_endpoint_accepts_public_id_and_primary_key(admin_client):
    """
    `/api/tasks/<task_id>` keys on the public task id, but a caller that kept
    the numeric `id` from a create/list response used to get a bare 404.
    """
    listing = admin_client.get("/api/tasks").get_json()
    tasks = listing.get("tasks") or []
    if not tasks:
        pytest.skip("no tasks recorded yet")
    task = tasks[0]
    assert admin_client.get(f"/api/tasks/{task['task_id']}").status_code == 200
    by_pk = admin_client.get(f"/api/tasks/{task['id']}")
    assert by_pk.status_code == 200, by_pk.get_data(as_text=True)
    assert by_pk.get_json()["task"]["task_id"] == task["task_id"]


# --------------------------------------------------------------------- installer
@pytest.mark.parametrize("port", ["5555", "5556", "8080"])
def test_installer_url_matches_the_port_the_panel_uses(port):
    """
    `panel_url` used to ignore its argument and read a variable that never
    existed, so a panel bumped to another port printed a URL for 5555 — a link
    that does not answer.
    """
    script = PROJECT / "install.sh"
    body = script.read_text()
    start = body.index("panel_url() {")
    end = body.index("# ------", start)
    snippet = body[start:end]
    out = subprocess.run(
        ["bash", "-c",
         f'{snippet}\nPY={PROJECT}/.venv/bin/python\npanel_url {port}'],
        capture_output=True, text=True, cwd=str(PROJECT), timeout=60)
    if out.returncode != 0 and "No such file" in out.stderr:
        pytest.skip(f"installer needs a python interpreter: {out.stderr.strip()[:80]}")
    assert out.returncode == 0, out.stderr
    url = out.stdout.strip()
    # Two supported shapes:  http://<ip>:5556   and  https://5556-<id>.e2b.app
    assert re.search(rf"(?<!\d){port}(?!\d)", url), (
        f"{url!r} does not contain the port the panel listens on")


def test_installer_defines_every_function_the_dispatch_uses():
    """
    A slice-based edit once deleted three helper functions (health_check,
    status_panel, stop_panel) without any syntax error — the installer still
    parsed and then failed at runtime with "command not found".
    """
    body = (PROJECT / "install.sh").read_text()
    defined = set(re.findall(r"^([a-z_]+)\(\) \{", body, flags=re.M))
    dispatch = body[body.index('case "$ACTION" in'):body.index("esac", body.index('case "$ACTION" in'))]
    used = set(re.findall(r"([a-z_]{4,})", dispatch)) - {"case", "exit", "stop",
                                                         "logs", "status",
                                                         "restart"}
    missing = sorted(used - defined)
    assert not missing, f"install.sh dispatch calls undefined functions: {missing}"
    # And the launch path itself must still work end to end.
    syntax = subprocess.run(["bash", "-n", str(PROJECT / "install.sh")],
                            capture_output=True, text=True, timeout=30)
    assert syntax.returncode == 0, syntax.stderr


def test_installer_status_command_actually_runs():
    """
    The early dispatch (`--status`, `--stop`) ran before some helpers were
    defined, so `read_env: command not found` was printed instead of a status.
    """
    out = subprocess.run(["bash", "install.sh", "--status"],
                         capture_output=True, text=True, cwd=str(PROJECT),
                         timeout=120)
    combined = out.stdout + out.stderr
    assert "command not found" not in combined, combined[-400:]
    assert out.returncode in (0, 1), out.returncode
    assert ("health check passed" in combined
            or "did not answer" in combined
            or "no pid file" in combined), combined[-400:]


# ------------------------------------------------------------------ orphan sweep
def test_orphan_cleanup_reports_what_it_swept(app):
    """An interrupted provision must not leak a netns/veth forever."""
    with app.app_context():
        report = app.extensions["skvm_manager"].cleanup_orphans()
    assert {"checked", "killed", "swept"} <= set(report)
    assert isinstance(report["swept"], list)


def test_image_catalogue_reconciles_with_disk(app):
    """
    Status must follow the filesystem: a cached image is `ready`, and a row can
    never claim `ready` once its layers are gone.
    """
    with app.app_context():
        from skvm.extensions import db
        from skvm.models import OSImage
        from skvm.provisioning.providers.namespace import NamespaceProvider

        manager = app.extensions["skvm_manager"]
        provider, name = manager.provider()
        report = manager.reconcile_image_cache()
        assert report["ok"] is True, report
        if not isinstance(provider, NamespaceProvider):
            pytest.skip(f"active provider {name} has no on-disk image cache")
        for image in OSImage.query.all():
            ready = provider.image_ready(image.slug)
            assert (image.status == "ready") == ready, image.slug
            if ready:
                assert image.size_bytes > 0
                assert "verified on disk" in (image.status_detail or "")
            else:
                assert image.size_bytes == 0
        db.session.commit()


def test_root_file_operations_keep_the_absolute_root(monkeypatch):
    """New folder and upload must not turn `/name` into a cwd-relative path."""
    from skvm.services.filesystem import ExecResult, InstanceFiles

    files = InstanceFiles(provider=object(), instance=object())
    commands = []

    def fake_exec(command, **kwargs):
        commands.append(command)
        return ExecResult(0, b"", "")

    monkeypatch.setattr(files, "exec", fake_exec)
    made = files.make_dir("/", "audit-dir")
    assert made["path"] == "/audit-dir"
    assert commands[0][-1] == "/audit-dir"

    uploaded = files.upload("/", "audit-root.txt", b"real data")
    assert uploaded["path"] == "/audit-root.txt"
    assert commands[-2] == ["/bin/mkdir", "-p", "--", "/"]
    assert commands[-1][-1] == "/audit-root.txt"


def test_plan_and_node_counts_exclude_deleted_archived_instances(app, admin):
    """The displayed count must be the same live count used by delete guards."""
    import secrets

    from skvm.extensions import db
    from skvm.models import Node, Plan, VPS, VPSStatus, User

    suffix = secrets.token_hex(4)
    with app.app_context():
        owner = User.query.filter_by(username=admin).first()
        plan = Plan(name=f"Count Plan {suffix}", slug=f"count-plan-{suffix}",
                    vcpu=1, memory_mb=256, disk_gb=1)
        node = Node(name=f"Count Node {suffix}", address="127.0.0.1")
        db.session.add_all([plan, node])
        db.session.flush()
        live = VPS(instance_id=f"sk{suffix}live", name=f"count-live-{suffix}",
                   hostname=f"count-live-{suffix}", owner_id=owner.id,
                   plan_id=plan.id, node_id=node.id, status=VPSStatus.RUNNING,
                   vcpu=1, memory_mb=256, disk_gb=1)
        deleted = VPS(instance_id=f"sk{suffix}dead", name=f"count-dead-{suffix}",
                      hostname=f"count-dead-{suffix}", owner_id=owner.id,
                      plan_id=plan.id, node_id=node.id, status=VPSStatus.DELETED,
                      vcpu=1, memory_mb=256, disk_gb=1)
        db.session.add_all([live, deleted])
        db.session.commit()
        assert plan.to_dict()["instances"] == 1
        assert node.to_dict()["instances"] == 1
        db.session.delete(live)
        db.session.delete(deleted)
        db.session.delete(plan)
        db.session.delete(node)
        db.session.commit()


def test_image_catalogue_rejects_path_traversal_slugs(admin_client):
    response = admin_client.post("/api/images", json={
        "name": "Unsafe", "reference": "library/alpine:3.20",
        "version": "3.20", "slug": "../outside"})
    assert response.status_code == 400
    assert "slug" in response.get_json()["error"].lower()


def test_maintenance_banner_message_can_be_cleared(admin_client):
    """Blanking the maintenance text in the form must really clear it."""
    original = admin_client.get("/api/system/maintenance").get_json()["maintenance"]
    enabled = admin_client.post("/api/system/maintenance", json={
        "enabled": True, "allow_admins": True, "message": "temporary test banner"})
    assert enabled.status_code == 200
    assert enabled.get_json()["maintenance"]["message"] == "temporary test banner"
    cleared = admin_client.post("/api/system/maintenance", json={
        "enabled": bool(original.get("enabled")),
        "allow_admins": bool(original.get("allow_admins", True)),
        "message": ""})
    assert cleared.status_code == 200
    assert cleared.get_json()["maintenance"]["message"] == ""
    restored = admin_client.post("/api/system/maintenance", json={
        "enabled": bool(original.get("enabled")),
        "allow_admins": bool(original.get("allow_admins", True)),
        "message": original.get("message", "")})
    assert restored.status_code == 200
    assert restored.get_json()["maintenance"]["message"] == original.get("message", "")
