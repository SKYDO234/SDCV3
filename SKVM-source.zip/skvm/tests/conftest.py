"""Shared pytest fixtures — every test runs against a throwaway data directory."""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

import pytest

os.environ.setdefault("SKVM_ENV", "testing")
os.environ.setdefault("SKVM_ALLOW_SUDO", "0")


@pytest.fixture(scope="session")
def data_dir():
    path = Path(tempfile.mkdtemp(prefix="skvm-test-"))
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture(scope="session")
def app(data_dir):
    from skvm.app import create_app
    from skvm.config import Config

    class TestConfig(Config):
        TESTING = True
        SKVM_START_MONITOR = False
        WTF_CSRF_ENABLED = False
        RATELIMIT_ENABLED = False
        SECRET_KEY = "test-secret-key-not-for-production"
        DATA_DIR = data_dir
        DB_PATH = data_dir / "test.db"
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{data_dir / 'test.db'}"
        INSTANCES_DIR = data_dir / "instances"
        IMAGES_DIR = data_dir / "images"
        BACKUP_DIR = data_dir / "backups"
        LOG_DIR = data_dir / "logs"
        RUN_DIR = data_dir / "run"
        TMP_DIR = data_dir / "tmp"
        SETUP_TOKEN = "test-setup-token"

        @classmethod
        def ensure_dirs(cls):  # noqa: D102 - real directories for the test run
            for path in (cls.DATA_DIR, cls.INSTANCES_DIR, cls.IMAGES_DIR,
                         cls.BACKUP_DIR, cls.LOG_DIR, cls.RUN_DIR, cls.TMP_DIR,
                         cls.DB_PATH.parent):
                Path(path).mkdir(parents=True, exist_ok=True)

    application = create_app(TestConfig)
    application.config["WTF_CSRF_ENABLED"] = False
    yield application


@pytest.fixture(scope="session")
def admin(app):
    with app.app_context():
        from skvm.models import Role, User
        from skvm.services.bootstrap import create_admin

        existing = User.query.filter_by(username="admin").first()
        if existing is None:
            user = create_admin("admin", "admin@example.test", "TestAdmin-Passw0rd!")
        else:
            user = existing
        user.must_change_password = False
        user.role = Role.ADMIN
        from skvm.extensions import db

        db.session.commit()
        return user.username


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def admin_client(app, client, admin):
    response = client.post("/login", data={"username": admin,
                                           "password": "TestAdmin-Passw0rd!"},
                           follow_redirects=True)
    assert response.status_code in (200, 302)
    return client


# ---------------------------------------------------------------------------
# End-to-end fixtures
#
# Real provisioning runs through helpers/skvm-helper, which only accepts paths
# under <project>/data or /tmp/skvm.  The end-to-end test therefore uses a data
# directory inside /tmp/skvm so it exercises the production code path (the
# helper's allowlist included) without touching the real data directory.
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def e2e_data_dir():
    base = Path("/tmp/skvm")
    import uuid

    path = base / f"e2e-{uuid.uuid4().hex[:8]}"
    path.mkdir(parents=True, exist_ok=True)
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture(scope="session")
def e2e_app(e2e_data_dir):
    from skvm.app import create_app
    from skvm.config import Config

    class E2EConfig(Config):
        TESTING = True
        SKVM_START_MONITOR = False
        WTF_CSRF_ENABLED = False
        RATELIMIT_ENABLED = False
        SECRET_KEY = "e2e-secret"
        DATA_DIR = e2e_data_dir
        DB_PATH = e2e_data_dir / "e2e.db"
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{e2e_data_dir / 'e2e.db'}"
        INSTANCES_DIR = e2e_data_dir / "instances"
        IMAGES_DIR = e2e_data_dir / "images"
        BACKUP_DIR = e2e_data_dir / "backups"
        LOG_DIR = e2e_data_dir / "logs"
        RUN_DIR = e2e_data_dir / "run"
        TMP_DIR = e2e_data_dir / "tmp"

        @classmethod
        def ensure_dirs(cls):
            for path in (cls.DATA_DIR, cls.INSTANCES_DIR, cls.IMAGES_DIR,
                         cls.BACKUP_DIR, cls.LOG_DIR, cls.RUN_DIR, cls.TMP_DIR,
                         cls.DB_PATH.parent):
                Path(path).mkdir(parents=True, exist_ok=True)

    return create_app(E2EConfig)


@pytest.fixture(scope="session")
def e2e_admin_client(e2e_app):
    from skvm.models import Role, User
    from skvm.services.bootstrap import create_admin

    with e2e_app.app_context():
        user = User.query.filter_by(username="e2e-admin").first()
        if user is None:
            user = create_admin("e2e-admin", "e2e@example.test", "E2E-Admin-Passw0rd!")
        user.must_change_password = False
        user.role = Role.ADMIN
        from skvm.extensions import db

        db.session.commit()

    client = e2e_app.test_client()
    response = client.post("/login", data={"username": "e2e-admin",
                                           "password": "E2E-Admin-Passw0rd!"},
                           follow_redirects=True)
    assert response.status_code in (200, 302)
    return client
