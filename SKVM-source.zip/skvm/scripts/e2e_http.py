#!/usr/bin/env python3
"""
End-to-end check against the *running* panel over HTTP.

This is the strongest test in the project: it signs in as the real
administrator, asks the panel to create a real container, waits for the
provisioning task by polling the panel's own task API, then verifies the
instance through the panel's own endpoints (state, metrics, files, console
session), stops it, and deletes it.

Nothing is stubbed — the instance it inspects is a real namespace container
with a real PID, managed by the panel the user is looking at.

    .venv/bin/python scripts/e2e_http.py --password '…'
    .venv/bin/python scripts/e2e_http.py --username admin --password '…' --keep
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

import requests

CSRF_RE = re.compile(r'name="csrf_token"[^>]*value="([^"]+)"')
META_RE = re.compile(r'name="csrf-token" content="([^"]+)"')


class Panel:
    def __init__(self, base: str, username: str, password: str):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        self.username = username
        self.password = password
        self.step = 0

    def say(self, text: str, ok: bool | None = None) -> None:
        self.step += 1
        mark = "   " if ok is None else ("[ok]" if ok else "[!!]")
        print(f"  {mark} {text}", flush=True)

    def csrf(self, html: str = "") -> str:
        for response in (None,):
            pass
        if not html:
            html = self.s.get(f"{self.base}/profile/").text
        for pattern in (CSRF_RE, META_RE):
            match = pattern.search(html)
            if match:
                return match.group(1)
        raise SystemExit("no CSRF token found — is the panel really running?")

    def login(self) -> None:
        html = self.s.get(f"{self.base}/login", allow_redirects=False)
        if html.status_code in (301, 302) and "/setup" in html.headers.get("Location", ""):
            raise SystemExit("panel has no administrator yet — run setup first")
        token = self.csrf(html.text)
        response = self.s.post(f"{self.base}/login",
                               data={"username": self.username,
                                     "password": self.password,
                                     "csrf_token": token},
                               allow_redirects=False)
        if response.status_code not in (302, 303):
            raise SystemExit(f"sign-in failed: {response.status_code} "
                             f"{response.text[:200]}")
        me = self.s.get(f"{self.base}/api/me").json()
        if not me.get("ok"):
            raise SystemExit(f"not authenticated after login: {me}")
        self.role = me["user"]["role"]
        self.say(f"signed in as {me['user']['username']} ({self.role}), "
                 f"permissions: {json.dumps(me['permissions'])}")

    def api(self, method: str, path: str, **kwargs):
        headers = kwargs.pop("headers", {})
        headers["X-CSRFToken"] = self.csrf()
        headers["X-Requested-With"] = "XMLHttpRequest"
        response = self.s.request(method, f"{self.base}{path}", headers=headers,
                                  **kwargs)
        try:
            return response.status_code, response.json()
        except ValueError:
            return response.status_code, {"raw": response.text[:400]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://127.0.0.1:5555")
    parser.add_argument("--username", default="admin")
    parser.add_argument("--password", default="")
    parser.add_argument("--keep", action="store_true",
                        help="keep the instance instead of deleting it")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--image", default="",
                        help="image slug to provision (default: first cached)")
    args = parser.parse_args()

    password = args.password or ""
    if not password:
        env = Path(".env")
        if env.exists():
            for line in env.read_text().splitlines():
                if line.startswith("SKVM_ADMIN_PASSWORD="):
                    password = line.split("=", 1)[1].strip().strip('"')
    if not password:
        print("need --password (or SKVM_ADMIN_PASSWORD in .env)", file=sys.stderr)
        return 2

    panel = Panel(args.url, args.username, password)
    failures: list[str] = []

    print("\n== 1. authentication")
    try:
        panel.login()
    except SystemExit as exc:
        print(f"  [!!] {exc}")
        return 1

    print("\n== 2. capability report (what this host can really do)")
    code, caps = panel.api("GET", "/api/system/capabilities")
    panel.say(f"GET /api/system/capabilities -> {code}", code == 200)
    providers = caps.get("providers") or caps.get("provider_list") or []
    if isinstance(providers, dict):                 # tolerate either shape
        providers = [{"name": k, **(v or {})} for k, v in providers.items()]
    active = caps.get("active_provider") or {}
    panel.say(f"active runtime: {active.get('name')} ({active.get('kind')}) | "
              f"can_provision: {caps.get('can_provision')}")
    for info in providers:
        panel.say(f"{str(info.get('name')):10s} available={info.get('available')} "
                  f"kind={info.get('kind')} reason={info.get('reason') or '-'}")
    facts = caps.get("active_facts") or {}
    if facts:
        panel.say(f"isolation: {facts.get('isolation')}")
        panel.say(f"network: {facts.get('network_model')}")
        panel.say(f"supports: {json.dumps(facts.get('supports'))}")
        if "not a virtual machine" not in (facts.get("isolation") or ""):
            failures.append("capability report does not distinguish containers "
                            "from virtual machines")
    caps_map = caps.get("capabilities") or {}
    for key in ("kvm", "docker", "lxc", "lxcfs", "ssh"):
        info = caps_map.get(key)
        if info:
            panel.say(f"probe {key:6s} available={info.get('available')} "
                      f"level={info.get('level')} reason={info.get('reason') or '-'}")
    if not caps.get("can_provision"):
        failures.append("host cannot provision at all")
        print("\nThis host cannot provision; nothing further can be proven.")
        return 1

    print("\n== 3. real provisioning through the panel API")
    code, images = panel.api("GET", "/api/images")
    catalogue = [i for i in images.get("images", []) if i.get("is_active")]
    if not catalogue:
        failures.append("no active OS image in the catalogue")
        print("  [!!] no active image; cannot continue")
        return 1
    image = None
    if args.image:
        image = next((i for i in catalogue if i["slug"] == args.image), None)
        if image is None:
            failures.append(f"no image with slug {args.image}")
            return 1
    else:                       # prefer one that is already cached (fast)
        image = next((i for i in catalogue if i.get("cached")), catalogue[0])
    code, plans = panel.api("GET", "/api/plans")
    plan = (plans.get("plans") or [None])[0]
    panel.say(f"using image {image['slug']} (cached={image.get('cached')}, "
              f"status={image.get('status')}) and plan "
              f"{plan['name'] if plan else 'custom'}")

    code, users = panel.api("GET", "/api/users")
    owner = next((u for u in users.get("users", [])
                  if u["username"] == panel.username), None)
    if owner is None:
        failures.append("could not resolve the owning account")
        return 1

    name = f"e2e-http-{int(time.time()) % 100000}"
    body = {"name": name, "hostname": name, "vcpu": 1, "memory_mb": 256,
            "disk_gb": 1, "image_id": image["id"], "owner_id": owner["id"],
            "init_command": "/bin/sh -c 'while :; do sleep 3600; done'"}
    if plan:
        body["plan_id"] = plan["id"]
        body["vcpu"] = plan["vcpu"]
        body["memory_mb"] = plan["memory_mb"]
        body["disk_gb"] = plan["disk_gb"]
    code, created = panel.api("POST", "/api/instances", json=body)
    if code not in (200, 201, 202) or not created.get("ok"):
        failures.append(f"create failed: {code} {json.dumps(created)[:300]}")
        print(f"  [!!] POST /api/instances -> {code} {json.dumps(created)[:300]}")
        return 1
    instance_id = created["instance"]["instance_id"]
    task_id = (created.get("task") or {}).get("task_id")
    panel.say(f"POST /api/instances -> {code}, instance {instance_id}, "
              f"task {task_id}", True)

    print("\n== 4. following the provisioning task (panel's own task API)")
    deadline = time.time() + args.timeout
    status = None
    last_line = None
    while time.time() < deadline:
        code, task = panel.api("GET", f"/api/tasks/{task_id}")
        body = task.get("task", {}) or {}
        status = body.get("status")
        line = f"{body.get('progress')}% {body.get('message') or ''}".strip()
        if line != last_line:                 # only report real changes
            last_line = line
            panel.say(f"task {task_id}: {line}")
        if status in ("success", "succeeded", "failed", "cancelled",
                      "interrupted"):
            break
        time.sleep(2)
    code, task = panel.api("GET", f"/api/tasks/{task_id}")
    logs = (task.get("task", {}) or {}).get("logs") or ""
    lines = [ln for ln in str(logs).splitlines() if ln.strip()]
    panel.say(f"task {task_id} status={status}",
              status in ("success", "succeeded"))
    for line in lines[-12:]:
        print(f"        | {line}")
    if status not in ("success", "succeeded"):
        failures.append(f"provisioning task ended as {status}")
        print("\nStopping here: provisioning did not succeed.")
        if not args.keep:
            panel.api("POST", f"/api/instances/{instance_id}/actions",
                      json={"action": "delete"})
        return 1

    def follow(task_id: str) -> str:
        """Wait for a queued task the panel returned, printing real progress."""
        deadline = time.time() + args.timeout
        last = None
        while time.time() < deadline:
            code, payload = panel.api("GET", f"/api/tasks/{task_id}")
            body = payload.get("task", {}) or {}
            line = f"{body.get('progress')}% {body.get('message') or ''}".strip()
            if line != last:
                last = line
                panel.say(f"task {task_id}: {line}")
            if body.get("status") in ("success", "succeeded", "failed",
                                      "cancelled", "interrupted"):
                return body.get("status")
            time.sleep(1.5)
        return "timeout"

    print("\n== 5. verifying the instance through the panel")
    code, detail = panel.api("GET", f"/api/instances/{instance_id}")
    instance = detail.get("instance", {})
    panel.say(f"status={instance.get('status')} kind={instance.get('kind')} "
              f"is_virtual_machine={instance.get('is_virtual_machine')} "
              f"isolation={instance.get('isolation')!r}",
              instance.get("status") == "running")
    network = instance.get("network") or {}
    internal_ip = network.get("internal_ip")
    runtime_id = instance.get("runtime_id")
    panel.say(f"runtime_id(init pid)={runtime_id} internal_ip={internal_ip} "
              f"ssh_enabled={network.get('ssh_enabled')}")
    if not internal_ip:
        failures.append("a running instance reported no address")
    if instance.get("is_virtual_machine"):
        failures.append("a container must never be reported as a virtual machine")
        panel.say("is_virtual_machine is true for a container!", False)
    if network.get("public_ip") or network.get("ssh_port"):
        failures.append("an address or SSH port was reported that the namespace "
                        "provider cannot publish")
    if runtime_id and str(runtime_id).isdigit():
        import os
        try:
            os.kill(int(runtime_id), 0)
            panel.say(f"the container's init process {runtime_id} is alive on "
                      f"this host (not a simulated number)", True)
        except PermissionError:
            # The init runs as root inside its own namespaces, so an
            # unprivileged probe gets EPERM — which proves it exists.
            panel.say(f"init process {runtime_id} exists (EPERM: it runs as "
                      f"root in its own namespaces, so signalling it is denied "
                      f"to this unprivileged probe)", True)
        except ProcessLookupError as exc:
            failures.append(f"reported init pid {runtime_id} does not exist: {exc}")
            panel.say(f"init pid {runtime_id} does NOT exist: {exc}", False)
        except OSError as exc:
            failures.append(f"could not verify init pid {runtime_id}: {exc}")
            panel.say(f"could not verify init pid {runtime_id}: {exc}", False)

    code, payload = panel.api("GET", f"/api/instances/{instance_id}/metrics")
    snap = payload.get("metrics") or payload
    sources = snap.get("sources") or snap.get("source") or []
    if isinstance(sources, str):
        sources = [sources]
    cgroup = snap.get("cgroup") or {}
    memory = cgroup.get("memory") or {}
    pids = cgroup.get("pids")
    processes = pids.get("current") if isinstance(pids, dict) else pids
    panel.say(f"metrics available={snap.get('available')} from {len(sources)} "
              f"real source(s): {', '.join(str(x)[:40] for x in sources)}")
    panel.say(f"cgroup memory.current={memory.get('current_mb')} MiB "
              f"pids.current={processes} "
              f"cpu.system_usec={(cgroup.get('cpu') or {}).get('system_usec')}",
              snap.get("available") is True)
    if snap.get("available") is False and not snap.get("reason"):
        failures.append("metrics reported unavailable without a reason")

    code, files = panel.api("GET", f"/api/instances/{instance_id}/files?path=/")
    entries = [e["name"] for e in files.get("entries", [])]
    panel.say(f"file listing of / -> {len(entries)} entries: {entries[:8]}",
              code == 200 and len(entries) > 0)
    if not entries:
        failures.append("the file manager returned an empty root filesystem")

    code, sessions = panel.api("GET", "/api/console/sessions")
    panel.say(f"console sessions endpoint -> {code} ({sessions.get('total')} active)")

    print("\n== 6. instance pages render with this real instance")
    for path in (f"/vps/{instance_id}", f"/vps/{instance_id}/console",
                 f"/vps/{instance_id}/files", f"/vps/{instance_id}/usage",
                 f"/vps/{instance_id}/ssh"):
        response = panel.s.get(f"{panel.base}{path}", allow_redirects=False)
        bad = "Traceback (most recent" in response.text or \
              "jinja2.exceptions" in response.text
        ok = response.status_code == 200 and not bad
        panel.say(f"GET {path} -> {response.status_code}", ok)
        if not ok:
            failures.append(f"{path} -> {response.status_code}")

    print("\n== 7. stop, then delete")
    code, queued = panel.api("POST", f"/api/instances/{instance_id}/actions",
                             json={"action": "stop"})
    stop_task = (queued.get("task") or {}).get("task_id")
    panel.say(f"POST actions stop -> {code} (task {stop_task})", code in (200, 202))
    if stop_task:
        panel.say(f"stop task finished: {follow(stop_task)}", True)
    code, detail = panel.api("GET", f"/api/instances/{instance_id}")
    state = (detail.get("instance") or {}).get("status")
    panel.say(f"status after stop: {state}", state == "stopped")
    if state != "stopped":
        failures.append("instance did not report stopped after a stop action")

    if args.keep:
        panel.say(f"--keep given: leaving {instance_id} in place")
    else:
        code, deleted = panel.api("DELETE", f"/api/instances/{instance_id}")
        delete_task = (deleted.get("task") or {}).get("task_id") \
            if isinstance(deleted, dict) else None
        panel.say(f"DELETE /api/instances/{instance_id} -> {code}", code in (200, 202))
        if code not in (200, 202):
            failures.append(f"delete failed: {code} {json.dumps(deleted)[:200]}")
        elif delete_task:
            panel.say(f"delete task finished: {follow(delete_task)}", True)
        code, listing = panel.api("GET", "/api/instances")
        remaining = [i["instance_id"] for i in listing.get("instances", [])
                     if i["instance_id"] == instance_id]
        panel.say(f"instance gone from the list: {not remaining}", not remaining)
        if remaining:
            failures.append("the deleted instance is still listed")

    print("\n" + "=" * 62)
    if failures:
        print(f"FAILED ({len(failures)}):")
        for item in failures:
            print(f"  - {item}")
        return 1
    print("end-to-end HTTP check passed: the panel really created, ran, "
          "accounted for, reported and removed a container")
    return 0


if __name__ == "__main__":
    sys.exit(main())
