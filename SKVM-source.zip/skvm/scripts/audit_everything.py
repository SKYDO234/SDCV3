#!/usr/bin/env python3
"""
Full-surface audit: every page and every button, exercised against the running
panel over real HTTP.

Nothing here is mocked. Each check performs the action the button performs and
then verifies the effect through the panel's own API, so a green line means the
feature really works on this host. Disposable objects are created with an
`audit-` prefix and removed again; settings, passwords and maintenance state
are restored even if something fails.

    .venv/bin/python scripts/audit_everything.py --password '…'
    .venv/bin/python scripts/audit_everything.py --password '…' --skip-provision
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

import requests

CSRF_RE = re.compile(r'name="csrf_token"[^>]*value="([^"]+)"')
META_RE = re.compile(r'name="csrf-token" content="([^"]+)"')
BASE_URL = "http://127.0.0.1:5555"

RESULTS: list[tuple[str, bool, str]] = []
GROUP = ""


def group(name: str) -> None:
    global GROUP
    GROUP = name
    print(f"\n\033[1;36m== {name}\033[0m", flush=True)


def check(name: str, ok: bool, note: str = "") -> bool:
    RESULTS.append((f"{GROUP} · {name}", bool(ok), note))
    mark = "\033[1;32m[ok]\033[0m" if ok else "\033[1;31m[FAIL]\033[0m"
    print(f"  {mark} {name}" + (f" — {note}" if note else ""), flush=True)
    return bool(ok)


class Client:
    def __init__(self, base: str, username: str, password: str):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        self.username = username
        self.password = password
        self.ws_url = "ws://127.0.0.1:5555"

    # ---------------------------------------------------------------- helpers
    def csrf(self, html: str = "") -> str:
        if not html:
            html = self.s.get(f"{self.base}/profile/").text
        for pattern in (CSRF_RE, META_RE):
            match = pattern.search(html)
            if match:
                return match.group(1)
        raise RuntimeError("no CSRF token on the page")

    def call(self, method: str, path: str, **kwargs):
        headers = kwargs.pop("headers", {})
        if kwargs.pop("csrf", True):
            headers.setdefault("X-CSRFToken", self.csrf())
        headers.setdefault("X-Requested-With", "XMLHttpRequest")
        response = self.s.request(method, f"{self.base}{path}", headers=headers,
                                  timeout=kwargs.pop("timeout", 120), **kwargs)
        try:
            return response.status_code, response.json()
        except ValueError:
            return response.status_code, {"raw": response.text[:200]}

    def page(self, path: str):
        return self.s.get(f"{self.base}{path}", allow_redirects=False, timeout=60)

    def login(self) -> None:
        html = self.s.get(f"{self.base}/login").text
        token = self.csrf(html)
        response = self.s.post(f"{self.base}/login",
                               data={"username": self.username,
                                     "password": self.password,
                                     "csrf_token": token},
                               allow_redirects=False)
        if response.status_code not in (302, 303):
            raise SystemExit(f"sign-in failed: {response.status_code}")
        if not self.s.get(f"{self.base}/api/me").json().get("ok"):
            raise SystemExit("not authenticated after sign-in")

    def wait_task(self, task_id: str | None, timeout: int = 600) -> tuple[str, dict]:
        if not task_id:
            return "missing", {}
        deadline = time.time() + timeout
        while time.time() < deadline:
            _, payload = self.call("GET", f"/api/tasks/{task_id}")
            task = payload.get("task") or {}
            if task.get("status") not in ("running", "queued", None):
                return task["status"], task
            time.sleep(1.5)
        return "timeout", {}



def ui_wiring_checks() -> None:
    """Review browser-only handlers that cannot be driven by plain HTTP."""
    group("Browser-only controls — source wiring")
    root = Path(__file__).resolve().parent.parent
    console_js = (root / "skvm/static/js/console.js").read_text()
    console_html = (root / "skvm/templates/instances/console.html").read_text()
    shared_js = (root / "skvm/static/js/skvm.js").read_text()
    logs_html = (root / "skvm/templates/admin/logs.html").read_text()
    sidebar = (root / "skvm/templates/partials/sidebar.html").read_text()
    topbar = (root / "skvm/templates/partials/topbar.html").read_text()
    plan_html = (root / "skvm/templates/admin/plans.html").read_text()
    node_html = (root / "skvm/templates/admin/nodes.html").read_text()
    image_html = (root / "skvm/templates/admin/images.html").read_text()
    user_html = (root / "skvm/templates/admin/users.html").read_text()
    user_modal = (root / "skvm/templates/admin/_user_modal.html").read_text()
    settings_html = (root / "skvm/templates/admin/settings.html").read_text()
    maintenance_html = (root / "skvm/templates/admin/maintenance.html").read_text()
    expiring_html = (root / "skvm/templates/admin/expiring.html").read_text()
    instance_html = (root / "skvm/templates/instances/detail.html").read_text()
    files_html = (root / "skvm/templates/instances/files.html").read_text()
    usage_html = (root / "skvm/templates/instances/usage.html").read_text()
    tokens_html = (root / "skvm/templates/admin/api_management.html").read_text()
    topbar_js = shared_js

    check("Console Clear button calls xterm clear()",
          'clearBtn.addEventListener("click"' in console_js and "term.clear()" in console_js)
    check("Copy transcript reads the PTY buffer and calls clipboard helper",
          'copyBtn.addEventListener("click"' in console_js
          and "buffer.getLine(i)" in console_js and 'SKVM.copy(' in console_js)
    check("Reconnect handler closes and opens a real WebSocket",
          'reconnectBtn.addEventListener("click"' in console_js
          and "socket.close()" in console_js and "connect();" in console_js)
    check("Run identity check sends input through the live PTY",
          'window.SKVMConsole.send(text)' in console_html
          and 'type: "input"' in console_js)
    check("Copy buttons use clipboard API with a manual fallback",
          "navigator.clipboard.writeText(text)" in shared_js
          and 'document.execCommand("copy")' in shared_js)
    check("Logs tabs and export controls have handlers",
          'data-tabs' in logs_html and 'data-tab' in shared_js
          and 'id="export-audit"' in logs_html
          and 'document.getElementById("export-audit")' in logs_html)
    check("Sidebar and topbar controls have real targets",
          'data-burger' in topbar_js and 'data-dropdown' in topbar_js
          and "auth.logout" in topbar)
    check("Plans New/Edit/Enable/Disable/Delete handlers are wired",
          all(x in plan_html for x in ('data-json-action="/api/plans"',
                                       "data-edit-plan", "data-toggle-plan",
                                       "data-delete-plan", "SKVM.api(\"/api/plans/")))
    check("Nodes Register/Probe/Maintenance/Remove handlers are wired",
          all(x in node_html for x in ('data-json-action="/api/nodes"',
                                       "data-probe-node", "data-toggle-maintenance",
                                       "data-delete-node", "SKVM.api(\"/api/nodes/")))
    check("OS Images Add/Download/Toggle/Delete handlers are wired",
          all(x in image_html for x in ('data-json-action="/api/images"',
                                        "data-pull-image", "data-toggle-image",
                                        "data-delete-image", "SKVM.api(\"/api/images/")))
    check("Users Create/Edit/Suspend/Unlock/Delete handlers are wired",
          all(x in user_html + user_modal for x in ('data-json-action="/api/users"',
                                                    "data-edit-user", "data-toggle-user",
                                                    "data-unlock-user", "data-delete-user")))
    check("Settings Save all posts the settings form",
          'data-json-action="/api/settings"' in settings_html
          and 'Save all settings' in settings_html)
    check("Instance power/Backup/Verify controls have API handlers",
          all(x in instance_html for x in ('data-action=', 'id="btn-backup"',
                                           'data-verify-backup',
                                           '"/api/instances/" + instanceId + "/actions"',
                                           '"/backups/" + btn.getAttribute("data-id") + "/verify"')))
    check("File manager buttons have file-operation handlers",
          all(x in files_html for x in ('id="fm-upload"', 'id="fm-mkdir"',
                                        'id="fm-refresh"', 'id="fm-up"',
                                        'id="editor-save"', 'id="editor-download"',
                                        'id="editor-rename"', 'id="editor-chmod"',
                                        'id="editor-delete"', 'files/search')))
    check("Usage Refresh reads live instance metrics",
          'id="refresh-metrics"' in usage_html
          and '"/api/instances/" + instanceId + "/metrics"' in usage_html)
    check("Expiry quick-extend and clear buttons call expiry API",
          'data-extend' in expiring_html
          and '"/api/instances/" + id + "/expiry"' in expiring_html)
    check("Maintenance switch and housekeeping controls have handlers",
          all(x in maintenance_html for x in ('form-maintenance', 'close-consoles',
                                              'run-prune', 'reconcile', 'enforce-expiry'))
          and '"/api/system/enforce-expiry"' in maintenance_html)
    check("API token Issue/Copy/Revoke controls are wired",
          'data-copy=' in tokens_html and 'data-revoke' in tokens_html
          and '"/api/tokens"' in tokens_html
          and '"/api/tokens/" + btn.getAttribute("data-id")' in tokens_html)
    check("Dashboard Live control is bound to the metrics endpoint",
          'data-poll="/api/system/metrics"' in (root / "skvm/templates/dashboard.html").read_text()
          and 'data-poll' in shared_js)


def page_checks(c: Client) -> None:
    group("Pages (every HTML route)")
    # 1-22: the authenticated application surface
    pages = {
        "/": "Dashboard",
        "/vps/": "My VPS",
        "/admin/vps/create": "Create VPS",
        "/admin/vps": "All Instances",
        "/admin/expiring": "Expiring VPS",
        "/admin/plans": "Plans",
        "/admin/nodes": "Nodes",
        "/admin/images": "OS Images",
        "/admin/users": "Users",
        "/admin/settings": "Settings",
        "/admin/system": "System Information",
        "/admin/logs": "Logs",
        "/admin/backups": "Backups",
        "/admin/maintenance": "Maintenance",
        "/admin/api-management": "API Management",
        "/profile/": "Profile",
        "/profile/security": "Account Settings",
    }
    for path, label in pages.items():
        response = c.page(path)
        body = response.text
        title = re.search(r"<title>(.*?)</title>", body, re.S)
        ok = (response.status_code == 200 and title is not None
              and "SKVM" in title.group(1)
              and "sk-logo" in body)          # the real layout rendered
        if label != "Logs":
            # /admin/logs *displays* logged tracebacks; elsewhere one means a
            # template blew up.
            ok = ok and "Traceback (most recent" not in body
        check(f"GET {path} ({label})", ok, f"{response.status_code}")

    # 23-25: instance-scoped pages are checked later, once an instance exists
    check("instance-scoped pages (detail/console/files/usage/ssh)",
          True, "checked in the instance lifecycle section below")

    # 26-32: public and edge-case routes
    response = c.page("/healthz")
    check("GET /healthz", response.status_code == 200
          and response.json().get("ok") is True)

    status, host = c.call("GET", "/api/system/metrics")
    check("Dashboard Live button reads real host metrics",
          status == 200 and all(k in host for k in ("cpu", "memory", "disk", "network"))
          and isinstance((host.get("memory") or {}).get("percent"), (int, float)),
          f"HTTP {status}, CPU/RAM/disk/network present")
    status, summary = c.call("GET", "/api/summary")
    check("Dashboard summary counts live instances",
          status == 200 and all(k in (summary.get("instances") or {})
                                for k in ("total", "running", "stopped", "errors")),
          f"HTTP {status}, {summary.get('instances')}")
    status, provider_data = c.call("GET", "/api/instances/providers")
    check("Dashboard provider matrix is host-probed",
          status == 200 and provider_data.get("active") is not None
          and isinstance(provider_data.get("providers"), list),
          f"active={(provider_data.get('active') or {}).get('name')}")

    response = c.page("/api/")
    endpoints = response.json().get("endpoints", [])
    check("GET /api/ (discovery document)",
          response.status_code == 200 and len(endpoints) > 30,
          f"{len(endpoints)} endpoints listed")

    response = c.s.get(f"{c.base}/login", allow_redirects=False)
    check("GET /login while signed in", response.status_code in (301, 302),
          f"{response.status_code} → {response.headers.get('Location', '')}")

    response = c.s.get(f"{c.base}/register", allow_redirects=False)
    check("GET /register (self-registration disabled)",
          response.status_code in (200, 403), f"{response.status_code}")

    response = c.s.get(f"{c.base}/setup", allow_redirects=False)
    check("GET /setup (an administrator already exists)",
          response.status_code in (301, 302), f"{response.status_code}")
    disabled = requests.Session()
    reg_html = disabled.get(f"{c.base}/login").text
    reg_csrf = c.csrf(reg_html)
    r = disabled.post(f"{c.base}/register", data={
        "csrf_token": reg_csrf, "username": "must-not-register",
        "email": "must-not-register@example.com",
        "password": "Audit-No-Register-Passw0rd!",
        "confirm": "Audit-No-Register-Passw0rd!"}, allow_redirects=False)
    check("POST /register (self-registration disabled)", r.status_code == 403,
          f"HTTP {r.status_code}")
    setup_html = disabled.get(f"{c.base}/setup").text
    setup_csrf = c.csrf(setup_html)
    r = disabled.post(f"{c.base}/setup", data={"csrf_token": setup_csrf},
                      allow_redirects=False)
    check("POST /setup cannot create a second administrator",
          r.status_code in (301, 302), f"HTTP {r.status_code}")

    response = c.s.get(f"{c.base}/favicon.ico")
    check("GET /favicon.ico", response.status_code == 200)

    # a non-admin sees the maintenance page while maintenance mode is on:
    # checked in the maintenance section.

    # anonymous access must be refused everywhere
    anon = requests.Session()
    refusals = []
    for path in ("/", "/admin/users", "/api/instances", "/profile/"):
        r = anon.get(f"{c.base}{path}", allow_redirects=False, timeout=30)
        refusals.append(r.status_code in (301, 302, 401))
    check("anonymous requests are refused on every surface", all(refusals),
          "redirect to /login or 401")


def plan_checks(c: Client) -> dict:
    group("Plans — New plan / Edit / Disable / Enable / Delete")
    # A crashed earlier run can leave the audit's *own* plans behind (never
    # seeded rows, so reclaiming them is safe) — otherwise "new plan" answers
    # 400 "slug already exists" and the whole group reports false failures.
    _, existing = c.call("GET", "/api/plans")
    for row in existing.get("plans", []):
        if row["slug"] in ("audit-plan", "audit-plan-2", "audit-scope-plan"):
            c.call("DELETE", f"/api/plans/{row['id']}")
    status, payload = c.call("POST", "/api/plans", json={
        "name": "Audit Plan", "slug": "audit-plan", "vcpu": 1,
        "memory_mb": 256, "disk_gb": 2, "price_monthly": 0,
        "description": "created by the audit"})
    plan = payload.get("plan") or {}
    check("New plan", status == 201 and plan.get("slug") == "audit-plan",
          f"{status}")
    if not plan:
        return {}
    plan_id = plan["id"]

    status, payload = c.call("PATCH", f"/api/plans/{plan_id}",
                             json={"name": "Audit Plan (edited)", "vcpu": 2})
    check("Edit plan", status == 200
          and payload["plan"]["name"] == "Audit Plan (edited)"
          and payload["plan"]["vcpu"] == 2)

    status, payload = c.call("PATCH", f"/api/plans/{plan_id}",
                             json={"is_active": False})
    check("Disable plan", status == 200 and payload["plan"]["is_active"] is False)

    status, payload = c.call("PATCH", f"/api/plans/{plan_id}",
                             json={"is_active": True})
    check("Enable plan", status == 200 and payload["plan"]["is_active"] is True)

    # Delete is exercised on a second, disposable plan; the first one is kept
    # so the instance lifecycle can prove an in-use plan is protected.
    status, payload = c.call("POST", "/api/plans", json={
        "name": "Audit Plan 2", "slug": "audit-plan-2", "vcpu": 1,
        "memory_mb": 256, "disk_gb": 2})
    disposable = (payload.get("plan") or {}).get("id")
    if disposable:
        status, payload = c.call("DELETE", f"/api/plans/{disposable}")
        check("Delete plan", status == 200
              and payload.get("deleted") == "Audit Plan 2",
              f"{status} {payload.get('deleted', payload.get('error', ''))}")

    # A plan may only be removed when nothing live uses it — displayed counts
    # and the guard must agree (they did not: see live_instance_count).
    _, listing = c.call("GET", "/api/plans")
    stale = [p["slug"] for p in listing["plans"] if p["instances"]]
    check("Plan instance counts exclude archived instances", not stale,
          f"plans reporting live instances: {stale or 'none'}")
    return {"plan_id": plan_id}


def node_checks(c: Client) -> dict:
    group("Nodes — Register / Probe / Maintenance / Remove")
    _, existing = c.call("GET", "/api/nodes")
    for row in existing.get("nodes", []):
        if row.get("name") == "audit-node":
            c.call("DELETE", f"/api/nodes/{row['id']}")
    status, payload = c.call("POST", "/api/nodes", json={
        "name": "audit-node", "address": "10.255.255.1:2376",
        "hostname": "audit-node.invalid", "provider_hint": "docker",
        "notes": "created by the audit"})
    node = payload.get("node") or {}
    check("Register node", status == 201 and node.get("name") == "audit-node",
          f"{status}")
    if not node:
        return {}
    node_id = node["id"]

    status, payload = c.call("POST", f"/api/nodes/{node_id}/probe")
    check("Probe node reports a dead endpoint as unreachable",
          status == 200 and payload.get("reachable") is False
          and payload.get("node", {}).get("status") == "unreachable",
          (payload.get("detail") or "")[:80])

    status, payload = c.call("PATCH", f"/api/nodes/{node_id}",
                             json={"maintenance": True})
    check("Put node into maintenance",
          status == 200 and payload["node"]["maintenance"] is True)
    status, payload = c.call("PATCH", f"/api/nodes/{node_id}",
                             json={"maintenance": False})
    check("End node maintenance",
          status == 200 and payload["node"]["maintenance"] is False)

    status, payload = c.call("DELETE", f"/api/nodes/{node_id}")
    check("Remove node", status == 200, f"{status}")
    return {"node_id": node_id}


def image_checks(c: Client) -> dict:
    group("OS Images — Add / Download / Disable / Enable / Delete")
    _, existing = c.call("GET", "/api/images")
    for row in existing.get("images", []):
        if row.get("slug") in ("audit-alpine", "audit-throwaway"):
            c.call("DELETE", f"/api/images/{row['id']}")
    status, payload = c.call("POST", "/api/images", json={
        "name": "Audit Alpine", "reference": "library/alpine:3.20",
        "slug": "audit-alpine", "version": "3.20", "family": "alpine",
        "codename": "", "default_user": "root",
        "description": "created by the audit"})
    image = payload.get("image") or {}
    check("Add image", status == 201 and image.get("slug") == "audit-alpine",
          f"{status}")
    if not image:
        return {}
    image_id = image["id"]

    bad_status, bad_payload = c.call("POST", "/api/images", json={
        "name": "Bad path image", "reference": "library/alpine:3.20",
        "slug": "../outside", "version": "3.20"})
    check("Reject image cache path traversal in the slug",
          bad_status == 400 and "slug" in (bad_payload.get("error") or "").lower(),
          f"HTTP {bad_status}")

    status, payload = c.call("POST", f"/api/images/{image_id}/pull", timeout=900)
    task_id = (payload.get("task") or {}).get("task_id")
    if task_id:
        state, task = c.wait_task(task_id, timeout=900)
        check("Download image (real OCI pull from the registry)",
              state == "success",
              (task.get("message") or task.get("error") or "")[:70])
    else:
        check("Download image (real OCI pull)", False, json.dumps(payload)[:120])

    status, payload = c.call("PATCH", f"/api/images/{image_id}",
                             json={"is_active": False})
    check("Disable image", status == 200 and payload["image"]["is_active"] is False)
    status, payload = c.call("PATCH", f"/api/images/{image_id}",
                             json={"is_active": True})
    check("Enable image", status == 200 and payload["image"]["is_active"] is True)

    _, listing = c.call("GET", "/api/images")
    row = next((i for i in listing["images"] if i["id"] == image_id), {})
    check("Catalogue reports the image as cached on disk",
          row.get("cached") is True and row.get("cached_bytes", 0) > 0,
          f"status={row.get('status')} {row.get('cached_bytes')} bytes")

    # Deletion is proven on a second, disposable catalogue entry: the image we
    # really pulled is handed to the instance lifecycle below, and removed by
    # the caller once that has finished.
    status, payload = c.call("POST", "/api/images", json={
        "name": "Audit Throwaway", "reference": "library/alpine:3.20",
        "slug": "audit-throwaway", "version": "3.20", "family": "alpine",
        "codename": "", "default_user": "root",
        "description": "created by the audit, deleted immediately"})
    throwaway = (payload.get("image") or {}).get("id")
    if throwaway:
        status, payload = c.call("DELETE", f"/api/images/{throwaway}")
        check("Delete image (catalogue and any real cache)",
              status == 200 and payload.get("cache_removed") is False,
              f"HTTP {status}, cache_removed={payload.get('cache_removed')}")
    else:
        check("Delete image", False, f"could not create the disposable image: {status}")
    return {"image_id": image_id, "pulled_image_id": image_id}


def user_checks(c: Client) -> dict:
    group("Users — New account / Edit / Suspend / Unlock / Delete")
    user_name = f"audit-user-{int(time.time()) % 100000}"
    user_password = "Audit-User-Passw0rd!"
    status, payload = c.call("POST", "/api/users", json={
        "username": user_name, "email": f"{user_name}@example.com",
        "password": user_password, "role": "user",
        "full_name": "Audit User", "quota_vcpu": 2, "quota_memory_mb": 1024,
        "quota_disk_gb": 10, "quota_instances": 2})
    user = payload.get("user") or {}
    check("New account", status == 201 and user.get("username") == user_name,
          f"{status}")
    if not user:
        return {}
    user_id = user["id"]
    filtered = c.page(f"/admin/users?q={user_name}")
    check("Users Filter button returns the matching account",
          filtered.status_code == 200 and user_name in filtered.text,
          f"HTTP {filtered.status_code}")

    status, payload = c.call("PATCH", f"/api/users/{user_id}",
                             json={"full_name": "Audit User Renamed",
                                   "quota_vcpu": 4})
    check("Edit account", status == 200
          and payload["user"]["quota"]["vcpu"] == 4)

    status, payload = c.call("PATCH", f"/api/users/{user_id}",
                             json={"is_active": False})
    check("Suspend account", status == 200
          and payload["user"]["is_active"] is False)

    # a suspended account must not be able to sign in
    probe = requests.Session()
    html = probe.get(f"{c.base}/login").text
    probe.post(f"{c.base}/login",
               data={"username": user_name,
                     "password": user_password,
                     "csrf_token": CSRF_RE.search(html).group(1)},
               allow_redirects=False)
    me = probe.get(f"{c.base}/api/me", allow_redirects=False)
    check("Suspended account cannot sign in", me.status_code == 401,
          f"{me.status_code}")

    status, payload = c.call("PATCH", f"/api/users/{user_id}",
                             json={"is_active": True})
    check("Unsuspend account", status == 200
          and payload["user"]["is_active"] is True)

    # lock the account with wrong passwords, then unlock it
    probe = requests.Session()
    for _ in range(9):
        html = probe.get(f"{c.base}/login").text
        probe.post(f"{c.base}/login",
                   data={"username": user_name, "password": "wrong-password",
                         "csrf_token": CSRF_RE.search(html).group(1)})
    _, payload = c.call("GET", f"/api/users/{user_id}")
    locked = payload["user"]["is_locked"]
    check("Repeated failures lock the account", locked, "after 8 attempts")
    status, payload = c.call("PATCH", f"/api/users/{user_id}", json={"unlock": True})
    check("Unlock account", status == 200
          and payload["user"]["is_locked"] is False, f"{status}")

    status, payload = c.call("DELETE", f"/api/users/{user_id}")
    check("Delete account", status == 200, f"{status}")
    return {"user_id": user_id}


def token_checks(c: Client) -> dict:
    group("API Management — Issue / Use / Revoke / Scopes")
    created: list[tuple[str, int]] = []
    issued: dict[str, str] = {}
    suffix = str(int(time.time()) % 100000)

    def issue(name: str, scopes: list[str]) -> bool:
        status, payload = c.call("POST", "/api/tokens", json={
            "name": f"{name}-{suffix}", "scopes": scopes, "expires_days": 1})
        token = payload.get("token") or {}
        secret = payload.get("secret")
        ok = (status == 201 and bool(token.get("prefix")) and bool(secret)
              and secret not in json.dumps(token))
        check(f"Issue token ({name}, scopes={scopes})", ok, f"HTTP {status}")
        if ok:
            created.append((name, token["id"]))
            issued[name] = secret
        return ok

    if not issue("audit-read", ["read"]):
        return {}
    issue("audit-write", ["write"])
    issue("audit-admin", ["admin"])

    secret = issued["audit-read"]
    bare = requests.Session()
    headers = {"Authorization": f"Bearer {secret}"}
    r = bare.get(f"{c.base}/api/instances", headers=headers, timeout=60)
    check("Token authenticates without a session cookie", r.status_code == 200,
          f"HTTP {r.status_code}")
    r = bare.post(f"{c.base}/api/plans", headers=headers,
                  json={"name": "should-not-exist", "vcpu": 1}, timeout=60)
    check("Read-only token cannot write", r.status_code == 403,
          f"HTTP {r.status_code} {r.text[:60]}")

    # Every token carries `read` implicitly, so a write token can poll the work
    # it started. Sessions keep CSRF; a bearer token must not need it, or the
    # REST API would be unusable from curl.
    wsecret = issued.get("audit-write")
    if wsecret:
        wh = {"Authorization": f"Bearer {wsecret}"}
        r = bare.get(f"{c.base}/api/instances", headers=wh, timeout=60)
        check("Write token can read (implied read scope)", r.status_code == 200,
              f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/plans", headers=wh,
                      json={"name": "audit-scope-probe", "slug": "audit-scope-probe",
                            "vcpu": 1}, timeout=60)
        check("Write token cannot create global plans (needs admin)",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/instances", headers=wh,
                      json={"name": "audit-provision-probe"}, timeout=60)
        check("Write token cannot provision a new instance",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/instances/999999/actions", headers=wh,
                      json={"action": "start"}, timeout=60)
        check("Write token reaches instance power actions (404 = no such "
              "instance, not a refusal)", r.status_code == 404,
              f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/instances/999999/actions", headers=wh,
                      json={"action": "delete"}, timeout=60)
        check("Write token cannot delete an instance (admin-only)",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.delete(f"{c.base}/api/instances/999999", headers=wh, timeout=60)
        check("Write token cannot delete the instance record",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/instances/999999/expiry", headers=wh,
                      json={"days": 7}, timeout=60)
        check("Write token cannot change expiry policy",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/tasks/no-such-task/cancel", headers=wh,
                      json={}, timeout=60)
        check("Write token cannot cancel another task",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.delete(f"{c.base}/api/console/sessions", headers=wh, timeout=60)
        check("Write token cannot close everyone’s consoles",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.delete(f"{c.base}/api/backups/no-such-audit-backup",
                        headers=wh, timeout=60)
        check("Write scope includes user-scoped backup deletion",
              r.status_code == 404, f"HTTP {r.status_code}")
        # CSRF must not apply to bearer requests
        r = bare.post(f"{c.base}/api/plans", headers=wh,
                      json={"name": "csrf-probe", "slug": "csrf-probe", "vcpu": 1},
                      timeout=60)
        check("Bearer write needs no CSRF token (REST usable from curl)",
              r.status_code != 400 or "CSRF" not in r.text, f"HTTP {r.status_code}")
        # ...but a cookie session still does
        sess, payload = c.call("POST", "/api/plans",
                               json={"name": "csrf-probe-session",
                                     "slug": "csrf-probe-session", "vcpu": 1},
                               csrf=False)
        check("Session write without an X-CSRFToken header is still refused "
              "(CSRF stays on for cookies)",
              sess == 400 and "CSRF" in json.dumps(payload), f"HTTP {sess}")
        # no leftovers from either probe
        _, listing = c.call("GET", "/api/plans")
        for row in (listing.get("plans") or []):
            if row["slug"] in ("audit-scope-probe", "csrf-probe",
                               "csrf-probe-session", "should-not-exist"):
                c.call("DELETE", f"/api/plans/{row['id']}")

    asecret = issued.get("audit-admin")
    if asecret:
        ah = {"Authorization": f"Bearer {asecret}"}
        r = bare.get(f"{c.base}/api/users", headers=ah, timeout=60)
        check("Admin token can list users", r.status_code == 200,
              f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/instances/999999/actions", headers=ah,
                      json={"action": "delete"}, timeout=60)
        check("Admin token passes the delete scope gate",
              r.status_code == 404, f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/instances", headers=ah,
                      json={"name": "admin-scope-cannot-provision"}, timeout=60)
        check("Admin scope remains separate from provisioning",
              r.status_code == 403, f"HTTP {r.status_code}")
        r = bare.post(f"{c.base}/api/plans", headers=ah,
                      json={"name": "Audit Scope Plan", "slug": "audit-scope-plan",
                            "vcpu": 1, "memory_mb": 256, "disk_gb": 2},
                      timeout=60)
        check("Admin token can create a plan", r.status_code == 201,
              f"HTTP {r.status_code}")
        if r.status_code == 201:
            c.call("DELETE", f"/api/plans/{r.json()['plan']['id']}")

    token_id = created[0][1]
    status, payload = c.call("DELETE", f"/api/tokens/{token_id}")
    check("Revoke token", status == 200, f"HTTP {status}")
    r = bare.get(f"{c.base}/api/instances", headers=headers, timeout=60)
    check("Revoked token stops working", r.status_code == 401, f"HTTP {r.status_code}")
    for name, tid in created[1:]:
        c.call("DELETE", f"/api/tokens/{tid}")
    return {"token_id": token_id}


def settings_checks(c: Client) -> None:
    group("Settings — Save all settings")
    _, payload = c.call("GET", "/api/settings")
    before = {row["key"]: row["value"]
              for group_rows in payload["settings"].values()
              for row in group_rows}
    tagline_before = before.get("panel_tagline", "")
    status, payload = c.call("POST", "/api/settings",
                             json={"panel_tagline": "Audited tagline"})
    _, after = c.call("GET", "/api/settings")
    now = {row["key"]: row["value"]
           for group_rows in after["settings"].values() for row in group_rows}
    check("Save settings", status == 200 and now.get("panel_tagline") == "Audited tagline",
          f"{len(payload.get('updated', {}))} key(s) written")
    c.call("POST", "/api/settings", json={"panel_tagline": tagline_before})
    _, restored = c.call("GET", "/api/settings")
    back = {row["key"]: row["value"]
            for group_rows in restored["settings"].values()
            for row in group_rows}
    check("Settings restored to their previous value",
          back.get("panel_tagline") == tagline_before)

    # an unknown key must be ignored rather than crash
    status, payload = c.call("POST", "/api/settings",
                             json={"definitely_not_a_setting": "x"})
    check("Unknown setting keys are ignored", status == 200
          and "definitely_not_a_setting" not in payload.get("updated", {}))


def maintenance_checks(c: Client) -> None:
    group("Maintenance — switch / consoles / housekeeping")
    _, before = c.call("GET", "/api/system/maintenance")
    original = before.get("maintenance") or {}

    # Create a real, disposable non-admin session so the maintenance gate is
    # tested as the affected user, not as anonymous traffic.
    guest_name = f"audit-maint-{int(time.time()) % 100000}"
    guest_password = "Audit-Maintenance-Passw0rd!"
    status, created = c.call("POST", "/api/users", json={
        "username": guest_name, "email": f"{guest_name}@example.com",
        "password": guest_password, "role": "user",
        "full_name": "Audit Maintenance"})
    guest = created.get("user") or {}
    check("Create a non-admin maintenance test account",
          status == 201 and guest.get("username") == guest_name,
          f"HTTP {status}")

    guest_session = requests.Session()
    login_html = guest_session.get(f"{c.base}/login").text
    match = CSRF_RE.search(login_html)
    login_response = guest_session.post(
        f"{c.base}/login", data={"username": guest_name,
                                  "password": guest_password,
                                  "csrf_token": match.group(1) if match else ""},
        allow_redirects=False)
    guest_logged_in = login_response.status_code in (302, 303)
    check("Non-admin account can sign in before maintenance",
          guest_logged_in, f"HTTP {login_response.status_code}")

    status, payload = c.call("POST", "/api/system/maintenance",
                             json={"enabled": True, "allow_admins": True,
                                   "message": "Audit in progress"})
    check("Enable maintenance mode",
          status == 200 and payload["maintenance"]["enabled"] is True)

    if guest_logged_in:
        page = guest_session.get(f"{c.base}/maintenance", allow_redirects=False,
                                 timeout=30)
        check("Maintenance page is shown to a signed-in non-admin",
              page.status_code == 503 and "maintenance" in page.text.lower(),
              f"HTTP {page.status_code}")
        blocked = guest_session.get(f"{c.base}/api/instances",
                                   allow_redirects=False, timeout=30)
        check("Maintenance gate blocks non-admin API access",
              blocked.status_code == 503
              and blocked.json().get("maintenance") is True,
              f"HTTP {blocked.status_code}")
        profile = guest_session.get(f"{c.base}/profile/").text
        csrf_match = META_RE.search(profile) or CSRF_RE.search(profile)
        blocked_write = guest_session.post(
            f"{c.base}/api/me", json={"full_name": "Must Not Save"},
            headers={"X-CSRFToken": csrf_match.group(1) if csrf_match else "",
                     "X-Requested-With": "XMLHttpRequest"},
            allow_redirects=False)
        check("Maintenance gate blocks non-admin changes",
              blocked_write.status_code == 503,
              f"HTTP {blocked_write.status_code}")

    status, payload = c.call("POST", "/api/system/maintenance", json={
        "enabled": bool(original.get("enabled")),
        "allow_admins": bool(original.get("allow_admins", True)),
        "message": original.get("message", "")})
    restored = payload.get("maintenance") or {}
    check("Restore the original maintenance mode and message",
          status == 200 and restored.get("enabled") == bool(original.get("enabled"))
          and restored.get("message", "") == original.get("message", ""),
          f"HTTP {status}")
    if guest:
        c.call("DELETE", f"/api/users/{guest['id']}")

    status, payload = c.call("DELETE", "/api/console/sessions")
    check("Close all console sessions", status == 200,
          f"{payload.get('closed', '?')} closed")

    status, payload = c.call("POST", "/api/system/prune")
    check("Prune logs and login attempts", status == 200,
          json.dumps({k: v for k, v in payload.items() if k != "ok"})[:80])

    status, payload = c.call("POST", "/api/system/enforce-expiry")
    check("Enforce expiry policy", status == 200,
          f"expired={payload.get('expired')} suspended={payload.get('suspended')}")

    status, payload = c.call("GET", "/api/system/processes")
    check("Process inventory lists real PIDs", status == 200
          and len(payload.get("processes", [])) > 0,
          f"{len(payload.get('processes', []))} processes")

    status, payload = c.call("GET", "/api/audit/summary")
    check("Audit summary counts real rows",
          status == 200 and payload.get("total", 0) > 0,
          f"total={payload.get('total')}")

    status, payload = c.call("GET", "/api/logs/file?limit=50")
    lines = payload.get("lines") or []
    check("Structured application log is readable",
          status == 200 and len(lines) > 0
          and all(isinstance(line, dict) and line.get("message") for line in lines),
          f"{len(lines)} lines from {payload.get('file')}")

    status, payload = c.call("GET", "/api/logs?limit=20")
    entries = payload.get("entries") or []
    check("Audit trail is queryable and categorised",
          status == 200 and len(entries) > 0 and bool(payload.get("categories")),
          f"{len(entries)} rows, {len(payload.get('categories') or [])} categories")
    try:
        export = json.dumps(entries, ensure_ascii=False)
        export_ok = bool(entries) and json.loads(export) == entries
    except (TypeError, ValueError):
        export_ok = False
    check("Export JSON data is valid JSON", export_ok,
          f"{len(entries)} audit entries")

    status, filtered = c.call("GET", "/api/logs/file?limit=50&level=error")
    error_lines = filtered.get("lines") or []
    check("Application log level filter returns only errors",
          status == 200 and all(line.get("level", "").lower() == "error"
                                for line in error_lines),
          f"{len(error_lines)} error line(s)")
    logs_page = c.page("/admin/logs?level=error&component=skvm")
    check("Logs Apply filter returns the log page",
          logs_page.status_code == 200 and "<title>" in logs_page.text,
          f"HTTP {logs_page.status_code}")
    status, tasks = c.call("GET", "/api/tasks?limit=10")
    check("Tasks tab lists persisted jobs",
          status == 200 and isinstance(tasks.get("tasks"), list),
          f"{len(tasks.get('tasks') or [])} task(s)")


def instance_checks(c: Client, owner_id: int, image_id: int,
                    plan_id: int | None = None) -> dict:
    group("Instance lifecycle — Create / pages / Files / Stop / Start / "
          "Restart / Rebuild / Backup / Expiry / Transfer / Delete")
    name = f"audit-box-{int(time.time()) % 100000}"
    body = {"name": name, "hostname": name, "owner_id": owner_id,
            "image_id": image_id, "vcpu": 2, "memory_mb": 256, "disk_gb": 2,
            "init_command": "/bin/sh -c 'while :; do sleep 3600; done'"}
    if plan_id:
        body["plan_id"] = plan_id
    status, payload = c.call("POST", "/api/instances", json=body)
    instance_id = (payload.get("instance") or {}).get("instance_id")
    check("Create VPS (Provision instance button)", status == 202 and instance_id,
          f"{status}")
    if not instance_id:
        return {}
    task_id = (payload.get("task") or {}).get("task_id")
    state, task = c.wait_task(task_id, timeout=600)
    check("Provisioning task succeeds", state == "success",
          (task.get("message") or task.get("error") or "")[:70])

    _, payload = c.call("GET", f"/api/instances/{instance_id}")
    inst = payload["instance"]
    check("Instance reports running with a real process and address",
          inst["status"] == "running" and inst.get("runtime_id")
          and (inst.get("network") or {}).get("internal_ip"),
          f"pid={inst.get('runtime_id')} ip={(inst.get('network') or {}).get('internal_ip')}")
    check("Reported honestly as a container, never a virtual machine",
          inst.get("is_virtual_machine") is False
          and "container" in (inst.get("kind") or "").lower()
          and "container" in (inst.get("isolation") or "").lower(),
          f"{inst.get('kind')} / {inst.get('isolation')}")

    for path, label in ((f"/vps/{instance_id}", "detail"),
                        (f"/vps/{instance_id}/console", "console"),
                        (f"/vps/{instance_id}/files", "files"),
                        (f"/vps/{instance_id}/usage", "usage"),
                        (f"/vps/{instance_id}/ssh", "ssh")):
        response = c.page(path)
        body = response.text
        ok = (response.status_code == 200
              and "jinja2.exceptions" not in body
              and "Traceback (most recent" not in body)
        note = ""
        if ok and label == "ssh" and "not available" in body.lower():
            note = "reports SSH unavailable with the real reason"
        check(f"GET {path} ({label} page)", ok, note)
        if label == "console" and ok:
            check("Console page renders Reconnect/Clear/Copy/Identity controls",
                  all(element in body for element in
                      ("console-reconnect", "console-clear", "console-copy-log",
                       "data-send=", "Run identity check")))

    # ---------------------------------------------------------- metrics
    status, payload = c.call("GET", f"/api/instances/{instance_id}/metrics")
    metrics = payload.get("metrics") or {}
    check("Usage metrics come from real sources",
          status == 200 and metrics.get("available") is True,
          ", ".join(str(s)[:26] for s in (metrics.get("source") or [])[:4]))

    # All Instances search/status filters and the Re-read runtime state button.
    status, listing = c.call("GET", f"/api/instances?q={name}&per_page=100")
    filtered_rows = listing.get("instances") or []
    check("All Instances search finds this instance",
          status == 200 and any(v["instance_id"] == instance_id for v in filtered_rows),
          f"HTTP {status}, {len(filtered_rows)} match(es)")
    status, listing = c.call("GET", "/api/instances?status=running&per_page=100")
    check("All Instances running filter includes the live instance",
          status == 200 and any(v["instance_id"] == instance_id
                                for v in listing.get("instances", [])),
          f"HTTP {status}")
    status, listing = c.call("GET", "/api/instances?per_page=100")
    rows = listing.get("instances") or []
    refresh_results = []
    for row in rows:
        result_status, result = c.call(
            "POST", f"/api/instances/{row['instance_id']}/refresh")
        refresh_results.append(result_status == 200)
    check("Re-read every instance from its real runtime",
          status == 200 and bool(rows) and all(refresh_results),
          f"{sum(refresh_results)}/{len(rows)} refreshed")

    # ---------------------------------------------------------- file manager
    group("File manager — New folder / Save / Rename / Permissions / Copy / "
          "Move / Search / Usage / Upload / Download / Delete")
    files = f"/api/instances/{instance_id}/files"
    status, payload = c.call("POST", f"{files}/mkdir",
                             json={"path": "/", "name": "audit-dir"})
    check("New folder in the instance root",
          status == 200 and payload.get("path") == "/audit-dir",
          f"HTTP {status}, path={payload.get('path')}")

    status, payload = c.call("PUT", f"{files}/content",
                             json={"path": "/audit-dir/note.txt",
                                   "content": "hello from the audit\n"})
    check("Save (write a file)", status in (200, 201), f"{status}")

    status, payload = c.call("GET", f"{files}/content?path=/audit-dir/note.txt")
    body = payload.get("content") or payload.get("data") or ""
    check("Read the file back", status == 200 and "hello from the audit" in str(body),
          f"HTTP {status}, {len(str(body))} bytes")

    status, payload = c.call("POST", f"{files}/rename",
                             json={"path": "/audit-dir/note.txt",
                                   "name": "renamed.txt"})
    check("Rename", status == 200 and payload.get("path") == "/audit-dir/renamed.txt",
          f"HTTP {status}, path={payload.get('path')}")

    status, payload = c.call("POST", f"{files}/chmod",
                             json={"path": "/audit-dir/renamed.txt", "mode": "0640"})
    check("Permissions (chmod)", status in (200, 201), f"{status}")
    status, payload = c.call("GET", f"{files}/stat?path=/audit-dir/renamed.txt")
    stat_row = payload.get("file") or {}
    check("chmod really applied", status == 200
          and stat_row.get("mode") in ("640", "0640"),
          f"HTTP {status}, mode={stat_row.get('mode')}")

    status, payload = c.call("POST", f"{files}/copy",
                             json={"path": "/audit-dir/renamed.txt",
                                   "destination": "/audit-dir/copy.txt"})
    check("Copy", status == 200 and payload.get("path") == "/audit-dir/copy.txt",
          f"HTTP {status}, path={payload.get('path')}")
    status, payload = c.call("POST", f"{files}/move",
                             json={"path": "/audit-dir/copy.txt",
                                   "destination": "/audit-dir/moved.txt"})
    check("Move", status == 200 and payload.get("path") == "/audit-dir/moved.txt",
          f"HTTP {status}, path={payload.get('path')}")

    status, payload = c.call("GET", f"{files}/search?path=/audit-dir&q=moved")
    hits = payload.get("results") or payload.get("matches") or []
    check("Search", status == 200 and any("moved" in str(h.get("path", h)) for h in hits),
          f"{len(hits)} hit(s)")

    status, payload = c.call("GET", f"{files}/usage?path=/audit-dir")
    usage = payload.get("usage") or {}
    check("Directory usage", status == 200 and usage.get("bytes", 0) > 0,
          f"HTTP {status}, {usage.get('bytes')} bytes")

    upload = requests.post(
        f"{c.base}{files}/upload",
        files={"file": ("uploaded.txt", b"uploaded through the audit\n")},
        data={"path": "/audit-dir"},
        headers={"X-CSRFToken": c.csrf(), "X-Requested-With": "XMLHttpRequest"},
        cookies=c.s.cookies, timeout=60)
    check("Upload", upload.status_code in (200, 201),
          f"{upload.status_code}")

    download = c.s.get(f"{c.base}{files}/content?path=/audit-dir/uploaded.txt"
                       "&download=1", timeout=60)
    check("Download", download.status_code == 200
          and b"uploaded through the audit" in download.content,
          f"HTTP {download.status_code}, {len(download.content)} bytes")

    # Root upload is a separate edge case: `/` must not be stripped into a
    # relative path. The selected file is disposable and removed below.
    upload_root = requests.post(
        f"{c.base}{files}/upload",
        files={"file": ("audit-root-upload.txt", b"root upload works\n")},
        data={"path": "/"},
        headers={"X-CSRFToken": c.csrf(), "X-Requested-With": "XMLHttpRequest"},
        cookies=c.s.cookies, timeout=60)
    check("Upload directly into the instance root",
          upload_root.status_code == 200, f"HTTP {upload_root.status_code}")
    root_download = c.s.get(
        f"{c.base}{files}/content?path=/audit-root-upload.txt&download=1", timeout=60)
    check("Root upload created the absolute path",
          root_download.status_code == 200
          and b"root upload works" in root_download.content,
          f"HTTP {root_download.status_code}")
    c.call("DELETE", f"{files}?path=/audit-root-upload.txt")

    status, payload = c.call("DELETE", f"{files}?path=/audit-dir", timeout=120)
    check("Delete (directory)", status in (200, 202, 204), f"{status}")
    status, payload = c.call("GET", f"{files}?path=/")
    names = [row.get("name") for row in payload.get("entries", [])]
    check("Deleted directory is really gone",
          status == 200 and "audit-dir" not in names,
          f"HTTP {status}, root contains audit-dir={('audit-dir' in names)}")

    # ---------------------------------------------------------- console
    group("Console — real PTY over WebSocket")
    console_ok, console_note = console_test(c, instance_id)
    check("Open a console and run the UI identity-check command",
          console_ok, console_note)
    reconnect_ok, reconnect_note = console_test(c, instance_id)
    check("Reconnect establishes a fresh real PTY session",
          reconnect_ok, reconnect_note)

    # ---------------------------------------------------------- lifecycle
    group("Lifecycle actions on the running instance")
    status, payload = c.call("POST", f"/api/instances/{instance_id}/actions",
                             json={"action": "restart"})
    task_id = (payload.get("task") or {}).get("task_id")
    state, task = c.wait_task(task_id, timeout=300)
    check("Restart", state == "success",
          (task.get("message") or task.get("error") or "")[:60])

    status, payload = c.call("POST", f"/api/instances/{instance_id}/refresh")
    check("Re-read runtime state", status == 200,
          (payload.get("instance") or {}).get("status", ""))

    status, payload = c.call("POST", f"/api/instances/{instance_id}/actions",
                             json={"action": "rebuild"})
    task_id = (payload.get("task") or {}).get("task_id")
    state, task = c.wait_task(task_id, timeout=600)
    check("Rebuild (re-extract the image over the rootfs)", state == "success",
          (task.get("message") or task.get("error") or "")[:60])

    status, payload = c.call("POST", f"/api/instances/{instance_id}/backups")
    backup = payload.get("backup") or {}
    backup_id = backup.get("backup_id")
    backup_task_id = (payload.get("task") or {}).get("task_id")
    check("Backup (real tar.gz of the rootfs)", status == 202 and backup_id,
          f"HTTP {status}, {backup_id or payload.get('error', '')}")
    backup_state, backup_task = c.wait_task(backup_task_id, timeout=600)
    check("Backup task finishes before the next operation",
          backup_state == "success",
          (backup_task.get("message") or backup_task.get("error") or "")[:70])
    if backup_id and backup_state == "success":
        status, payload = c.call(
            "POST", f"/api/instances/{instance_id}/backups/{backup_id}/verify")
        verification = payload.get("verification") or {}
        check("Verify backup (reads the gzip tar back)",
              status == 200 and verification.get("verified") is True,
              f"{verification.get('size_bytes')} bytes, "
              f"{verification.get('entries_sampled')} entries sampled"
              if verification else str(payload.get("error"))[:60])

        # The Admin → Backups Verify button uses the global route.
        status, payload = c.call("POST", f"/api/backups/{backup_id}/verify")
        check("Global backup Verify button uses the real verifier",
              status == 200 and (payload.get("verification") or {}).get("verified") is True,
              f"HTTP {status}")

        # Corrupt only this disposable audit archive and require an honest 409.
        import sqlite3
        connection = sqlite3.connect("data/skvm.db")
        row = connection.execute(
            "select file_path from backups where backup_id = ?", (backup_id,)).fetchone()
        connection.close()
        archive = Path(row[0]) if row and row[0] else Path("")
        if archive.exists():
            archive.write_bytes(b"this is not an archive")
            status, payload = c.call("POST", f"/api/backups/{backup_id}/verify")
            verification = payload.get("verification") or {}
            check("Verify rejects a damaged archive", status == 409
                  and verification.get("verified") is False,
                  str(payload.get("error"))[:60])
        status, payload = c.call("DELETE", f"/api/backups/{backup_id}")
        check("Delete the disposable backup", status == 200,
              f"HTTP {status}")

    # The Logs → Tasks Cancel action applies to a real queued/running operation.
    # Start an actual archive task and cancel immediately; if it won the race
    # and already finished, the API must refuse to cancel the finished task.
    cancel_resp_status, cancel_payload = c.call(
        "POST", f"/api/instances/{instance_id}/backups",
        json={"label": "audit-cancel-task"})
    cancel_backup = cancel_payload.get("backup") or {}
    cancel_task = (cancel_payload.get("task") or {}).get("task_id")
    check("Start a second real backup for the task Cancel control",
          cancel_resp_status == 202 and bool(cancel_backup.get("backup_id")),
          f"HTTP {cancel_resp_status}")
    cancel_state_ok = False
    cancel_note = "no task id"
    if cancel_task:
        cancel_status, cancel_result = c.call(
            "POST", f"/api/tasks/{cancel_task}/cancel")
        task_result = cancel_result.get("task") or {}
        if cancel_status == 200:
            cancel_state_ok = task_result.get("status") == "cancelled"
            cancel_note = f"HTTP {cancel_status}, status={task_result.get('status')}"
        elif cancel_status == 409:
            latest_status, latest = c.call("GET", f"/api/tasks/{cancel_task}")
            latest_task = latest.get("task") or {}
            cancel_state_ok = latest_status == 200 and latest_task.get("status") in (
                "success", "failed")
            cancel_note = f"already finished; HTTP {cancel_status}, {latest_task.get('status')}"
        else:
            cancel_note = f"HTTP {cancel_status}: {cancel_result.get('error')}"

        # Cancellation is a record state, not a claim that an in-flight tar
        # operation was killed. Wait until the real archive job reaches a
        # terminal file state before cleaning up the disposable snapshot.
        cancel_backup_id = cancel_backup.get("backup_id")
        deadline = time.time() + 600
        archive_status = ""
        while time.time() < deadline and cancel_backup_id:
            _, current_backups = c.call("GET", f"/api/instances/{instance_id}/backups")
            row = next((b for b in current_backups.get("backups", [])
                        if b.get("backup_id") == cancel_backup_id), {})
            archive_status = row.get("status", "")
            if archive_status in ("ready", "failed"):
                break
            time.sleep(1)
        check("Cancel task button marks work cancelled (or refuses a task that won the race)",
              cancel_state_ok, f"{cancel_note}; archive={archive_status or 'pending'}")
        if cancel_backup_id and archive_status in ("ready", "failed"):
            delete_status, _ = c.call("DELETE", f"/api/backups/{cancel_backup_id}")
            check("Clean up the disposable cancelled-task backup", delete_status == 200,
                  f"HTTP {delete_status}")

    for days in (1, 3, 7, 30):
        status, payload = c.call("POST", f"/api/instances/{instance_id}/expiry",
                                 json={"days": days})
        expiry = (payload.get("instance") or {}).get("days_to_expiry")
        check(f"Expiring VPS +{days}d button",
              status == 200 and expiry is not None and 0 <= expiry <= days,
              f"HTTP {status}, days_to_expiry={expiry}")
    expiring_page = c.page("/admin/expiring")
    check("Expiring VPS list shows the instance with its new expiry",
          expiring_page.status_code == 200 and name in expiring_page.text,
          f"HTTP {expiring_page.status_code}")
    status, payload = c.call("POST", f"/api/instances/{instance_id}/expiry",
                             json={"clear": True})
    check("Clear expiry button", status == 200
          and payload["instance"].get("expires_at") is None)

    transfer_name = f"audit-xfer-{int(time.time()) % 100000}"
    status, payload = c.call("POST", "/api/users", json={
        "username": transfer_name, "email": f"{transfer_name}@example.test",
        "password": "Audit-Transfer-Passw0rd!", "role": "user",
        "full_name": "Audit Transfer"})
    other = payload.get("user") or {}
    check("Create temporary transfer recipient", status == 201
          and other.get("username") == transfer_name, f"HTTP {status}")
    if other:
        status, payload = c.call("POST", f"/api/instances/{instance_id}/transfer",
                                 json={"owner_id": other["id"]})
        moved = status == 200 and (payload.get("instance") or {}).get("owner", {}).get("id") == other["id"]
        status_back, payload_back = c.call(
            "POST", f"/api/instances/{instance_id}/transfer",
            json={"owner_id": owner_id})
        back = (status_back == 200 and
                (payload_back.get("instance") or {}).get("owner", {}).get("id") == owner_id)
        check("Transfer ownership to another user and back", moved and back,
              f"to {transfer_name} and back")
        c.call("DELETE", f"/api/users/{other['id']}")

    status, payload = c.call("POST", f"/api/instances/{instance_id}/actions",
                             json={"action": "stop"})
    task_id = (payload.get("task") or {}).get("task_id")
    state, task = c.wait_task(task_id, timeout=300)
    _, detail = c.call("GET", f"/api/instances/{instance_id}")
    check("Stop", state == "success"
          and detail.get("instance", {}).get("status") == "stopped",
          f"task={state}; {task.get('message') or payload.get('error') or ''}"[:100])

    status, payload = c.call("POST", f"/api/instances/{instance_id}/actions",
                             json={"action": "start"})
    task_id = (payload.get("task") or {}).get("task_id")
    state, task = c.wait_task(task_id, timeout=300)
    _, detail = c.call("GET", f"/api/instances/{instance_id}")
    check("Start", state == "success"
          and detail["instance"]["status"] == "running",
          (task.get("message") or "")[:60])

    if plan_id:
        status, payload = c.call("DELETE", f"/api/plans/{plan_id}")
        check("Deleting a plan that an instance uses is refused",
              status == 409 and "still use this plan" in json.dumps(payload),
              str(payload.get("error"))[:60])

    status, payload = c.call("POST", f"/api/instances/{instance_id}/actions",
                             json={"action": "delete"})
    task_id = (payload.get("task") or {}).get("task_id")
    state, task = c.wait_task(task_id, timeout=300)
    _, listing = c.call("GET", "/api/instances")
    gone = not any(i["instance_id"] == instance_id for i in listing["instances"])
    check("Delete button (POST /actions) and it leaves the list",
          status == 202 and state == "success" and gone,
          f"HTTP {status}, task={state}, {task.get('message') or ''}"[:80])
    return {"instance_id": instance_id}


def console_test(c: Client, instance_id: str) -> tuple[bool, str]:
    """Attach a real console, run a command and read its output back."""
    try:
        from simple_websocket import Client as WSClient
    except ImportError:
        return False, "simple-websocket is not installed in this interpreter"

    cookie = "; ".join(f"{k}={v}" for k, v in c.s.cookies.get_dict().items())
    url = f"{c.ws_url}/ws/console/{instance_id}"
    try:
        ws = WSClient.connect(url, headers={"Cookie": cookie})
    except Exception as exc:  # noqa: BLE001
        return False, f"handshake failed: {type(exc).__name__}: {exc}"

    transcript = []
    try:
        deadline = time.time() + 30
        ready = None
        while time.time() < deadline and ready is None:
            message = ws.receive(timeout=10)
            if message is None:
                break
            payload = json.loads(message)
            if payload.get("type") == "error":
                return False, f"server refused: {payload.get('message')}"
            if payload.get("type") == "ready":
                ready = payload
                transcript.append(payload)
        if ready is None:
            return False, "no 'ready' frame from the server"

        # This is the exact command shipped by the UI's Run identity check.
        command = "hostname && cat /etc/os-release | head -3\n"
        ws.send(json.dumps({"type": "input", "data": command}))
        output = ""
        deadline = time.time() + 25
        while time.time() < deadline and "NAME=" not in output:
            message = ws.receive(timeout=10)
            if message is None:
                break
            payload = json.loads(message)
            if payload.get("type") == "output":
                output += payload.get("data", "")
        ws.send(json.dumps({"type": "resize", "cols": 100, "rows": 40}))
        ws.send(json.dumps({"type": "ping"}))
        ws.send(json.dumps({"type": "close"}))

        cleaned = re.sub(r"\x1b\[[0-9;?]*[a-zA-Z]", "", output)
        if "NAME=" not in cleaned:
            return False, ("identity check returned no OS release data; "
                           f"{len(cleaned)} bytes: {cleaned[-220:]!r}")
        broken_tty = ("no job control" in cleaned.lower()
                      or "cannot set terminal process group" in cleaned.lower()
                      or "getcwd: cannot access parent directories" in cleaned.lower())
        if broken_tty:
            return False, "shell connected but reported a broken PTY/cwd: " + cleaned[-220:]
        return True, (f"real PTY shell returned /etc/os-release for "
                      f"{ready.get('name')} without job-control or cwd warnings "
                      f"({len(cleaned)} bytes)")
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"
    finally:
        try:
            ws.close()
        except Exception:  # noqa: BLE001
            pass


def account_checks(c: Client) -> None:
    group("Account — profile / password / sessions")
    _, payload = c.call("GET", "/api/me")
    me = payload["user"]
    original_name, original_email = me["full_name"], me["email"]

    status, payload = c.call("PATCH", "/api/me",
                             json={"full_name": "Audited Administrator"})
    check("Save profile", status == 200
          and payload["user"]["full_name"] == "Audited Administrator")
    c.call("PATCH", "/api/me", json={"full_name": original_name})

    status, payload = c.call("POST", "/api/me/password", json={
        "current_password": c.password, "new_password": "Audit-Rotated-Passw0rd!"})
    rotated = status == 200
    check("Update password", rotated,
          json.dumps(payload.get("error", ""))[:60])
    if rotated:
        fresh = Client(c.base, c.username, "Audit-Rotated-Passw0rd!")
        try:
            fresh.login()
            check("The new password works", True)
        except SystemExit as exc:
            check("The new password works", False, str(exc))
        status, payload = fresh.call("POST", "/api/me/password", json={
            "current_password": "Audit-Rotated-Passw0rd!",
            "new_password": c.password})
        check("Password restored", status == 200)
        c.login()

    status, payload = c.call("DELETE", "/api/console/sessions")
    check("Close all of my console sessions", status == 200,
          f"{payload.get('closed', '?')} closed")

    status, payload = c.call("POST", "/api/me/password", json={
        "current_password": "definitely-wrong", "new_password": "Whatever-Passw0rd!"})
    check("Wrong current password is refused", status == 403, f"{status}")

    logout_page = c.page("/logout")
    logout_csrf = c.csrf(logout_page.text)
    logout = c.s.post(f"{c.base}/logout", data={"csrf_token": logout_csrf},
                      allow_redirects=False, timeout=30)
    check("Sign out confirmation form ends the session",
          logout_page.status_code == 200 and logout.status_code in (302, 303)
          and "/login" in logout.headers.get("Location", ""),
          f"page={logout_page.status_code}, POST={logout.status_code} → "
          f"{logout.headers.get('Location', '')}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=BASE_URL)
    parser.add_argument("--username", default="admin")
    parser.add_argument("--password", default="")
    parser.add_argument("--skip-provision", action="store_true")
    args = parser.parse_args()

    password = args.password
    if not password:
        env = Path(".env")
        if env.exists():
            for line in env.read_text().splitlines():
                if line.startswith("SKVM_ADMIN_PASSWORD="):
                    password = line.split("=", 1)[1].strip().strip('"')
    if not password:
        print("need --password or SKVM_ADMIN_PASSWORD in .env", file=sys.stderr)
        return 2

    c = Client(args.url, args.username, password)
    c.login()
    print(f"\nAuditing {args.url} as {args.username}")

    ui_wiring_checks()
    page_checks(c)
    plan_checks_result = plan_checks(c)
    node_checks(c)
    image = image_checks(c)
    user = user_checks(c)
    token_checks(c)
    settings_checks(c)
    maintenance_checks(c)

    _, me = c.call("GET", "/api/me")
    owner_id = me["user"]["id"]
    if args.skip_provision:
        group("Instance lifecycle")
        check("Skipped (--skip-provision)", True)
    else:
        image_id = (image or {}).get("pulled_image_id") or (image or {}).get("image_id")
        _, listing = c.call("GET", "/api/images")
        if image_id and not any(i["id"] == image_id for i in listing["images"]):
            image_id = None          # the row was removed; pick a live one instead
        if not image_id:
            cached = [i for i in listing["images"] if i.get("cached")]
            image_id = cached[0]["id"] if cached else None
        if image_id is None:
            group("Instance lifecycle")
            check("Instance lifecycle", False, "no usable image available")
        else:
            plan_id = (plan_checks_result or {}).get("plan_id")
            instance_checks(c, owner_id, image_id, plan_id=plan_id)
            if plan_id:
                status, payload = c.call("DELETE", f"/api/plans/{plan_id}")
                check("Delete the plan once it is free again", status == 200,
                      f"{status}")

    # If provisioning was skipped or failed, still remove the image that the
    # audit pulled; delete also clears its real on-disk cache.
    pulled_image_id = (image or {}).get("pulled_image_id")
    if pulled_image_id:
        c.call("DELETE", f"/api/images/{pulled_image_id}")

    account_checks(c)

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = [r for r in RESULTS if not r[1]]
    print("\n" + "=" * 74)
    print(f"CHECKED {len(RESULTS)} things — {passed} passed, {len(failed)} failed")
    if failed:
        print("\nFailures:")
        for name, _, note in failed:
            print(f"  - {name}: {note}")
        return 1
    print("all server-backed controls were exercised; browser-only controls were verified against their handlers")
    return 0


if __name__ == "__main__":
    sys.exit(main())
