#!/usr/bin/env python3
"""
Real HTTP smoke test against a running SKVM panel.

Unlike the pytest suite (which drives Flask's test client), this talks to the
panel over TCP, exactly like a browser: it completes the setup wizard if the
panel has no administrator yet, signs in, and then requests every page and the
main API endpoints, checking that each one answers and that no page leaks a
traceback.

    python3 scripts/smoke.py                       # http://127.0.0.1:5555
    python3 scripts/smoke.py --url http://host:5555 --token <SETUP_TOKEN>
    python3 scripts/smoke.py --username admin --password '…'
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import time
from pathlib import Path

import requests

PAGES = [
    "/", "/vps/", "/admin/vps", "/admin/vps/create", "/admin/expiring",
    "/admin/users", "/admin/plans", "/admin/nodes", "/admin/images",
    "/admin/settings", "/admin/system", "/admin/logs", "/admin/backups",
    "/admin/maintenance", "/admin/api-management", "/profile/",
    "/profile/security",
]

APIS = [
    "/healthz", "/api/", "/api/me", "/api/system/capabilities",
    "/api/system/metrics", "/api/instances", "/api/plans", "/api/nodes",
    "/api/images", "/api/users", "/api/settings", "/api/tasks", "/api/logs",
    "/api/backups", "/api/tokens", "/api/summary", "/api/system/nodes",
    "/api/system/processes",
]

CSRF_RE = re.compile(r'name="csrf_token"[^>]*value="([^"]+)"')
META_RE = re.compile(r'name="csrf-token" content="([^"]+)"')


class Smoke:
    def __init__(self, base: str, token: str = "", username: str = "",
                 password: str = "", insecure: bool = False):
        self.base = base.rstrip("/")
        self.token = token
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.session.verify = not insecure
        self.failures: list[str] = []
        self.notes: list[str] = []

    # ------------------------------------------------------------------ utils
    def csrf(self, html: str) -> str:
        for pattern in (CSRF_RE, META_RE):
            match = pattern.search(html)
            if match:
                return match.group(1)
        return ""

    def check(self, response, path: str, expect: tuple[int, ...] = (200,)) -> None:
        status = response.status_code
        if status == 429:
            # The panel is doing its job: it is rate limiting this client.
            self.failures.append(f"{path} -> 429 (rate limited; retry in a minute)")
            print(f"  [rate] {status} {path}")
            return
        ok = status in expect
        marker = "ok  " if ok else "FAIL"
        print(f"  [{marker}] {status} {path}")
        if not ok:
            self.failures.append(f"{path} -> {status}")
            return
        # The log viewer renders real log lines, which may legitimately quote a
        # traceback from an earlier failure — everything else must be clean.
        if "text/html" in response.headers.get("Content-Type", "") and path != "/admin/logs":
            body = response.text
            for bad in ("jinja2.exceptions", "UndefinedError", "Traceback (most recent"):
                if bad in body:
                    self.failures.append(f"{path} contains {bad}")
                    print(f"  [FAIL] {path} contains {bad}")

    # ------------------------------------------------------------------- flow
    def run(self) -> int:
        print(f"SKVM smoke test against {self.base}")
        print("\n-- reachability")
        try:
            health = self.session.get(f"{self.base}/healthz", timeout=15)
        except requests.RequestException as exc:
            print(f"  [FAIL] cannot reach the panel: {exc}")
            return 2
        self.check(health, "/healthz")
        try:
            data = health.json()
            print(f"     app={data.get('app')} version={data.get('version')} "
                  f"db={data.get('database', {}).get('ok')}")
            runtime = data.get("runtime") or {}
            print(f"     runtime={runtime.get('provider')} "
                  f"can_provision={runtime.get('can_provision')}")
            for diag in runtime.get("providers", []):
                if not diag.get("available"):
                    print(f"       - {diag['name']}: {diag.get('reason')}")
        except ValueError:
            self.failures.append("health endpoint did not return JSON")

        print("\n-- setup wizard")
        login_page = self.session.get(f"{self.base}/setup", timeout=15)
        if login_page.status_code == 200 and "setup token" in login_page.text.lower():
            if not self.token:
                print("  [skip] the panel still needs setup and no --token was given")
            else:
                csrf = self.csrf(login_page.text)
                response = self.session.post(
                    f"{self.base}/setup",
                    data={"csrf_token": csrf, "setup_token": self.token,
                          "username": self.username or "admin",
                          "email": "admin@example.com",
                          "password": self.password or "SmokeTest-Passw0rd!",
                          "confirm": self.password or "SmokeTest-Passw0rd!",
                          "full_name": "Smoke Admin"},
                    timeout=30, allow_redirects=False)
                if response.status_code in (200, 302):
                    print(f"  [ok  ] {response.status_code} administrator created")
                    self.password = self.password or "SmokeTest-Passw0rd!"
                else:
                    self.failures.append(f"setup failed with {response.status_code}")
                    print(f"  [FAIL] {response.status_code} setup")
        else:
            print("  [ok  ] setup already completed")

        print("\n-- sign in")
        page = self.session.get(f"{self.base}/login", timeout=15)
        response = self.session.post(
            f"{self.base}/login",
            data={"csrf_token": self.csrf(page.text),
                  "username": self.username or "admin",
                  "password": self.password or os.environ.get("SKVM_SMOKE_PASSWORD", "")},
            timeout=30, allow_redirects=False)
        if response.status_code in (302, 303) and "/login" not in response.headers.get(
                "Location", ""):
            print(f"  [ok  ] {response.status_code} signed in")
        else:
            print(f"  [FAIL] sign-in returned {response.status_code} "
                  f"({response.headers.get('Location', '')})")
            self.failures.append("sign-in failed")
            return 1 if self.failures else 0

        print("\n-- pages (must render, not bounce back to /login)")
        for path in PAGES:
            response = self.session.get(f"{self.base}{path}", timeout=30,
                                        allow_redirects=False)
            if response.status_code in (301, 302, 303) and "/login" in \
                    response.headers.get("Location", ""):
                self.failures.append(f"{path} redirected to /login while signed in")
                print(f"  [FAIL] {response.status_code} {path} -> login")
            else:
                self.check(response, path, expect=(200, 301, 302))
            time.sleep(0.05)

        print("\n-- api")
        for path in APIS:
            self.check(self.session.get(f"{self.base}{path}", timeout=30), path)
            time.sleep(0.05)

        print()
        if self.failures:
            print(f"FAILED ({len(self.failures)}):")
            for failure in self.failures:
                print(f"  - {failure}")
            return 1
        print("all checks passed")
        return 0


def main() -> int:
    env_file = Path(__file__).resolve().parent.parent / ".env"
    token = ""
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if line.startswith("SKVM_SETUP_TOKEN="):
                token = line.split("=", 1)[1].strip().strip('"')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default=os.environ.get(
        "SKVM_URL", "http://127.0.0.1:5555"))
    parser.add_argument("--token", default=token)
    parser.add_argument("--username", default=os.environ.get("SKVM_SMOKE_USER", "admin"))
    parser.add_argument("--password", default=os.environ.get("SKVM_SMOKE_PASSWORD", ""))
    parser.add_argument("--insecure", action="store_true",
                        help="skip TLS verification")
    args = parser.parse_args()
    return Smoke(args.url, args.token, args.username, args.password,
                 args.insecure).run()


if __name__ == "__main__":
    sys.exit(main())
