#!/usr/bin/env python3
"""
Fetch the vendored front-end assets.

The panel never loads anything from a CDN at runtime: the preview iframe (and
locked-down servers in general) have no outbound network, so Tailwind, Lucide
and xterm.js are served from ``skvm/static/vendor/``.

    python3 scripts/fetch_vendor.py [--force]

Missing files are downloaded; existing files are left alone unless --force is
given.  Failure is not fatal — the panel renders with its own CSS and an inline
icon sprite, and the console page explains that xterm.js is missing.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.error
import urllib.request
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
VENDOR_DIR = PROJECT / "skvm" / "static" / "vendor"

ASSETS: list[tuple[str, str, int]] = [
    # filename, url, minimum plausible size in bytes
    ("tailwind.min.js",
     "https://cdn.tailwindcss.com/3.4.17", 200_000),
    ("lucide.min.js",
     "https://cdn.jsdelivr.net/npm/lucide@0.469.0/dist/umd/lucide.min.js", 150_000),
    ("xterm.js",
     "https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/lib/xterm.js", 100_000),
    ("xterm.css",
     "https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/css/xterm.css", 1_000),
    ("addon-fit.js",
     "https://cdn.jsdelivr.net/npm/@xterm/addon-fit@0.10.0/lib/addon-fit.js", 500),
    ("addon-web-links.js",
     "https://cdn.jsdelivr.net/npm/@xterm/addon-web-links@0.11.0/lib/addon-web-links.js", 500),
]


def fetch(url: str, timeout: int = 60) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "skvm-installer/1.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true",
                        help="re-download files that already exist")
    args = parser.parse_args()

    VENDOR_DIR.mkdir(parents=True, exist_ok=True)
    failures: list[str] = []
    for name, url, minimum in ASSETS:
        target = VENDOR_DIR / name
        if target.exists() and target.stat().st_size >= minimum and not args.force:
            print(f"present  {name} ({target.stat().st_size} bytes)")
            continue
        try:
            payload = fetch(url)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            print(f"FAILED   {name}: {exc}", file=sys.stderr)
            failures.append(name)
            continue
        if len(payload) < minimum:
            print(f"FAILED   {name}: got only {len(payload)} bytes from {url}",
                  file=sys.stderr)
            failures.append(name)
            continue
        target.write_bytes(payload)
        digest = hashlib.sha256(payload).hexdigest()[:16]
        print(f"fetched  {name} ({len(payload)} bytes, sha256:{digest}…)")

    if failures:
        print("missing: " + ", ".join(failures), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
