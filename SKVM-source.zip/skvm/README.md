# SKVM — Virtual Private Server Control Plane

SKVM is a self-hosted panel that provisions and manages **Linux containers** on
the machine it runs on: it pulls real OCI images, materialises a root
filesystem, starts the instance under its own namespaces with kernel-enforced
resource limits, gives you a genuine PTY console and file manager, and reports
resource usage measured from the kernel.

Everything in the UI is backed by live data. There are no mock metrics, no
placeholder addresses, no invented credentials and no buttons that do nothing.

---

## 1. Install and run

```bash
chmod +x install.sh && ./install.sh
```

The installer is idempotent — run it as often as you like. It:

1. checks the Python version (3.9+; tested on 3.13),
2. creates/reuses `.venv` and installs `requirements.txt`,
3. writes `.env` with freshly generated `SKVM_SECRET_KEY` and `SKVM_SETUP_TOKEN`
   (an existing `.env` is never overwritten),
4. creates the data directories (`data/{instances,images,backups,logs,run,tmp}`),
5. verifies the vendored front-end assets, downloading any that are missing,
6. initialises the SQLite schema and seeds the default plans, images and node,
7. optionally creates the first administrator from `SKVM_ADMIN_*` in `.env`,
8. starts the panel bound to `0.0.0.0:$PORT` (default **5555**), performs a real
   `/healthz` check, and prints the URL it actually answers on — including the
   forwarded preview URL when it detects a sandbox host.

Useful commands:

```bash
./install.sh --foreground      # run in this terminal (Ctrl+C stops it)
./install.sh --no-start        # install only
./install.sh --stop | --restart | --status | --logs
./install.sh --port 8080       # change the port (persisted to .env)
```

`--status` performs a real health request, so it tells you the truth about
whether the panel is up rather than whether a pid file exists.

Then open the URL printed by the installer:

* **first run** — `/setup` asks for the one-time token from `.env`
  (`SKVM_SETUP_TOKEN`; it is consumed on use) and creates the administrator,
* **after that** — `/login`.

### Manual start / production variants

```bash
.venv/bin/python run.py                      # Werkzeug, threaded, WebSocket-capable
gunicorn --bind 0.0.0.0:5555 --worker-class gevent --workers 1 wsgi:app
```

The interactive console needs a WSGI server that can upgrade WebSocket.
Werkzeug (used by `run.py`) can; gunicorn needs the gevent worker
(`pip install gevent`) — with the default sync/gthread workers the HTTP panel
works but the console cannot upgrade, and the console page says so.

---

## 2. What "VPS" means here — and what it does not

SKVM provisions **containers**, not KVM virtual machines. The three candidate
backends are probed on every start, in the order `docker,lxc,namespace`
(configurable via `SKVM_PROVIDER_ORDER`), and the first one that genuinely
works is used:

| Backend | Requires | What the instance is |
|---|---|---|
| `docker` | a Docker daemon socket | Docker container sharing the host kernel |
| `lxc` | `lxc-start`, `lxc-info`, `lxc-ls`, cgroup v2 | LXC system container sharing the host kernel |
| `namespace` | passwordless sudo + user/PID/mount/UTS/IPC/net namespaces + cgroup v2 | container built directly from namespaces, veth pair and NAT egress |

Rules the code enforces:

* `is_virtual_machine` is `True` **only** for `vm_kvm`; every container kind
  reports `False`, and the UI labels instances as containers everywhere
  (Dashboard, instance list, detail page, create form, capability banner).
* If no backend is available, the instance list and the create page say so,
  listing the real reason for each candidate — provisioning is refused instead
  of pretending to succeed.
* A backend is only reported as available when its binaries, kernel features
  and privileges really answer to a live probe, not from `shutil.which` alone.
* LXCFS, when present, is used only for filesystem/resource *visibility*
  (`/proc/cpuinfo`, `/proc/meminfo` shapes inside the container). It is never
  used as, or described as, a virtualization engine.

---

## 3. Feature map

**Users and access**
* Roles: `admin`, `operator`, `user`. Only administrators create instances,
  manage users/plans/nodes/images/global settings, or perform privileged ops.
* Regular users see and control only their own instances; every route and API
  re-checks ownership and role server-side (`require_admin`, `require_operator`,
  `scoped_api`, `InstanceService.get()`).
* Password hashing with scrypt, per-account lockout after repeated failures,
  login attempts recorded with IP and user agent.
* CSRF protection on every state-changing HTML/API call, rate limits per route,
  strict CSP/`X-Frame-Options`/`nosniff` headers, same-origin checks on the
  WebSocket handshake.

**Instances**
* Create wizard with plan presets, live quota arithmetic and grouped image
  picker; the form is disabled with an explanation when no runtime is usable.
* Lifecycle: start, stop, restart, rebuild, delete (delete requires typing the
  instance name and administrator rights), transfer to another user.
* Provisioning progress is a durable task: every step the backend really
  performs is logged and streamed to the browser as it happens.
* Expiry policy: instances can carry an expiry date; a background monitor
  suspends expired instances (never deletes), and the "Expiring" page lets an
  administrator extend or clear the deadline.

**Access to the instance**
* **Console** — a real PTY inside the instance over WebSocket (xterm.js), with
  idle timeout, per-user session cap, audit records and administrator
  "close all sessions".
* **File manager** — list, read, edit, upload, download, rename, chmod and
  delete inside the instance's own filesystem (never on the host).
* **SSH information** — shows only verified facts. If no `sshd` and published
  port exist, the page says exactly what is missing and offers the console and
  file manager instead. No placeholder hostnames or credentials, ever.
* **Resource usage** — CPU, memory, disk, network and cgroup accounting with
  the sample source named; unavailable measurements are reported as
  unavailable with a reason rather than filled with zeros.

**Operations**
* Capability report (`Admin → System`) listing every probed capability, the
  provider comparison table and the diagnostics for anything missing.
* Image catalogue with real OCI pulls (token auth against
  `auth.docker.io`, layer download, cached layer count and byte size).
* Backups: real `tar.gz` snapshots of an instance root filesystem, with a
  verification action that proves the archive is a readable gzip stream; a
  backup that cannot be verified is marked `failed` with the reason.
* Task history with per-task logs, cancellation, and a startup reconciler that
  marks interrupted work as `interrupted` instead of leaving it "running".
* Audit trail of every security-relevant action, filterable and exportable.
* Structured JSON logs written to `data/logs/skvm.log` plus the console.
* REST API with bearer tokens (scopes `read`, `write`, `provision`, `admin`;
  SHA-256 hashed at rest, shown once) at `/api/`, discoverable from `/api/`.

---

## 4. Repository layout

```
install.sh              idempotent installer + launcher
run.py / wsgi.py        entry points (Werkzeug / gunicorn)
config.py               thin shim re-exporting skvm.config
skvm/
  app.py                application factory, logging, filters, health, CLI
  config.py             environment-driven configuration
  models.py             SQLAlchemy models (users, vps, tasks, images, …)
  security.py           validation, tokens, scoping and guards
  views/                HTML pages (auth, admin, instances, profile)
  api/                  REST API and the WebSocket console/task endpoints
  services/             business logic: instances, tasks, metrics, backup,
                        console (real PTY), filesystem, settings, audit
  provisioning/         capability probe, OCI client, runtime glue, manager,
                        providers/{docker,lxc,namespace}
  static/               design system CSS, JS runtime, vendored libraries
  templates/            Jinja templates (dark glassmorphism UI)
helpers/
  skvm-helper           privileged entry point (argv allowlist)
  ns-launch             namespace-container supervisor
scripts/
  fetch_vendor.py       downloads the vendored front-end assets
  smoke.py              HTTP smoke test against a running panel
tests/                  pytest suite (unit, smoke, API/security, end-to-end)
```

---

## 5. Tests

```bash
.venv/bin/python -m pytest tests -q            # fast suite
SKVM_E2E=1 .venv/bin/python -m pytest tests -q  # + real provisioning end-to-end
.venv/bin/python scripts/smoke.py              # HTTP check against a live panel
```

* `tests/test_smoke.py` renders every page with real data and asserts no
  template or context error leaks.
* `tests/test_api_security.py` drives the API as anonymous, user, operator and
  admin clients, checking authorisation, CSRF, ownership isolation and the
  token scopes.
* `tests/test_e2e_provision.py` pulls a real image, provisions a real
  container, reads its metrics, resolves the console command, lists files,
  stops and deletes it, and re-creates an instance over a running one to prove
  a retried provision cleans up first. It skips itself when the host cannot
  provision.
* `tests/test_regressions.py` pins the bugs found while auditing the running
  panel (registry probe handshake, token scopes, image-cache reconciliation,
  installer URL, orphan sweep) so they cannot come back.
* `scripts/e2e_http.py` drives the whole lifecycle over HTTP against a live
  panel: sign in, read capabilities, create an instance, follow the real task,
  verify the process/address/metrics/files, render every instance page, stop
  and delete it.

`GUIDE.md` is the user manual: every page, every button, and what each one
really does.

`AUDIT_REPORT.md` records the latest full-surface check: 184 checks, 184
passed, 0 failed, the defects fixed, and the remaining host limitations.

`VERIFICATION.md` contains the earlier infrastructure/runtime audit and its
reproduction notes.

---

## 6. Where things live on disk

```
data/skvm.db            SQLite database (WAL mode)
data/instances/<id>/    rootfs, meta.json, state.json, runtime.log per instance
data/images/<slug>/     cached OCI layers + meta.json
data/backups/           tar.gz snapshots
data/logs/skvm.log      structured application log
data/logs/server.log    stdout/stderr of the panel process
data/run/skvm.pid       pid of the installed background process
```

---

## 7. Honest limitations

* Container isolation shares the host kernel. It is not a hypervisor boundary;
  a KVM VPS cannot be offered without `/dev/kvm` and a hypervisor, so SKVM
  never claims to offer one.
* The `namespace` backend cannot enforce a per-instance **disk** quota: it
  applies `RLIMIT_FSIZE` and reports the limitation rather than pretending.
  Docker's default storage driver has the same gap and the code says so.
* Port publishing for guest services requires the docker backend. With the
  namespace backend, instances get their own IP and NAT egress on the host, and
  must be reached through the provided console/file manager.
* Inside a restricted sandbox (no Docker socket, no `/dev/kvm`, no sshd) the
  panel still runs and provisions with the namespace backend, but the
  capability report will show the missing pieces with their real reasons.

---

## 8. License

Provided as-is for self-hosting. Review `install.sh` and `helpers/` before
running the panel on a machine you care about: the privileged helper is the
only component that escalates, its argv is allowlisted, and the panel never
runs a shell on the host on behalf of a user.
