#!/usr/bin/env bash
#
# SKVM installer / launcher.
#
#   chmod +x install.sh && ./install.sh
#
# Idempotent: run it as often as you like.  It creates (or reuses) a virtual
# environment, writes .env with freshly generated secrets the first time,
# creates the data directories, verifies the vendored front-end assets,
# initialises the database, and then starts the panel bound to 0.0.0.0:$PORT,
# printing the real URL and the result of a real health check.
#
# Commands:
#   ./install.sh                 install (if needed) and start
#   ./install.sh --foreground    install and run in this terminal
#   ./install.sh --no-start      install only
#   ./install.sh --stop          stop a running panel
#   ./install.sh --restart       stop, then start
#   ./install.sh --status        report whether the panel answers
#   ./install.sh --logs          tail the panel log
#   ./install.sh --port 8080     use a different port
#   ./install.sh --no-vendor     do not try to (re)download vendor assets
#
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

VENV_DIR="$PROJECT_DIR/.venv"
PY="$VENV_DIR/bin/python"
ENV_FILE="$PROJECT_DIR/.env"
PID_FILE="$PROJECT_DIR/data/run/skvm.pid"
SERVER_LOG="$PROJECT_DIR/data/logs/server.log"
REQUIRED_PY_MAJOR=3
REQUIRED_PY_MINOR=9

ACTION="start"
START_MODE="background"
PORT_OVERRIDE=""
DO_VENDOR=1

# ---------------------------------------------------------------- arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --foreground) START_MODE="foreground" ;;
    --no-start)   ACTION="install" ;;
    --stop)       ACTION="stop" ;;
    --restart)    ACTION="restart" ;;
    --status)     ACTION="status" ;;
    --logs)       ACTION="logs" ;;
    --no-vendor)  DO_VENDOR=0 ;;
    --port)       PORT_OVERRIDE="${2:-}"; shift ;;
    --port=*)     PORT_OVERRIDE="${1#*=}" ;;
    -h|--help)    sed -n '2,25p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1 (try --help)" >&2; exit 2 ;;
  esac
  shift
done

say()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }
ok()   { printf '\033[1;32m[ok]\033[0m %s\n' "$*"; }

# ------------------------------------------------------------------ helpers
port_in_use() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    ss -ltn 2>/dev/null | awk '{print $4}' | grep -qE "[:.]${port}$"
    return $?
  fi
  "$PY" - "$port" <<'PYEOF' 2>/dev/null
import socket, sys
port = int(sys.argv[1])
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
try:
    s.bind(("0.0.0.0", port))
except OSError:
    sys.exit(0)
sys.exit(1)
PYEOF
}

panel_pid() {
  [ -f "$PID_FILE" ] || return 1
  local pid
  pid="$(cat "$PID_FILE" 2>/dev/null || true)"
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null || return 1
  echo "$pid"
}

panel_url() {
  # The port must be the one the panel is *actually* listening on: it is passed
  # in by every caller. Reading only the environment silently produced a URL for
  # 5555 even when a port conflict had moved the panel to 5556.
  local port="${1:-${SKVM_PORT:-${PORT:-5555}}}"
  local host
  host="$("$PY" - "$port" <<'PYEOF' 2>/dev/null || true
import os, socket, sys

port = sys.argv[1]
host = os.environ.get("SKVM_PUBLIC_HOST", "").strip()
if host:
    scheme = "https" if host.endswith(".e2b.app") or host.startswith("https://") else "http"
    if host.startswith("http://") or host.startswith("https://"):
        print(f"{host.rstrip('/')}:{port}" if host.count(":") <= 2 else host.rstrip("/"))
    else:
        print(f"{scheme}://{host}:{port}")
    raise SystemExit

sandbox = os.environ.get("E2B_SANDBOX_ID", "").strip()
if sandbox:
    # E2B forwards every listening port on its own subdomain, so a sandbox
    # panel is reachable over https on the port-specific hostname.
    print(f"https://{port}-{sandbox}.e2b.app")
    raise SystemExit

try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("1.1.1.1", 80))
    ip = s.getsockname()[0]
    s.close()
except OSError:
    ip = "127.0.0.1"
print(f"http://{ip}:{port}")
PYEOF
)"
  [ -n "$host" ] || host="http://127.0.0.1:$port"
  echo "$host"
}

# A python interpreter that exists even before the venv is built, so that
# --status / --stop work on a machine where the venv was removed.
pybin() {
  if [ -x "$PY" ]; then echo "$PY"; else echo "${SYSTEM_PY:-python3}"; fi
}

# ---------------------------------------------------------------------- env
if [ ! -f "$ENV_FILE" ]; then
  say "generating .env with fresh secrets"
  cp .env.example "$ENV_FILE"
  SECRET="$("$PY" -c 'import secrets; print(secrets.token_hex(32))')"
  SETUP="$("$PY" -c 'import secrets; print(secrets.token_urlsafe(24))')"
  "$PY" - "$ENV_FILE" "$SECRET" "$SETUP" <<'PYEOF'
import pathlib, sys
path = pathlib.Path(sys.argv[1])
secret, setup = sys.argv[2], sys.argv[3]
text = path.read_text()
text = text.replace("SKVM_SECRET_KEY=\n", f"SKVM_SECRET_KEY={secret}\n")
text = text.replace("SKVM_SETUP_TOKEN=\n", f"SKVM_SETUP_TOKEN={setup}\n")
path.write_text(text)
PYEOF
  ok "wrote $ENV_FILE"
else
  say ".env already exists — keeping your values"
  if ! grep -qE '^SKVM_SECRET_KEY=.+' "$ENV_FILE"; then
    SECRET="$("$PY" -c 'import secrets; print(secrets.token_hex(32))')"
    "$PY" - "$ENV_FILE" "$SECRET" <<'PYEOF'
import pathlib, sys
path = pathlib.Path(sys.argv[1])
text = path.read_text()
path.write_text(text.replace("SKVM_SECRET_KEY=\n", f"SKVM_SECRET_KEY={sys.argv[2]}\n"))
PYEOF
    ok "generated a missing SKVM_SECRET_KEY"
  fi
fi

if [ -n "$PORT_OVERRIDE" ]; then
  if grep -qE '^PORT=' "$ENV_FILE"; then
    "$PY" - "$ENV_FILE" "$PORT_OVERRIDE" <<'PYEOF'
import pathlib, re, sys
path = pathlib.Path(sys.argv[1])
text = re.sub(r"^PORT=.*$", f"PORT={sys.argv[2]}", path.read_text(), flags=re.M)
path.write_text(text)
PYEOF
  else
    printf '\nPORT=%s\n' "$PORT_OVERRIDE" >> "$ENV_FILE"
  fi
  ok "port set to $PORT_OVERRIDE in .env"
fi

# .env is read with a parser rather than `source`d: values may contain spaces
# or characters that a shell would try to execute, and the panel reads the file
# itself through python-dotenv.
read_env() {
  "$(pybin)" - "$ENV_FILE" "$1" "$2" <<'PYEOF'
import pathlib, sys
path, key, default = pathlib.Path(sys.argv[1]), sys.argv[2], sys.argv[3]
value = default
for line in path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    name, _, raw = line.partition("=")
    if name.strip() == key:
        value = raw.strip().strip('"').strip("'")
print(value)
PYEOF
}


health_check() {
  local port="${1:-5555}" tries="${2:-40}"
  for _ in $(seq 1 "$tries"); do
    if "$(pybin)" - "$port" <<'PYEOF' 2>/dev/null
import json, sys, urllib.request
port = sys.argv[1]
try:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/healthz", timeout=3) as r:
        data = json.loads(r.read().decode())
except Exception:
    sys.exit(1)
sys.exit(0 if data.get("ok") else 1)
PYEOF
    then
      return 0
    fi
    sleep 0.75
  done
  return 1
}

status_panel() {
  local port
  port="$(read_env PORT 5555)"
  port="${port:-5555}"
  local pid
  if pid="$(panel_pid)"; then
    say "panel process is alive (pid $pid)"
  else
    warn "no pid file / process for the panel"
  fi
  if health_check "$port" 4; then
    ok "health check passed: $(panel_url "$port")/healthz"
  else
    warn "the panel did not answer on port $port"
    return 1
  fi
}

stop_panel() {
  local pid
  if ! pid="$(panel_pid)"; then
    say "no running panel found (nothing to stop)"
    return 0
  fi
  say "stopping panel (pid $pid)"
  kill "$pid" 2>/dev/null || true
  for _ in $(seq 1 20); do
    kill -0 "$pid" 2>/dev/null || break
    sleep 0.25
  done
  if kill -0 "$pid" 2>/dev/null; then
    warn "the panel ignored SIGTERM — sending SIGKILL"
    kill -9 "$pid" 2>/dev/null || true
  fi
  rm -f "$PID_FILE"
  ok "panel stopped"
}

# ------------------------------------------------------------------ logging
tail_logs() {
  [ -f "$SERVER_LOG" ] || die "no server log yet at $SERVER_LOG"
  exec tail -f "$SERVER_LOG"
}

case "$ACTION" in
  stop)    stop_panel; exit 0 ;;
  logs)    tail_logs ;;
  status)  status_panel; exit $? ;;
  restart) stop_panel ;;
esac

echo
say "SKVM installer — $PROJECT_DIR"

# ------------------------------------------------------------------- python
if command -v python3 >/dev/null 2>&1; then
  SYSTEM_PY="$(command -v python3)"
else
  die "python3 is required but was not found on PATH"
fi
if ! "$SYSTEM_PY" -c "import sys; sys.exit(0 if sys.version_info >= ($REQUIRED_PY_MAJOR, $REQUIRED_PY_MINOR) else 1)"; then
  die "python >= $REQUIRED_PY_MAJOR.$REQUIRED_PY_MINOR is required (found $("$SYSTEM_PY" -V 2>&1))"
fi
ok "python: $("$SYSTEM_PY" -V 2>&1)"

# --------------------------------------------------------------------- venv
if [ ! -x "$PY" ]; then
  say "creating virtual environment in .venv"
  "$SYSTEM_PY" -m venv "$VENV_DIR" 2>/dev/null || die "could not create a virtual environment (is python3-venv installed?)"
fi
ok "virtual environment ready"

say "installing python dependencies (this is a no-op when they are present)"
"$PY" -m pip install --quiet --upgrade pip >/dev/null 2>&1 || warn "pip self-upgrade skipped"
if ! "$PY" -m pip install --quiet -r requirements.txt; then
  die "dependency installation failed — check your network or proxy settings"
fi
ok "dependencies installed"

PORT="$(read_env PORT 5555)"
HOST="$(read_env HOST 0.0.0.0)"
PORT="${PORT:-5555}"
HOST="${HOST:-0.0.0.0}"

# ------------------------------------------------------------------- layout
say "preparing data directories"
"$PY" - <<'PYEOF'
from skvm.config import Config
Config.ensure_dirs()
print("data:", Config.DATA_DIR)
PYEOF
ok "data layout ready"

# ------------------------------------------------------------ vendor assets
if [ "$DO_VENDOR" -eq 1 ]; then
  MISSING=""
  for asset in static/vendor/tailwind.min.js static/vendor/lucide.min.js \
               static/vendor/xterm.js static/vendor/xterm.css \
               static/vendor/addon-fit.js; do
    [ -s "$PROJECT_DIR/skvm/$asset" ] || MISSING="$MISSING $asset"
  done
  if [ -n "$MISSING" ]; then
    say "fetching missing front-end assets:$MISSING"
    "$PY" scripts/fetch_vendor.py || warn "vendor download failed — the panel still works (the console degrades gracefully)"
  else
    ok "vendored front-end assets present"
  fi
fi

# ------------------------------------------------------------------ database
say "initialising the database"
"$PY" - <<'PYEOF'
from skvm.app import create_app
from skvm.services.bootstrap import create_schema, seed, setup_state

app = create_app()
with app.app_context():
    create_schema(app)
    report = seed()
    state = setup_state(app)
print(f"schema ready; seed={report}; admin_exists={state['admin_exists']}")
PYEOF
ok "database ready"

# --------------------------------------------------------------- first admin
if [ -n "${SKVM_ADMIN_USERNAME:-}" ] && [ -n "${SKVM_ADMIN_PASSWORD:-}" ]; then
  say "creating the initial administrator '$SKVM_ADMIN_USERNAME' if needed"
  "$PY" - <<'PYEOF' || warn "could not create the administrator automatically"
import os
from skvm.app import create_app
from skvm.models import User
from skvm.services.bootstrap import create_admin

app = create_app()
with app.app_context():
    if User.query.filter_by(username=os.environ["SKVM_ADMIN_USERNAME"]).first():
        print("administrator already exists — left untouched")
    else:
        create_admin(os.environ["SKVM_ADMIN_USERNAME"],
                     os.environ.get("SKVM_ADMIN_EMAIL") or os.environ["SKVM_ADMIN_USERNAME"] + "@localhost",
                     os.environ["SKVM_ADMIN_PASSWORD"])
        print("administrator created")
PYEOF
fi

if [ "$ACTION" = "install" ]; then
  echo
  ok "installation complete — start it later with ./install.sh"
  exit 0
fi

if [ "$START_MODE" = "foreground" ]; then
  echo
  say "starting the panel in the foreground (Ctrl+C to stop)"
  exec "$PY" run.py
fi

# ------------------------------------------------------------------- launch
candidate_port="$PORT"
if port_in_use "$candidate_port"; then
  if pid="$(panel_pid)"; then
    say "panel is already running (pid $pid) — restarting it"
    stop_panel
  else
    warn "port $candidate_port is already in use by another process"
    for p in $(seq $((candidate_port + 1)) $((candidate_port + 20))); do
      if ! port_in_use "$p"; then candidate_port="$p"; break; fi
    done
    [ "$candidate_port" != "$PORT" ] && say "using port $candidate_port instead" \
      || die "no free port found near $PORT"
    "$PY" - "$ENV_FILE" "$candidate_port" <<'PYEOF'
import pathlib, re, sys
path = pathlib.Path(sys.argv[1])
path.write_text(re.sub(r"^PORT=.*$", f"PORT={sys.argv[2]}", path.read_text(), flags=re.M))
PYEOF
    PORT="$candidate_port"
  fi
fi

mkdir -p "$PROJECT_DIR/data/run" "$PROJECT_DIR/data/logs"
say "starting SKVM on $HOST:$PORT"
: > "$SERVER_LOG"
HOST="$HOST" PORT="$PORT" nohup "$PY" run.py >>"$SERVER_LOG" 2>&1 &
echo $! > "$PID_FILE"
sleep 1

if panel_pid >/dev/null; then
  ok "panel process started (pid $(cat "$PID_FILE"))"
else
  warn "the panel exited immediately — last log lines:"
  tail -n 30 "$SERVER_LOG" >&2 || true
  exit 1
fi

if health_check "$PORT" 40; then
  URL="$(panel_url "$PORT")"
  echo
  ok "health check passed"
  echo   "     panel : $URL"
  echo   "     health: $URL/healthz"
  echo   "     log   : $SERVER_LOG"
  if "$PY" - "$PORT" <<'PYEOF' 2>/dev/null
import json, sys, urllib.request
try:
    with urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/healthz", timeout=4) as r:
        data = json.loads(r.read().decode())
except Exception:
    sys.exit(1)
runtime = data.get("runtime") or {}
print("     runtime:", runtime.get("provider") or "unavailable",
      "| can_provision:", runtime.get("can_provision"))
for diag in runtime.get("providers", []):
    if not diag.get("available"):
        print(f"       - {diag['name']}: {diag.get('reason', 'unavailable')}")
PYEOF
  then :; fi
  echo
  say "next steps"
  ADMIN_STATE="$("$PY" - <<'PYEOF' 2>/dev/null || echo unknown
from skvm.app import create_app
from skvm.services.bootstrap import admin_exists

app = create_app()
with app.app_context():
    print("yes" if admin_exists() else "no")
PYEOF
)"
  if [ "$ADMIN_STATE" = "no" ]; then
    echo "     1. open $URL/setup and finish the wizard"
    TOKEN="$(read_env SKVM_SETUP_TOKEN '')"
    [ -n "$TOKEN" ] && echo "        setup token (from .env, consumed once): $TOKEN"
  else
    echo "     1. sign in at $URL/login with the administrator account you created"
    echo "        (forgot it? ./install.sh --status shows whether an admin exists;"
    echo "         use 'flask --app wsgi create-admin' to add another one)"
  fi
  echo "     2. read the capability report (Admin → System) to see which container"
  echo "        backends this host really supports"
  echo "     3. ./install.sh --stop | --restart | --status | --logs"
  echo
else
  warn "the panel did not answer /healthz within 30s — check $SERVER_LOG"
  tail -n 20 "$SERVER_LOG" >&2 || true
  exit 1
fi
