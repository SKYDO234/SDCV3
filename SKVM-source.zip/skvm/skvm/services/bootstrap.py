"""
Database bootstrap: schema creation plus genuine seed data.

Seeded rows describe real, pullable images (Ubuntu 20.04/22.04, Debian 11/12)
but start with status `not_downloaded`.  A row only becomes `ready` after the
panel actually downloaded the layers — the UI never shows a fake "available".
"""
from __future__ import annotations

import logging
import os
import secrets
from datetime import timedelta

from sqlalchemy import inspect as sa_inspect

from ..extensions import db
from ..models import Node, OSImage, Plan, Setting, TaskStatus, User, Role, utcnow
from . import settings_service

logger = logging.getLogger("skvm.bootstrap")

SUPPORTED_IMAGES = [
    {
        "name": "Ubuntu", "slug": "ubuntu-20.04", "family": "ubuntu",
        "version": "20.04", "codename": "focal",
        "reference": "library/ubuntu:20.04", "default_user": "root",
        "sort_order": 10,
    },
    {
        "name": "Ubuntu", "slug": "ubuntu-22.04", "family": "ubuntu",
        "version": "22.04", "codename": "jammy",
        "reference": "library/ubuntu:22.04", "default_user": "root",
        "sort_order": 20,
    },
    {
        "name": "Debian", "slug": "debian-11", "family": "debian",
        "version": "11", "codename": "bullseye",
        "reference": "library/debian:11", "default_user": "root",
        "sort_order": 30,
    },
    {
        "name": "Debian", "slug": "debian-12", "family": "debian",
        "version": "12", "codename": "bookworm",
        "reference": "library/debian:12", "default_user": "root",
        "sort_order": 40,
    },
]

DEFAULT_PLANS = [
    {"name": "Nano", "slug": "nano", "vcpu": 1, "memory_mb": 512,
     "disk_gb": 5, "price_monthly": 0.0, "sort_order": 10,
     "description": "Smallest instance — smoke tests and tiny services."},
    {"name": "Micro", "slug": "micro", "vcpu": 1, "memory_mb": 1024,
     "disk_gb": 10, "price_monthly": 0.0, "sort_order": 20,
     "description": "One vCPU and 1 GiB RAM for small workloads."},
    {"name": "Small", "slug": "small", "vcpu": 2, "memory_mb": 2048,
     "disk_gb": 20, "price_monthly": 0.0, "sort_order": 30,
     "description": "Two vCPUs and 2 GiB RAM — general purpose."},
    {"name": "Medium", "slug": "medium", "vcpu": 4, "memory_mb": 4096,
     "disk_gb": 40, "price_monthly": 0.0, "sort_order": 40,
     "description": "Four vCPUs and 4 GiB RAM for heavier services."},
]


def create_schema(app) -> list[str]:
    """Create any missing tables.  Safe to run on every start (idempotent)."""
    created: list[str] = []
    inspector = sa_inspect(db.engine)
    existing = set(inspector.get_table_names())
    db.create_all()
    after = set(sa_inspect(db.engine).get_table_names())
    created = sorted(after - existing)
    if created:
        logger.info("created tables: %s", ", ".join(created))
    return created


def seed() -> dict:
    """Idempotent seeding of settings, images, plans and the local node."""
    report = {"settings": settings_service.seed_defaults(), "images": 0,
              "plans": 0, "node": False}

    for item in SUPPORTED_IMAGES:
        if not OSImage.query.filter_by(slug=item["slug"]).first():
            db.session.add(OSImage(status="not_downloaded",
                                   status_detail="not downloaded yet",
                                   **item))
            report["images"] += 1

    for item in DEFAULT_PLANS:
        if not Plan.query.filter_by(slug=item["slug"]).first():
            db.session.add(Plan(**item))
            report["plans"] += 1

    if not Node.query.filter_by(is_local=True).first():
        import socket

        db.session.add(Node(
            name="local", is_local=True, hostname=socket.gethostname(),
            address="127.0.0.1", provider_hint="auto", status="online",
            last_seen_at=utcnow(), notes="This machine (auto-registered).",
        ))
        report["node"] = True

    db.session.commit()
    return report


def admin_exists() -> bool:
    return User.query.filter_by(role=Role.ADMIN).count() > 0


def create_admin(username: str, email: str, password: str, full_name: str = "",
                 role: str = Role.ADMIN) -> User:
    user = User(
        username=username, email=email, full_name=full_name or username,
        role=role, is_active_flag=True,
        quota_vcpu=64, quota_memory_mb=65536, quota_disk_gb=2048,
        quota_instances=50,
    )
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    logger.info("created %s account '%s'", role, username)
    return user


def wipe_interrupted_marker() -> None:
    """Mark tasks that were in flight when the process died."""
    from ..models import Task

    for task in Task.query.filter(Task.status.in_(
            [TaskStatus.QUEUED, TaskStatus.RUNNING])).all():
        task.status = TaskStatus.INTERRUPTED
        task.message = "interrupted by a restart"
        task.finished_at = utcnow()
    db.session.commit()


def setup_state(app) -> dict:
    """
    What the setup wizard / install script needs to know.  Never exposes the
    setup token, only whether one is configured.
    """
    token = app.config.get("SETUP_TOKEN") or ""
    return {
        "admin_exists": admin_exists(),
        "setup_token_configured": bool(token),
        "setup_token_hint": (token[:4] + "…" if token else ""),
        "checks": ["database", "directories", "runtime"],
    }
