"""Service layer: the only place business rules are enforced."""
