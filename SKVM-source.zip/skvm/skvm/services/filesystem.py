"""
Instance file manager.

File operations are executed **inside the instance** through the provider's
exec interface (`nsenter`, `docker exec` or `lxc-attach`), never on the host:

  * no shell is ever involved — argv lists only, so a file called
    `; rm -rf /` is just a weird filename;
  * every path is validated (absolute, no `..` segments, no control characters)
    *and* re-checked inside the instance by only ever running with `--` guards;
  * reads are size-capped so a 40 GB log cannot exhaust the panel;
  * two levels of confinement apply: the provider's own isolation plus the
    path validation, so a user cannot reach the host filesystem.
"""
from __future__ import annotations

import json
import logging
import os
import posixpath
import re
import shlex
import subprocess
from dataclasses import dataclass

from ..provisioning.detect import is_admin, probe_sudo
from ..provisioning.providers import ProviderError

logger = logging.getLogger("skvm.files")

MAX_READ_BYTES = 2 * 1024 * 1024        # text preview
MAX_DOWNLOAD_BYTES = 256 * 1024 * 1024  # single-file download
SAFE_NAME = re.compile(r"^[^/\x00]{1,255}$")
FORBIDDEN = ("\x00", "\n", "\r")


class FileError(Exception):
    pass


@dataclass
class ExecResult:
    rc: int
    stdout: bytes
    stderr: str

    @property
    def ok(self) -> bool:
        return self.rc == 0

    @property
    def text(self) -> str:
        return self.stdout.decode("utf-8", "replace")


def normalize_path(path: str, *, allow_root: bool = False) -> str:
    """Validate and normalise an instance path. Raises FileError otherwise."""
    if path is None:
        raise FileError("a path is required")
    if any(ch in path for ch in FORBIDDEN):
        raise FileError("the path contains control characters")
    p = path.strip()
    if not p:
        p = "/" if allow_root else ""
    if not p:
        raise FileError("a path is required")
    if not p.startswith("/"):
        p = "/" + p
    parts = []
    for segment in p.split("/"):
        if segment in ("", "."):
            continue
        if segment == "..":
            raise FileError("parent directory traversal (..) is not allowed")
        parts.append(segment)
    normalised = "/" + "/".join(parts)
    if len(normalised) > 4096:
        raise FileError("path is too long")
    return normalised


def validate_entry_name(name: str) -> str:
    if not SAFE_NAME.match(name or "") or name in (".", ".."):
        raise FileError("invalid entry name")
    return name


class InstanceFiles:
    """Executes real file operations inside a running instance."""

    def __init__(self, provider, instance, timeout: int = 60):
        self.provider = provider
        self.instance = instance
        self.timeout = timeout

    # ------------------------------------------------------------- plumbing
    def _argv(self, command: list[str]) -> list[str]:
        argv = self.provider.exec_argv(self.instance, command)
        if argv is None:
            raise FileError(
                "the instance is not running, so its filesystem cannot be "
                "accessed"
            )
        return argv

    def exec(self, command: list[str], input_bytes: bytes | None = None,
             timeout: int | None = None, max_bytes: int = MAX_DOWNLOAD_BYTES
             ) -> ExecResult:
        argv = self._argv(command)
        needs_root = not is_admin()
        if needs_root and not probe_sudo().get("available"):
            raise FileError(
                "this host requires elevated privileges to reach the instance "
                "filesystem, and passwordless sudo is unavailable"
            )
        cmd = ["sudo", "-n", *argv] if (needs_root and argv[0] != "docker") else argv
        try:
            proc = subprocess.run(
                cmd, input=input_bytes, capture_output=True,
                timeout=timeout or self.timeout,
            )
        except subprocess.TimeoutExpired:
            raise FileError(
                f"the operation did not finish within {timeout or self.timeout}s"
            ) from None
        except FileNotFoundError as exc:
            raise FileError(f"required command missing: {exc}") from exc
        except OSError as exc:
            raise FileError(f"could not run the operation: {exc}") from exc
        if len(proc.stdout) > max_bytes:
            raise FileError(
                f"the result exceeds the {max_bytes // 1048576} MiB transfer limit"
            )
        return ExecResult(proc.returncode, proc.stdout,
                          proc.stderr.decode("utf-8", "replace"))

    def _check(self, result: ExecResult, what: str) -> ExecResult:
        if not result.ok:
            message = (result.stderr or result.text).strip().splitlines()
            raise FileError(f"{what} failed: {message[-1][:300] if message else 'unknown error'}")
        return result

    # ---------------------------------------------------------------- reads
    def list_dir(self, path: str) -> dict:
        target = normalize_path(path, allow_root=True)
        # GNU find is present in every Debian/Ubuntu base image and gives a
        # structured, locale-independent listing; falls back to ls otherwise.
        result = self.exec([
            "/usr/bin/find", target, "-mindepth", "1", "-maxdepth", "1",
            "-printf", r"%f\t%y\t%s\t%T@\t%m\t%u\t%g\n",
        ], timeout=45)
        entries: list[dict] = []
        if result.ok:
            for line in result.text.splitlines():
                parts = line.split("\t")
                if len(parts) < 7:
                    continue
                name, kind, size, mtime, mode, owner, group = parts[:7]
                entries.append(_entry(name, kind, size, mtime, mode, owner, group))
        else:
            # Fall back to a plain ls (busybox/minimal images).
            fallback = self.exec(["/bin/ls", "-la", "--", target], timeout=45)
            if not fallback.ok:
                raise FileError(
                    f"cannot list {target}: "
                    f"{(fallback.stderr or result.stderr).strip()[:300]}"
                )
            for line in fallback.text.splitlines()[1:]:
                fields = line.split(None, 8)
                if len(fields) < 9:
                    continue
                mode, _, owner, group, size, _, _, _, name = fields
                entries.append(_entry(name, "l" if mode.startswith(("l", "d"))
                                      else "-", size, "0", mode, owner, group))
        entries.sort(key=lambda e: (not e["is_dir"], e["name"].lower()))
        parent = posixpath.dirname(target.rstrip("/")) or "/"
        return {"path": target, "parent": parent, "entries": entries,
                "count": len(entries)}

    def stat(self, path: str) -> dict:
        target = normalize_path(path)
        # Debian/Ubuntu ship GNU stat at /usr/bin/stat; minimal Alpine images
        # ship the BusyBox applet at /bin/stat instead. Keep the same fields and
        # never pretend a file was read when neither command can stat it.
        fmt = "%n\t%s\t%Y\t%a\t%U\t%G\t%F"
        failures = []
        for binary in ("/usr/bin/stat", "/bin/stat"):
            result = self.exec([binary, "-c", fmt, "--", target], timeout=30)
            if not result.ok:
                failures.append((result.stderr or result.text).strip())
                continue
            parts = result.text.strip().split("\t")
            if len(parts) < 7:
                failures.append(f"{binary} returned an unexpected result")
                continue
            _name, size, mtime, mode, owner, group, ftype = parts[:7]
            return {"path": target, "size": int(size or 0),
                    "mtime": float(mtime or 0), "mode": mode,
                    "owner": owner, "group": group, "type": ftype,
                    "is_dir": "directory" in ftype}
        reason = next((error for error in failures if error),
                      "stat command is unavailable")
        raise FileError(f"cannot stat {target}: {reason[:200]}")

    def read_text(self, path: str, max_bytes: int = MAX_READ_BYTES) -> dict:
        target = normalize_path(path)
        info = self.stat(target)
        if info["is_dir"]:
            raise FileError("this is a directory")
        if info["size"] > max_bytes:
            raise FileError(
                f"the file is {info['size'] / 1024:.0f} KiB which exceeds the "
                f"{max_bytes // 1024} KiB in-browser editor limit — download it "
                "instead"
            )
        result = self._check(
            self.exec(["/bin/cat", "--", target], max_bytes=max_bytes + 1024),
            f"reading {target}")
        try:
            text = result.stdout.decode("utf-8")
            binary = False
        except UnicodeDecodeError:
            text = result.stdout.decode("latin-1")
            binary = any(b < 9 or (13 < b < 32) for b in result.stdout[:4096])
        return {"path": target, "content": text, "size": info["size"],
                "binary": binary, "mode": info["mode"], "owner": info["owner"]}

    def download(self, path: str) -> tuple[bytes, str]:
        target = normalize_path(path)
        info = self.stat(target)
        if info["is_dir"]:
            raise FileError("downloading a directory is not supported — "
                            "create a backup instead")
        if info["size"] > MAX_DOWNLOAD_BYTES:
            raise FileError(
                f"the file is {info['size'] / 1048576:.1f} MiB which exceeds the "
                f"{MAX_DOWNLOAD_BYTES // 1048576} MiB download limit")
        result = self._check(self.exec(["/bin/cat", "--", target]),
                             f"reading {target}")
        return result.stdout, posixpath.basename(target)

    # --------------------------------------------------------------- writes
    def write_text(self, path: str, content: str) -> dict:
        target = normalize_path(path)
        payload = content.encode("utf-8")
        result = self.exec(["/usr/bin/tee", "--", target], input_bytes=payload,
                           timeout=120)
        self._check(result, f"writing {target}")
        return {"path": target, "bytes": len(payload)}

    def upload(self, path: str, filename: str, data: bytes) -> dict:
        directory = normalize_path(path, allow_root=True)
        name = validate_entry_name(filename)
        # Do not strip the root slash: `directory == "/"` must produce
        # `/filename`, not the relative path `filename` in the shell's cwd.
        target = posixpath.join(directory, name)
        self.exec(["/bin/mkdir", "-p", "--", directory], timeout=30)
        result = self.exec(["/usr/bin/tee", "--", target], input_bytes=data,
                           timeout=300)
        self._check(result, f"uploading {name}")
        return {"path": target, "bytes": len(data)}

    def make_dir(self, path: str, name: str) -> dict:
        directory = normalize_path(path, allow_root=True)
        entry = validate_entry_name(name)
        # Keep the leading slash when `directory == "/"`; stripping it first
        # turns `/audit-dir` into the relative path `audit-dir`, so mkdir reports
        # success in the helper's working directory while every later operation
        # correctly looks for `/audit-dir` and fails. This made the New folder
        # button claim success without creating a folder in the container root.
        target = posixpath.join(directory, entry)
        self._check(self.exec(["/bin/mkdir", "-p", "--", target], timeout=30),
                    f"creating {entry}")
        return {"path": target}

    def delete(self, path: str) -> dict:
        target = normalize_path(path)
        if target == "/":
            raise FileError("refusing to delete the instance root filesystem")
        self._check(self.exec(["/bin/rm", "-rf", "--", target], timeout=180),
                    f"deleting {target}")
        return {"path": target, "deleted": True}

    def rename(self, path: str, new_name: str) -> dict:
        target = normalize_path(path)
        entry = validate_entry_name(new_name)
        parent = posixpath.dirname(target.rstrip("/")) or "/"
        destination = posixpath.join(parent, entry)
        if destination == target:
            return {"path": target}
        self._check(self.exec(["/bin/mv", "-f", "--", target, destination],
                              timeout=120), f"renaming to {entry}")
        return {"path": destination}

    def copy(self, path: str, destination: str | None = None) -> dict:
        source = normalize_path(path)
        if destination:
            dest = normalize_path(destination)
        else:
            parent = posixpath.dirname(source.rstrip("/")) or "/"
            dest = posixpath.join(parent, posixpath.basename(source) + ".copy")
        self._check(self.exec(["/bin/cp", "-a", "--", source, dest], timeout=300),
                    f"copying to {dest}")
        return {"source": source, "path": dest}

    def move(self, path: str, destination: str) -> dict:
        source = normalize_path(path)
        dest = normalize_path(destination)
        self._check(self.exec(["/bin/mv", "-f", "--", source, dest], timeout=300),
                    f"moving to {dest}")
        return {"source": source, "path": dest}

    def chmod(self, path: str, mode: str) -> dict:
        target = normalize_path(path)
        if not re.match(r"^[0-7]{3,4}$", mode or ""):
            raise FileError("mode must be an octal value such as 0644")
        self._check(self.exec(["/bin/chmod", mode, "--", target], timeout=30),
                    f"changing permissions on {target}")
        return {"path": target, "mode": mode}

    def disk_usage(self, path: str = "/") -> dict:
        target = normalize_path(path, allow_root=True)
        result = self.exec(["/usr/bin/du", "-sb", "--", target], timeout=120)
        if not result.ok:
            # BusyBox du lacks `-b`; use its portable kilobyte summary and try
            # both standard applet locations used by Debian/Alpine images.
            result = self.exec(["/usr/bin/du", "-s", "-k", "--", target], timeout=120)
            if not result.ok:
                result = self.exec(["/bin/du", "-s", "-k", "--", target], timeout=120)
            if not result.ok:
                raise FileError("du is not available in this instance")
            parts = result.text.split()
            return {"path": target, "bytes": int(parts[0]) * 1024 if parts else 0}
        parts = result.text.split()
        return {"path": target, "bytes": int(parts[0]) if parts else 0}

    def search(self, path: str, pattern: str, limit: int = 200) -> dict:
        target = normalize_path(path, allow_root=True)
        if not pattern or len(pattern) > 128 or any(
                ch in pattern for ch in FORBIDDEN):
            raise FileError("invalid search pattern")
        # Pass the glob as one argv element (never through a shell). GNU and
        # BusyBox find both support -print; BusyBox does not consistently
        # implement GNU's -printf format, so obtain metadata via stat instead.
        result = self.exec([
            "/usr/bin/find", target, "-maxdepth", "6", "-iname", f"*{pattern}*",
            "-print",
        ], timeout=60)
        if not result.ok:
            raise FileError("search failed: "
                            f"{(result.stderr or result.text).strip()[:200]}")
        hits = []
        for found in result.text.splitlines()[:limit]:
            if not found:
                continue
            info = self.stat(found)
            hits.append({"path": info["path"],
                         "type": "d" if info["is_dir"] else "f",
                         "size": info["size"], "mtime": info["mtime"]})
        return {"path": target, "query": pattern, "results": hits,
                "count": len(hits), "truncated": len(hits) >= limit}


def _entry(name: str, kind: str, size, mtime, mode, owner, group) -> dict:
    is_dir = kind == "d"
    is_link = kind == "l"
    try:
        size_int = int(size)
    except (TypeError, ValueError):
        size_int = 0
    try:
        mtime_f = float(mtime)
    except (TypeError, ValueError):
        mtime_f = 0.0
    return {
        "name": name,
        "type": {"d": "directory", "l": "symlink", "f": "file",
                 "-": "file"}.get(kind, "other"),
        "kind": kind,
        "size": size_int,
        "mtime": mtime_f,
        "mode": mode,
        "owner": owner,
        "group": group,
        "is_dir": is_dir,
        "is_link": is_link,
        "ext": (name.rsplit(".", 1)[1].lower() if "." in name
                and not is_dir else ""),
    }
