"""
Interactive VPS console.

A real PTY is allocated on the host, and the child process is started *inside
the instance* through the provider's exec bridge:

  namespace containers -> sudo nsenter --target <init pid> --pid --mount ... -- /bin/bash -l
  docker               -> docker exec -it <id> /bin/bash -l
  lxc                  -> sudo lxc-attach --name <name> -- /bin/bash -l

The master side of the PTY is pumped to the browser over a WebSocket and
rendered by xterm.js, so keystrokes, colours, job control and terminal resizing
all behave like a real SSH session — because it is a real terminal.

Guarantees enforced here:
  * only the instance owner (or an administrator) may open a console;
  * the instance must actually be running;
  * a per-user session cap and an idle timeout apply;
  * every session is recorded (user, instance, pid, times) for audit;
  * no host shell is ever spawned — the child is always the instance's shell.
"""
from __future__ import annotations

import errno
import fcntl
import logging
import os
import pty
import select
import signal
import struct
import subprocess
import termios
import threading
import time

from ..extensions import db
from ..models import ConsoleSession, VPS, VPSStatus, utcnow
from ..provisioning.detect import is_admin, probe_sudo

logger = logging.getLogger("skvm.console")

TIOCSWINSZ = getattr(termios, "TIOCSWINSZ", 0x5414)
TIOCGWINSZ = getattr(termios, "TIOCGWINSZ", 0x5413)


class ConsoleError(Exception):
    pass


class ConsoleHandle:
    """A live PTY attached to one instance."""

    def __init__(self, record: ConsoleSession, master_fd: int, proc: subprocess.Popen,
                 command: str):
        self.record = record
        self.master = master_fd
        self.proc = proc
        self.command = command
        self.last_activity = time.time()
        self.closed = False
        self._lock = threading.Lock()
        self.output_bytes = 0
        self.input_bytes = 0

    # ------------------------------------------------------------- plumbing
    def read(self, timeout: float = 0.05) -> bytes:
        if self.closed:
            return b""
        try:
            r, _, _ = select.select([self.master], [], [], timeout)
        except (OSError, ValueError):
            return b""
        if not r:
            return b""
        try:
            chunk = os.read(self.master, 65536)
        except OSError as exc:
            if exc.errno in (errno.EIO, errno.EBADF):
                self.closed = True
                return b""
            raise
        if not chunk:
            self.closed = True
            return b""
        self.output_bytes += len(chunk)
        self.last_activity = time.time()
        return chunk

    def write(self, data: bytes) -> int:
        if self.closed:
            return 0
        with self._lock:
            try:
                written = os.write(self.master, data)
                self.input_bytes += written
                self.last_activity = time.time()
                return written
            except OSError as exc:
                if exc.errno in (errno.EIO, errno.EBADF, errno.EAGAIN):
                    self.closed = True
                    return 0
                raise

    def resize(self, cols: int, rows: int) -> None:
        cols = max(20, min(500, int(cols or 120)))
        rows = max(5, min(200, int(rows or 30)))
        try:
            fcntl.ioctl(self.master, TIOCSWINSZ,
                        struct.pack("HHHH", rows, cols, 0, 0))
        except OSError as exc:
            logger.debug("resize failed: %s", exc)
        self.record.cols, self.record.rows = cols, rows

    @property
    def alive(self) -> bool:
        return not self.closed and self.proc.poll() is None

    @property
    def idle_seconds(self) -> float:
        return time.time() - self.last_activity

    def signal(self, sig: int) -> None:
        try:
            self.proc.send_signal(sig)
        except (ProcessLookupError, PermissionError, OSError):
            pass

    def close(self, reason: str = "client disconnected") -> None:
        if self.closed and self.proc.poll() is not None:
            return
        self.closed = True
        try:
            self.proc.terminate()
        except (ProcessLookupError, OSError):
            pass
        for _ in range(10):
            if self.proc.poll() is not None:
                break
            time.sleep(0.05)
        if self.proc.poll() is None:
            try:
                self.proc.kill()
            except (ProcessLookupError, OSError):
                pass
        try:
            os.close(self.master)
        except OSError:
            pass
        try:
            self.record.closed_at = utcnow()
            self.record.close_reason = reason[:64]
            self.record.pid = self.proc.pid
            db.session.add(self.record)
            db.session.commit()
        except Exception as exc:  # noqa: BLE001
            logger.debug("could not persist console close: %s", exc)
        logger.info("console session %s closed (%s)", self.record.session_key, reason)


class ConsoleManager:
    def __init__(self, app):
        self.app = app
        self._sessions: dict[str, ConsoleHandle] = {}
        self._lock = threading.Lock()

    # ---------------------------------------------------------------- limits
    def _limits(self) -> tuple[int, int]:
        from . import settings_service

        per_user = int(self.app.config["CONSOLE_MAX_SESSIONS_PER_USER"])
        idle = int(settings_service.get("console_idle_timeout",
                                        self.app.config["CONSOLE_IDLE_TIMEOUT"]))
        return per_user, idle

    def user_session_count(self, user_id: int) -> int:
        with self._lock:
            return len([h for h in self._sessions.values()
                        if h.record.user_id == user_id and h.alive])

    # ------------------------------------------------------------------ open
    def open(self, provider, vps: VPS, user, cols: int = 120, rows: int = 30,
             shell_hint: str = "") -> ConsoleHandle:
        if provider is None:
            raise ConsoleError("no container runtime is available for this instance")
        if vps.status != VPSStatus.RUNNING:
            raise ConsoleError(
                f"the instance is {vps.status_label.lower()} — start it before "
                "opening a console"
            )

        per_user, idle = self._limits()
        if self.user_session_count(user.id) >= per_user:
            raise ConsoleError(
                f"you already have {per_user} console session(s) open; close one "
                "first"
            )

        argv = provider.console_argv(vps, cols=cols, rows=rows)
        if not argv:
            raise ConsoleError(
                f"the {provider.label} backend cannot provide an interactive "
                "console for this instance"
            )

        # Privileged bridges (nsenter / lxc-attach) need sudo on a non-root panel.
        needs_root = argv[0] not in ("docker",)
        if needs_root and not is_admin():
            if not probe_sudo().get("available"):
                raise ConsoleError(
                    "the panel needs passwordless sudo to attach to the instance "
                    "namespace, and it is unavailable on this host"
                )
            argv = ["sudo", "-n", *argv]

        master, slave = pty.openpty()
        try:
            fcntl.ioctl(slave, TIOCSWINSZ,
                        struct.pack("HHHH", max(5, rows), max(20, cols), 0, 0))
        except OSError:
            pass

        env = {
            "TERM": "xterm-256color",
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "HOME": "/root",
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "SKVM_INSTANCE": vps.instance_id,
        }
        try:
            def _attach_controlling_tty():
                # setsid() makes the child a session leader; TIOCSCTTY then
                # makes the allocated PTY its controlling terminal. Without
                # this, interactive shells print "no job control" and Ctrl-C,
                # Ctrl-Z and foreground process groups do not behave like a
                # real console even though bytes can be sent through the PTY.
                os.setsid()
                fcntl.ioctl(0, termios.TIOCSCTTY, 0)
                os.tcsetpgrp(0, os.getpgrp())

            proc = subprocess.Popen(
                argv,
                stdin=slave, stdout=slave, stderr=slave,
                preexec_fn=_attach_controlling_tty,
                env=env,
                close_fds=True,
            )
        except FileNotFoundError as exc:
            os.close(master)
            os.close(slave)
            raise ConsoleError(f"console command not found: {exc}") from exc
        except OSError as exc:
            os.close(master)
            os.close(slave)
            raise ConsoleError(f"could not start the console: {exc}") from exc
        finally:
            try:
                os.close(slave)
            except OSError:
                pass

        record = ConsoleSession(
            vps_id=vps.id, user_id=user.id, pid=proc.pid, cols=cols, rows=rows,
            command=" ".join(argv)[:255],
        )
        db.session.add(record)
        db.session.commit()

        handle = ConsoleHandle(record, master, proc, " ".join(argv))
        handle.idle_limit = idle
        with self._lock:
            self._sessions[record.session_key] = handle
        logger.info("console session %s opened for %s on %s (pid %s)",
                    record.session_key, user.username, vps.name, proc.pid)
        return handle

    def get(self, session_key: str) -> ConsoleHandle | None:
        with self._lock:
            return self._sessions.get(session_key)

    def close(self, session_key: str, reason: str = "closed") -> None:
        with self._lock:
            handle = self._sessions.pop(session_key, None)
        if handle:
            handle.close(reason)

    def close_all(self, reason: str = "panel shutdown") -> int:
        with self._lock:
            handles = list(self._sessions.values())
            self._sessions.clear()
        for handle in handles:
            handle.close(reason)
        return len(handles)

    def reap(self) -> int:
        """Close sessions whose PTY died or that sat idle too long."""
        removed = 0
        with self._lock:
            for key, handle in list(self._sessions.items()):
                idle_limit = getattr(handle, "idle_limit", 1800)
                if not handle.alive:
                    self._sessions.pop(key, None)
                    handle.close("process exited")
                    removed += 1
                elif handle.idle_seconds > idle_limit:
                    self._sessions.pop(key, None)
                    handle.close("idle timeout")
                    removed += 1
        return removed

    def active(self) -> list[dict]:
        with self._lock:
            return [
                {**h.record.to_dict(), "alive": h.alive,
                 "idle_seconds": round(h.idle_seconds, 1),
                 "output_bytes": h.output_bytes, "input_bytes": h.input_bytes,
                 "command": h.command}
                for h in self._sessions.values()
            ]
