"""
InstanceService — the single place where instance requests are validated.

The HTTP layer calls this; it applies quota checks, ownership rules and audit
logging, then hands the work to the ProvisioningManager.  Keeping it separate
means the CLI, the API and the HTML views all enforce exactly the same rules.
"""
from __future__ import annotations

from flask import current_app, has_request_context
from flask_login import current_user

from ..extensions import db
from ..models import OSImage, Plan, Task, User, VPS, VPSStatus, utcnow
from . import audit


class ServiceError(Exception):
    def __init__(self, message: str, code: int = 400, **extra):
        super().__init__(message)
        self.code = code
        self.extra = extra


class InstanceService:
    def __init__(self, app):
        self.app = app
        self.manager = app.extensions["skvm_manager"]

    # ------------------------------------------------------------- queries
    def visible(self, user: User | None = None):
        user = user or current_user
        query = VPS.query.filter(VPS.status != VPSStatus.DELETED)
        return query if user.can_view_all else query.filter(VPS.owner_id == user.id)

    def get(self, instance_id: str, user: User | None = None) -> VPS:
        vps = VPS.query.filter_by(instance_id=instance_id).first()
        if vps is None or vps.status == VPSStatus.DELETED:
            raise ServiceError("no such instance", 404)
        user = user or current_user
        if not user.can_access(vps):
            raise ServiceError("you do not have access to this instance", 403)
        return vps

    def summary(self, user: User | None = None) -> dict:
        rows = self.visible(user).all()
        return {
            "total": len(rows),
            "running": len([v for v in rows if v.status == VPSStatus.RUNNING]),
            "stopped": len([v for v in rows if v.status == VPSStatus.STOPPED]),
            "error": len([v for v in rows if v.status == VPSStatus.ERROR]),
            "expired": len([v for v in rows if v.is_expired]),
            "vcpu": sum(v.vcpu for v in rows),
            "memory_mb": sum(v.memory_mb for v in rows),
            "disk_gb": sum(v.disk_gb for v in rows),
        }

    # ------------------------------------------------------------- actions
    def action(self, instance_id: str, action: str, user: User) -> Task:
        vps = self.get(instance_id, user)
        if not user.can_operate(vps):
            raise ServiceError("your role cannot control this instance", 403)
        if action == "delete" and not user.is_admin:
            raise ServiceError("only administrators can delete instances", 403)
        if action in ("start",) and vps.status == VPSStatus.RUNNING:
            raise ServiceError("this instance is already running", 409)
        if action in ("stop",) and vps.status != VPSStatus.RUNNING:
            raise ServiceError(f"this instance is {vps.status} — nothing to stop",
                               409)
        task, error = self.manager.submit_power(vps, action, user)
        if error:
            raise ServiceError(error, 409)
        audit.record(f"instance.{action}", vps.name, category="instance",
                     target=vps.name)
        return task

    def delete(self, instance_id: str, user: User) -> Task:
        return self.action(instance_id, "delete", user)

    # ------------------------------------------------------------ ownership
    def transfer(self, instance_id: str, new_owner_id: int, admin: User) -> VPS:
        if not admin.is_admin:
            raise ServiceError("administrator privileges are required", 403)
        vps = self.get(instance_id, admin)
        new_owner = db.session.get(User, new_owner_id)
        if new_owner is None:
            raise ServiceError("no such account", 404)
        if not new_owner.is_active_flag:
            raise ServiceError("that account is suspended", 400)
        previous = vps.owner.username if vps.owner else "?"
        vps.owner_id = new_owner.id
        db.session.commit()
        audit.record("instance.transferred",
                     f"{vps.name} moved from {previous} to {new_owner.username}",
                     category="instance", level="warning", target=vps.name)
        return vps

    # ------------------------------------------------------------- helpers
    def resolve_image(self, image_id: int | None) -> OSImage | None:
        if not image_id:
            return None
        image = db.session.get(OSImage, int(image_id))
        if image is None:
            raise ServiceError("the selected operating system does not exist", 404)
        if not image.is_active:
            raise ServiceError("that operating system image is disabled", 400)
        return image

    def resolve_plan(self, plan_id: int | None) -> Plan | None:
        if not plan_id:
            return None
        plan = db.session.get(Plan, int(plan_id))
        if plan is None:
            raise ServiceError("the selected plan does not exist", 404)
        return plan
