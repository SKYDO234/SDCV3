"""
Backup service.

A backup is a real ``tar.gz`` archive of an instance's root filesystem, built by
the provisioning manager (``ProvisioningManager.create_backup``).  This module
owns everything *around* that archive: listing, verification, download metadata
and deletion.  A backup that cannot be proven to be a readable gzip stream is
reported as ``failed`` — never as ``ready``.
"""
from __future__ import annotations

import gzip
import logging
import os
import tarfile
from pathlib import Path

from ..models import Backup, VPS, VPSStatus, utcnow
from . import audit

logger = logging.getLogger("skvm.backup")


class BackupError(Exception):
    def __init__(self, message: str, code: int = 400):
        super().__init__(message)
        self.code = code


class BackupService:
    def __init__(self, app):
        self.app = app

    # ------------------------------------------------------------- locations
    @property
    def root(self) -> Path:
        return Path(self.app.config["BACKUP_DIR"])

    def path_for(self, backup: Backup) -> Path:
        if backup.file_path:
            return Path(backup.file_path)
        return self.root / f"{backup.backup_id}.tar.gz"

    # ---------------------------------------------------------------- listing
    def visible(self, user):
        query = Backup.query
        if not user.can_view_all:
            query = query.join(VPS, Backup.vps_id == VPS.id).filter(
                VPS.owner_id == user.id)
        return query.order_by(Backup.id.desc())

    def all(self, limit: int | None = None):
        query = Backup.query.order_by(Backup.id.desc())
        return query.limit(limit).all() if limit else query.all()

    def for_instance(self, vps: VPS):
        return Backup.query.filter_by(vps_id=vps.id).order_by(Backup.id.desc()).all()

    # ----------------------------------------------------------------- actions
    def get(self, backup_id: str, user) -> Backup:
        backup = Backup.query.filter_by(backup_id=backup_id).first()
        if backup is None:
            raise BackupError("no such backup", 404)
        if not user.can_view_all and (backup.vps is None or
                                      backup.vps.owner_id != user.id):
            raise BackupError("you do not have access to this backup", 403)
        return backup

    def delete(self, backup_id: str, user) -> dict:
        backup = self.get(backup_id, user)
        if not backup.vps or (backup.vps.owner_id != user.id and not user.can_view_all):
            raise BackupError("you do not have access to this backup", 403)
        path = self.path_for(backup)
        removed = False
        detail = ""
        try:
            if path.exists():
                path.unlink()
                removed = True
            else:
                detail = "the archive file was already missing from disk"
        except OSError as exc:
            raise BackupError(f"could not delete {path.name}: {exc}", 500) from exc
        name = backup.vps.name if backup.vps else backup.backup_id
        from ..extensions import db

        db.session.delete(backup)
        db.session.commit()
        audit.record("backup.deleted",
                     f"backup of {name} deleted"
                     + (f" ({detail})" if detail else ""),
                     category="backup", level="warning", target=name)
        return {"backup_id": backup_id, "file_removed": removed,
                "path": str(path), "detail": detail}

    def verify(self, backup_id: str, user) -> dict:
        """Prove that the archive on disk is a readable gzip tar stream."""
        backup = self.get(backup_id, user)
        path = self.path_for(backup)
        if not path.exists():
            return {"verified": False, "reason": "the archive file is missing from disk",
                    "path": str(path)}
        try:
            size = path.stat().st_size
        except OSError as exc:
            return {"verified": False, "reason": f"stat failed: {exc}", "path": str(path)}
        if size == 0:
            return {"verified": False, "reason": "the archive is empty (0 bytes)",
                    "path": str(path)}
        try:
            with gzip.open(path, "rb") as handle:
                head = handle.read(512)
            with tarfile.open(path, "r:gz") as tar:
                names = []
                for index, member in enumerate(tar):
                    if index == 0:
                        names.append(member.name)
                    if index >= 25:
                        break
            return {"verified": True, "path": str(path), "size_bytes": size,
                    "gzip_header_ok": len(head) > 0,
                    "entries_sampled": len(names),
                    "first_entries": names,
                    "checked_at": utcnow().isoformat()}
        except (OSError, tarfile.TarError, EOFError) as exc:
            return {"verified": False,
                    "reason": f"{type(exc).__name__}: {exc}",
                    "path": str(path), "size_bytes": size}

    def reconcile(self) -> dict:
        """
        Re-check every finished backup against the filesystem.

        Called by the background monitor: a ``ready`` row whose archive
        disappeared (or stopped being a valid gzip stream) is downgraded with an
        honest reason instead of continuing to look healthy.
        """
        changed, checked = [], 0
        for backup in Backup.query.filter(Backup.status.in_(("ready", "failed"))).all():
            checked += 1
            path = self.path_for(backup)
            try:
                if not path.exists():
                    state, detail = "failed", f"archive missing at {path}"
                elif path.stat().st_size == 0:
                    state, detail = "failed", "archive is 0 bytes"
                else:
                    with gzip.open(path, "rb") as handle:
                        handle.read(64)
                    state, detail = "ready", f"{path.stat().st_size} bytes at {path}"
            except (OSError, EOFError, gzip.BadGzipFile) as exc:
                state, detail = "failed", f"unreadable archive: {exc}"
            if backup.status != state or backup.detail != detail:
                backup.status = state
                backup.detail = detail[:400]
                backup.size_bytes = path.stat().st_size if path.exists() else 0
                changed.append(backup.backup_id)
        if changed:
            from ..extensions import db

            db.session.commit()
            logger.info("backup reconcile changed %d row(s)", len(changed))
        return {"checked": checked, "changed": changed}

    # ------------------------------------------------------------------ usage
    def storage(self) -> dict:
        root = self.root
        total = 0
        files = 0
        if root.exists():
            for base, _dirs, names in os.walk(root, onerror=lambda e: None):
                for name in names:
                    try:
                        total += os.lstat(os.path.join(base, name)).st_size
                        files += 1
                    except OSError:
                        continue
        import shutil

        try:
            usage = shutil.disk_usage(str(root if root.exists() else root.parent))
        except OSError:
            usage = None
        return {
            "root": str(root),
            "bytes": total,
            "files": files,
            "rows": Backup.query.count(),
            "failed": Backup.query.filter(Backup.status == "failed").count(),
            "free_bytes": usage.free if usage else 0,
            "free_gb": round(usage.free / 1e9, 2) if usage else 0.0,
        }

    def expiring_instances_with_backups(self, limit: int = 20) -> list[VPS]:
        """
        Instances that are suspended or expired but still have storage on disk —
        useful before a destructive cleanup.
        """
        return (VPS.query
                .filter(VPS.status.in_((VPSStatus.SUSPENDED, VPSStatus.EXPIRED,
                                        VPSStatus.STOPPED)))
                .order_by(VPS.id.desc()).limit(limit).all())


__all__ = ["BackupService", "BackupError"]
