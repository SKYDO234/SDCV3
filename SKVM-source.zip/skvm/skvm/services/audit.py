"""Audit logging — every privileged action is recorded with real context."""
from __future__ import annotations

import json
import logging
from datetime import timedelta

from flask import has_request_context, request
from flask_login import current_user

from ..extensions import db
from ..models import AuditLog, utcnow

logger = logging.getLogger("skvm.audit")


def _client_ip() -> str:
    if not has_request_context():
        return ""
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",")[0].strip()[:64]
    return (request.remote_addr or "")[:64]


def record(action: str, message: str = "", *, category: str = "general",
           level: str = "info", target: str = "", meta: dict | None = None,
           actor=None, commit: bool = True) -> AuditLog:
    """Write an audit entry.  Never raises — logging must not break a request."""
    try:
        user = actor
        if user is None and has_request_context():
            user = current_user if getattr(current_user, "is_authenticated", False) else None
        entry = AuditLog(
            level=level,
            category=category,
            action=action[:96],
            message=message[:2000],
            actor_id=getattr(user, "id", None),
            actor_username=getattr(user, "username", "") or "system",
            target=target[:120],
            ip=_client_ip(),
            user_agent=(request.headers.get("User-Agent", "")[:255]
                        if has_request_context() else ""),
            meta_json=json.dumps(meta or {}, default=str),
        )
        db.session.add(entry)
        if commit:
            db.session.commit()
        log_line = f"{action} by {entry.actor_username} target={target or '-'} {message}"
        getattr(logger, level if level in ("info", "warning", "error", "critical")
                else "info")(log_line)
        return entry
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit write failed: %s", exc)
        return AuditLog(action=action, message=message)


def recent(limit: int = 100, category: str | None = None,
           level: str | None = None):
    query = AuditLog.query
    if category:
        query = query.filter(AuditLog.category == category)
    if level:
        query = query.filter(AuditLog.level == level)
    return query.order_by(AuditLog.id.desc()).limit(limit).all()


def prune(older_than_days: int = 30) -> int:
    cutoff = utcnow() - timedelta(days=older_than_days)
    deleted = AuditLog.query.filter(AuditLog.created_at < cutoff).delete(
        synchronize_session=False)
    db.session.commit()
    logger.info("pruned %s audit entries older than %s days", deleted, older_than_days)
    return deleted
