"""Persistent global settings with real defaults."""
from __future__ import annotations

from ..extensions import db
from ..models import MaintenanceState, Setting

DEFAULTS: list[dict] = [
    {"key": "panel_name", "value": "SKVM", "value_type": "string",
     "label": "Panel name", "group": "branding",
     "description": "Shown in the sidebar and page titles."},
    {"key": "panel_tagline", "value": "Virtual Private Server Control Plane",
     "value_type": "string", "label": "Panel tagline", "group": "branding",
     "description": "Subtitle under the panel name."},
    {"key": "support_url", "value": "", "value_type": "string",
     "label": "Support URL", "group": "branding",
     "description": "Injected into instance MOTD/help links. Blank hides it."},
    {"key": "registration_enabled", "value": "false", "value_type": "bool",
     "label": "Allow self-registration", "group": "security",
     "description": "When off, only administrators can create accounts."},
    {"key": "default_role", "value": "user", "value_type": "string",
     "label": "Default role for new accounts", "group": "security",
     "description": "Applied when an account is created without an explicit role."},
    {"key": "session_hours", "value": "12", "value_type": "int",
     "label": "Session lifetime (hours)", "group": "security",
     "description": "How long a login stays valid."},
    {"key": "max_login_failures", "value": "8", "value_type": "int",
     "label": "Failed logins before lockout", "group": "security",
     "description": "Per-account failure budget."},
    {"key": "lockout_minutes", "value": "15", "value_type": "int",
     "label": "Lockout duration (minutes)", "group": "security",
     "description": "How long an account stays locked after too many failures."},
    {"key": "default_provider", "value": "auto", "value_type": "string",
     "label": "Default provisioning provider", "group": "provisioning",
     "description": "auto picks the best verified runtime on this host."},
    {"key": "max_vcpu", "value": "16", "value_type": "int",
     "label": "Maximum vCPUs per instance", "group": "provisioning",
     "description": "Hard ceiling enforced when creating an instance."},
    {"key": "max_memory_mb", "value": "32768", "value_type": "int",
     "label": "Maximum memory per instance (MiB)", "group": "provisioning",
     "description": "Hard ceiling enforced when creating an instance."},
    {"key": "max_disk_gb", "value": "200", "value_type": "int",
     "label": "Maximum disk per instance (GiB)", "group": "provisioning",
     "description": "Hard ceiling enforced when creating an instance."},
    {"key": "max_instances_per_user", "value": "10", "value_type": "int",
     "label": "Instances per user", "group": "provisioning",
     "description": "Upper bound for non-administrator accounts."},
    {"key": "allow_overcommit", "value": "true", "value_type": "bool",
     "label": "Allow host overcommit", "group": "provisioning",
     "description": "Permit the sum of allocations to exceed physical resources."},
    {"key": "default_expiry_days", "value": "30", "value_type": "int",
     "label": "Default expiry (days)", "group": "provisioning",
     "description": "Applied when no expiry is entered. 0 keeps instances forever."},
    {"key": "suspend_on_expiry", "value": "true", "value_type": "bool",
     "label": "Suspend expired instances", "group": "provisioning",
     "description": "Stop and suspend instances once they expire."},
    {"key": "console_idle_timeout", "value": "1800", "value_type": "int",
     "label": "Console idle timeout (seconds)", "group": "console",
     "description": "Idle web console sessions are closed after this long."},
    {"key": "file_manager_max_upload_mb", "value": "256", "value_type": "int",
     "label": "File manager upload limit (MiB)", "group": "console",
     "description": "Rejected above this size."},
    {"key": "metrics_interval", "value": "15", "value_type": "int",
     "label": "Metrics collection interval (seconds)", "group": "monitoring",
     "description": "How often instance metrics are refreshed in the background."},
    {"key": "audit_retention_days", "value": "30", "value_type": "int",
     "label": "Audit retention (days)", "group": "monitoring",
     "description": "Older entries are pruned during maintenance."},
    {"key": "alert_webhook", "value": "", "value_type": "string",
     "label": "Alert webhook URL", "group": "monitoring",
     "description": "Optional: POSTed when an instance fails."},
    {"key": "maintenance_message", "value": "",
     "value_type": "string", "label": "Maintenance banner text",
     "group": "maintenance",
     "description": "Displayed to non-administrators during maintenance."},
]

_TYPE_MAP = {d["key"]: d["value_type"] for d in DEFAULTS}
_DEFAULT_MAP = {d["key"]: d["value"] for d in DEFAULTS}


def seed_defaults() -> int:
    created = 0
    for item in DEFAULTS:
        if db.session.get(Setting, item["key"]) is None:
            db.session.add(Setting(**item))
            created += 1
    if db.session.get(MaintenanceState, 1) is None:
        db.session.add(MaintenanceState(id=1, enabled=False, allow_admins=True,
                                        message=""))
    db.session.commit()
    return created


def get(key: str, default=None):
    row = db.session.get(Setting, key)
    if row is None:
        if default is not None:
            return default
        raw = _DEFAULT_MAP.get(key)
        if raw is None:
            return None
        return _coerce(raw, _TYPE_MAP.get(key, "string"))
    return row.python_value()


def _coerce(value, value_type: str):
    if value_type == "bool":
        return str(value).lower() in {"1", "true", "yes", "on"}
    if value_type == "int":
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0
    if value_type == "float":
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0
    return value


def set_value(key: str, value, value_type: str | None = None) -> Setting:
    row = db.session.get(Setting, key)
    if row is None:
        row = Setting(key=key, value_type=value_type or _TYPE_MAP.get(key, "string"),
                      label=key.replace("_", " ").title(), group="custom")
        db.session.add(row)
    if value_type and row.value_type != value_type:
        row.value_type = value_type
    if isinstance(value, bool):
        row.value = "true" if value else "false"
        row.value_type = "bool"
    else:
        row.value = str(value)
    db.session.commit()
    return row


def as_dict(group: str | None = None) -> dict:
    query = Setting.query
    if group:
        query = query.filter(Setting.group == group)
    return {row.key: row.python_value() for row in query.all()}


def all_rows(group: str | None = None) -> list[Setting]:
    query = Setting.query
    if group:
        query = query.filter(Setting.group == group)
    rows = query.order_by(Setting.group, Setting.key).all()
    if not rows:
        seed_defaults()
        rows = query.order_by(Setting.group, Setting.key).all()
    return rows


def maintenance() -> MaintenanceState:
    state = db.session.get(MaintenanceState, 1)
    if state is None:
        state = MaintenanceState(id=1)
        db.session.add(state)
        db.session.commit()
    return state


def set_maintenance(enabled: bool, message: str = "", allow_admins: bool = True,
                    actor: str = "") -> MaintenanceState:
    state = maintenance()
    state.enabled = bool(enabled)
    # The maintenance form always submits `message`, including an intentional
    # empty string. Preserve that value so an operator can clear an old banner.
    state.message = message
    state.allow_admins = bool(allow_admins)
    state.enabled_by = actor
    db.session.commit()
    return state
