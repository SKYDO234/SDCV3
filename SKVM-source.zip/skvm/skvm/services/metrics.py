"""
Metrics service.

Two kinds of measurement live here and they are deliberately kept apart:

``collect_host_metrics()``
    Real numbers for the machine SKVM itself runs on (psutil + the kernel).

``MetricsService``
    A background sampler that keeps a short history of host samples and of
    every running instance, so charts show measured data instead of zeros.
    Nothing is synthesised: a series is simply absent when its source is
    unavailable, and each sample carries the ``source`` list it came from.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from collections import deque
from datetime import datetime, timezone

import psutil

logger = logging.getLogger("skvm.metrics")

HOST_HISTORY = 720          # ~1 hour at the default 5 s interval
INSTANCE_HISTORY = 240


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def collect_host_metrics(app=None) -> dict:
    """Live host metrics. Every field is measured; nothing is estimated."""
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except OSError:
        load = []
    try:
        cpu_times = psutil.cpu_times_percent(interval=0.12)
        per_cpu = psutil.cpu_percent(interval=0.12, percpu=True)
    except Exception:  # noqa: BLE001
        cpu_times, per_cpu = None, []

    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk_path = "/"
    if app is not None:
        try:
            disk_path = str(app.config["DATA_DIR"])
        except Exception:  # noqa: BLE001
            disk_path = "/"
    try:
        disk = psutil.disk_usage(disk_path if os.path.exists(disk_path) else "/")
    except OSError:
        disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()
    boot = psutil.boot_time()

    temps: dict = {}
    try:
        getter = getattr(psutil, "sensors_temperatures", None)
        if getter:
            for name, entries in (getter() or {}).items():
                temps[name] = [{"label": e.label, "current": e.current}
                               for e in entries[:4]]
    except Exception:  # noqa: BLE001
        temps = {}

    counts: dict = {}
    if app is not None:
        try:
            from ..models import Task, TaskStatus, VPS, VPSStatus

            counts = {
                "instances": VPS.query.filter(VPS.status != VPSStatus.DELETED).count(),
                "running": VPS.query.filter(VPS.status == VPSStatus.RUNNING).count(),
                "stopped": VPS.query.filter(VPS.status == VPSStatus.STOPPED).count(),
                "errors": VPS.query.filter(VPS.status == VPSStatus.ERROR).count(),
                "tasks_running": Task.query.filter(
                    Task.status == TaskStatus.RUNNING).count(),
            }
        except Exception as exc:  # noqa: BLE001
            logger.debug("counts unavailable: %s", exc)

    load_1 = (load[0] if load else psutil.cpu_percent(interval=0))
    return {
        "cpu": {
            "percent": round(float(load_1) / max(1, psutil.cpu_count() or 1), 1)
            if load else psutil.cpu_percent(interval=0),
            "load_avg": load,
            "per_cpu": per_cpu,
            "cores_logical": psutil.cpu_count(logical=True),
            "cores_physical": psutil.cpu_count(logical=False),
            "times_percent": {
                "user": cpu_times.user if cpu_times else None,
                "system": cpu_times.system if cpu_times else None,
                "idle": cpu_times.idle if cpu_times else None,
                "iowait": getattr(cpu_times, "iowait", 0.0) if cpu_times else None,
            },
        },
        "memory": {
            "total_mb": round(vm.total / 1048576, 1),
            "used_mb": round((vm.total - vm.available) / 1048576, 1),
            "available_mb": round(vm.available / 1048576, 1),
            "percent": vm.percent,
            "buffers_mb": round(getattr(vm, "buffers", 0) / 1048576, 1),
            "cached_mb": round(getattr(vm, "cached", 0) / 1048576, 1),
            "swap": {
                "total_mb": round(swap.total / 1048576, 1),
                "used_mb": round(swap.used / 1048576, 1),
                "percent": swap.percent,
            },
        },
        "disk": {
            "path": disk_path,
            "total_gb": round(disk.total / 1e9, 2),
            "used_gb": round(disk.used / 1e9, 2),
            "free_gb": round(disk.free / 1e9, 2),
            "percent": disk.percent,
        },
        "network": {
            "bytes_sent": net.bytes_sent,
            "bytes_recv": net.bytes_recv,
            "packets_sent": net.packets_sent,
            "packets_recv": net.packets_recv,
        },
        "process": {"total": len(psutil.pids()), "pid": os.getpid()},
        "uptime_seconds": int(time.time() - boot),
        "boot_time": boot,
        "temperatures": temps,
        "counts": counts,
        "source": ["psutil", "kernel /proc"],
        "captured_at": _now_iso(),
    }


class MetricsService:
    """Background sampler + ring buffers used by every chart in the panel."""

    def __init__(self, app, interval: float = 5.0):
        self.app = app
        self.interval = max(2.0, float(interval))
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.host: deque = deque(maxlen=HOST_HISTORY)
        self.instances: dict[str, deque] = {}
        self.last_host: dict | None = None
        self.samples = 0
        self.last_error = ""

    # ------------------------------------------------------------- lifecycle
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="skvm-metrics",
                                        daemon=True)
        self._thread.start()
        logger.info("metrics sampler started (every %.1fs)", self.interval)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None

    def _loop(self) -> None:
        # Give the rest of startup a moment before hammering the kernel.
        if self._stop.wait(1.5):
            return
        while not self._stop.is_set():
            try:
                with self.app.app_context():
                    self.sample()
            except Exception as exc:  # noqa: BLE001
                self.last_error = f"{type(exc).__name__}: {exc}"
                logger.warning("metrics sample failed: %s", exc)
            self._stop.wait(self.interval)

    # ---------------------------------------------------------------- sampling
    def sample(self, include_instances: bool = True) -> dict:
        data = collect_host_metrics(self.app)
        stamp = time.time()
        with self._lock:
            self.host.append({
                "ts": stamp,
                "at": data["captured_at"],
                "cpu_percent": data["cpu"]["percent"],
                "load_avg": data["cpu"]["load_avg"],
                "memory_percent": data["memory"]["percent"],
                "memory_used_mb": data["memory"]["used_mb"],
                "disk_percent": data["disk"]["percent"],
                "disk_used_gb": data["disk"]["used_gb"],
            })
            self.last_host = data
            self.samples += 1
        if include_instances:
            self.sample_instances()
        return data

    def sample_instances(self) -> int:
        """Collect real per-instance metrics from each instance's provider."""
        from ..models import VPS, VPSStatus

        manager = self.app.extensions.get("skvm_manager")
        if manager is None:
            return 0
        collected = 0
        for vps in VPS.query.filter(VPS.status == VPSStatus.RUNNING).all():
            provider = manager.provider_for(vps)
            if provider is None:
                continue
            try:
                metrics = provider.metrics(vps)
            except Exception as exc:  # noqa: BLE001
                logger.debug("instance metrics failed for %s: %s", vps.name, exc)
                continue
            if not metrics.get("available"):
                continue
            vps.set_metrics(metrics)
            self.record_instance(vps.instance_id, metrics)
            collected += 1
        try:
            from ..extensions import db

            db.session.commit()
        except Exception:  # noqa: BLE001
            db.session.rollback()
        return collected

    def record_instance(self, instance_id: str, metrics: dict) -> None:
        cpu = metrics.get("cpu") or {}
        mem = metrics.get("memory") or {}
        disk = metrics.get("disk") or {}
        with self._lock:
            series = self.instances.setdefault(instance_id,
                                               deque(maxlen=INSTANCE_HISTORY))
            series.append({
                "ts": time.time(),
                "at": metrics.get("captured_at"),
                "cpu_percent": cpu.get("percent"),
                "memory_used_mb": mem.get("used_mb"),
                "memory_percent": mem.get("percent"),
                "disk_used_mb": disk.get("used_mb"),
                "processes": metrics.get("processes"),
                "source": metrics.get("source", []),
            })

    # --------------------------------------------------------------- readers
    def latest(self) -> dict:
        with self._lock:
            if self.last_host is None:
                return collect_host_metrics(self.app)
            return self.last_host

    def history(self, key: str, points: int = 120) -> list[dict]:
        with self._lock:
            rows = list(self.host)[-points:]
        return [{"ts": r["ts"], "at": r["at"], "value": r.get(key)} for r in rows]

    def instance_series(self, instance_id: str, points: int = 120) -> list[dict]:
        with self._lock:
            series = self.instances.get(instance_id)
            rows = list(series)[-points:] if series else []
        return rows

    def status(self) -> dict:
        with self._lock:
            return {
                "samples": self.samples,
                "host_points": len(self.host),
                "instance_series": len(self.instances),
                "interval": self.interval,
                "running": bool(self._thread and self._thread.is_alive()),
                "last_error": self.last_error,
            }


def summary_for_dashboard(app) -> dict:
    """Shape used by the dashboard tiles (cpu / memory / disk / uptime)."""
    service = app.extensions.get("skvm_metrics")
    data = service.latest() if service else collect_host_metrics(app)
    return {
        "cpu_percent": data["cpu"]["percent"],
        "cpu_cores": data["cpu"]["cores_logical"],
        "load_avg": data["cpu"]["load_avg"],
        "memory_percent": data["memory"]["percent"],
        "memory_used_mb": data["memory"]["used_mb"],
        "memory_total_mb": data["memory"]["total_mb"],
        "disk_percent": data["disk"]["percent"],
        "disk_used_gb": data["disk"]["used_gb"],
        "disk_total_gb": data["disk"]["total_gb"],
        "uptime_seconds": data["uptime_seconds"],
        "captured_at": data["captured_at"],
    }


__all__ = ["MetricsService", "collect_host_metrics", "summary_for_dashboard"]
