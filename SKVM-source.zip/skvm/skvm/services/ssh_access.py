"""
SSH / remote-access facts.

SKVM never invents an address, a port or a credential.  This module answers a
single question honestly: *what remote access actually exists for this
instance right now?*  Everything it returns is either taken from the database
(which was filled in by a real runtime inspection) or left blank.
"""
from __future__ import annotations

import socket

DEFAULT_SSH_PORT_START = 22000
DEFAULT_SSH_PORT_END = 22999


def port_free(port: int, host: str = "0.0.0.0") -> bool:
    """Is this TCP port really bindable right now?"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((host, port))
            return True
        except OSError:
            return False


def allocate_ssh_port(start: int = DEFAULT_SSH_PORT_START,
                      end: int = DEFAULT_SSH_PORT_END) -> int | None:
    """First free port in the publish range, checked against the kernel."""
    from ..models import VPS

    taken = {v.ssh_port for v in VPS.query.filter(VPS.ssh_port.isnot(None)).all()}
    for port in range(start, end + 1):
        if port in taken:
            continue
        if port_free(port):
            return port
    return None


def describe(vps, profile=None, capabilities: dict | None = None) -> dict:
    """
    A complete, honest description of remote access for one instance.

    ``available`` is true only when a port was actually published *and* the
    instance is running; otherwise ``reason`` explains exactly what is missing
    and ``alternatives`` lists what does work.
    """
    facts = capabilities.get("active_facts") if capabilities else None
    sshd = bool(profile.available("sshd")) if profile is not None else None
    kind = getattr(vps, "kind", "") or ""

    published = bool(vps.ssh_enabled and vps.ssh_port)
    running = bool(vps.is_running)
    address = vps.primary_address or ""

    reason = ""
    if published and not running:
        reason = f"instance is {vps.status_label.lower()}"
    elif published and not address:
        reason = "no address is known for this instance yet"
    elif not published:
        if sshd is False:
            reason = "no sshd is available on this host or image"
        elif kind == "container_namespace":
            reason = ("the namespace backend does not publish ports automatically; "
                      "an sshd inside the instance plus a forwarded port is required")
        elif kind == "container_lxc":
            reason = "no port was published for tcp/22 on this instance"
        elif kind == "container_docker":
            reason = "the container was created without a published port for tcp/22"
        else:
            reason = "this instance kind does not expose SSH"

    return {
        "available": bool(published and running and address),
        "host": address,
        "port": vps.ssh_port,
        "user": vps.ssh_user or "root",
        "command": (f"ssh {vps.ssh_user or 'root'}@{address} -p {vps.ssh_port}"
                    if published and running and address else ""),
        "fingerprint": vps.ssh_key_fingerprint or "",
        "reason": reason,
        "sshd_on_host": sshd,
        "kind": kind,
        "network_model": (facts or {}).get("network_model", "") if facts else "",
        "alternatives": [
            "web console — a real PTY inside the instance",
            "file manager — upload, download and edit files",
        ],
        "note": ("Authentication is configured inside the instance; SKVM does not "
                 "store or generate instance login secrets."),
    }


__all__ = ["describe", "allocate_ssh_port", "port_free"]
