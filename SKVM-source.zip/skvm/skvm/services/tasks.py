"""
Background task runner.

Long operations (image pulls, provisioning, rebuilds, backups) run in worker
threads and persist every state change to the `tasks` table, so:

  * the UI can poll real progress and read the real log;
  * a panel restart does not lose history;
  * tasks that were running when the panel died are reconciled to
    `interrupted` at boot instead of pretending to still be in flight;
  * duplicate submissions are rejected through a per-instance lock.
"""
from __future__ import annotations

import json
import logging
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor
import time
from datetime import datetime

from ..extensions import db
from ..models import Task, TaskStatus, utcnow

logger = logging.getLogger("skvm.tasks")


def commit_with_retry(attempts: int = 6, base_delay: float = 0.15) -> bool:
    """
    Commit, retrying while SQLite reports the database is locked.

    Provisioning tasks write progress from background threads while the web
    process reads; without this a log line could fail the whole task.
    """
    from sqlalchemy.exc import OperationalError

    for attempt in range(attempts):
        try:
            db.session.commit()
            return True
        except OperationalError as exc:
            if "locked" not in str(exc).lower() or attempt == attempts - 1:
                db.session.rollback()
                logger.warning("commit failed: %s", exc)
                return False
            db.session.rollback()
            time.sleep(base_delay * (attempt + 1))
    return False


class TaskRunner:
    """A small, honest thread pool with persisted task state."""

    def __init__(self, app, max_workers: int = 4):
        self.app = app
        self._pool = ThreadPoolExecutor(
            max_workers=max_workers, thread_name_prefix="skvm-task"
        )
        #: instance ids (or resource keys) with an operation in flight
        self._locks: dict[str, str] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------ locking
    def reserve(self, key: str, task_id: str) -> bool:
        with self._lock:
            if key in self._locks:
                return False
            self._locks[key] = task_id
            return True

    def release(self, key: str) -> None:
        with self._lock:
            self._locks.pop(key, None)

    def busy(self, key: str) -> str | None:
        with self._lock:
            return self._locks.get(key)

    # ------------------------------------------------------------ lifecycle
    def submit(self, task: Task, func, *args, **kwargs) -> Task:
        """Queue `func(task, *args, **kwargs)` for execution."""
        self._pool.submit(self._execute, task.id, func, *args, **kwargs)
        return task

    def _execute(self, task_id: int, func, *args, **kwargs) -> None:
        with self.app.app_context():
            task = db.session.get(Task, task_id)
            if task is None:
                return
            task.status = TaskStatus.RUNNING
            task.started_at = utcnow()
            task.progress = max(1, task.progress or 0)
            task.message = "starting"
            db.session.commit()
            logger.info("task %s (%s) started", task.task_id, task.kind)
            try:
                func(task, *args, **kwargs)
                task = db.session.get(Task, task_id)
                if task and not task.is_finished:
                    task.status = TaskStatus.SUCCESS
                    task.progress = 100
                    task.message = task.message or "completed"
                if task:
                    task.finished_at = utcnow()
                    db.session.commit()
                logger.info("task %s finished", task.task_id)
            except Exception as exc:  # noqa: BLE001 - must never kill the pool
                tb = traceback.format_exc()
                logger.exception("task %s failed", task.task_id)
                task = db.session.get(Task, task_id)
                if task:
                    task.status = TaskStatus.FAILED
                    task.error = f"{type(exc).__name__}: {exc}"
                    task.message = str(exc)[:240]
                    task.append_log(f"FAILED: {type(exc).__name__}: {exc}",
                                    commit=False)
                    for line in tb.strip().splitlines()[-6:]:
                        task.append_log(f"  {line}", commit=False)
                    task.finished_at = utcnow()
                    db.session.commit()
                self._on_failure(task, exc)
            finally:
                if task is None:
                    return
                if task.vps_id:
                    self.release(f"vps:{task.vps_id}")
                else:
                    self.release(f"task:{task.kind}")

    def _on_failure(self, task: Task | None, exc: Exception) -> None:
        """Roll instance state back to something truthful after a failure."""
        if task is None or not task.vps_id:
            return
        from ..models import VPS, VPSStatus

        vps = db.session.get(VPS, task.vps_id)
        if vps is None:
            return
        vps.last_error = f"{type(exc).__name__}: {exc}"[:1000]
        if vps.status in VPSStatus.TRANSIENT:
            vps.status = VPSStatus.ERROR
            vps.status_message = str(exc)[:240]
        db.session.commit()

    def shutdown(self, wait: bool = False) -> None:
        self._pool.shutdown(wait=wait)

    # ------------------------------------------------------------ reconciliation
    def reconcile(self) -> dict:
        """
        Called once at startup.  Tasks left queued/running by a previous process
        are marked `interrupted` — never silently reported as successful.
        """
        stale = Task.query.filter(
            Task.status.in_([TaskStatus.QUEUED, TaskStatus.RUNNING])
        ).all()
        for task in stale:
            task.status = TaskStatus.INTERRUPTED
            task.finished_at = utcnow()
            task.message = "interrupted by a panel restart"
            task.append_log("task marked interrupted: the panel restarted while "
                            "this task was in flight")
        # Instances stuck in a transient state need re-verification.
        from ..models import VPS, VPSStatus

        stuck = VPS.query.filter(
            VPS.status.in_(list(VPSStatus.TRANSIENT))
        ).all()
        for vps in stuck:
            vps.status = VPSStatus.UNKNOWN
            vps.status_message = ("state is being re-verified after a panel "
                                  "restart")
        db.session.commit()
        if stale or stuck:
            logger.warning("reconciled %d task(s) and %d instance(s) after restart",
                           len(stale), len(stuck))
        return {"tasks_interrupted": len(stale), "instances_reverified": len(stuck)}


class TaskLogger:
    """Progress sink handed to providers; writes straight into the task row."""

    def __init__(self, task_id: int, app):
        self.task_id = task_id
        self.app = app
        self._last_percent: int | None = None

    def __call__(self, message: str, percent: int | None = None) -> None:
        self.info(message, percent)

    def info(self, message: str, percent: int | None = None) -> None:
        with self.app.app_context():
            task = db.session.get(Task, self.task_id)
            if task is None:
                return
            # Deduplicate consecutive identical lines (providers report often).
            lines = task.log_lines
            if not lines or lines[-1].split("] ", 1)[-1] != message:
                task.append_log(message, commit=False)
            task.message = message[:250]
            if percent is not None:
                self._last_percent = percent
                task.progress = max(0, min(100, int(percent)))
            elif self._last_percent is not None and task.progress < 99:
                self._last_percent = min(99, self._last_percent + 1)
                task.progress = self._last_percent
            # One commit per log line, retried while the database is locked.
            db.session.add(task)
            commit_with_retry()

    def warning(self, message: str) -> None:
        self.info(f"WARNING: {message}")

    def error(self, message: str) -> None:
        self.info(f"ERROR: {message}")
