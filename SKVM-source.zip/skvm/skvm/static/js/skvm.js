/* ==========================================================================
   SKVM front-end runtime.
   Small, dependency-free, and honest: every call hits a real endpoint and
   surfaces the real error text returned by the server.
   ========================================================================== */
(function () {
  "use strict";

  const SKVM = {};
  window.SKVM = SKVM;

  /* ---------------------------------------------------------------- utils */
  SKVM.csrfToken = () => {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.content : "";
  };

  SKVM.escape = (value) =>
    String(value === null || value === undefined ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  SKVM.bytes = (value) => {
    const n = Number(value || 0);
    if (!isFinite(n) || n <= 0) return "0 B";
    const units = ["B", "KiB", "MiB", "GiB", "TiB", "PiB"];
    let i = 0, v = n;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
    return (i === 0 ? v.toFixed(0) : v.toFixed(1)) + " " + units[i];
  };

  SKVM.duration = (seconds) => {
    let s = Math.max(0, Math.floor(Number(seconds) || 0));
    const d = Math.floor(s / 86400); s -= d * 86400;
    const h = Math.floor(s / 3600); s -= h * 3600;
    const m = Math.floor(s / 60); s -= m * 60;
    if (d) return d + "d " + h + "h";
    if (h) return h + "h " + m + "m";
    if (m) return m + "m " + s + "s";
    return s + "s";
  };

  SKVM.ago = (iso) => {
    if (!iso) return "—";
    const then = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z");
    const diff = (Date.now() - then.getTime()) / 1000;
    if (!isFinite(diff)) return "—";
    if (diff < 60) return "just now";
    if (diff < 3600) return Math.floor(diff / 60) + "m ago";
    if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
    return Math.floor(diff / 86400) + "d ago";
  };

  SKVM.time = (iso) => {
    if (!iso) return "—";
    const d = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z");
    if (isNaN(d.getTime())) return "—";
    return d.toLocaleString(undefined, {
      year: "numeric", month: "short", day: "2-digit",
      hour: "2-digit", minute: "2-digit",
    });
  };

  /* ----------------------------------------------------------------- api */
  SKVM.api = async function (path, options) {
    const opts = Object.assign({ method: "GET", expect: "json" }, options || {});
    const headers = Object.assign({ "X-Requested-With": "XMLHttpRequest" }, opts.headers || {});
    let body = opts.body;
    if (body !== undefined && body !== null && !(body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    if (opts.method !== "GET" && opts.method !== "HEAD") {
      headers["X-CSRFToken"] = SKVM.csrfToken();
    }
    let response;
    try {
      response = await fetch(path, {
        method: opts.method, headers: headers, body: body,
        credentials: "same-origin",
      });
    } catch (err) {
      throw new Error("network error: " + err.message);
    }
    if (response.status === 401 && !opts.noRedirect) {
      const json = await response.json().catch(() => ({}));
      if (!json.maintenance) {
        window.location.href = "/login?next=" + encodeURIComponent(window.location.pathname);
        throw new Error("authentication required");
      }
    }
    if (opts.expect === "raw") {
      if (!response.ok) throw new Error("HTTP " + response.status);
      return response;
    }
    let data = null;
    const text = await response.text();
    if (text) {
      try { data = JSON.parse(text); }
      catch (e) {
        if (!response.ok) throw new Error("HTTP " + response.status + ": " + text.slice(0, 200));
        return text;
      }
    }
    if (!response.ok || (data && data.ok === false)) {
      const message = (data && (data.error || data.message)) || ("HTTP " + response.status);
      const error = new Error(message);
      error.status = response.status;
      error.data = data;
      throw error;
    }
    return data;
  };

  /* -------------------------------------------------------------- toasts */
  SKVM.toast = function (message, type, title, timeout) {
    type = type || "info";
    let host = document.querySelector(".sk-toasts");
    if (!host) {
      host = document.createElement("div");
      host.className = "sk-toasts";
      document.body.appendChild(host);
    }
    const icons = { ok: "check-circle", error: "alert-circle", warn: "alert-triangle", info: "info" };
    const el = document.createElement("div");
    el.className = "sk-toast sk-toast-" + type;
    el.innerHTML =
      '<i data-lucide="' + (icons[type] || "info") + '" class="sk-icon"></i>' +
      '<div class="sk-toast-body">' +
      (title ? '<div class="sk-toast-title">' + SKVM.escape(title) + "</div>" : "") +
      '<div class="sk-toast-msg">' + SKVM.escape(message) + "</div></div>" +
      '<button class="sk-toast-close" aria-label="Dismiss"><i data-lucide="x" class="sk-icon sk-icon-sm"></i></button>';
    host.appendChild(el);
    SKVM.icons.render(el);
    const remove = () => el.remove();
    el.querySelector(".sk-toast-close").addEventListener("click", remove);
    setTimeout(remove, timeout || (type === "error" ? 12000 : 5200));
    return el;
  };

  SKVM.ok = (m, t) => SKVM.toast(m, "ok", t);
  SKVM.err = (m, t) => SKVM.toast(m, "error", t);

  /* -------------------------------------------------------------- modals */
  SKVM.modal = function (id) {
    const el = document.getElementById(id);
    if (!el) return null;
    return {
      open() { el.classList.add("is-open"); SKVM.icons.render(el); },
      close() { el.classList.remove("is-open"); },
      el,
    };
  };

  SKVM.confirm = function (options) {
    const opts = typeof options === "string" ? { message: options } : (options || {});
    return new Promise((resolve) => {
      const back = document.createElement("div");
      back.className = "sk-modal-backdrop is-open";
      const danger = opts.danger !== false;
      back.innerHTML =
        '<div class="sk-modal" role="dialog" aria-modal="true">' +
        '<div class="sk-modal-head"><i data-lucide="' +
        (opts.icon || (danger ? "alert-triangle" : "help-circle")) +
        '" class="sk-icon"></i><h3>' + SKVM.escape(opts.title || "Please confirm") + "</h3></div>" +
        '<div class="sk-modal-body"><div class="sk-dim">' +
        SKVM.escape(opts.message || "Are you sure?") + "</div>" +
        (opts.detail ? '<div class="sk-code sk-mt">' + SKVM.escape(opts.detail) + "</div>" : "") +
        (opts.confirmText ? '<div class="sk-field sk-mt"><label class="sk-label">Type <span class="mono">' +
          SKVM.escape(opts.confirmText) + "</span> to confirm</label>" +
          '<input class="sk-input" data-confirm-input autocomplete="off"></div>' : "") +
        "</div>" +
        '<div class="sk-modal-foot">' +
        '<button class="sk-btn" data-cancel>Cancel</button>' +
        '<button class="sk-btn ' + (danger ? "sk-btn-danger" : "sk-btn-primary") +
        '" data-ok' + (opts.confirmText ? " disabled" : "") + ">" +
        SKVM.escape(opts.okText || "Confirm") + "</button></div></div>";
      document.body.appendChild(back);
      SKVM.icons.render(back);
      const input = back.querySelector("[data-confirm-input]");
      const okBtn = back.querySelector("[data-ok]");
      if (input) {
        input.addEventListener("input", () => {
          okBtn.disabled = input.value.trim() !== opts.confirmText;
        });
        setTimeout(() => input.focus(), 60);
      }
      const finish = (value) => { back.remove(); resolve(value); };
      okBtn.addEventListener("click", () => finish(true));
      back.querySelector("[data-cancel]").addEventListener("click", () => finish(false));
      back.addEventListener("click", (e) => { if (e.target === back) finish(false); });
      document.addEventListener("keydown", function onKey(e) {
        if (e.key === "Escape") { document.removeEventListener("keydown", onKey); finish(false); }
      });
    });
  };

  /* --------------------------------------------------------------- misc */
  SKVM.copy = async function (text, label) {
    try {
      await navigator.clipboard.writeText(text);
      SKVM.ok((label || "Copied") + " to the clipboard", "Copied");
    } catch (e) {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); SKVM.ok("Copied to the clipboard"); }
      catch (e2) { SKVM.err("Your browser blocked clipboard access — copy manually."); }
      ta.remove();
    }
  };

  SKVM.setBusy = function (button, busy, label) {
    if (!button) return;
    if (busy) {
      button.dataset.originalHtml = button.innerHTML;
      button.disabled = true;
      button.innerHTML = '<span class="sk-spinner"></span> ' + SKVM.escape(label || "Working…");
    } else {
      button.disabled = false;
      if (button.dataset.originalHtml) button.innerHTML = button.dataset.originalHtml;
    }
  };

  /* -------------------------------------------------------- task watcher */
  SKVM.watchTask = function (taskId, options) {
    const opts = options || {};
    const interval = opts.interval || 1500;
    let stopped = false;
    const tick = async () => {
      if (stopped) return;
      try {
        const data = await SKVM.api("/api/tasks/" + encodeURIComponent(taskId), { noRedirect: true });
        const task = data.task;
        if (opts.onUpdate) opts.onUpdate(task);
        if (task.status === "success" || task.status === "failed" ||
            task.status === "interrupted" || task.status === "cancelled") {
          stopped = true;
          if (opts.onDone) opts.onDone(task);
          return;
        }
      } catch (err) {
        if (opts.onError) opts.onError(err);
        if (!opts.keepPollingOnError) { stopped = true; return; }
      }
      setTimeout(tick, interval);
    };
    tick();
    return { stop() { stopped = true; } };
  };

  /* --------------------------------------------------------- live meters */
  SKVM.sparkline = function (canvas, values, options) {
    if (!canvas) return;
    const opts = options || {};
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || 300;
    const h = canvas.clientHeight || 150;
    canvas.width = w * dpr; canvas.height = h * dpr;
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);

    const pad = 6;
    const data = (values && values.length ? values : [0]).slice(-90);
    const max = Math.max(opts.max || 100, Math.max.apply(null, data) * 1.15, 1);

    ctx.strokeStyle = "rgba(255,255,255,.07)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = pad + ((h - pad * 2) * i) / 4;
      ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(w - pad, y); ctx.stroke();
    }

    const step = (w - pad * 2) / Math.max(1, data.length - 1);
    const points = data.map((v, i) => [pad + i * step, h - pad - ((h - pad * 2) * v) / max]);
    const colour = opts.colour || "#5b8cff";

    ctx.beginPath();
    points.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
    ctx.lineWidth = 2; ctx.strokeStyle = colour;
    ctx.shadowColor = colour; ctx.shadowBlur = 9;
    ctx.stroke();
    ctx.shadowBlur = 0;

    if (opts.fill !== false && points.length > 1) {
      const grad = ctx.createLinearGradient(0, pad, 0, h - pad);
      grad.addColorStop(0, colour + "55");
      grad.addColorStop(1, colour + "00");
      ctx.beginPath();
      ctx.moveTo(points[0][0], h - pad);
      points.forEach((p) => ctx.lineTo(p[0], p[1]));
      ctx.lineTo(points[points.length - 1][0], h - pad);
      ctx.closePath();
      ctx.fillStyle = grad; ctx.fill();

      const last = points[points.length - 1];
      ctx.beginPath(); ctx.arc(last[0], last[1], 3, 0, Math.PI * 2);
      ctx.fillStyle = colour; ctx.fill();
    }
  };

  /* ------------------------------------------------------ ui behaviours */
  SKVM.icons = {
    render(root) {
      const scope = root || document;
      if (window.lucide && typeof window.lucide.createIcons === "function") {
        try {
          window.lucide.createIcons({ attrs: { class: "sk-icon" }, nameAttr: "data-lucide" });
          // Lucide replaces the <i> elements; restore our sizing class.
          scope.querySelectorAll("svg[data-lucide], svg.lucide").forEach((svg) => {
            if (!svg.classList.contains("sk-icon")) svg.classList.add("sk-icon");
          });
          return;
        } catch (e) { /* fall through to the built-in sprite */ }
      }
      const shapes = window.SKVM_ICONS || {};
      scope.querySelectorAll("[data-lucide]").forEach((node) => {
        if (node.tagName.toLowerCase() === "svg") return;
        const name = node.getAttribute("data-lucide");
        const paths = shapes[name] || shapes["help-circle"] || "";
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", "0 0 24 24");
        svg.setAttribute("fill", "none");
        svg.setAttribute("stroke", "currentColor");
        svg.setAttribute("stroke-width", "1.9");
        svg.setAttribute("stroke-linecap", "round");
        svg.setAttribute("stroke-linejoin", "round");
        svg.setAttribute("aria-hidden", "true");
        svg.setAttribute("class", (node.className || "").replace(/^|\s+(?=\S)/g, "$&") + " sk-icon");
        svg.innerHTML = paths;
        node.replaceWith(svg);
      });
    },
  };

  SKVM.init = function () {
    SKVM.icons.render(document);

    // sidebar (mobile)
    const burger = document.querySelector("[data-burger]");
    const sidebar = document.querySelector(".sk-sidebar");
    const scrim = document.querySelector(".sk-sidebar-scrim");
    const toggleSidebar = (open) => {
      if (!sidebar) return;
      sidebar.classList.toggle("is-open", open);
      if (scrim) scrim.classList.toggle("is-open", open);
    };
    if (burger) burger.addEventListener("click", () => toggleSidebar(!sidebar.classList.contains("is-open")));
    if (scrim) scrim.addEventListener("click", () => toggleSidebar(false));

    // dropdowns
    document.querySelectorAll("[data-dropdown]").forEach((trigger) => {
      const menu = document.getElementById(trigger.getAttribute("data-dropdown"));
      if (!menu) return;
      trigger.addEventListener("click", (e) => {
        e.stopPropagation();
        document.querySelectorAll(".sk-dropdown-menu.is-open").forEach((m) => {
          if (m !== menu) m.classList.remove("is-open");
        });
        menu.classList.toggle("is-open");
      });
    });
    document.addEventListener("click", () => {
      document.querySelectorAll(".sk-dropdown-menu.is-open").forEach((m) => m.classList.remove("is-open"));
    });

    // modals
    document.querySelectorAll("[data-modal-open]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        const m = SKVM.modal(el.getAttribute("data-modal-open"));
        if (m) m.open();
        document.dispatchEvent(new CustomEvent("skvm:modal-open", { detail: el.getAttribute("data-modal-open") }));
      });
    });
    document.querySelectorAll("[data-modal-close]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        const back = el.closest(".sk-modal-backdrop");
        if (back) back.classList.remove("is-open");
      });
    });
    document.querySelectorAll(".sk-modal-backdrop").forEach((back) => {
      back.addEventListener("click", (e) => { if (e.target === back) back.classList.remove("is-open"); });
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") document.querySelectorAll(".sk-modal-backdrop.is-open").forEach((b) => b.classList.remove("is-open"));
    });

    // copy buttons
    document.querySelectorAll("[data-copy]").forEach((btn) => {
      btn.addEventListener("click", () => SKVM.copy(btn.getAttribute("data-copy"), btn.getAttribute("data-copy-label")));
    });

    // tabs
    document.querySelectorAll("[data-tabs]").forEach((group) => {
      const buttons = group.querySelectorAll(".sk-tab");
      buttons.forEach((btn) => {
        btn.addEventListener("click", () => {
          const target = btn.getAttribute("data-tab");
          buttons.forEach((b) => b.classList.toggle("is-active", b === btn));
          const container = document.querySelector(group.getAttribute("data-tabs"));
          if (container) {
            container.querySelectorAll(".sk-tab-panel").forEach((panel) => {
              panel.classList.toggle("is-active", panel.getAttribute("data-panel") === target);
            });
          }
          if (history.replaceState) history.replaceState(null, "", "#" + target);
        });
      });
      const initial = window.location.hash.replace("#", "");
      if (initial) {
        const match = group.querySelector('.sk-tab[data-tab="' + initial + '"]');
        if (match) match.click();
      }
    });

    // auto-refresh polling regions: <div data-poll="/api/..."> with a renderer
    document.querySelectorAll("[data-poll]").forEach((el) => {
      const path = el.getAttribute("data-poll");
      const interval = parseInt(el.getAttribute("data-poll-interval") || "5000", 10);
      const render = el.getAttribute("data-poll-render");
      const run = async () => {
        if (document.hidden) return;
        try {
          const data = await SKVM.api(path, { noRedirect: true });
          if (render && typeof SKVM[render] === "function") SKVM[render](el, data);
          document.dispatchEvent(new CustomEvent("skvm:poll", { detail: { el, data, path } }));
        } catch (err) { /* transient failures are not surfaced as toasts */ }
      };
      run();
      setInterval(run, interval);
    });

    // live clocks
    document.querySelectorAll("[data-now]").forEach((el) => {
      const fmt = () => { el.textContent = new Date().toLocaleTimeString(); };
      fmt(); setInterval(fmt, 1000);
    });

    // confirm-then-submit buttons
    document.querySelectorAll("[data-confirm-action]").forEach((el) => {
      el.addEventListener("click", async (e) => {
        e.preventDefault();
        const go = await SKVM.confirm({
          title: el.getAttribute("data-confirm-title") || "Please confirm",
          message: el.getAttribute("data-confirm-action"),
          detail: el.getAttribute("data-confirm-detail") || "",
          okText: el.getAttribute("data-confirm-ok") || "Confirm",
          confirmText: el.getAttribute("data-confirm-phrase") || "",
        });
        if (go) {
          const form = el.closest("form");
          if (form) form.submit();
          else if (el.getAttribute("data-href")) window.location = el.getAttribute("data-href");
        }
      });
    });

    // JSON-submitting forms: <form data-json-action="/api/...">
    document.querySelectorAll("form[data-json-action]").forEach((form) => {
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const button = form.querySelector('[type="submit"]');
        const payload = {};
        new FormData(form).forEach((value, key) => {
          if (key.endsWith("[]")) {
            const k = key.slice(0, -2);
            payload[k] = payload[k] || [];
            payload[k].push(value);
          } else { payload[key] = value; }
        });
        SKVM.setBusy(button, true, form.getAttribute("data-busy-label") || "Saving…");
        try {
          const data = await SKVM.api(form.getAttribute("data-json-action"), { method: form.getAttribute("data-method") || "POST", body: payload });
          SKVM.ok(form.getAttribute("data-success") || "Saved.");
          document.dispatchEvent(new CustomEvent("skvm:form-success", { detail: { form, data } }));
          if (form.getAttribute("data-reload") === "1") setTimeout(() => window.location.reload(), 700);
          if (form.getAttribute("data-redirect")) setTimeout(() => (window.location = form.getAttribute("data-redirect")), 700);
        } catch (err) {
          SKVM.err(err.message, "Action failed");
          document.dispatchEvent(new CustomEvent("skvm:form-error", { detail: { form, error: err } }));
        } finally {
          SKVM.setBusy(button, false);
        }
      });
    });

    // search inputs with debounce that filter table rows client-side
    document.querySelectorAll("[data-filter-target]").forEach((input) => {
      const table = document.querySelector(input.getAttribute("data-filter-target"));
      if (!table) return;
      input.addEventListener("input", () => {
        const needle = input.value.trim().toLowerCase();
        table.querySelectorAll("tbody tr").forEach((row) => {
          const match = !needle || row.textContent.toLowerCase().includes(needle);
          row.classList.toggle("sk-hidden", !match);
        });
      });
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", SKVM.init);
  } else { SKVM.init(); }
})();
