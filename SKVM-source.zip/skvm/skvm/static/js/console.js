/* ==========================================================================
   SKVM console client — xterm.js ⇄ /ws/console/<instance_id>
   The WebSocket is attached to a real PTY running a shell inside the instance.
   ========================================================================== */
(function () {
  "use strict";

  function boot() {
    const mount = document.getElementById("console-root");
    if (!mount) return;

    const instanceId = mount.getAttribute("data-instance");
    const statusEl = document.getElementById("console-status");
    const noticeEl = document.getElementById("console-notice");
    const reconnectBtn = document.getElementById("console-reconnect");
    const clearBtn = document.getElementById("console-clear");
    const copyBtn = document.getElementById("console-copy-log");

    if (typeof window.Terminal === "undefined") {
      mount.innerHTML =
        '<div style="padding:1rem">' +
        '<div class="sk-alert sk-alert-warn"><i data-lucide="alert-triangle" class="sk-icon"></i>' +
        "<div><div class=\"sk-alert-title\">xterm.js is not installed</div>" +
        "<div class=\"sk-tiny sk-dim\">The terminal emulator asset was not found in " +
        "<span class=\"mono\">static/vendor/</span>. Re-run <span class=\"mono\">./install.sh</span> " +
        "with network access to fetch <span class=\"mono\">xterm.js</span>, " +
        "<span class=\"mono\">xterm.css</span> and the fit addon. The console needs it to " +
        "render a real interactive terminal.</div></div></div></div>";
      if (window.SKVM) window.SKVM.icons.render(mount);
      return;
    }

    const term = new window.Terminal({
      cursorBlink: true,
      cursorStyle: "bar",
      fontFamily: 'ui-monospace, "SFMono-Regular", "JetBrains Mono", Menlo, Consolas, monospace',
      fontSize: 13.5,
      lineHeight: 1.35,
      letterSpacing: 0.2,
      scrollback: 8000,
      theme: {
        background: "#05070d",
        foreground: "#dbe4f3",
        cursor: "#5b8cff",
        cursorAccent: "#05070d",
        selectionBackground: "rgba(91,140,255,.32)",
        black: "#1b2033", red: "#f87171", green: "#34d399", yellow: "#fbbf24",
        blue: "#60a5fa", magenta: "#c084fc", cyan: "#22d3ee", white: "#e2e8f0",
        brightBlack: "#4b5563", brightRed: "#fca5a5", brightGreen: "#6ee7b7",
        brightYellow: "#fde68a", brightBlue: "#93c5fd", brightMagenta: "#d8b4fe",
        brightCyan: "#67e8f9", brightWhite: "#f8fafc",
      },
      allowProposedApi: true,
    });

    let fit = null;
    if (window.FitAddon && window.FitAddon.FitAddon) {
      fit = new window.FitAddon.FitAddon();
      term.loadAddon(fit);
    }
    term.open(mount);

    const doFit = () => {
      try {
        if (fit) fit.fit();
      } catch (e) { /* container not measurable yet */ }
    };
    setTimeout(doFit, 60);
    window.addEventListener("resize", () => { doFit(); sendResize(); });

    let socket = null;
    let closedByUser = false;
    let attempts = 0;

    // Buttons in the page can send a checked, predefined command into the
    // attached PTY. Keep the actual WebSocket handle private to this closure.
    window.SKVMConsole = window.SKVMConsole || {};
    window.SKVMConsole.send = function (text) {
      if (!socket || socket.readyState !== WebSocket.OPEN) return false;
      socket.send(JSON.stringify({ type: "input", data: String(text || "") }));
      term.focus();
      return true;
    };

    function setStatus(text, tone) {
      if (!statusEl) return;
      statusEl.className = "sk-badge sk-badge-" + (tone || "muted");
      statusEl.textContent = text;
    }

    function sendResize() {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "resize", cols: term.cols, rows: term.rows }));
      }
    }

    function connect() {
      const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
      const url = proto + "//" + window.location.host + "/ws/console/" + encodeURIComponent(instanceId);
      setStatus("connecting…", "info");
      try {
        socket = new WebSocket(url);
      } catch (err) {
        setStatus("failed", "danger");
        term.writeln("\r\n\x1b[31mCould not open the WebSocket: " + err.message + "\x1b[0m");
        return;
      }

      socket.onopen = () => {
        attempts = 0;
        setStatus("connected", "ok");
        doFit();
        sendResize();
        term.focus();
      };

      socket.onmessage = (event) => {
        let payload;
        try { payload = JSON.parse(event.data); }
        catch (e) { term.write(event.data); return; }
        switch (payload.type) {
          case "ready":
            setStatus("session " + payload.session.slice(0, 8), "ok");
            if (noticeEl && payload.notice) {
              noticeEl.textContent = payload.notice + "  shell: " + payload.shell;
            }
            break;
          case "output":
            term.write(payload.data);
            break;
          case "error":
            setStatus("error", "danger");
            term.writeln("\r\n\x1b[33m" + payload.error + "\x1b[0m");
            if (payload.code) { closedByUser = true; }
            break;
          case "exit":
            setStatus("exited", "muted");
            term.writeln("\r\n\x1b[90m[session ended with status " + payload.code + "]" +
              "  Press the reconnect button to start a new shell.\x1b[0m");
            break;
          case "pong":
            break;
          default:
            break;
        }
      };

      socket.onclose = (event) => {
        if (closedByUser) { setStatus("closed", "muted"); return; }
        setStatus("disconnected", "warn");
        if (event.code === 4401 || event.code === 4403 || event.code === 4404) {
          term.writeln("\r\n\x1b[31mThe console was refused: " +
            (event.reason || "authorization failed") + "\x1b[0m");
          closedByUser = true;
          return;
        }
        attempts += 1;
        if (attempts <= 3) {
          const delay = attempts * 1200;
          term.writeln("\r\n\x1b[90mConnection lost — reconnecting in " +
            (delay / 1000) + "s…\x1b[0m");
          setTimeout(connect, delay);
        } else {
          term.writeln("\r\n\x1b[31mGave up reconnecting. Use the reconnect button.\x1b[0m");
        }
      };

      socket.onerror = () => setStatus("socket error", "danger");
    }

    term.onData((data) => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "input", data: data }));
      }
    });

    term.onResize((size) => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "resize", cols: size.cols, rows: size.rows }));
      }
    });

    if (reconnectBtn) {
      reconnectBtn.addEventListener("click", () => {
        closedByUser = false;
        attempts = 0;
        if (socket) { try { socket.close(); } catch (e) {} }
        connect();
      });
    }
    if (clearBtn) {
      clearBtn.addEventListener("click", () => term.clear());
    }
    if (copyBtn) {
      copyBtn.addEventListener("click", () => {
        const buffer = term.buffer.active;
        const lines = [];
        for (let i = 0; i < buffer.length; i += 1) {
          const line = buffer.getLine(i);
          if (line) lines.push(line.translateToString(true));
        }
        if (window.SKVM) window.SKVM.copy(lines.join("\n").trimEnd(), "Terminal transcript");
      });
    }

    window.addEventListener("beforeunload", () => {
      closedByUser = true;
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "close" }));
        socket.close();
      }
    });

    connect();
    term.focus();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
