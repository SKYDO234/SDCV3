"""
SKVM database models.

Everything the panel shows is persisted here: users, plans, nodes, OS images,
instances, provisioning tasks, backups, API tokens, settings and audit logs.
"""
from __future__ import annotations

import json
import secrets
from datetime import datetime, timedelta, timezone

from flask_login import UserMixin
from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def gen_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def gen_instance_id() -> str:
    return "sk" + secrets.token_hex(8)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow, nullable=False
    )


# --------------------------------------------------------------------------
# users & auth
# --------------------------------------------------------------------------
class Role:
    ADMIN = "admin"
    OPERATOR = "operator"
    USER = "user"
    VIEWER = "viewer"

    ALL = (ADMIN, OPERATOR, USER, VIEWER)
    LABELS = {
        ADMIN: "Administrator",
        OPERATOR: "Operator",
        USER: "User",
        VIEWER: "Read-only",
    }

    # Capability matrix — enforced server-side on every route.
    @staticmethod
    def can_manage_users(role: str) -> bool:
        return role == Role.ADMIN

    @staticmethod
    def can_manage_infrastructure(role: str) -> bool:
        """Plans, nodes, images, global settings, maintenance, API mgmt."""
        return role in (Role.ADMIN, Role.OPERATOR)

    @staticmethod
    def can_create_instances(role: str) -> bool:
        # Per the specification only administrators may create VPS instances.
        return role == Role.ADMIN

    @staticmethod
    def can_operate_own_instances(role: str) -> bool:
        """power ops / console / files on instances the user owns."""
        return role in (Role.ADMIN, Role.OPERATOR, Role.USER)

    @staticmethod
    def can_view_all_instances(role: str) -> bool:
        return role in (Role.ADMIN, Role.OPERATOR, Role.VIEWER)

    @staticmethod
    def is_admin(role: str) -> bool:
        return role == Role.ADMIN


class User(UserMixin, TimestampMixin, db.Model):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(120), default="")
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(16), default=Role.USER, nullable=False)
    is_active_flag: Mapped[bool] = mapped_column("is_active", Boolean, default=True, nullable=False)
    suspended_reason: Mapped[str] = mapped_column(String(255), default="")

    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_login_ip: Mapped[str] = mapped_column(String(64), default="")
    failed_login_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    quota_vcpu: Mapped[int] = mapped_column(Integer, default=4, nullable=False)
    quota_memory_mb: Mapped[int] = mapped_column(Integer, default=4096, nullable=False)
    quota_disk_gb: Mapped[int] = mapped_column(Integer, default=50, nullable=False)
    quota_instances: Mapped[int] = mapped_column(Integer, default=3, nullable=False)

    theme: Mapped[str] = mapped_column(String(16), default="dark")
    notify_email: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    instances: Mapped[list["VPS"]] = relationship(
        back_populates="owner", cascade="all, delete-orphan", foreign_keys="VPS.owner_id"
    )

    # ---- auth helpers
    def set_password(self, raw: str) -> None:
        self.password_hash = generate_password_hash(raw, method="scrypt")

    def check_password(self, raw: str) -> bool:
        if not self.password_hash:
            return False
        try:
            return check_password_hash(self.password_hash, raw)
        except Exception:
            return False

    # UserMixin / Flask-Login expects is_active as a property
    @property
    def is_active(self) -> bool:  # type: ignore[override]
        if not self.is_active_flag:
            return False
        if self.locked_until and self.locked_until > utcnow():
            return False
        return True

    @property
    def is_locked(self) -> bool:
        return bool(self.locked_until and self.locked_until > utcnow())

    @property
    def display_name(self) -> str:
        return self.full_name or self.username

    @property
    def role_label(self) -> str:
        return Role.LABELS.get(self.role, self.role)

    @property
    def initials(self) -> str:
        parts = (self.full_name or self.username).split()
        if len(parts) >= 2:
            return (parts[0][0] + parts[1][0]).upper()
        return (self.username[:2]).upper()

    # ---- authorization shortcuts (server-side only)
    @property
    def is_admin(self) -> bool:
        return Role.is_admin(self.role)

    @property
    def can_create_vps(self) -> bool:
        return Role.can_create_instances(self.role)

    @property
    def can_manage_infra(self) -> bool:
        return Role.can_manage_infrastructure(self.role)

    @property
    def can_view_all(self) -> bool:
        return Role.can_view_all_instances(self.role)

    def owns(self, vps: "VPS") -> bool:
        return vps.owner_id == self.id

    def can_access(self, vps: "VPS") -> bool:
        """Admins/operators may reach any instance; others only their own."""
        if self.is_admin or self.role == Role.OPERATOR:
            return True
        return vps.owner_id == self.id

    def can_operate(self, vps: "VPS") -> bool:
        """Write/destructive operations on an instance."""
        if self.is_admin:
            return True
        if self.role == Role.VIEWER:
            return False
        return vps.owner_id == self.id

    def to_dict(self, include_quota: bool = True) -> dict:
        data = {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "full_name": self.full_name,
            "role": self.role,
            "role_label": self.role_label,
            "is_active": self.is_active_flag,
            "is_locked": self.is_locked,
            "last_login_at": self.last_login_at.isoformat() if self.last_login_at else None,
            "last_login_ip": self.last_login_ip,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        if include_quota:
            data["quota"] = {
                "vcpu": self.quota_vcpu,
                "memory_mb": self.quota_memory_mb,
                "disk_gb": self.quota_disk_gb,
                "instances": self.quota_instances,
            }
        return data


class ApiToken(TimestampMixin, db.Model):
    """Bearer tokens for the REST API (admin managed)."""

    __tablename__ = "api_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    token_prefix: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    scopes: Mapped[str] = mapped_column(String(255), default="read")
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_used_ip: Mapped[str] = mapped_column(String(64), default="")
    revoked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    user: Mapped[User] = relationship()

    @property
    def is_expired(self) -> bool:
        return bool(self.expires_at and self.expires_at <= utcnow())

    @property
    def is_valid(self) -> bool:
        return not self.revoked and not self.is_expired

    @property
    def scope_list(self) -> list[str]:
        return [s for s in (self.scopes or "").split(",") if s]

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "prefix": self.token_prefix,
            "scopes": self.scope_list,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "revoked": self.revoked,
            "owner": self.user.username if self.user else None,
            "created_at": self.created_at.isoformat(),
        }


class LoginAttempt(db.Model):
    __tablename__ = "login_attempts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), index=True, default="")
    ip: Mapped[str] = mapped_column(String(64), index=True, default="")
    success: Mapped[bool] = mapped_column(Boolean, default=False)
    user_agent: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


# --------------------------------------------------------------------------
# infrastructure: plans, nodes, images
# --------------------------------------------------------------------------
class Plan(TimestampMixin, db.Model):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(80), unique=True, index=True, nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    vcpu: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    memory_mb: Mapped[int] = mapped_column(Integer, default=1024, nullable=False)
    disk_gb: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
    bandwidth_gb: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    price_monthly: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_public: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "description": self.description,
            "vcpu": self.vcpu,
            "memory_mb": self.memory_mb,
            "disk_gb": self.disk_gb,
            "bandwidth_gb": self.bandwidth_gb,
            "price_monthly": self.price_monthly,
            "is_active": self.is_active,
            "is_public": self.is_public,
            "sort_order": self.sort_order,
            "instances": self.live_instance_count,
        }

    instances: Mapped[list["VPS"]] = relationship(back_populates="plan")

    @property
    def live_instance_count(self) -> int:
        """
        Instances still using this plan.

        Deleted instances keep their row for the audit trail, so counting
        ``self.instances`` would report a plan as busy long after its last
        instance was deleted — and then let the deletion through anyway,
        because the guard (and every quota check) counts only live rows. The
        number shown must be the number the guard uses.
        """
        return sum(1 for vps in (self.instances or [])
                   if vps.status != VPSStatus.DELETED)


class Node(TimestampMixin, db.Model):
    """A provisioning host.  `local` is this machine; remote nodes are records
    that must have a reachable daemon before they can be scheduled onto."""

    __tablename__ = "nodes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    hostname: Mapped[str] = mapped_column(String(255), default="")
    address: Mapped[str] = mapped_column(String(255), default="")
    provider_hint: Mapped[str] = mapped_column(String(32), default="auto")
    is_local: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    maintenance: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # live snapshot, refreshed by the monitor
    status: Mapped[str] = mapped_column(String(24), default="unknown")
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    agent_version: Mapped[str] = mapped_column(String(32), default="")
    notes: Mapped[str] = mapped_column(Text, default="")

    cpu_cores: Mapped[int] = mapped_column(Integer, default=0)
    memory_mb: Mapped[int] = mapped_column(Integer, default=0)
    disk_gb: Mapped[int] = mapped_column(Integer, default=0)
    metrics_json: Mapped[str] = mapped_column(Text, default="{}")

    instances: Mapped[list["VPS"]] = relationship(back_populates="node")

    @property
    def metrics(self) -> dict:
        try:
            return json.loads(self.metrics_json or "{}")
        except ValueError:
            return {}

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "hostname": self.hostname,
            "address": self.address,
            "provider_hint": self.provider_hint,
            "is_local": self.is_local,
            "is_active": self.is_active,
            "maintenance": self.maintenance,
            "status": self.status,
            "last_seen_at": self.last_seen_at.isoformat() if self.last_seen_at else None,
            "agent_version": self.agent_version,
            "notes": self.notes,
            "cpu_cores": self.cpu_cores,
            "memory_mb": self.memory_mb,
            "disk_gb": self.disk_gb,
            "metrics": self.metrics,
            "instances": self.live_instance_count,
        }

    @property
    def live_instance_count(self) -> int:
        """Instances still running on this node (deleted rows excluded)."""
        return sum(1 for vps in (self.instances or [])
                   if vps.status != VPSStatus.DELETED)


class OSImage(TimestampMixin, db.Model):
    """An installable operating system root filesystem.

    `reference` is a real, pullable OCI image reference (e.g. library/ubuntu:22.04)
    — never a decorative row.  `status` reflects genuine local availability.
    """

    __tablename__ = "os_images"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    slug: Mapped[str] = mapped_column(String(80), unique=True, index=True, nullable=False)
    family: Mapped[str] = mapped_column(String(32), default="linux")
    version: Mapped[str] = mapped_column(String(32), default="")
    codename: Mapped[str] = mapped_column(String(32), default="")
    registry: Mapped[str] = mapped_column(String(120), default="registry-1.docker.io")
    reference: Mapped[str] = mapped_column(String(255), nullable=False)
    default_user: Mapped[str] = mapped_column(String(32), default="root")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="not_downloaded")
    status_detail: Mapped[str] = mapped_column(Text, default="")
    rootfs_path: Mapped[str] = mapped_column(String(512), default="")
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    digest: Mapped[str] = mapped_column(String(128), default="")
    pulled_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)

    @property
    def available(self) -> bool:
        return self.status == "ready"

    @property
    def label(self) -> str:
        return f"{self.name} {self.version}".strip()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "family": self.family,
            "version": self.version,
            "codename": self.codename,
            "registry": self.registry,
            "reference": self.reference,
            "default_user": self.default_user,
            "is_active": self.is_active,
            "status": self.status,
            "status_detail": self.status_detail,
            "available": self.available,
            "size_bytes": self.size_bytes,
            "size_mb": round(self.size_bytes / 1048576, 1) if self.size_bytes else 0,
            "digest": self.digest,
            "pulled_at": self.pulled_at.isoformat() if self.pulled_at else None,
            "label": self.label,
        }


# --------------------------------------------------------------------------
# instances
# --------------------------------------------------------------------------
class VPSStatus:
    PROVISIONING = "provisioning"
    RUNNING = "running"
    STOPPED = "stopped"
    RESTARTING = "restarting"
    REBUILDING = "rebuilding"
    ERROR = "error"
    SUSPENDED = "suspended"
    DELETING = "deleting"
    DELETED = "deleted"
    UNKNOWN = "unknown"

    ALL = (
        PROVISIONING, RUNNING, STOPPED, RESTARTING, REBUILDING,
        ERROR, SUSPENDED, DELETING, DELETED, UNKNOWN,
    )
    LIVE = (RUNNING,)
    TRANSIENT = (PROVISIONING, RESTARTING, REBUILDING, DELETING)
    LABELS = {
        PROVISIONING: "Provisioning",
        RUNNING: "Running",
        STOPPED: "Stopped",
        RESTARTING: "Restarting",
        REBUILDING: "Rebuilding",
        ERROR: "Error",
        SUSPENDED: "Suspended",
        DELETING: "Deleting",
        DELETED: "Deleted",
        UNKNOWN: "Unknown",
    }
    TONE = {
        RUNNING: "ok",
        STOPPED: "muted",
        PROVISIONING: "info",
        REBUILDING: "info",
        RESTARTING: "info",
        DELETING: "warn",
        SUSPENDED: "warn",
        ERROR: "danger",
        DELETED: "muted",
        UNKNOWN: "muted",
    }


class VPS(TimestampMixin, db.Model):
    """A provisioned instance.

    IMPORTANT/HONESTY: `kind` records what the instance *actually* is.
      container_docker  — OCI container managed by the Docker daemon
      container_lxc     — LXC/Incus system container
      container_namespace — unprivileged Linux-namespace container
                            (user+PID+mount+UTS+IPC namespaces, cgroup limits)
    None of these are KVM virtual machines.  The UI labels them accordingly and
    `is_virtual_machine` stays False unless a real hypervisor backend exists.
    """

    __tablename__ = "vps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    instance_id: Mapped[str] = mapped_column(
        String(32), unique=True, index=True, default=gen_instance_id, nullable=False
    )
    name: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    hostname: Mapped[str] = mapped_column(String(64), nullable=False)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("plans.id", ondelete="SET NULL"))
    node_id: Mapped[int | None] = mapped_column(ForeignKey("nodes.id", ondelete="SET NULL"))
    image_id: Mapped[int | None] = mapped_column(ForeignKey("os_images.id", ondelete="SET NULL"))

    provider: Mapped[str] = mapped_column(String(24), default="", nullable=False)
    kind: Mapped[str] = mapped_column(String(32), default="", nullable=False)
    runtime_id: Mapped[str] = mapped_column(String(128), default="")
    rootfs_path: Mapped[str] = mapped_column(String(512), default="")

    vcpu: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    memory_mb: Mapped[int] = mapped_column(Integer, default=1024, nullable=False)
    disk_gb: Mapped[int] = mapped_column(Integer, default=10, nullable=False)

    status: Mapped[str] = mapped_column(String(24), default=VPSStatus.PROVISIONING, index=True)
    status_message: Mapped[str] = mapped_column(Text, default="")
    stopped_by_user: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    os_name: Mapped[str] = mapped_column(String(80), default="")
    os_version: Mapped[str] = mapped_column(String(32), default="")
    os_reference: Mapped[str] = mapped_column(String(255), default="")

    internal_ip: Mapped[str] = mapped_column(String(64), default="")
    public_ip: Mapped[str] = mapped_column(String(64), default="")
    ssh_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ssh_user: Mapped[str] = mapped_column(String(32), default="root")
    ssh_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ssh_key_fingerprint: Mapped[str] = mapped_column(String(128), default="")

    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    suspend_on_expiry: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    auto_renew: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    cpu_used_percent: Mapped[float] = mapped_column(Float, default=0.0)
    memory_used_mb: Mapped[float] = mapped_column(Float, default=0.0)
    disk_used_mb: Mapped[float] = mapped_column(Float, default=0.0)
    metrics_json: Mapped[str] = mapped_column(Text, default="{}")
    metrics_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    boot_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str] = mapped_column(Text, default="")

    owner: Mapped[User] = relationship(back_populates="instances", foreign_keys=[owner_id])
    plan: Mapped[Plan | None] = relationship(back_populates="instances")
    node: Mapped[Node | None] = relationship(back_populates="instances")
    image: Mapped[OSImage | None] = relationship()
    tasks: Mapped[list["Task"]] = relationship(
        back_populates="vps", cascade="all, delete-orphan"
    )
    backups: Mapped[list["Backup"]] = relationship(
        back_populates="vps", cascade="all, delete-orphan"
    )

    # ---- derived
    @property
    def is_running(self) -> bool:
        return self.status == VPSStatus.RUNNING

    @property
    def is_transient(self) -> bool:
        return self.status in VPSStatus.TRANSIENT

    @property
    def is_virtual_machine(self) -> bool:
        """True only for genuine hypervisor-backed instances. Always False for
        every container backend this panel implements."""
        return self.kind == "vm_kvm"

    @property
    def kind_label(self) -> str:
        return {
            "container_docker": "Docker container",
            "container_lxc": "LXC system container",
            "container_namespace": "Namespace container (unprivileged)",
            "vm_kvm": "KVM virtual machine",
        }.get(self.kind, self.kind or "Unknown")

    @property
    def kind_short(self) -> str:
        return {
            "container_docker": "Docker",
            "container_lxc": "LXC",
            "container_namespace": "Namespace",
            "vm_kvm": "KVM",
        }.get(self.kind, "—")

    @property
    def status_label(self) -> str:
        return VPSStatus.LABELS.get(self.status, self.status.title())

    @property
    def status_tone(self) -> str:
        return VPSStatus.TONE.get(self.status, "muted")

    @property
    def is_expired(self) -> bool:
        return bool(self.expires_at and self.expires_at <= utcnow())

    @property
    def days_to_expiry(self) -> int | None:
        if not self.expires_at:
            return None
        delta = self.expires_at - utcnow()
        return int(delta.total_seconds() // 86400)

    @property
    def uptime_seconds(self) -> int | None:
        if not self.boot_at or not self.is_running:
            return None
        return int((utcnow() - self.boot_at).total_seconds())

    @property
    def primary_address(self) -> str:
        return self.public_ip or self.internal_ip or ""

    @property
    def metrics(self) -> dict:
        try:
            return json.loads(self.metrics_json or "{}")
        except ValueError:
            return {}

    def set_metrics(self, payload: dict) -> None:
        self.metrics_json = json.dumps(payload)
        self.metrics_at = utcnow()
        cpu = payload.get("cpu", {})
        mem = payload.get("memory", {})
        if isinstance(cpu, dict) and cpu.get("percent") is not None:
            self.cpu_used_percent = float(cpu["percent"])
        if isinstance(mem, dict) and mem.get("used_mb") is not None:
            self.memory_used_mb = float(mem["used_mb"])
        disk = payload.get("disk", {})
        if isinstance(disk, dict) and disk.get("used_mb") is not None:
            self.disk_used_mb = float(disk["used_mb"])

    def to_dict(self, detail: bool = False) -> dict:
        data = {
            "id": self.id,
            "instance_id": self.instance_id,
            "name": self.name,
            "hostname": self.hostname,
            "status": self.status,
            "status_label": self.status_label,
            "status_tone": self.status_tone,
            "status_message": self.status_message,
            "owner": {
                "id": self.owner_id,
                "username": self.owner.username if self.owner else None,
            },
            "provider": self.provider,
            "kind": self.kind,
            "kind_label": self.kind_label,
            "kind_short": self.kind_short,
            "is_virtual_machine": self.is_virtual_machine,
            "isolation": self.kind_label,
            "runtime_id": self.runtime_id,
            "resources": {
                "vcpu": self.vcpu,
                "memory_mb": self.memory_mb,
                "disk_gb": self.disk_gb,
            },
            "os": {
                "name": self.os_name,
                "version": self.os_version,
                "reference": self.os_reference,
            },
            "network": {
                "public_ip": self.public_ip or None,
                "internal_ip": self.internal_ip or None,
                "ssh_port": self.ssh_port,
                "ssh_user": self.ssh_user,
                "ssh_enabled": self.ssh_enabled,
                "ssh_key_fingerprint": self.ssh_key_fingerprint or None,
            },
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "days_to_expiry": self.days_to_expiry,
            "is_expired": self.is_expired,
            "uptime_seconds": self.uptime_seconds,
            "metrics_at": self.metrics_at.isoformat() if self.metrics_at else None,
            "last_error": self.last_error or None,
        }
        if detail:
            data["metrics"] = self.metrics
            data["node"] = {"id": self.node_id, "name": self.node.name if self.node else None}
            data["plan"] = (
                {"id": self.plan_id, "name": self.plan.name} if self.plan else None
            )
        return data


# --------------------------------------------------------------------------
# tasks / audit / backups / settings
# --------------------------------------------------------------------------
class TaskStatus:
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    INTERRUPTED = "interrupted"
    CANCELLED = "cancelled"


class Task(TimestampMixin, db.Model):
    """A persisted background job (provision, rebuild, backup, image pull...).

    Survives restarts: any task still marked running at boot is reconciled to
    `interrupted` so the UI never shows a ghost operation.
    """

    __tablename__ = "tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    task_id: Mapped[str] = mapped_column(
        String(32), unique=True, index=True, default=gen_instance_id, nullable=False
    )
    kind: Mapped[str] = mapped_column(String(48), index=True, nullable=False)
    title: Mapped[str] = mapped_column(String(160), default="")
    status: Mapped[str] = mapped_column(String(16), default=TaskStatus.QUEUED, index=True)
    progress: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[str] = mapped_column(String(255), default="")
    logs: Mapped[str] = mapped_column(Text, default="")
    result: Mapped[str] = mapped_column(Text, default="{}")
    error: Mapped[str] = mapped_column(Text, default="")
    retries: Mapped[int] = mapped_column(Integer, default=0)
    max_retries: Mapped[int] = mapped_column(Integer, default=2)
    payload: Mapped[str] = mapped_column(Text, default="{}")
    requested_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    vps_id: Mapped[int | None] = mapped_column(
        ForeignKey("vps.id", ondelete="CASCADE"), nullable=True, index=True
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    vps: Mapped[VPS | None] = relationship(back_populates="tasks")
    requested_by: Mapped[User | None] = relationship()

    MAX_LOG_CHARS = 200_000

    def append_log(self, line: str, commit: bool = True) -> None:
        """
        Append one timestamped line to the task log.

        ``commit=False`` lets a caller batch several field updates into a single
        commit (see ``TaskLogger.info``).  Commits are retried while SQLite
        holds a write lock, because provisioning tasks log from background
        threads while the web process is serving requests.
        """
        stamp = utcnow().strftime("%H:%M:%S")
        chunk = f"[{stamp}] {line}"
        combined = (self.logs or "") + chunk + "\n"
        if len(combined) > self.MAX_LOG_CHARS:
            combined = combined[-self.MAX_LOG_CHARS:]
        self.logs = combined
        if commit:
            from .services.tasks import commit_with_retry

            commit_with_retry()

    @property
    def is_finished(self) -> bool:
        return self.status in (
            TaskStatus.SUCCESS, TaskStatus.FAILED,
            TaskStatus.INTERRUPTED, TaskStatus.CANCELLED,
        )

    @property
    def is_durable(self) -> bool:
        return self.status in (TaskStatus.QUEUED, TaskStatus.RUNNING)

    @property
    def log_lines(self) -> list[str]:
        return [ln for ln in (self.logs or "").splitlines() if ln.strip()]

    def result_data(self) -> dict:
        try:
            return json.loads(self.result or "{}")
        except ValueError:
            return {}

    def payload_data(self) -> dict:
        try:
            return json.loads(self.payload or "{}")
        except ValueError:
            return {}

    def to_dict(self, include_logs: bool = False) -> dict:
        data = {
            "id": self.id,
            "task_id": self.task_id,
            "kind": self.kind,
            "title": self.title,
            "status": self.status,
            "progress": self.progress,
            "message": self.message,
            "error": self.error or None,
            "retries": self.retries,
            "max_retries": self.max_retries,
            "vps_id": self.vps_id,
            "vps_name": self.vps.name if self.vps else None,
            "requested_by": self.requested_by.username if self.requested_by else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "result": self.result_data(),
        }
        if include_logs:
            data["logs"] = self.log_lines
        return data


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    level: Mapped[str] = mapped_column(String(16), default="info", index=True)
    category: Mapped[str] = mapped_column(String(32), default="general", index=True)
    action: Mapped[str] = mapped_column(String(96), index=True, default="")
    message: Mapped[str] = mapped_column(Text, default="")
    actor_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    actor_username: Mapped[str] = mapped_column(String(64), default="")
    target: Mapped[str] = mapped_column(String(120), default="")
    ip: Mapped[str] = mapped_column(String(64), default="")
    user_agent: Mapped[str] = mapped_column(String(255), default="")
    meta_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)

    actor: Mapped[User | None] = relationship()

    @property
    def meta(self) -> dict:
        try:
            return json.loads(self.meta_json or "{}")
        except ValueError:
            return {}

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "level": self.level,
            "category": self.category,
            "action": self.action,
            "message": self.message,
            "actor": self.actor_username,
            "target": self.target,
            "ip": self.ip,
            "meta": self.meta,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Backup(TimestampMixin, db.Model):
    __tablename__ = "backups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    backup_id: Mapped[str] = mapped_column(
        String(32), unique=True, index=True, default=gen_instance_id, nullable=False
    )
    vps_id: Mapped[int] = mapped_column(ForeignKey("vps.id", ondelete="CASCADE"))
    label: Mapped[str] = mapped_column(String(120), default="")
    file_path: Mapped[str] = mapped_column(String(512), default="")
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(16), default="creating")
    detail: Mapped[str] = mapped_column(Text, default="")
    created_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    vps: Mapped[VPS] = relationship(back_populates="backups")
    created_by: Mapped[User | None] = relationship()

    @property
    def size_mb(self) -> float:
        return round(self.size_bytes / 1048576, 2)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "backup_id": self.backup_id,
            "vps_id": self.vps_id,
            "vps_name": self.vps.name if self.vps else None,
            "label": self.label,
            "size_bytes": self.size_bytes,
            "size_mb": self.size_mb,
            "status": self.status,
            "detail": self.detail,
            "created_by": self.created_by.username if self.created_by else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Setting(db.Model):
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")
    value_type: Mapped[str] = mapped_column(String(16), default="string")
    label: Mapped[str] = mapped_column(String(120), default="")
    group: Mapped[str] = mapped_column(String(32), default="general")
    description: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    def python_value(self):
        if self.value_type == "bool":
            return str(self.value).lower() in {"1", "true", "yes", "on"}
        if self.value_type == "int":
            try:
                return int(self.value)
            except (TypeError, ValueError):
                return 0
        if self.value_type == "float":
            try:
                return float(self.value)
            except (TypeError, ValueError):
                return 0.0
        return self.value

    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "value": self.value,
            "value_type": self.value_type,
            "label": self.label,
            "group": self.group,
            "description": self.description,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class MaintenanceState(db.Model):
    """Single-row table (id=1) describing the maintenance mode."""

    __tablename__ = "maintenance_state"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    message: Mapped[str] = mapped_column(Text, default="")
    allow_admins: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    scheduled_for: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    enabled_by: Mapped[str] = mapped_column(String(64), default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    def to_dict(self) -> dict:
        return {
            "enabled": self.enabled,
            "message": self.message,
            "allow_admins": self.allow_admins,
            "scheduled_for": self.scheduled_for.isoformat() if self.scheduled_for else None,
            "enabled_by": self.enabled_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ConsoleSession(db.Model):
    """Real PTY sessions currently attached to an instance's console."""

    __tablename__ = "console_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_key: Mapped[str] = mapped_column(
        String(48), unique=True, index=True, default=gen_token, nullable=False
    )
    vps_id: Mapped[int] = mapped_column(ForeignKey("vps.id", ondelete="CASCADE"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    pid: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cols: Mapped[int] = mapped_column(Integer, default=120)
    rows: Mapped[int] = mapped_column(Integer, default=30)
    opened_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    command: Mapped[str] = mapped_column(String(255), default="")
    close_reason: Mapped[str] = mapped_column(String(64), default="")

    vps: Mapped[VPS] = relationship()
    user: Mapped[User] = relationship()

    @property
    def is_open(self) -> bool:
        return self.closed_at is None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "session_key": self.session_key,
            "vps_id": self.vps_id,
            "user": self.user.username if self.user else None,
            "pid": self.pid,
            "cols": self.cols,
            "rows": self.rows,
            "command": self.command,
            "open": self.is_open,
            "opened_at": self.opened_at.isoformat() if self.opened_at else None,
            "closed_at": self.closed_at.isoformat() if self.closed_at else None,
        }


__all__ = [
    "User", "Role", "ApiToken", "LoginAttempt", "Plan", "Node", "OSImage",
    "VPS", "VPSStatus", "Task", "TaskStatus", "AuditLog", "Backup", "Setting",
    "MaintenanceState", "ConsoleSession", "utcnow", "gen_token", "gen_instance_id",
    "UniqueConstraint", "func", "timedelta",
]
