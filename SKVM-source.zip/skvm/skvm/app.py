"""SKVM application factory."""
from __future__ import annotations

import atexit
import json
import logging
import logging.handlers
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, url_for
from flask_login import current_user

from .config import Config
from .extensions import csrf, db, limiter, login_manager
from .models import Role, Task, TaskStatus, VPS, VPSStatus, utcnow
from .services import settings_service
from .services.bootstrap import create_schema, seed
from .services.console import ConsoleManager
from .services.tasks import TaskRunner


class JsonFormatter(logging.Formatter):
    """Structured logs — one JSON object per line when SKVM_LOG_JSON=true."""

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.fromtimestamp(record.created, timezone.utc)
            .isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in ("request_id", "user", "instance", "task", "action", "ip"):
            value = getattr(record, key, None)
            if value:
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_sqlite(app) -> None:
    """
    SQLite needs two pragmas to survive real use:

    * ``journal_mode=WAL`` so a background provisioning task can write while a
      request is being served.
    * ``busy_timeout`` so a brief writer collision waits instead of failing with
      "database is locked".
    """
    from sqlalchemy import event
    from sqlalchemy.engine import Engine

    uri = str(app.config.get("SQLALCHEMY_DATABASE_URI", ""))
    if not uri.startswith("sqlite"):
        return

    @event.listens_for(Engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, connection_record):  # noqa: ARG001
        try:
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=30000")
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
        except Exception:  # noqa: BLE001 - never break a connection over a pragma
            pass


def register_auth_loaders() -> None:
    """
    Flask-Login needs to resolve a session cookie (and a bearer token) back to a
    real user row on every request; without these the panel would 500.
    """
    if getattr(login_manager, "_skvm_loaders_registered", False):
        return
    login_manager._skvm_loaders_registered = True  # type: ignore[attr-defined]

    @login_manager.user_loader
    def _load_user(user_id: str):
        from .models import User

        try:
            user = db.session.get(User, int(user_id))
        except (TypeError, ValueError):
            return None
        if user is None or not user.is_active_flag:
            return None
        return user

    @login_manager.request_loader
    def _load_user_from_request(request):  # noqa: ARG001
        """Bearer tokens authenticate API clients exactly like a session does."""
        header = request.headers.get("Authorization", "")
        if not header.lower().startswith("bearer "):
            return None
        from .security import effective_scopes, verify_api_token

        token = verify_api_token(header.split(" ", 1)[1].strip())
        if token is None or token.user is None or not token.user.is_active_flag:
            return None
        from flask import g

        g.api_token = token
        g.api_user = token.user
        g.api_scopes = effective_scopes(token.scope_list)
        return token.user

    @login_manager.unauthorized_handler
    def _unauthorized():
        from flask import jsonify, redirect, request, url_for

        if (request.path.startswith("/api/") or request.path.startswith("/ws/")
                or request.headers.get("X-Requested-With") == "XMLHttpRequest"):
            return jsonify({"ok": False, "error": "authentication required",
                            "code": 401}), 401
        return redirect(url_for("auth.login", next=request.full_path))


def configure_logging(config) -> None:
    # `config` is a Flask config mapping — read keys, not attributes.
    log_dir = Path(config["LOG_DIR"])
    log_dir.mkdir(parents=True, exist_ok=True)
    level = getattr(logging, str(config["LOG_LEVEL"]).upper(), logging.INFO)

    root = logging.getLogger()
    root.setLevel(level)
    for handler in list(root.handlers):
        root.removeHandler(handler)

    stream = logging.StreamHandler()
    stream.setFormatter(JsonFormatter() if config["LOG_JSON"]
                        else logging.Formatter(config["LOG_FORMAT"]))
    root.addHandler(stream)

    file_handler = logging.handlers.RotatingFileHandler(
        log_dir / "skvm.log", maxBytes=config["LOG_MAX_BYTES"],
        backupCount=config["LOG_BACKUP_COUNT"], encoding="utf-8",
    )
    file_handler.setFormatter(logging.Formatter(config["LOG_FORMAT"]))
    root.addHandler(file_handler)

    logging.getLogger("werkzeug").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("docker").setLevel(logging.WARNING)


def create_app(config_object=Config, overrides: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_object)
    if overrides:
        app.config.update(overrides)

    app.config["SERVER_NAME"] = None
    config_object.ensure_dirs()
    configure_logging(app.config)

    log = logging.getLogger("skvm.app")
    log.info("starting %s %s in %s mode", app.config["APP_NAME"],
             app.config["VERSION"], app.config["ENV_NAME"])

    db.init_app(app)
    configure_sqlite(app)
    # CSRF is enforced for cookie-authenticated requests. A request that presents
    # an `Authorization: Bearer skvm_…` token is *not* cookie-authenticated and
    # cannot be forged by a third-party site, so it must not be forced to send a
    # CSRF token — otherwise the REST API would be unusable from curl or any
    # other plain HTTP client, which is the whole point of the token API.
    # `WTF_CSRF_CHECK_DEFAULT = False` hands control of when to protect to us.
    app.config.setdefault("WTF_CSRF_CHECK_DEFAULT", False)
    csrf.init_app(app)

    @app.before_request
    def _csrf_protection():
        if not app.config.get("WTF_CSRF_ENABLED", True):
            return None
        from flask import g

        from .extensions import csrf as csrf_ext

        header = request.headers.get("Authorization", "")
        if header.lower().startswith("bearer "):
            g.csrf_exempt_reason = "bearer token"
            return None
        return csrf_ext.protect()
    login_manager.init_app(app)
    limiter.init_app(app)
    register_auth_loaders()

    # Rate limiting: real limits, applied per endpoint (see the views) on top of
    # this global ceiling.  Headers are sent so an operator can see the quota.
    app.config.setdefault("RATELIMIT_DEFAULT", "1200 per hour")
    app.config.setdefault("RATELIMIT_HEADERS_ENABLED", True)

    from .views import register_views
    from .api import register_api

    register_views(app)
    register_api(app)
    register_cli(app)

    with app.app_context():
        create_schema(app)
        report = seed()
        log.info("bootstrap: %s", report)

        runner = TaskRunner(app, max_workers=4)
        from .provisioning.manager import ProvisioningManager
        from .services.backup import BackupService
        from .services.instances import InstanceService
        from .services.metrics import MetricsService

        manager = ProvisioningManager(app, runner)
        app.extensions["skvm_runner"] = runner
        app.extensions["skvm_manager"] = manager
        app.extensions["skvm_console"] = ConsoleManager(app)
        app.extensions["skvm_instances"] = InstanceService(app)
        app.extensions["skvm_backups"] = BackupService(app)

        # Make the image catalogue agree with the cache on disk before the
        # first request: after a database reset or a manual cache drop the
        # panel would otherwise report stale "not downloaded" state.
        try:
            cache = manager.reconcile_image_cache()
            if cache.get("promoted") or cache.get("demoted"):
                log.info("image cache reconcile: %s", cache)
        except Exception as exc:  # noqa: BLE001 - never block startup on this
            log.warning("image cache reconcile failed: %s", exc)

        metrics = MetricsService(
            app, interval=float(settings_service.get("metrics_sample_seconds", 5) or 5))
        app.extensions["skvm_metrics"] = metrics
        if not app.config.get("TESTING"):
            metrics.start()

        # Reconcile anything left over from a previous process.
        reconcile = runner.reconcile()
        if reconcile["tasks_interrupted"] or reconcile["instances_reverified"]:
            log.warning("restart reconciliation: %s", reconcile)
        try:
            manager.refresh_local_node()
        except Exception as exc:  # noqa: BLE001
            log.warning("could not refresh the local node record: %s", exc)

        if app.config.get("SKVM_START_MONITOR", True) and not app.config.get("TESTING"):
            manager.start_monitor(
                interval=int(settings_service.get("metrics_interval", 15)))

        # Keep the login-attempt table from growing without bound.
        from .models import LoginAttempt

        LoginAttempt.query.filter(
            LoginAttempt.created_at < utcnow() - timedelta(days=7)
        ).delete(synchronize_session=False)
        db.session.commit()

        from .provisioning.runtime import helper_version

        helper = helper_version()
        if not helper.get("ok"):
            log.warning("privileged helper not available: %s", helper.get("error"))
        else:
            log.info("privileged helper v%s ready (euid=%s)",
                     helper.get("version"), helper.get("euid"))

    register_error_handlers(app)
    register_context(app)

    def _shutdown() -> None:
        """Stop background threads and close real resources cleanly."""
        metrics = app.extensions.get("skvm_metrics")
        if metrics is not None:
            metrics.stop()
        monitor = app.extensions.get("skvm_manager")
        if monitor is not None:
            try:
                monitor.stop_monitor()
            except Exception:  # noqa: BLE001
                pass
        console = app.extensions.get("skvm_console")
        if console is not None:
            try:
                console.close_all("panel stopped")
            except Exception:  # noqa: BLE001
                pass

    atexit.register(_shutdown)

    @app.before_request
    def _maintenance_gate():
        from .models import MaintenanceState

        if request.path.startswith(("/static/", "/api/health", "/healthz",
                                    "/api/system/health")):
            return None
        if not current_user.is_authenticated:
            return None
        state = db.session.get(MaintenanceState, 1)
        if state is None or not state.enabled:
            return None
        if current_user.is_admin and state.allow_admins:
            return None
        allowed_endpoints = {"auth.logout", "auth.login", "static", "health",
                             "maintenance_page", "profile.index"}
        if request.endpoint in allowed_endpoints:
            return None
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "maintenance": True,
                            "error": state.message or "the panel is in maintenance"}), 503
        return render_template("errors/maintenance.html", state=state), 503

    @app.after_request
    def _security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        response.headers.setdefault(
            "Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        # The panel is embedded in the sandbox preview iframe, so no
        # frame-ancestors restriction that would break the preview.
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self' "
            "'unsafe-inline'; script-src 'self'; connect-src 'self' ws: wss:; "
            "font-src 'self' data:; object-src 'none'; base-uri 'self'",
        )
        return response

    @app.teardown_appcontext
    def _shutdown_session(exception=None):
        db.session.remove()

    return app


def register_error_handlers(app: Flask) -> None:
    def wants_json() -> bool:
        return (request.path.startswith("/api/")
                or request.headers.get("X-Requested-With") == "XMLHttpRequest"
                or (request.accept_mimetypes.accept_json
                    and not request.accept_mimetypes.accept_html))

    @app.errorhandler(400)
    def bad_request(error):
        message = getattr(error, "description", "Bad request")
        if wants_json():
            return jsonify({"ok": False, "error": message, "code": 400}), 400
        return render_template("errors/error.html", code=400,
                               title="Bad request", message=message), 400

    @app.errorhandler(401)
    def unauthorized(error):
        if wants_json():
            return jsonify({"ok": False, "error": "authentication required",
                            "code": 401}), 401
        return redirect(url_for("auth.login", next=request.full_path))

    @app.errorhandler(403)
    def forbidden(error):
        message = getattr(error, "description", "You do not have permission "
                                                "to access this resource.")
        if wants_json():
            return jsonify({"ok": False, "error": message, "code": 403}), 403
        return render_template("errors/error.html", code=403,
                               title="Access denied", message=message), 403

    @app.errorhandler(404)
    def not_found(error):
        if wants_json():
            return jsonify({"ok": False, "error": "not found", "code": 404}), 404
        return render_template("errors/error.html", code=404,
                               title="Not found",
                               message="That page does not exist."), 404

    @app.errorhandler(429)
    def rate_limited(error):
        message = ("Too many requests — slow down and try again shortly.")
        if wants_json():
            return jsonify({"ok": False, "error": message, "code": 429,
                            "retry_after": getattr(error, "retry_after", None)}), 429
        return render_template("errors/error.html", code=429,
                               title="Rate limited", message=message), 429

    @app.errorhandler(500)
    def server_error(error):
        logging.getLogger("skvm.app").exception("unhandled error: %s", error)
        message = ("An internal error occurred. The full traceback is in "
                   "data/logs/skvm.log.")
        if wants_json():
            return jsonify({"ok": False, "error": message, "code": 500}), 500
        return render_template("errors/error.html", code=500,
                               title="Internal error", message=message), 500

    @app.errorhandler(Exception)
    def unhandled(error):
        from werkzeug.exceptions import HTTPException

        if isinstance(error, HTTPException):
            return error
        logging.getLogger("skvm.app").exception("unhandled exception")
        if wants_json():
            return jsonify({"ok": False,
                            "error": f"{type(error).__name__}: {error}",
                            "code": 500}), 500
        return render_template("errors/error.html", code=500,
                               title="Internal error",
                               message=f"{type(error).__name__}: {error}"), 500


def _page_url(page: int) -> str:
    """Build a URL that keeps the current query string but swaps `page`."""
    from urllib.parse import urlencode

    args = request.args.to_dict(flat=True)
    args["page"] = page
    return f"{request.path}?{urlencode(args)}"


def register_context(app: Flask) -> None:
    @app.context_processor
    def inject_globals():
        manager = app.extensions.get("skvm_manager")
        badge = None
        try:
            if manager is not None:
                provider, _ = manager.provider()
                if provider is not None:
                    badge = {"name": provider.name, "label": provider.label,
                             "kind": provider.kind}
        except Exception:
            badge = None
        panel_name = "SKVM"
        try:
            panel_name = settings_service.get("panel_name", "SKVM") or "SKVM"
        except Exception:
            pass
        return {
            "app_name": panel_name,
            "app_version": app.config["VERSION"],
            "app_tagline": app.config.get("APP_TAGLINE", ""),
            "runtime_badge": badge,
            "now": utcnow(),
            "Role": Role,
            "VPSStatus": VPSStatus,
            "nav_pending_tasks": (Task.query.filter(
                Task.status.in_([TaskStatus.QUEUED, TaskStatus.RUNNING])).count()
                if current_user.is_authenticated else 0),
            "nav_alert_instances": (VPS.query.filter(
                VPS.status == VPSStatus.ERROR).count()
                if current_user.is_authenticated and current_user.can_view_all else 0),
        }

    def provider_label(name: str | None) -> str:
        """Human label for a provider name stored on an instance row."""
        from .provisioning.providers import PROVIDERS_BY_NAME

        if not name:
            return "no runtime"
        cls = PROVIDERS_BY_NAME.get(str(name))
        return cls.label if cls else str(name)

    app.jinja_env.globals.update(page_url=_page_url, provider_label=provider_label)

    @app.template_filter("filesize")
    def filesize(value, suffix: str = "B") -> str:
        try:
            size = float(value or 0)
        except (TypeError, ValueError):
            return "—"
        for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
            if size < 1024 or unit == "TiB":
                return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TiB"

    @app.template_filter("duration")
    def duration(value) -> str:
        if value is None:
            return "—"
        try:
            seconds = int(value)
        except (TypeError, ValueError):
            return "—"
        if seconds < 0:
            return "—"
        days, rem = divmod(seconds, 86400)
        hours, rem = divmod(rem, 3600)
        minutes, secs = divmod(rem, 60)
        if days:
            return f"{days}d {hours}h"
        if hours:
            return f"{hours}h {minutes}m"
        if minutes:
            return f"{minutes}m {secs}s"
        return f"{secs}s"

    @app.template_filter("reltime")
    def reltime(value) -> str:
        if not value:
            return "—"
        delta = (utcnow() - value) if isinstance(value, datetime) else None
        if delta is None:
            return str(value)
        seconds = int(delta.total_seconds())
        if seconds < 60:
            return "just now"
        if seconds < 3600:
            return f"{seconds // 60}m ago"
        if seconds < 86400:
            return f"{seconds // 3600}h ago"
        return f"{seconds // 86400}d ago"

    @app.template_filter("datetime")
    def fmt_datetime(value, fmt: str = "%Y-%m-%d %H:%M") -> str:
        if not value:
            return "—"
        try:
            return value.strftime(fmt)
        except AttributeError:
            return str(value)

    @app.template_filter("pct")
    def pct(value, digits: int = 1) -> str:
        try:
            return f"{float(value or 0):.{digits}f}%"
        except (TypeError, ValueError):
            return "—"

    @app.template_filter("tojson_safe")
    def tojson_safe(value):
        return json.dumps(value, default=str)

    @app.route("/healthz")
    @app.route("/api/health")
    def health():
        """
        Real health endpoint: reports database connectivity, runtime probe
        results and the active provider.  Used by install.sh and the tests.
        """
        started = time.time()
        status = {"ok": True, "app": app.config["APP_NAME"],
                  "version": app.config["VERSION"],
                  "env": app.config["ENV_NAME"], "time": utcnow().isoformat() + "Z"}
        try:
            db.session.execute(db.text("SELECT 1"))
            status["database"] = {"ok": True, "uri": app.config["SQLALCHEMY_DATABASE_URI"].split("///")[-1]}
        except Exception as exc:  # noqa: BLE001
            status["ok"] = False
            status["database"] = {"ok": False, "error": str(exc)}
        manager = app.extensions.get("skvm_manager")
        if manager is not None:
            try:
                provider, diagnostics = manager.provider()
                status["runtime"] = {
                    "provider": provider.name if provider else None,
                    "kind": provider.kind if provider else None,
                    "can_provision": provider is not None,
                    "providers": [{"name": d["name"], "available": d["available"],
                                   "reason": d.get("reason", "")}
                                  for d in diagnostics],
                }
            except Exception as exc:  # noqa: BLE001
                status["runtime"] = {"error": str(exc)}
        status["response_ms"] = round((time.time() - started) * 1000, 2)
        return jsonify(status), 200 if status["ok"] else 503


def register_cli(app: Flask) -> None:
    @app.cli.command("init-db")
    def init_db():
        """Create tables and seed defaults."""
        create_schema(app)
        print(seed())

    @app.cli.command("create-admin")
    def create_admin_cmd():
        """Create an administrator interactively."""
        import click

        from .security import validate_email, validate_password, validate_username
        from .services.bootstrap import create_admin

        username = click.prompt("Username")
        email = click.prompt("Email")
        password = click.prompt("Password", hide_input=True, confirmation_prompt=True)
        problems = (validate_username(username) + validate_email(email)
                    + validate_password(password, username, email))
        if problems:
            raise SystemExit("Cannot create the account: " + "; ".join(problems))
        user = create_admin(username, email, password)
        print(f"Administrator '{user.username}' created.")
