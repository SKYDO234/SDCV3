"""API blueprints, including the WebSocket console endpoints."""
from __future__ import annotations

import logging

from flask import Blueprint, current_app, g, jsonify, request
from flask_login import current_user

from ..models import User, VPS
from ..security import (api_error, api_ok, effective_scopes, login_required_api, require_admin,
                        validate_password)
from .admin import admin_bp
from .files import files_bp
from .instances import instances_bp
from .system import system_bp

logger = logging.getLogger("skvm.api")

api_bp = Blueprint("api", __name__, url_prefix="/api")


@api_bp.route("/")
def index():
    """API discovery document — lists the real, implemented surface."""
    routes = []
    for rule in current_app.url_map.iter_rules():
        if not str(rule).startswith(("/api", "/ws")):
            continue
        if "static" in rule.endpoint:
            continue
        routes.append({
            "path": str(rule),
            "methods": sorted(m for m in rule.methods
                              if m not in ("HEAD", "OPTIONS")),
            "endpoint": rule.endpoint,
        })
    routes.sort(key=lambda r: (r["path"], r["methods"]))
    return jsonify({
        "ok": True,
        "name": current_app.config["APP_NAME"],
        "version": current_app.config["VERSION"],
        "authentication": {
            "session": "log in at /login (cookie, CSRF protected)",
            "token": "Authorization: Bearer skvm_… (created under Admin → API)",
        },
        "scopes": ["read", "write", "provision", "admin"],
        "endpoints": routes,
    })


@api_bp.route("/me")
@login_required_api
def me():
    """Who am I, what may I do, and which token (if any) carried the request."""
    from ..security import api_user

    token = getattr(g, "api_token", None)      # set when a bearer token was used
    user = token.user if token is not None else api_user()
    if user is None:
        return api_error("authentication required", 401)
    permissions = {
        "manage_users": user.is_admin,
        "manage_infrastructure": user.can_manage_infra,
        "create_instances": user.can_create_vps,
        "view_all_instances": user.can_view_all,
        "operate_own_instances": user.role in ("admin", "operator", "user"),
        "delete_instances": user.is_admin,
    }
    return api_ok(user=user.to_dict(), permissions=permissions,
                  token=token.to_dict() if token else None)


@api_bp.route("/me", methods=["PATCH", "PUT"])
@login_required_api
def update_me():
    """Update your own profile — never your own role or quotas."""
    from ..extensions import db
    from ..security import validate_email

    payload = request.get_json(silent=True) or {}
    changed = []
    if "full_name" in payload:
        full_name = str(payload.get("full_name") or "").strip()[:120]
        current_user.full_name = full_name
        changed.append("full_name")
    if "email" in payload:
        email = str(payload.get("email") or "").strip().lower()
        problems = validate_email(email)
        if problems:
            return api_error("; ".join(problems), 400)
        clash = User.query.filter(User.email == email,
                                  User.id != current_user.id).first()
        if clash is not None:
            return api_error("that email address is already in use", 409)
        current_user.email = email
        changed.append("email")
    if "notify_email" in payload:
        current_user.notify_email = bool(payload.get("notify_email"))
        changed.append("notify_email")
    db.session.commit()
    from ..services import audit

    audit.record("account.updated", f"profile fields changed: {', '.join(changed)}",
                 category="account")
    return api_ok(user=current_user.to_dict(), changed=changed)


@api_bp.route("/me/password", methods=["POST"])
@login_required_api
def change_own_password():
    from ..extensions import db

    payload = request.get_json(silent=True) or {}
    current = str(payload.get("current_password") or "")
    new = str(payload.get("new_password") or "")
    if not current_user.check_password(current):
        from ..services import audit

        audit.record("account.password_change_failed", "wrong current password",
                     category="account", level="warning")
        return api_error("the current password is not correct", 403)
    problems = validate_password(new, current_user.username, current_user.email)
    if problems:
        return api_error("; ".join(problems), 400)
    if new == current:
        return api_error("the new password must differ from the current one", 400)
    current_user.set_password(new)
    db.session.commit()
    from ..services import audit

    audit.record("account.password_changed", "password changed from the profile page",
                 category="account", level="warning")
    return api_ok(message="Password updated. Other sessions keep working until they expire.")


@api_bp.route("/console/sessions", methods=["GET", "DELETE"])
@require_admin
def console_sessions():
    """Real PTY sessions currently attached to instances (administrators only)."""
    manager = current_app.extensions["skvm_console"]
    if request.method == "GET":
        return api_ok(sessions=manager.active(), total=len(manager.active()))
    closed = manager.close_all("closed by an administrator")
    from ..services import audit

    audit.record("console.closed_all", f"{closed} session(s) closed by an admin",
                 category="console", level="warning", target="panel")
    return api_ok(closed=closed)


@api_bp.route("/summary")
@login_required_api
def summary():
    manager = current_app.extensions["skvm_manager"]
    query = VPS.query
    if not current_user.can_view_all:
        query = query.filter(VPS.owner_id == current_user.id)
    from ..models import User, VPSStatus

    query = query.filter(VPS.status != VPSStatus.DELETED)
    instances = query.all()
    return api_ok(
        instances={"total": len(instances),
                   "running": len([i for i in instances if i.is_running]),
                   "stopped": len([i for i in instances
                                   if i.status == VPSStatus.STOPPED]),
                   "errors": len([i for i in instances
                                  if i.status == VPSStatus.ERROR])},
        allocation={
            "vcpu": sum(i.vcpu for i in instances),
            "memory_mb": sum(i.memory_mb for i in instances),
            "disk_gb": sum(i.disk_gb for i in instances),
            "memory_used_mb": round(sum(i.memory_used_mb or 0 for i in instances), 1),
            "disk_used_mb": round(sum(i.disk_used_mb or 0 for i in instances), 1),
        },
        host=manager.profile().resources,
        capabilities={"can_provision": manager.capabilities()["can_provision"]},
    )


def register_api(app):
    @app.before_request
    def _enforce_token_scope():
        """
        Bearer tokens authenticate through the login manager, so the role-gated
        routes (require_admin / require_operator) would otherwise let a
        read-only token perform writes. Enforce the token's scope once, for
        every /api path; touching current_user first makes the request loader
        run. Session-authenticated requests are unaffected.
        """
        from flask import g

        from ..security import enforce_token_scope

        if not request.path.startswith("/api/"):
            return None
        header = request.headers.get("Authorization", "")
        if header.lower().startswith("bearer "):
            from ..security import verify_api_token

            token = verify_api_token(header.split(None, 1)[1].strip())
            if token is None or token.user is None or not token.user.is_active_flag:
                return jsonify({"ok": False,
                                "error": "invalid or expired API token",
                                "code": 401}), 401
            g.api_token = token
            g.api_user = token.user
            g.api_scopes = effective_scopes(token.scope_list)
        else:
            _ = current_user.is_authenticated     # runs the session/loader
        denial = enforce_token_scope()
        if denial is not None:
            return jsonify(denial[0]), denial[1]
        return None

    app.register_blueprint(api_bp)
    app.register_blueprint(system_bp)
    app.register_blueprint(instances_bp)
    app.register_blueprint(files_bp)
    app.register_blueprint(admin_bp)

    # WebSocket support (xterm.js console + live task/metrics streams).
    try:
        from flask_sock import Sock

        sock = Sock(app)
        from .ws import register_console_socket, register_stream_sockets

        register_console_socket(app, sock)
        register_stream_sockets(app, sock)
        app.extensions["skvm_sock"] = sock
        logger.info("websocket endpoints registered (console, tasks, metrics)")
    except Exception as exc:  # noqa: BLE001
        logger.error("WebSocket support unavailable: %s", exc)

    @app.route("/api/ping")
    def ping():
        return api_ok(pong=True, version=current_app.config["VERSION"])
