"""
WebSocket console endpoint (xterm.js ⇄ real PTY).

Protocol (JSON control frames + raw data):
  client → server
    {"type":"input","data":"ls -la\n"}   keystrokes
    {"type":"resize","cols":120,"rows":30}
    {"type":"ping"}
  server → client
    {"type":"ready","session":"…","shell":"…"}
    {"type":"output","data":"…"}          terminal output
    {"type":"exit","code":0}
    {"type":"error","error":"…"}
    {"type":"pong"}

The PTY is attached to a shell running *inside the instance*; the host shell is
never exposed and the user's ownership of the instance is re-checked when the
socket is opened.
"""
from __future__ import annotations

import json
import logging

from flask import current_app
from flask_login import current_user

from ..models import VPS, VPSStatus
from ..security import check_origin
from ..services import audit
from ..services.console import ConsoleError

logger = logging.getLogger("skvm.ws")


def register_console_socket(app, sock):
    @sock.route("/ws/console/<instance_id>")
    def console_socket(ws, instance_id):
        manager = app.extensions["skvm_manager"]
        console = app.extensions["skvm_console"]

        # ---- authorization (re-checked here, never trusted from the page)
        if not _token_scope_ok("provision"):
            _fail(ws, "authentication required", 4401)
            return
        vps = VPS.query.filter_by(instance_id=instance_id).first()
        if vps is None or vps.status == VPSStatus.DELETED:
            _fail(ws, "no such instance", 4404)
            return
        if not current_user.can_access(vps):
            audit.record("console.access_denied",
                         f"{current_user.username} → {vps.name}",
                         category="security", level="warning",
                         target=vps.instance_id)
            _fail(ws, "you do not have access to this instance", 4403)
            return
        if not check_origin():
            _fail(ws, "cross-origin console requests are refused", 4403)
            return

        provider = manager.provider_for(vps)
        if provider is None:
            _fail(ws, "no container runtime is available on this host", 4503)
            return

        # ---- open the real PTY
        try:
            handle = console.open(provider, vps, current_user, cols=120, rows=30)
        except ConsoleError as exc:
            _fail(ws, str(exc), 4503)
            return
        except Exception as exc:  # noqa: BLE001
            logger.exception("console open failed")
            _fail(ws, f"{type(exc).__name__}: {exc}", 4500)
            return

        audit.record("console.opened",
                     f"{current_user.username} opened a console on {vps.name} "
                     f"(pid {handle.proc.pid})", category="console",
                     target=vps.instance_id)

        try:
            ws.send(json.dumps({
                "type": "ready", "session": handle.record.session_key,
                "instance": vps.instance_id, "name": vps.name,
                "shell": handle.command,
                "notice": ("This is a container console. The prompt is a shell "
                           "running inside the instance."),
            }))
            _pump(ws, handle, console)
        finally:
            console.close(handle.record.session_key, "socket closed")
            audit.record("console.closed",
                         f"{current_user.username} closed the console on {vps.name}",
                         category="console", target=vps.instance_id)


def _token_scope_ok(min_scope: str) -> bool:
    """WebSocket requests authenticate like API requests: session or token."""
    from ..security import token_scope_allows

    return bool(current_user.is_authenticated and token_scope_allows(min_scope))


def _pump(ws, handle, console):
    """Bidirectional pump between the WebSocket and the PTY."""
    import time

    idle_limit = getattr(handle, "idle_limit", 1800)
    last_ping = time.time()

    while True:
        # ---- 1. terminal output → browser
        try:
            data = handle.read(timeout=0.05)
        except OSError as exc:
            ws.send(json.dumps({"type": "error",
                                "error": f"terminal read failed: {exc}"}))
            break
        if data:
            try:
                ws.send(json.dumps({"type": "output",
                                    "data": data.decode("utf-8", "replace")}))
            except Exception:
                break

        # ---- 2. browser → terminal
        try:
            message = ws.receive(timeout=0.01)
        except TimeoutError:
            message = None
        except Exception as exc:  # connection closed
            logger.debug("console socket closed: %s", exc)
            break

        if message is not None:
            try:
                payload = json.loads(message) if isinstance(message, str) else None
            except ValueError:
                payload = None
            if payload is None:
                if message:
                    handle.write(message if isinstance(message, bytes)
                                 else str(message).encode())
            else:
                kind = payload.get("type")
                if kind == "input":
                    handle.write(str(payload.get("data", "")).encode())
                elif kind == "resize":
                    handle.resize(int(payload.get("cols") or 120),
                                  int(payload.get("rows") or 30))
                elif kind == "ping":
                    ws.send(json.dumps({"type": "pong"}))
                elif kind == "close":
                    break

        # ---- 3. termination checks
        if not handle.alive:
            code = handle.proc.poll()
            try:
                # flush whatever the terminal produced before exiting
                for _ in range(20):
                    tail = handle.read(timeout=0.02)
                    if not tail:
                        break
                    ws.send(json.dumps({"type": "output",
                                        "data": tail.decode("utf-8", "replace")}))
                ws.send(json.dumps({"type": "exit", "code": code}))
            except Exception:
                pass
            break

        if handle.idle_seconds > idle_limit:
            try:
                ws.send(json.dumps({
                    "type": "error",
                    "error": f"the console was closed after "
                             f"{idle_limit // 60} minutes of inactivity",
                }))
            except Exception:
                pass
            break

    console.reap()


def _fail(ws, message: str, code: int) -> None:
    try:
        ws.send(json.dumps({"type": "error", "error": message, "code": code}))
        ws.close(reason=code)
    except Exception:
        pass


# --------------------------------------------------------------------------
# task + metrics streaming (polling over WebSocket for live dashboards)
# --------------------------------------------------------------------------
def register_stream_sockets(app, sock):
    from ..models import Task, VPS

    @sock.route("/ws/tasks")
    def task_stream(ws):
        if not _token_scope_ok("read"):
            _fail(ws, "authentication required", 4401)
            return
        import time

        seen: dict[str, str] = {}
        try:
            while True:
                query = Task.query
                if not current_user.can_view_all:
                    query = query.filter(
                        Task.requested_by_id == current_user.id)
                rows = query.order_by(Task.id.desc()).limit(25).all()
                payload = []
                for task in rows:
                    key = task.task_id
                    if seen.get(key) != f"{task.status}:{task.progress}:{task.message}":
                        seen[key] = f"{task.status}:{task.progress}:{task.message}"
                        payload.append(task.to_dict(include_logs=False))
                if payload:
                    ws.send(json.dumps({"type": "tasks", "tasks": payload}))
                message = None
                try:
                    message = ws.receive(timeout=2)
                except TimeoutError:
                    message = None
                if message:
                    try:
                        data = json.loads(message)
                    except ValueError:
                        data = {}
                    if data.get("type") == "ping":
                        ws.send(json.dumps({"type": "pong"}))
                time.sleep(1.2)
        except Exception as exc:
            logger.debug("task stream closed: %s", exc)

    @sock.route("/ws/metrics")
    def metrics_stream(ws):
        if not _token_scope_ok("read"):
            _fail(ws, "authentication required", 4401)
            return
        import time

        instance_id = current_app.request.args.get("instance")
        vps = None
        if instance_id:
            vps = VPS.query.filter_by(instance_id=instance_id).first()
            if vps is None or not current_user.can_access(vps):
                _fail(ws, "access denied", 4403)
                return
        manager = app.extensions["skvm_manager"]
        try:
            while True:
                message = ws.send(json.dumps({"type": "pending"}))
                del message
                if vps is not None:
                    provider = manager.provider_for(vps)
                    metrics = provider.metrics(vps) if provider else {
                        "available": False, "reason": "no runtime available"}
                    ws.send(json.dumps({"type": "instance", "instance_id":
                                        vps.instance_id, "status": vps.status,
                                        "metrics": metrics}))
                else:
                    profile = manager.profile()
                    ws.send(json.dumps({"type": "host",
                                        "resources": profile.resources}))
                try:
                    ws.receive(timeout=5)
                except TimeoutError:
                    pass
                time.sleep(2)
        except Exception as exc:
            logger.debug("metrics stream closed: %s", exc)
