"""Administrative API: users, plans, nodes, images, settings, logs, tokens, tasks."""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from flask import Blueprint, current_app, jsonify, request, session
from flask_login import current_user
from sqlalchemy import or_

from ..extensions import db, limiter
from ..models import (
    ApiToken, AuditLog, Backup, LoginAttempt, Node, OSImage, Plan, Role, Setting,
    Task, TaskStatus, User, VPS, VPSStatus, utcnow,
)
from ..security import (
    ValidationError, api_error, api_ok, body_int, body_str, create_api_token,
    hash_password, login_required_api, require_admin, require_operator,
    validate_email, validate_password, validate_username,
)
from ..services import audit, settings_service

admin_bp = Blueprint("api_admin", __name__, url_prefix="/api")


# --------------------------------------------------------------------------
# users
# --------------------------------------------------------------------------
@admin_bp.route("/users", methods=["GET", "POST"])
@require_admin
def users():
    if request.method == "GET":
        query = User.query
        search = request.args.get("q")
        role = request.args.get("role")
        if search:
            like = f"%{search}%"
            query = query.filter(or_(User.username.ilike(like),
                                     User.email.ilike(like),
                                     User.full_name.ilike(like)))
        if role in Role.ALL:
            query = query.filter(User.role == role)
        rows = query.order_by(User.id.desc()).limit(
            min(500, request.args.get("limit", 200, type=int))).all()
        counts = {u.id: VPS.query.filter(VPS.owner_id == u.id,
                                         VPS.status != VPSStatus.DELETED).count()
                  for u in rows}
        return api_ok(users=[{**u.to_dict(), "instance_count": counts[u.id]}
                             for u in rows], total=len(rows))

    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        username = body_str(data, "username", "", 32, required=True)
        email = body_str(data, "email", "", 255, required=True)
        password = str(data.get("password") or "")
        role = body_str(data, "role", Role.USER, 16)
        full_name = body_str(data, "full_name", "", 120)
        quota_vcpu = body_int(data, "quota_vcpu", 2, 1, 512)
        quota_memory_mb = body_int(data, "quota_memory_mb", 2048, 64, 262144)
        quota_disk_gb = body_int(data, "quota_disk_gb", 20, 1, 4096)
        quota_instances = body_int(data, "quota_instances", 2, 0, 500)
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)

    problems = (validate_username(username) + validate_email(email)
                + validate_password(password, username, email))
    if role not in Role.ALL:
        problems.append("unknown role")
    if User.query.filter_by(username=username).first():
        problems.append("that username is already taken")
    if User.query.filter_by(email=email).first():
        problems.append("that email is already registered")
    if problems:
        return api_error("; ".join(problems), 400, problems=problems)

    user = User(username=username, email=email, full_name=full_name or username,
                role=role, quota_vcpu=quota_vcpu, quota_memory_mb=quota_memory_mb,
                quota_disk_gb=quota_disk_gb, quota_instances=quota_instances)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    audit.record("user.created", f"{username} ({role})", category="admin",
                 target=username, meta={"role": role})
    return api_ok(user=user.to_dict()), 201


@admin_bp.route("/users/<int:user_id>", methods=["GET", "PATCH", "PUT", "DELETE"])
@require_admin
def user_detail(user_id):
    user = db.session.get(User, user_id)
    if user is None:
        return api_error("no such user", 404)
    if request.method == "GET":
        instances = VPS.query.filter(VPS.owner_id == user.id,
                                     VPS.status != VPSStatus.DELETED).all()
        return api_ok(user=user.to_dict(),
                      instances=[v.to_dict() for v in instances],
                      tokens=[t.to_dict() for t in
                              ApiToken.query.filter_by(user_id=user.id).all()])

    if request.method == "DELETE":
        if user.id == current_user.id:
            return api_error("you cannot delete your own account", 409)
        if user.is_admin and User.query.filter_by(role=Role.ADMIN).count() <= 1:
            return api_error("this is the only administrator account", 409)
        owned = VPS.query.filter(VPS.owner_id == user.id,
                                 VPS.status != VPSStatus.DELETED).count()
        if owned and request.args.get("force") != "1":
            return api_error(
                f"this account still owns {owned} instance(s). "
                "Delete them first, or pass ?force=1 to remove the account "
                "and its records.", 409, instances=owned)
        username = user.username
        db.session.delete(user)
        db.session.commit()
        audit.record("user.deleted", f"{username} and their records",
                     category="admin", level="warning", target=username)
        return api_ok(deleted=username)

    data = request.get_json(silent=True) or request.form.to_dict()
    changes = {}
    try:
        if "email" in data:
            email = body_str(data, "email", "", 255, required=True)
            problems = validate_email(email)
            if problems:
                return api_error("; ".join(problems), 400)
            if User.query.filter(User.email == email, User.id != user.id).first():
                return api_error("that email is already registered", 400)
            user.email = email
            changes["email"] = email
        if "full_name" in data:
            user.full_name = body_str(data, "full_name", "", 120)
            changes["full_name"] = user.full_name
        if "role" in data:
            role = body_str(data, "role", user.role, 16)
            if role not in Role.ALL:
                return api_error("unknown role", 400)
            if user.is_admin and role != Role.ADMIN and \
                    User.query.filter_by(role=Role.ADMIN).count() <= 1:
                return api_error("this is the only administrator account", 409)
            user.role = role
            changes["role"] = role
        if "is_active" in data:
            desired = bool(data["is_active"])
            if not desired and user.id == current_user.id:
                return api_error("you cannot suspend your own account", 409)
            if not desired and user.is_admin and \
                    User.query.filter_by(role=Role.ADMIN,
                                         is_active_flag=True).count() <= 1:
                return api_error("this is the only active administrator", 400)
            user.is_active_flag = desired
            changes["is_active"] = desired
            if desired:
                user.failed_login_count = 0
                user.locked_until = None
        if "suspended_reason" in data:
            user.suspended_reason = body_str(data, "suspended_reason", "", 255)
            changes["suspended_reason"] = user.suspended_reason
        for field, column in (("quota_vcpu", "quota_vcpu"),
                              ("quota_memory_mb", "quota_memory_mb"),
                              ("quota_disk_gb", "quota_disk_gb"),
                              ("quota_instances", "quota_instances")):
            if field in data:
                value = body_int(data, field, getattr(user, column), 0, 10 ** 6)
                setattr(user, column, value)
                changes[field] = value
        if "password" in data and data["password"]:
            problems = validate_password(str(data["password"]), user.username,
                                         user.email)
            if problems:
                return api_error("; ".join(problems), 400, problems=problems)
            user.set_password(str(data["password"]))
            changes["password"] = "changed"
            audit.record("user.password_reset",
                         f"password reset for {user.username}",
                         category="security", level="warning", target=user.username)
        if data.get("unlock"):
            user.locked_until = None
            user.failed_login_count = 0
            changes["unlocked"] = True
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)

    db.session.commit()
    audit.record("user.updated", json.dumps(changes), category="admin",
                 target=user.username, meta=changes)
    return api_ok(user=user.to_dict(), changes=changes)


@admin_bp.route("/users/<int:user_id>/vps", methods=["GET"])
@require_admin
def user_instances(user_id):
    user = db.session.get(User, user_id)
    if user is None:
        return api_error("no such user", 404)
    rows = VPS.query.filter(VPS.owner_id == user.id,
                            VPS.status != VPSStatus.DELETED).all()
    return api_ok(user=user.username, instances=[v.to_dict() for v in rows])


# --------------------------------------------------------------------------
# plans
# --------------------------------------------------------------------------
@admin_bp.route("/plans", methods=["GET", "POST"])
@require_operator
def plans():
    if request.method == "GET":
        return api_ok(plans=[p.to_dict() for p in
                             Plan.query.order_by(Plan.sort_order, Plan.id).all()])
    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        name = body_str(data, "name", "", 80, required=True)
        slug = body_str(data, "slug", "", 80) or name.lower().replace(" ", "-")
        vcpu = body_int(data, "vcpu", 1, 1, 512)
        memory_mb = body_int(data, "memory_mb", 1024, 64, 262144)
        disk_gb = body_int(data, "disk_gb", 10, 1, 4096)
        price = float(data.get("price_monthly") or 0)
    except (ValidationError, ValueError) as exc:
        return api_error(str(exc), 400)
    if Plan.query.filter_by(slug=slug).first():
        return api_error("a plan with that slug already exists", 400)
    plan = Plan(name=name, slug=slug, vcpu=vcpu, memory_mb=memory_mb,
                disk_gb=disk_gb, price_monthly=price,
                description=body_str(data, "description", "", 500),
                bandwidth_gb=body_int(data, "bandwidth_gb", 0, 0, 10 ** 6),
                sort_order=body_int(data, "sort_order", 0, 0, 10 ** 4),
                is_active=bool(data.get("is_active", True)))
    db.session.add(plan)
    db.session.commit()
    audit.record("plan.created", f"{name} ({vcpu} vCPU/{memory_mb} MiB/{disk_gb} GiB)",
                 category="admin", target=name)
    return api_ok(plan=plan.to_dict()), 201


@admin_bp.route("/plans/<int:plan_id>", methods=["PATCH", "PUT", "DELETE"])
@require_operator
def plan_detail(plan_id):
    plan = db.session.get(Plan, plan_id)
    if plan is None:
        return api_error("no such plan", 404)
    if request.method == "DELETE":
        in_use = VPS.query.filter(VPS.plan_id == plan.id,
                                  VPS.status != VPSStatus.DELETED).count()
        if in_use:
            return api_error(
                f"{in_use} instance(s) still use this plan — deactivate it "
                "instead", 409, instances=in_use)
        name = plan.name
        db.session.delete(plan)
        db.session.commit()
        audit.record("plan.deleted", name, category="admin", level="warning",
                     target=name)
        return api_ok(deleted=name)
    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        for field, lo, hi in (("vcpu", 1, 512), ("memory_mb", 64, 262144),
                              ("disk_gb", 1, 4096), ("bandwidth_gb", 0, 10 ** 6),
                              ("sort_order", 0, 10 ** 4)):
            if field in data:
                setattr(plan, field, body_int(data, field, getattr(plan, field),
                                              lo, hi))
        if "name" in data:
            plan.name = body_str(data, "name", plan.name, 80, required=True)
        if "description" in data:
            plan.description = body_str(data, "description", "", 500)
        if "price_monthly" in data:
            plan.price_monthly = float(data["price_monthly"] or 0)
        for flag in ("is_active", "is_public"):
            if flag in data:
                setattr(plan, flag, bool(data[flag]))
    except (ValidationError, ValueError) as exc:
        return api_error(str(exc), 400)
    db.session.commit()
    audit.record("plan.updated", plan.name, category="admin", target=plan.name)
    return api_ok(plan=plan.to_dict())


# --------------------------------------------------------------------------
# nodes
# --------------------------------------------------------------------------
@admin_bp.route("/nodes", methods=["GET", "POST"])
@require_operator
def nodes():
    manager = current_app.extensions["skvm_manager"]
    if request.method == "GET":
        if request.args.get("refresh") == "1":
            manager.refresh_local_node()
        return api_ok(nodes=[n.to_dict() for n in Node.query.order_by(Node.id).all()],
                      local_address=manager.local_node_address())
    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        name = body_str(data, "name", "", 80, required=True)
        address = body_str(data, "address", "", 255, required=True)
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)
    if Node.query.filter_by(name=name).first():
        return api_error("a node with that name already exists", 400)
    node = Node(name=name, address=address,
                hostname=body_str(data, "hostname", name, 255),
                provider_hint=body_str(data, "provider_hint", "auto", 32),
                notes=body_str(data, "notes", "", 500),
                is_local=False,
                status="registered")
    db.session.add(node)
    db.session.commit()
    audit.record("node.created", f"{name} at {address}", category="admin",
                 target=name)
    return api_ok(node=node.to_dict()), 201


@admin_bp.route("/nodes/<int:node_id>", methods=["GET", "PATCH", "DELETE"])
@require_operator
def node_detail(node_id):
    node = db.session.get(Node, node_id)
    if node is None:
        return api_error("no such node", 404)
    if request.method == "DELETE":
        if node.is_local:
            return api_error("the local node cannot be removed", 400)
        instances = VPS.query.filter(VPS.node_id == node.id,
                                     VPS.status != VPSStatus.DELETED).count()
        if instances:
            return api_error(f"{instances} instance(s) are scheduled on this node",
                             409)
        name = node.name
        db.session.delete(node)
        db.session.commit()
        audit.record("node.deleted", name, category="admin", level="warning",
                     target=name)
        return api_ok(deleted=name)
    data = request.get_json(silent=True) or request.form.to_dict()
    for field in ("name", "address", "hostname", "provider_hint", "notes"):
        if field in data:
            setattr(node, field, body_str(data, field, getattr(node, field), 500))
    for flag in ("is_active", "maintenance"):
        if flag in data:
            setattr(node, flag, bool(data[flag]))
    db.session.commit()
    audit.record("node.updated", node.name, category="admin", target=node.name)
    return api_ok(node=node.to_dict())


@admin_bp.route("/nodes/<int:node_id>/probe", methods=["POST"])
@require_operator
def node_probe(node_id):
    """Re-check a node's availability.  Only the local node can be verified
    from here — remote nodes report what is actually reachable over TCP."""
    import socket

    node = db.session.get(Node, node_id)
    if node is None:
        return api_error("no such node", 404)
    if node.is_local:
        manager = current_app.extensions["skvm_manager"]
        manager.refresh_local_node()
        return api_ok(node=node.to_dict(), reachable=True, method="local probe")
    host = (node.address or "").split(":")[0]
    port = 2376
    if ":" in (node.address or ""):
        try:
            port = int(node.address.rsplit(":", 1)[1])
        except ValueError:
            port = 2376
    reachable = False
    detail = ""
    try:
        with socket.create_connection((host, port), timeout=5):
            reachable = True
            detail = f"TCP {host}:{port} reachable"
    except OSError as exc:
        detail = f"could not reach {host}:{port} — {exc}"
    node.status = "online" if reachable else "unreachable"
    node.last_seen_at = utcnow() if reachable else node.last_seen_at
    db.session.commit()
    return api_ok(node=node.to_dict(), reachable=reachable, method="tcp probe",
                  detail=detail)


# --------------------------------------------------------------------------
# OS images
# --------------------------------------------------------------------------
@admin_bp.route("/images", methods=["GET", "POST"])
@require_operator
def images():
    manager = current_app.extensions["skvm_manager"]
    if request.method == "GET":
        # Server-side truth first: the API and the HTML page must never
        # disagree about what is cached.
        cache = manager.reconcile_image_cache()
        provider, _ = manager.provider()
        rows = OSImage.query.order_by(OSImage.sort_order, OSImage.id).all()
        data = []
        for image in rows:
            item = image.to_dict()
            cached = bool(provider and provider.image_ready(image.slug))
            item["cached"] = cached
            item["cached_bytes"] = (provider.image_size(image.slug)
                                    if provider and cached else 0)
            item["status"] = image.status
            item["available"] = cached
            data.append(item)
        return api_ok(images=data, cache=cache)
    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        name = body_str(data, "name", "", 80, required=True)
        reference = body_str(data, "reference", "", 255, required=True)
        version = body_str(data, "version", "", 32)
        slug = body_str(data, "slug", "", 80)
        if not slug:
            raw_slug = f"{name}-{version or 'latest'}".lower()
            slug = re.sub(r"[^a-z0-9._-]+", "-", raw_slug).strip("._-")
            slug = slug or "image-latest"
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,79}", slug):
            return api_error(
                "image slug must start with a lowercase letter or number and "
                "contain only lowercase letters, numbers, dots, underscores or hyphens",
                400, field="slug")
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)
    if OSImage.query.filter_by(slug=slug).first():
        return api_error("an image with that slug already exists", 400)
    image = OSImage(
        name=name, slug=slug, reference=reference,
        version=version,
        family=body_str(data, "family", "linux", 32),
        codename=body_str(data, "codename", "", 32),
        registry=body_str(data, "registry", current_app.config["OCI_REGISTRY"], 120),
        default_user=body_str(data, "default_user", "root", 32),
        status="not_downloaded", status_detail="not downloaded yet",
        sort_order=body_int(data, "sort_order", 100, 0, 10 ** 4),
    )
    db.session.add(image)
    db.session.commit()
    audit.record("image.created", f"{name} → {reference}", category="admin",
                 target=name)
    return api_ok(image=image.to_dict()), 201


@admin_bp.route("/images/<int:image_id>", methods=["PATCH", "DELETE"])
@require_operator
def image_detail(image_id):
    image = db.session.get(OSImage, image_id)
    if image is None:
        return api_error("no such image", 404)
    if request.method == "DELETE":
        in_use = VPS.query.filter(VPS.image_id == image.id,
                                  VPS.status != VPSStatus.DELETED).count()
        if in_use:
            return api_error(f"{in_use} instance(s) use this image", 409)
        name = image.label
        # A catalogue Delete must remove the real cached layers too; otherwise
        # the button only drops the DB row and silently leaks gigabytes on disk.
        # Resolve and constrain the path before touching it so a legacy or
        # malformed slug can never escape IMAGES_DIR.
        image_root = Path(current_app.config["IMAGES_DIR"]).resolve()
        candidate = image_root / image.slug
        if candidate.is_symlink():
            return api_error("refusing to remove an image cache symlink", 409)
        cache_path = candidate.resolve()
        if cache_path == image_root or image_root not in cache_path.parents:
            return api_error("image cache path is outside the image directory", 400)
        cache_removed = False
        try:
            if cache_path.exists():
                shutil.rmtree(cache_path)
                cache_removed = True
        except OSError as exc:
            return api_error(f"could not remove the image cache: {exc}", 500)
        db.session.delete(image)
        db.session.commit()
        audit.record("image.deleted", f"{name} (cache removed: {cache_removed})",
                     category="admin", level="warning", target=name)
        return api_ok(deleted=name, cache_removed=cache_removed)
    data = request.get_json(silent=True) or request.form.to_dict()
    for field in ("name", "version", "codename", "family", "registry",
                  "reference", "default_user"):
        if field in data:
            setattr(image, field, body_str(data, field, getattr(image, field), 255))
    if "is_active" in data:
        image.is_active = bool(data["is_active"])
    if "sort_order" in data:
        image.sort_order = body_int(data, "sort_order", image.sort_order, 0, 10 ** 4)
    db.session.commit()
    audit.record("image.updated", image.label, category="admin", target=image.label)
    return api_ok(image=image.to_dict())


@admin_bp.route("/images/<int:image_id>/pull", methods=["POST"])
@require_operator
def image_pull(image_id):
    """Download the real layers from the upstream registry."""
    image = db.session.get(OSImage, image_id)
    if image is None:
        return api_error("no such image", 404)
    manager = current_app.extensions["skvm_manager"]
    task, error = manager.submit_image_pull(image, current_user)
    if error:
        return api_error(error, 409)
    audit.record("image.pull", f"{image.label} ({image.reference})",
                 category="admin", target=image.label)
    return api_ok(task=task.to_dict(),
                  message=f"download of {image.reference} queued"), 202


# --------------------------------------------------------------------------
# settings
# --------------------------------------------------------------------------
@admin_bp.route("/settings", methods=["GET", "POST", "PATCH"])
@require_admin
def settings():
    if request.method == "GET":
        groups: dict[str, list] = {}
        for row in settings_service.all_rows():
            groups.setdefault(row.group, []).append(row.to_dict())
        return api_ok(settings=groups,
                      maintenance=settings_service.maintenance().to_dict())
    data = request.get_json(silent=True) or request.form.to_dict()
    updated = {}
    for key, value in data.items():
        if key.startswith("__"):
            continue
        if not Setting.query.filter_by(key=key).first() and key not in {
                d["key"] for d in settings_service.DEFAULTS}:
            continue
        settings_service.set_value(key, value)
        updated[key] = value
    audit.record("settings.updated", json.dumps(updated)[:500], category="admin",
                 level="warning", target="panel", meta=updated)
    return api_ok(updated=updated)


# --------------------------------------------------------------------------
# logs, tasks, backups, tokens
# --------------------------------------------------------------------------
@admin_bp.route("/logs", methods=["GET"])
@require_operator
def logs():
    limit = min(500, request.args.get("limit", 100, type=int))
    query = AuditLog.query
    if request.args.get("category"):
        query = query.filter(AuditLog.category == request.args["category"])
    if request.args.get("level"):
        query = query.filter(AuditLog.level == request.args["level"])
    if request.args.get("q"):
        query = query.filter(AuditLog.message.ilike(f"%{request.args['q']}%"))
    rows = query.order_by(AuditLog.id.desc()).limit(limit).all()
    return api_ok(entries=[e.to_dict() for e in rows],
                  categories=[c[0] for c in db.session.query(
                      AuditLog.category).distinct().all()])


@admin_bp.route("/logs/file", methods=["GET"])
@require_operator
def log_file():
    log_path = current_app.config["LOG_DIR"] / "skvm.log"
    if not log_path.exists():
        return api_ok(lines=[], file=str(log_path), note="no log file yet")
    lines = log_path.read_text(errors="replace").splitlines()
    limit = min(1000, request.args.get("limit", 200, type=int))
    level = (request.args.get("level") or "").lower()
    parsed = []
    for line in lines[-limit * 3:]:
        try:
            entry = json.loads(line)
        except ValueError:
            entry = {"level": "info", "message": line, "logger": "", "ts": ""}
        if level and (entry.get("level", "").lower() != level):
            continue
        parsed.append(entry)
    return api_ok(lines=parsed[-limit:], file=str(log_path),
                  size_bytes=log_path.stat().st_size)


@admin_bp.route("/tasks", methods=["GET"])
@login_required_api
def tasks():
    query = Task.query
    if not current_user.can_view_all:
        query = query.filter(Task.requested_by_id == current_user.id)
    if request.args.get("status"):
        query = query.filter(Task.status == request.args["status"])
    if request.args.get("kind"):
        query = query.filter(Task.kind == request.args["kind"])
    if request.args.get("vps_id"):
        query = query.filter(Task.vps_id == request.args.get("vps_id", type=int))
    rows = (query.order_by(Task.id.desc())
            .limit(min(200, request.args.get("limit", 50, type=int))).all())
    counts = {status: Task.query.filter(Task.status == status).count()
              for status in (TaskStatus.QUEUED, TaskStatus.RUNNING,
                             TaskStatus.SUCCESS, TaskStatus.FAILED,
                             TaskStatus.INTERRUPTED)}
    return api_ok(tasks=[t.to_dict() for t in rows], counts=counts)


@admin_bp.route("/tasks/<task_id>", methods=["GET"])
@login_required_api
def task_detail(task_id):
    # `task_id` is the public identifier; accept the numeric primary key too so
    # an API client that kept `id` from a task list is not left guessing.
    task = Task.query.filter_by(task_id=str(task_id)).first()
    if task is None and str(task_id).isdigit():
        task = db.session.get(Task, int(task_id))
    if task is None:
        return api_error("no such task", 404)
    if not current_user.can_view_all and task.requested_by_id != current_user.id:
        return api_error("access denied", 403)
    return api_ok(task=task.to_dict(include_logs=True))


@admin_bp.route("/tasks/<task_id>/cancel", methods=["POST"])
@require_admin
def task_cancel(task_id):
    # `task_id` is the public identifier; accept the numeric primary key too so
    # an API client that kept `id` from a task list is not left guessing.
    task = Task.query.filter_by(task_id=str(task_id)).first()
    if task is None and str(task_id).isdigit():
        task = db.session.get(Task, int(task_id))
    if task is None:
        return api_error("no such task", 404)
    if task.is_finished:
        return api_error(f"the task already finished with status "
                         f"'{task.status}'", 409)
    task.status = TaskStatus.CANCELLED
    task.message = "cancelled by an administrator"
    task.finished_at = utcnow()
    task.append_log("cancelled by an administrator; in-flight runtime work, if "
                    "any, continues until it finishes")
    db.session.commit()
    current_app.extensions["skvm_runner"].release(f"vps:{task.vps_id}")
    audit.record("task.cancelled", f"{task.kind} {task.task_id}",
                 category="admin", level="warning", target=task.title)
    return api_ok(task=task.to_dict(include_logs=True))


@admin_bp.route("/backups", methods=["GET"])
@login_required_api
def backups():
    query = Backup.query
    if not current_user.can_view_all:
        query = query.join(VPS, Backup.vps_id == VPS.id).filter(
            VPS.owner_id == current_user.id)
    rows = query.order_by(Backup.id.desc()).limit(200).all()
    return api_ok(backups=[b.to_dict() for b in rows],
                  total_bytes=sum(b.size_bytes or 0 for b in rows))


@admin_bp.route("/backups/<backup_id>/verify", methods=["POST"])
@login_required_api
def backup_verify(backup_id):
    """Read the archive back and report whether it is really usable."""
    backup = Backup.query.filter_by(backup_id=backup_id).first()
    if backup is None:
        return api_error("no such backup", 404)
    if not current_user.can_access(backup.vps):
        return api_error("access denied", 403)
    service = current_app.extensions["skvm_backups"]
    result = service.verify(backup_id, current_user)
    audit.record(
        "backup.verified",
        f"{backup_id}: " + ("readable" if result.get("verified")
                            else f"FAILED ({result.get('reason', 'unknown')})"),
        category="backup",
        level="info" if result.get("verified") else "warning",
        target=backup_id,
    )
    if not result.get("verified"):
        return api_error(result.get("reason") or "the archive could not be read",
                         409, verification=result)
    return api_ok(verification=result)


@admin_bp.route("/backups/<backup_id>", methods=["DELETE"])
@login_required_api
def backup_delete(backup_id):
    from pathlib import Path

    backup = Backup.query.filter_by(backup_id=backup_id).first()
    if backup is None:
        return api_error("no such backup", 404)
    if not current_user.can_access(backup.vps):
        return api_error("access denied", 403)
    if not current_user.is_admin and backup.vps.owner_id != current_user.id:
        return api_error("access denied", 403)
    path = Path(backup.file_path) if backup.file_path else None
    if path and path.exists():
        try:
            path.unlink()
        except OSError as exc:
            return api_error(f"the archive could not be removed: {exc}", 500)
    db.session.delete(backup)
    db.session.commit()
    audit.record("backup.deleted", backup_id, category="instance",
                 level="warning", target=backup_id)
    return api_ok(deleted=backup_id)


@admin_bp.route("/tokens", methods=["GET", "POST"])
@require_admin
def tokens():
    if request.method == "GET":
        return api_ok(tokens=[t.to_dict() for t in
                              ApiToken.query.order_by(ApiToken.id.desc()).all()])
    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        name = body_str(data, "name", "", 120, required=True)
        scopes = data.get("scopes") or ["read"]
        if isinstance(scopes, str):
            scopes = [s.strip() for s in scopes.split(",") if s.strip()]
        valid = {"read", "write", "provision", "admin"}
        if not set(scopes).issubset(valid):
            return api_error(f"scopes must be drawn from {sorted(valid)}", 400)
        expires_days = body_int(data, "expires_days", 0, 0, 3650)
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)
    raw, token = create_api_token(current_user, name, scopes,
                                  expires_days or None)
    audit.record("api_token.created", f"{name} ({','.join(scopes)}) for "
                                      f"{current_user.username}",
                 category="security", level="warning", target=name)
    return api_ok(token=token.to_dict(), secret=raw,
                  warning="copy this token now — it is not stored and cannot be "
                          "shown again"), 201


@admin_bp.route("/tokens/<int:token_id>", methods=["DELETE"])
@require_admin
def token_revoke(token_id):
    token = db.session.get(ApiToken, token_id)
    if token is None:
        return api_error("no such token", 404)
    token.revoked = True
    db.session.commit()
    audit.record("api_token.revoked", token.name, category="security",
                 level="warning", target=token.name)
    return api_ok(token=token.to_dict())


@admin_bp.route("/audit/summary", methods=["GET"])
@require_admin
def audit_summary():
    from sqlalchemy import func

    by_category = db.session.query(AuditLog.category,
                                   func.count(AuditLog.id)).group_by(
        AuditLog.category).all()
    by_level = db.session.query(AuditLog.level,
                                func.count(AuditLog.id)).group_by(
        AuditLog.level).all()
    return api_ok(by_category=dict(by_category), by_level=dict(by_level),
                  total=AuditLog.query.count(),
                  recent_login_failures=LoginAttempt.query.filter_by(
                      success=False).count())
