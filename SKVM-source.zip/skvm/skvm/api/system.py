"""System information, capabilities and health endpoints."""
from __future__ import annotations

import os
import platform
import shutil
import time
from datetime import timedelta

import psutil
from flask import Blueprint, current_app, jsonify, request
from flask_login import current_user

from ..models import Backup, Node, OSImage, Task, TaskStatus, User, VPS, VPSStatus, utcnow
from ..security import api_error, api_ok, login_required_api, require_admin, scoped_api
from ..services import settings_service

system_bp = Blueprint("api_system", __name__, url_prefix="/api/system")


def _manager():
    return current_app.extensions["skvm_manager"]


@system_bp.route("/health")
def health():
    return current_app.view_functions["health"]()


@system_bp.route("/info")
@login_required_api
def info():
    manager = _manager()
    profile = manager.profile(force=request.args.get("refresh") == "1")
    data = profile.to_dict()
    data["capabilities"] = {k: v.to_dict() for k, v in profile.caps.items()}
    data["config"] = {
        "app_name": current_app.config["APP_NAME"],
        "version": current_app.config["VERSION"],
        "env": current_app.config["ENV_NAME"],
        "port": current_app.config["PORT"],
        "data_dir": str(current_app.config["DATA_DIR"]),
    }
    data["counts"] = {
        "users": User.query.count(),
        "instances": VPS.query.filter(VPS.status != VPSStatus.DELETED).count(),
        "tasks": Task.query.count(),
        "images": OSImage.query.count(),
        "backups": Backup.query.count(),
    }
    return api_ok(system=data)


@system_bp.route("/capabilities")
@login_required_api
def capabilities():
    data = _manager().capabilities(force=request.args.get("refresh") == "1")
    return api_ok(**data)


@system_bp.route("/metrics")
@login_required_api
def metrics():
    """Live host metrics — always real, straight from psutil and the kernel."""
    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage("/")
    cpu_times = psutil.cpu_times_percent(interval=0.2)
    per_cpu = psutil.cpu_percent(interval=0.2, percpu=True)
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except OSError:
        load = []
    net = psutil.net_io_counters()
    boot = psutil.boot_time()
    temps = {}
    try:
        if hasattr(psutil, "sensors_temperatures"):
            for name, entries in (psutil.sensors_temperatures() or {}).items():
                temps[name] = [{"label": e.label, "current": e.current}
                               for e in entries[:4]]
    except Exception:
        temps = {}
    counts = {
        "instances": VPS.query.filter(VPS.status != VPSStatus.DELETED).count(),
        "running": VPS.query.filter(VPS.status == VPSStatus.RUNNING).count(),
        "stopped": VPS.query.filter(VPS.status == VPSStatus.STOPPED).count(),
        "errors": VPS.query.filter(VPS.status == VPSStatus.ERROR).count(),
        "tasks_running": Task.query.filter(
            Task.status == TaskStatus.RUNNING).count(),
    }
    return api_ok(
        cpu={
            "percent": psutil.cpu_percent(interval=0),
            "per_cpu": per_cpu,
            "cores_logical": psutil.cpu_count(logical=True),
            "cores_physical": psutil.cpu_count(logical=False),
            "load_avg": load,
            "times_percent": {
                "user": cpu_times.user, "system": cpu_times.system,
                "idle": cpu_times.idle, "iowait": getattr(cpu_times, "iowait", 0.0),
            },
        },
        memory={
            "total_mb": round(vm.total / 1048576, 1),
            "used_mb": round((vm.total - vm.available) / 1048576, 1),
            "available_mb": round(vm.available / 1048576, 1),
            "percent": vm.percent,
            "buffers_mb": round(getattr(vm, "buffers", 0) / 1048576, 1),
            "cached_mb": round(getattr(vm, "cached", 0) / 1048576, 1),
            "swap": {"total_mb": round(swap.total / 1048576, 1),
                     "used_mb": round(swap.used / 1048576, 1),
                     "percent": swap.percent},
        },
        disk={
            "total_gb": round(disk.total / 1e9, 2),
            "used_gb": round(disk.used / 1e9, 2),
            "free_gb": round(disk.free / 1e9, 2),
            "percent": disk.percent,
            "data_dir_usage": _dir_usage(str(current_app.config["DATA_DIR"])),
        },
        network={
            "bytes_sent": net.bytes_sent, "bytes_recv": net.bytes_recv,
            "packets_sent": net.packets_sent, "packets_recv": net.packets_recv,
        },
        process={"total": len(psutil.pids()), "pid": os.getpid()},
        uptime_seconds=int(time.time() - boot),
        boot_time=boot,
        temperatures=temps,
        counts=counts,
        captured_at=utcnow().isoformat() + "Z",
    )


def _dir_usage(path: str) -> dict:
    try:
        total = 0
        files = 0
        for base, _dirs, names in os.walk(path, onerror=lambda e: None):
            for name in names:
                try:
                    total += os.lstat(os.path.join(base, name)).st_size
                    files += 1
                except OSError:
                    continue
        return {"bytes": total, "files": files}
    except OSError:
        return {"bytes": 0, "files": 0}


@system_bp.route("/processes")
@require_admin
def processes():
    """Top processes on the host (administrators only)."""
    limit = min(50, max(5, request.args.get("limit", 20, type=int)))
    rows = []
    for proc in psutil.process_iter(
            ["pid", "name", "username", "cpu_percent", "memory_info",
             "create_time", "cmdline", "status"]):
        try:
            info = proc.info
            mem = info.get("memory_info")
            rows.append({
                "pid": info["pid"], "name": info["name"],
                "user": info.get("username", ""), "status": info.get("status"),
                "cpu_percent": round(info.get("cpu_percent") or 0, 1),
                "memory_mb": round((mem.rss if mem else 0) / 1048576, 1),
                "started_at": info.get("create_time"),
                "cmdline": " ".join(info.get("cmdline") or [])[:200],
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    rows.sort(key=lambda r: r["memory_mb"], reverse=True)
    return api_ok(processes=rows[:limit], total=len(rows))


@system_bp.route("/nodes")
@login_required_api
def nodes():
    manager = _manager()
    if request.args.get("refresh") == "1":
        manager.refresh_local_node()
    return api_ok(nodes=[n.to_dict() for n in Node.query.order_by(Node.id).all()])


@system_bp.route("/maintenance", methods=["GET", "POST"])
@require_admin
def maintenance():
    state = settings_service.maintenance()
    if request.method == "GET":
        return api_ok(maintenance=state.to_dict())
    payload = request.get_json(silent=True) or {}
    enabled = bool(payload.get("enabled"))
    updated = settings_service.set_maintenance(
        enabled, message=str(payload.get("message") or "")[:500],
        allow_admins=bool(payload.get("allow_admins", True)),
        actor=current_user.username,
    )
    from ..services import audit

    audit.record("maintenance.toggled",
                 f"maintenance mode {'enabled' if enabled else 'disabled'}",
                 category="admin", level="warning", target="panel")
    return api_ok(maintenance=updated.to_dict())


@system_bp.route("/enforce-expiry", methods=["POST"])
@require_admin
def enforce_expiry():
    """Apply the expiry policy right now instead of waiting for the monitor."""
    result = _manager().enforce_expiry()
    from ..services import audit

    audit.record("maintenance.expiry_enforced",
                 f"{result['expired']} expired, {result['suspended']} suspended",
                 category="admin", target="panel")
    return api_ok(**result)


@system_bp.route("/prune", methods=["POST"])
@require_admin
def prune():
    """Real housekeeping: prune audit rows and stale login attempts."""
    from ..models import LoginAttempt
    from ..services import audit as audit_service

    days = int(settings_service.get("audit_retention_days", 30) or 30)
    pruned_audit = audit_service.prune(older_than_days=days)
    pruned_attempts = LoginAttempt.query.filter(
        LoginAttempt.created_at < utcnow() - timedelta(days=7)
    ).delete(synchronize_session=False)
    from ..extensions import db

    db.session.commit()
    audit_service.record("maintenance.prune",
                         f"pruned {pruned_audit} audit rows and "
                         f"{pruned_attempts} login attempts",
                         category="admin", target="panel")
    return api_ok(audit_pruned=pruned_audit, attempts_pruned=pruned_attempts,
                  retention_days=days)
