"""Instance API: list, create, lifecycle, metrics, backups."""
from __future__ import annotations

import json
from datetime import timedelta

from flask import Blueprint, current_app, jsonify, request
from flask_login import current_user

from ..extensions import db, limiter
from ..models import Backup, Node, OSImage, Plan, Task, TaskStatus, User, VPS, VPSStatus, utcnow
from ..security import (
    ValidationError, api_error, api_ok, body_bool, body_int, body_str,
    login_required_api, require_admin, scoped_api,
)
from ..services import audit, settings_service
from ..services.instances import InstanceService, ServiceError

instances_bp = Blueprint("api_instances", __name__, url_prefix="/api/instances")


def service() -> InstanceService:
    return InstanceService(current_app)


def _visible(user=None):
    user = user or current_user
    if user.can_view_all:
        return VPS.query
    return VPS.query.filter(VPS.owner_id == user.id)


@instances_bp.route("", methods=["GET"])
@login_required_api
def list_instances():
    query = _visible().filter(VPS.status != VPSStatus.DELETED)
    status = request.args.get("status")
    search = request.args.get("q")
    owner = request.args.get("owner")
    if status:
        query = query.filter(VPS.status == status)
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(VPS.name.ilike(like), VPS.hostname.ilike(like),
                                    VPS.instance_id.ilike(like)))
    if owner and current_user.can_view_all:
        try:
            query = query.filter(VPS.owner_id == int(owner))
        except ValueError:
            pass
    page = max(1, request.args.get("page", 1, type=int))
    per_page = min(100, max(1, request.args.get("per_page", 25, type=int)))
    total = query.count()
    rows = (query.order_by(VPS.id.desc())
            .offset((page - 1) * per_page).limit(per_page).all())
    return api_ok(
        instances=[v.to_dict(detail=True) for v in rows],
        total=total, page=page, per_page=per_page,
        pages=max(1, (total + per_page - 1) // per_page),
    )


@instances_bp.route("/<instance_id>", methods=["GET"])
@login_required_api
def get_instance(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None or vps.status == VPSStatus.DELETED:
        return api_error("no such instance", 404)
    if not current_user.can_access(vps):
        audit.record("api.access_denied", f"instance {vps.name}", category="security",
                     level="warning", target=current_user.username)
        return api_error("you do not have access to this instance", 403)
    refresh = request.args.get("refresh", "1") == "1"
    manager = current_app.extensions["skvm_manager"]
    if refresh:
        manager.refresh_instance(vps, collect_metrics=request.args.get(
            "metrics", "1") == "1")
    provider = manager.provider_for(vps)
    facts = provider.host_facts().__dict__ if provider else {}
    return api_ok(instance=vps.to_dict(detail=True), host_facts=facts,
                  provider=provider.label if provider else None)


@instances_bp.route("/<instance_id>/metrics", methods=["GET"])
@login_required_api
def instance_metrics(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        return api_error("no such instance", 404)
    if not current_user.can_access(vps):
        return api_error("access denied", 403)
    manager = current_app.extensions["skvm_manager"]
    provider = manager.provider_for(vps)
    if provider is None:
        return api_error("no container runtime is available to measure this "
                         "instance", 503)
    metrics = provider.metrics(vps)
    if metrics.get("available"):
        vps.set_metrics(metrics)
        db.session.commit()
    return api_ok(instance_id=vps.instance_id, status=vps.status,
                  metrics=metrics, host=manager.profile().resources)


@instances_bp.route("", methods=["POST"])
@require_admin
@limiter.limit("20 per hour")
def create_instance():
    """Create a real instance.  Administrators only (server-enforced)."""
    data = request.get_json(silent=True) or request.form.to_dict()
    try:
        owner_id = body_int(data, "owner_id", 0, 0, 10 ** 9, "owner")
        if not owner_id:
            raise ValidationError("choose the account that will own this instance",
                                  field="owner_id")
        owner = db.session.get(User, owner_id)
        if owner is None:
            raise ValidationError("that account does not exist", field="owner_id")
        name = body_str(data, "name", "", 64, required=True)
        hostname = body_str(data, "hostname", name, 63) or name
        plan_id = body_int(data, "plan_id", 0, 0, 10 ** 9)
        plan = db.session.get(Plan, plan_id) if plan_id else None
        image_id = body_int(data, "image_id", 0, 0, 10 ** 9)
        image = db.session.get(OSImage, image_id) if image_id else None
        if plan:
            vcpu = body_int(data, "vcpu", plan.vcpu, 1, 512)
            memory_mb = body_int(data, "memory_mb", plan.memory_mb, 64, 262144)
            disk_gb = body_int(data, "disk_gb", plan.disk_gb, 1, 4096)
        else:
            vcpu = body_int(data, "vcpu", 1, 1, 512)
            memory_mb = body_int(data, "memory_mb", 1024, 64, 262144)
            disk_gb = body_int(data, "disk_gb", 10, 1, 4096)
        expires_days = body_int(data, "expires_days", int(
            settings_service.get("default_expiry_days", 30) or 0), 0, 3650)
        node_id = body_int(data, "node_id", 0, 0, 10 ** 9)
        init_command = body_str(data, "init_command", "", 200)
        want_networking = body_bool(data, "networking", True)
        want_ssh = body_bool(data, "ssh", False)
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)

    node = db.session.get(Node, node_id) if node_id else None
    manager = current_app.extensions["skvm_manager"]
    vps, task, errors = manager.create_instance(
        owner=owner, name=name, hostname=hostname, plan=plan, vcpu=vcpu,
        memory_mb=memory_mb, disk_gb=disk_gb, image=image,
        requested_by=current_user, expires_days=expires_days or None, node=node,
        init_command=init_command, want_networking=want_networking,
        want_ssh=want_ssh,
    )
    if errors:
        return api_error("; ".join(errors), 400, errors=errors)
    audit.record("instance.create_requested",
                 f"{vps.name} ({vcpu} vCPU, {memory_mb} MiB, {disk_gb} GiB, "
                 f"{image.label if image else 'no image'}) for {owner.username}",
                 category="instance", target=vps.name,
                 meta={"provider": vps.provider, "kind": vps.kind})
    return api_ok(instance=vps.to_dict(), task=task.to_dict(), message=(
        "provisioning started — follow the task log for real progress")), 202


@instances_bp.route("/<instance_id>/actions", methods=["POST"])
@login_required_api
def instance_action(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None or vps.status == VPSStatus.DELETED:
        return api_error("no such instance", 404)
    if not current_user.can_operate(vps):
        audit.record("api.action_denied", f"{instance_id}", category="security",
                     level="warning", target=current_user.username)
        return api_error("you do not have permission to control this instance", 403)

    payload = request.get_json(silent=True) or request.form.to_dict()
    action = (payload.get("action") or "").strip().lower()
    if action == "delete" and not current_user.is_admin:
        return api_error("only administrators can delete instances", 403)

    manager = current_app.extensions["skvm_manager"]
    try:
        task, error = manager.submit_power(vps, action, current_user)
    except ValueError as exc:
        return api_error(str(exc), 400)
    if error:
        return api_error(error, 409)
    if task is None:
        return api_error("the action could not be queued", 500)
    audit.record(f"instance.{action}", f"{vps.name}", category="instance",
                 target=vps.name)
    return api_ok(task=task.to_dict(),
                  message=f"{action} queued for {vps.name}"), 202


@instances_bp.route("/<instance_id>", methods=["DELETE"])
@require_admin
def delete_instance(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        return api_error("no such instance", 404)
    manager = current_app.extensions["skvm_manager"]
    task, error = manager.submit_power(vps, "delete", current_user)
    if error:
        return api_error(error, 409)
    audit.record("instance.delete_requested", vps.name, category="instance",
                 level="warning", target=vps.name)
    return api_ok(task=task.to_dict(), message="deletion queued"), 202


@instances_bp.route("/<instance_id>/backups", methods=["GET", "POST"])
@login_required_api
def backups(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        return api_error("no such instance", 404)
    if not current_user.can_access(vps):
        return api_error("access denied", 403)
    if request.method == "GET":
        return api_ok(backups=[b.to_dict() for b in
                               Backup.query.filter_by(vps_id=vps.id)
                               .order_by(Backup.id.desc()).all()])
    if not current_user.can_operate(vps):
        return api_error("your role cannot create backups", 403)
    label = (request.get_json(silent=True) or {}).get("label", "")
    manager = current_app.extensions["skvm_manager"]
    backup, task = manager.create_backup(vps, current_user, label=str(label)[:120])
    audit.record("instance.backup", f"backup of {vps.name} requested",
                 category="instance", target=vps.name)
    return api_ok(backup=backup.to_dict(), task=task.to_dict()), 202


@instances_bp.route("/<instance_id>/backups/<backup_id>/verify", methods=["POST"])
@login_required_api
def verify_backup(instance_id, backup_id):
    """
    Prove a snapshot is readable: open it as a real gzip stream and read the
    tar index back. Until this route existed, BackupService.verify() had no
    caller at all — the archive was written, marked `ready`, and never checked.
    """
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        return api_error("no such instance", 404)
    if not current_user.can_operate(vps):
        return api_error("your role cannot verify backups", 403)
    backup = Backup.query.filter_by(backup_id=backup_id, vps_id=vps.id).first()
    if backup is None:
        return api_error("no such backup for this instance", 404)
    service = current_app.extensions["skvm_backups"]
    result = service.verify(backup_id, current_user)
    audit.record(
        "backup.verified",
        f"{backup_id} on {vps.name}: "
        + ("readable" if result.get("verified") else
           f"FAILED ({result.get('reason', 'unknown')})"),
        category="backup",
        level="info" if result.get("verified") else "warning",
        target=vps.name,
    )
    if not result.get("verified"):
        return api_error(result.get("reason") or "the archive could not be read",
                         409, verification=result)
    return api_ok(verification=result)


@instances_bp.route("/<instance_id>/expiry", methods=["POST"])
@require_admin
def set_expiry(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        return api_error("no such instance", 404)
    data = request.get_json(silent=True) or {}
    days = data.get("days")
    clear = bool(data.get("clear"))
    if clear:
        vps.expires_at = None
    else:
        try:
            days = int(days)
        except (TypeError, ValueError):
            return api_error("days must be a whole number")
        if days < 0 or days > 3650:
            return api_error("days must be between 0 and 3650")
        vps.expires_at = utcnow() + timedelta(days=days)
    vps.suspend_on_expiry = bool(data.get("suspend_on_expiry",
                                          vps.suspend_on_expiry))
    vps.auto_renew = bool(data.get("auto_renew", vps.auto_renew))
    db.session.commit()
    audit.record("instance.expiry_updated",
                 f"{vps.name} expiry set to "
                 f"{vps.expires_at.isoformat() if vps.expires_at else 'never'}",
                 category="instance", target=vps.name)
    return api_ok(instance=vps.to_dict())


@instances_bp.route("/<instance_id>/transfer", methods=["POST"])
@require_admin
def transfer_instance(instance_id):
    """Move an instance to another owner (administrators only)."""
    payload = request.get_json(silent=True) or request.form.to_dict()
    try:
        owner_id = body_int(payload, "owner_id", 0, 0, 10 ** 9, "owner")
    except ValidationError as exc:
        return api_error(str(exc), 400, field=exc.field)
    if not owner_id:
        return api_error("'owner_id' is required")
    service_instance = service()
    try:
        vps = service_instance.transfer(instance_id, owner_id, current_user)
    except ServiceError as exc:
        return api_error(str(exc), exc.code)
    return api_ok(instance=vps.to_dict())


@instances_bp.route("/<instance_id>/refresh", methods=["POST"])
@login_required_api
def refresh(instance_id):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        return api_error("no such instance", 404)
    if not current_user.can_access(vps):
        return api_error("access denied", 403)
    manager = current_app.extensions["skvm_manager"]
    manager.refresh_instance(vps, collect_metrics=True)
    return api_ok(instance=vps.to_dict(detail=True), metrics=vps.metrics)


@instances_bp.route("/providers", methods=["GET"])
@login_required_api
def providers():
    capabilities = current_app.extensions["skvm_manager"].capabilities()
    return api_ok(providers=capabilities.get("providers", []),
                  active=capabilities.get("active_provider"),
                  facts=capabilities.get("active_facts"),
                  can_provision=capabilities.get("can_provision"))
