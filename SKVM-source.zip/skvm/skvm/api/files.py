"""Instance file-manager API."""
from __future__ import annotations

import io
import posixpath

from flask import Blueprint, current_app, jsonify, request, send_file
from flask_login import current_user

from ..models import VPS, VPSStatus
from ..security import (
    api_error, api_ok, login_required_api, wants_json,
)
from ..services import audit, settings_service
from ..services.filesystem import FileError, InstanceFiles, normalize_path

files_bp = Blueprint("api_files", __name__, url_prefix="/api/instances")


def _instance(instance_id: str):
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None or vps.status == VPSStatus.DELETED:
        return None, api_error("no such instance", 404)
    if not current_user.can_access(vps):
        return None, api_error("you do not have access to this instance", 403)
    return vps, None


def _files(vps) -> InstanceFiles:
    manager = current_app.extensions["skvm_manager"]
    provider = manager.provider_for(vps)
    if provider is None:
        raise FileError("no container runtime is available on this host")
    return InstanceFiles(provider, vps)


def _handle(operation):
    """Decorator-lite helper: run a file operation and translate its errors."""
    try:
        return operation()
    except FileError as exc:
        return api_error(str(exc), 400)
    except Exception as exc:  # noqa: BLE001
        current_app.logger.exception("file operation failed")
        return api_error(f"{type(exc).__name__}: {exc}", 500)


@files_bp.route("/<instance_id>/files", methods=["GET"])
@login_required_api
def list_files(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    path = request.args.get("path", "/")
    return _handle(lambda: api_ok(**_files(vps).list_dir(path)))


@files_bp.route("/<instance_id>/files/stat", methods=["GET"])
@login_required_api
def stat_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    path = request.args.get("path", "")
    if not path:
        return api_error("the 'path' parameter is required")
    return _handle(lambda: api_ok(file=_files(vps).stat(path)))


@files_bp.route("/<instance_id>/files/content", methods=["GET", "PUT", "POST"])
@login_required_api
def file_content(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if request.method == "GET":
        path = request.args.get("path", "")
        if not path:
            return api_error("the 'path' parameter is required")
        download = request.args.get("download") == "1"
        if download:
            def _download():
                data, filename = _files(vps).download(path)
                audit.record("instance.file_download",
                             f"{path} from {vps.name}", category="instance",
                             target=vps.name)
                return send_file(io.BytesIO(data), as_attachment=True,
                                 download_name=filename,
                                 mimetype="application/octet-stream")
            return _handle(_download)
        return _handle(lambda: api_ok(**_files(vps).read_text(path)))

    if not current_user.can_operate(vps):
        return api_error("your role cannot modify files on this instance", 403)
    payload = request.get_json(silent=True) or {}
    path = payload.get("path") or ""
    content = payload.get("content")
    if not path:
        return api_error("'path' is required")
    if content is None:
        return api_error("'content' is required")

    def _write():
        result = _files(vps).write_text(path, str(content))
        audit.record("instance.file_write", f"{path} on {vps.name}",
                     category="instance", target=vps.name)
        return api_ok(**result)

    return _handle(_write)


@files_bp.route("/<instance_id>/files/upload", methods=["POST"])
@login_required_api
def upload_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot upload files", 403)

    limit_mb = int(settings_service.get("file_manager_max_upload_mb", 256) or 256)
    max_bytes = limit_mb * 1024 * 1024
    path = request.form.get("path", "/")
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        return api_error("no file was included in the request")
    data = upload.read(max_bytes + 1)
    if len(data) > max_bytes:
        return api_error(f"the file exceeds the {limit_mb} MiB upload limit", 413,
                         size=len(data), limit_mb=limit_mb)
    filename = upload.filename.replace("\\", "/").split("/")[-1]

    def _upload():
        result = _files(vps).upload(path, filename, data)
        audit.record("instance.file_upload",
                     f"{filename} ({len(data)} bytes) → {path} on {vps.name}",
                     category="instance", target=vps.name)
        return api_ok(**result)

    return _handle(_upload)


@files_bp.route("/<instance_id>/files/mkdir", methods=["POST"])
@login_required_api
def make_directory(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot create directories", 403)
    payload = request.get_json(silent=True) or request.form.to_dict()
    path = payload.get("path", "/")
    name = payload.get("name", "")
    if not name:
        return api_error("'name' is required")
    return _handle(lambda: api_ok(**_files(vps).make_dir(path, name)))


@files_bp.route("/<instance_id>/files", methods=["DELETE"])
@login_required_api
def delete_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot delete files", 403)
    path = request.args.get("path") or (request.get_json(silent=True) or {}).get(
        "path", "")
    if not path:
        return api_error("the 'path' parameter is required")

    def _delete():
        result = _files(vps).delete(path)
        audit.record("instance.file_delete", f"{path} on {vps.name}",
                     category="instance", level="warning", target=vps.name)
        return api_ok(**result)

    return _handle(_delete)


@files_bp.route("/<instance_id>/files/rename", methods=["POST"])
@login_required_api
def rename_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot rename files", 403)
    payload = request.get_json(silent=True) or request.form.to_dict()
    path = payload.get("path", "")
    name = payload.get("name", "")
    if not path or not name:
        return api_error("'path' and 'name' are required")
    return _handle(lambda: api_ok(**_files(vps).rename(path, name)))


@files_bp.route("/<instance_id>/files/copy", methods=["POST"])
@login_required_api
def copy_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot copy files", 403)
    payload = request.get_json(silent=True) or request.form.to_dict()
    path = payload.get("path", "")
    destination = payload.get("destination") or None
    if not path:
        return api_error("'path' is required")
    return _handle(lambda: api_ok(**_files(vps).copy(path, destination)))


@files_bp.route("/<instance_id>/files/move", methods=["POST"])
@login_required_api
def move_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot move files", 403)
    payload = request.get_json(silent=True) or request.form.to_dict()
    path = payload.get("path", "")
    destination = payload.get("destination", "")
    if not path or not destination:
        return api_error("'path' and 'destination' are required")
    return _handle(lambda: api_ok(**_files(vps).move(path, destination)))


@files_bp.route("/<instance_id>/files/chmod", methods=["POST"])
@login_required_api
def chmod_file(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    if not current_user.can_operate(vps):
        return api_error("your role cannot change permissions", 403)
    payload = request.get_json(silent=True) or request.form.to_dict()
    path = payload.get("path", "")
    mode = payload.get("mode", "")
    if not path or not mode:
        return api_error("'path' and 'mode' are required")
    return _handle(lambda: api_ok(**_files(vps).chmod(path, mode)))


@files_bp.route("/<instance_id>/files/search", methods=["GET"])
@login_required_api
def search_files(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    path = request.args.get("path", "/")
    pattern = request.args.get("q", "")
    if not pattern:
        return api_error("the 'q' parameter is required")
    return _handle(lambda: api_ok(**_files(vps).search(path, pattern)))


@files_bp.route("/<instance_id>/files/usage", methods=["GET"])
@login_required_api
def files_usage(instance_id):
    vps, error = _instance(instance_id)
    if error:
        return error
    path = request.args.get("path", "/")
    return _handle(lambda: api_ok(usage=_files(vps).disk_usage(path)))
