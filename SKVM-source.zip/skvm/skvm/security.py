"""
Authorization, validation and API security helpers.

Everything a route needs to protect itself lives here so that the rules are
applied consistently.  The panel never relies on the UI to hide a control: each
route re-checks permission on the server.
"""
from __future__ import annotations

import functools
import hashlib
import hmac
import logging
import re
import secrets
from datetime import timedelta

from flask import abort, current_app, g, jsonify, redirect, request, url_for
from flask_login import current_user
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db
from .models import ApiToken, Role, User, utcnow
from .services import audit

logger = logging.getLogger("skvm.security")

USERNAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{2,31}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}$")
HOSTNAME_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$")
INSTANCE_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{1,40}$")


class ValidationError(ValueError):
    def __init__(self, message: str, field: str = ""):
        super().__init__(message)
        self.field = field


# --------------------------------------------------------------------------
# password handling
# --------------------------------------------------------------------------
COMMON_PASSWORDS = {
    "password", "password1", "12345678", "123456789", "qwerty123", "letmein",
    "admin123", "administrator", "skvm", "changeme", "welcome1", "iloveyou",
    "password123", "admin1234", "root1234", "vpspanel",
}


def validate_password(password: str, username: str = "", email: str = "") -> list[str]:
    """Return a list of real problems with the password (empty == acceptable)."""
    problems: list[str] = []
    minimum = current_app.config["PASSWORD_MIN_LENGTH"] if current_app else 10
    if not password or len(password) < minimum:
        problems.append(f"use at least {minimum} characters")
    if len(password) > 200:
        problems.append("use at most 200 characters")
    if password.lower() in COMMON_PASSWORDS:
        problems.append("this password appears in common-password lists")
    if password and password.lower() == (username or "").lower():
        problems.append("the password must differ from the username")
    local = (email or "").split("@")[0].lower()
    if local and password.lower() == local:
        problems.append("the password must differ from the email address")
    classes = sum(bool(re.search(p, password or "")) for p in
                  (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
    if classes < 3:
        problems.append("mix upper case, lower case, digits or symbols")
    return problems


def validate_username(username: str) -> list[str]:
    if not username or not USERNAME_RE.match(username):
        return ["use 3-32 characters: letters, digits, dot, dash or underscore, "
                "starting with a letter or digit"]
    return []


def validate_email(email: str) -> list[str]:
    if not email or not EMAIL_RE.match(email) or len(email) > 255:
        return ["enter a valid email address"]
    return []


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_api_token(user: User, name: str, scopes: list[str],
                     expires_days: int | None = None) -> tuple[str, ApiToken]:
    raw = f"skvm_{secrets.token_urlsafe(32)}"
    token = ApiToken(
        name=name[:120],
        token_prefix=raw[:12],
        token_hash=hash_token(raw),
        user_id=user.id,
        scopes=",".join(scopes or ["read"]),
        expires_at=(utcnow() + timedelta(days=expires_days)) if expires_days else None,
    )
    db.session.add(token)
    db.session.commit()
    return raw, token


def verify_api_token(raw: str) -> ApiToken | None:
    if not raw or not raw.startswith("skvm_"):
        return None
    prefix = raw[:12]
    candidates = ApiToken.query.filter(
        ApiToken.token_prefix == prefix, ApiToken.revoked.is_(False)
    ).all()
    for token in candidates:
        if hmac.compare_digest(token.token_hash, hash_token(raw)):
            if token.is_expired:
                return None
            token.last_used_at = utcnow()
            token.last_used_ip = (request.remote_addr or "")[:64]
            db.session.commit()
            return token
    return None


# --------------------------------------------------------------------------
# decorators
# --------------------------------------------------------------------------
def _deny(message: str, code: int = 403):
    if wants_json():
        return jsonify({"ok": False, "error": message, "code": code}), code
    abort(code, description=message)


def wants_json() -> bool:
    if request.path.startswith("/api/"):
        return True
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return True
    accept = request.headers.get("Accept", "")
    return "application/json" in accept and "text/html" not in accept


# --------------------------------------------------------------------------
# token scopes
# --------------------------------------------------------------------------
# Which scope a bearer token must carry to use a write route. Read-only
# requests always need "read"; global infrastructure and destructive actions
# are admin-only, while actions against an instance the user may operate are
# write-scoped. Provisioning a new instance is a separate capability.
TOKEN_SCOPE_RULES: tuple[tuple[str, str], ...] = (
    # global / administrative surfaces
    ("/api/users", "admin"),
    ("/api/settings", "admin"),
    ("/api/tokens", "admin"),
    ("/api/audit", "admin"),
    ("/api/plans", "admin"),
    ("/api/nodes", "admin"),
    ("/api/images", "admin"),
    ("/api/system", "admin"),
    ("/api/maintenance", "admin"),
    ("/api/tasks", "admin"),             # POST /tasks/<id>/cancel
    ("/api/console/sessions", "admin"),  # close all users' consoles
    ("/api/backups", "write"),           # own backups remain user-scoped
    # provision/console endpoints
    ("/api/instances", "provision"),     # exact POST /api/instances below
    ("/api/console", "provision"),
    ("/api/me", "write"),
)


# `read` is implied by every token: a token that can act must be able to poll
# the task and inspect the resource it just changed.
IMPLIED_SCOPES = ("read",)


def effective_scopes(scopes) -> set:
    """Scopes a token really holds, including the ones always granted."""
    scopes = set(scopes)
    return {"*"} if "*" in scopes else scopes | set(IMPLIED_SCOPES)


def required_token_scope(method: str, path: str) -> str:
    """Scope a bearer-token request needs, inferred from its method and path."""
    verb = method.upper()
    path = path.split("?", 1)[0].rstrip("/") or "/"
    if verb in ("GET", "HEAD", "OPTIONS"):
        return "read"

    # Instance creation, deletion, expiry and ownership transfer have distinct
    # privilege levels from ordinary instance power/files/backup operations.
    if verb == "POST" and path == "/api/instances":
        return "provision"
    if path.startswith("/api/instances/"):
        parts = path[len("/api/instances/"):].split("/")
        if verb == "DELETE" and len(parts) == 1:
            return "admin"                   # delete the VPS itself
        if len(parts) >= 2 and parts[1] in ("expiry", "transfer"):
            return "admin"
        return "write"

    # Keep the ordered prefix map for all global and other endpoint groups.
    for prefix, scope in TOKEN_SCOPE_RULES:
        if path.startswith(prefix):
            return scope
    return "write"


def token_scope_allows(min_scope: str) -> bool:
    """True for session auth, or a bearer token carrying ``min_scope``."""
    token = getattr(g, "api_token", None)
    if token is None:
        return current_user.is_authenticated
    return min_scope in effective_scopes(getattr(g, "api_scopes", set()))


def enforce_token_scope() -> tuple[dict, int] | None:
    """
    Reject a token-authenticated request that lacks the scope its route needs.

    Called both from the API blueprint's before_request hook (which also covers
    the role-gated routes) and from login_required_api. Sessions are never
    scope-limited — this only ever applies to bearer tokens.
    """
    token = getattr(g, "api_token", None)
    if token is None:
        return None
    scopes = effective_scopes(getattr(g, "api_scopes", set()))
    if "*" in scopes:
        return None
    needed = required_token_scope(request.method, request.path)
    if (needed == "write" and request.method.upper() == "POST"
            and request.path.endswith("/actions")):
        payload = request.get_json(silent=True) or request.form.to_dict()
        if str(payload.get("action") or "").strip().lower() == "delete":
            needed = "admin"
    if needed in scopes:
        return None
    return {"ok": False,
            "error": f"this token lacks the '{needed}' scope required for "
                     f"{request.method} {request.path}",
            "required_scope": needed,
            "token_scopes": sorted(scopes)}, 403


def login_required_api(view):
    """
    Require an authenticated session or a bearer token.

    When an ``Authorization: Bearer`` header is present it always wins over a
    session cookie, even if one is sent too: the caller explicitly asked to be
    authenticated as that token, so its (possibly narrower) scopes must apply
    rather than being silently widened by whatever session the browser holds.
    A bad token is rejected instead of silently falling back to the session.
    """

    @functools.wraps(view)
    def wrapper(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        if header.lower().startswith("bearer "):
            token = verify_api_token(header.split(None, 1)[1].strip())
            if token and token.user and token.user.is_active:
                g.api_token = token
                g.api_scopes = effective_scopes(token.scope_list)
                g.api_user = token.user
                denial = enforce_token_scope()
                if denial is not None:
                    return jsonify(denial[0]), denial[1]
                return view(*args, **kwargs)
            return jsonify({"ok": False,
                            "error": "invalid or expired API token"}), 401
        if current_user.is_authenticated:
            g.api_token = None
            g.api_scopes = {"*"}
            return view(*args, **kwargs)
        return jsonify({"ok": False, "error": "authentication required"}), 401

    return wrapper


def api_user() -> User | None:
    if getattr(g, "api_user", None):
        return g.api_user
    if current_user.is_authenticated:
        return current_user
    return None


def require_admin(view):
    @functools.wraps(view)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            if wants_json():
                return jsonify({"ok": False, "error": "authentication required",
                                "code": 401}), 401
            return redirect(url_for("auth.login", next=request.full_path))
        if not Role.is_admin(current_user.role):
            audit.record("permission.denied",
                         f"attempted {request.method} {request.path}",
                         category="security", level="warning",
                         target=current_user.username)
            return _deny("administrator privileges are required for this action")
        return view(*args, **kwargs)

    return wrapper


def require_operator(view):
    """Administrators and operators: plans, nodes, images, maintenance."""

    @functools.wraps(view)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            if wants_json():
                return jsonify({"ok": False, "error": "authentication required",
                                "code": 401}), 401
            return redirect(url_for("auth.login", next=request.full_path))
        if not Role.can_manage_infrastructure(current_user.role):
            audit.record("permission.denied",
                         f"attempted {request.method} {request.path}",
                         category="security", level="warning",
                         target=current_user.username)
            return _deny("you do not have permission to manage infrastructure")
        return view(*args, **kwargs)

    return wrapper


def scoped_api(min_scope: str = "read"):
    """Combine token/session auth with a scope check for API routes."""

    def decorator(view):
        @login_required_api
        @functools.wraps(view)
        def wrapper(*args, **kwargs):
            scopes = getattr(g, "api_scopes", {"*"})
            if "*" not in scopes and min_scope not in scopes:
                return jsonify({"ok": False,
                                "error": f"this token lacks the '{min_scope}' "
                                         "scope"}), 403
            user = api_user()
            if user is None or not user.is_active:
                return jsonify({"ok": False, "error": "account is not active"}), 401
            if min_scope in ("write", "provision") and not Role.can_create_instances(
                    user.role) and user.role != Role.OPERATOR:
                return jsonify({"ok": False,
                                "error": "your role cannot perform write "
                                         "operations"}), 403
            return view(*args, **kwargs)

        return wrapper

    return decorator


# --------------------------------------------------------------------------
# request helpers
# --------------------------------------------------------------------------
def json_body() -> dict:
    """Parse a JSON body, tolerating form submissions."""
    if request.is_json:
        data = request.get_json(silent=True)
        return data if isinstance(data, dict) else {}
    if request.form:
        return {k: v for k, v in request.form.items()}
    data = request.get_json(silent=True, force=True)
    return data if isinstance(data, dict) else {}


def body_int(data: dict, key: str, default: int, minimum: int = 0,
             maximum: int = 10 ** 9, field: str | None = None) -> int:
    raw = data.get(key, default)
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise ValidationError(
            f"{field or key} must be a whole number", field=key) from None
    if value < minimum or value > maximum:
        raise ValidationError(
            f"{field or key} must be between {minimum} and {maximum}", field=key)
    return value


def body_bool(data: dict, key: str, default: bool = False) -> bool:
    raw = data.get(key, default)
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def body_str(data: dict, key: str, default: str = "", max_length: int = 255,
             required: bool = False) -> str:
    raw = data.get(key, default)
    if raw is None:
        raw = ""
    value = str(raw).strip()
    if len(value) > max_length:
        raise ValidationError(
            f"{key} must be at most {max_length} characters", field=key)
    if required and not value:
        raise ValidationError(f"{key} is required", field=key)
    return value


def client_ip() -> str:
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.remote_addr or ""


def check_origin() -> bool:
    """Small CSRF belt-and-braces check for WebSocket and API calls."""
    origin = request.headers.get("Origin")
    if not origin:
        return True
    host = request.host
    return origin.split("//")[-1].split("/")[0] == host


def api_error(message: str, code: int = 400, **extra):
    payload = {"ok": False, "error": message}
    payload.update(extra)
    return jsonify(payload), code


def api_ok(**payload):
    payload.setdefault("ok", True)
    return jsonify(payload)


def hash_password(raw: str) -> str:
    return generate_password_hash(raw, method="scrypt")


def verify_password(hashed: str, raw: str) -> bool:
    try:
        return check_password_hash(hashed, raw)
    except Exception:
        return False
