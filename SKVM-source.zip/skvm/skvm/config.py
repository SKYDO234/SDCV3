"""
SKVM configuration.

Every value is environment-driven so that install.sh can generate a secure
`.env` and the panel behaves identically in a sandbox (RigBox / CodeSandbox)
and on a real dedicated VPS.
"""
from __future__ import annotations

import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

# Load .env from the project root (idempotent).
load_dotenv(BASE_DIR / ".env", override=False)


def _bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _path(name: str, default: str) -> Path:
    p = Path(os.environ.get(name, default)).expanduser()
    if not p.is_absolute():
        p = (BASE_DIR / p).resolve()
    return p


class Config:
    # ------------------------------------------------------------------ app
    APP_NAME = os.environ.get("SKVM_APP_NAME", "SKVM")
    APP_TAGLINE = os.environ.get("SKVM_APP_TAGLINE", "Virtual Private Server Control Plane")
    VERSION = "1.0.0"

    # Sandbox / deployment identity ----------------------------------------
    # `sandbox` is auto-detected by RuntimeProbe and only affects presentation.
    ENV_NAME = os.environ.get("SKVM_ENV", "production")

    HOST = os.environ.get("HOST", "0.0.0.0")
    PORT = _int("PORT", _int("SKVM_PORT", 5555))
    DEBUG = _bool("SKVM_DEBUG", False)
    # Werkzeug's reloader breaks PTY/WebSocket supervision, keep it off.
    USE_RELOADER = _bool("SKVM_RELOADER", False)

    # ----------------------------------------------------------- security
    SECRET_KEY = os.environ.get("SKVM_SECRET_KEY") or secrets.token_hex(32)
    SESSION_COOKIE_NAME = "skvm_session"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    # Secure cookies only when explicitly served over TLS (a plain-HTTP
    # sandbox preview would otherwise never receive the cookie).
    SESSION_COOKIE_SECURE = _bool("SKVM_COOKIE_SECURE", False)
    PERMANENT_SESSION_LIFETIME = _int("SKVM_SESSION_HOURS", 12) * 3600
    REMEMBER_COOKIE_DURATION = _int("SKVM_REMEMBER_DAYS", 14) * 86400

    # One-time bootstrap token written by install.sh.  Without it the setup
    # wizard refuses to create the first administrator.
    SETUP_TOKEN = os.environ.get("SKVM_SETUP_TOKEN", "")
    # Optional non-interactive bootstrap (used by install.sh / CI).
    BOOTSTRAP_ADMIN_USERNAME = os.environ.get("SKVM_ADMIN_USERNAME", "")
    BOOTSTRAP_ADMIN_EMAIL = os.environ.get("SKVM_ADMIN_EMAIL", "")
    BOOTSTRAP_ADMIN_PASSWORD = os.environ.get("SKVM_ADMIN_PASSWORD", "")

    WTF_CSRF_ENABLED = _bool("SKVM_CSRF", True)
    WTF_CSRF_TIME_LIMIT = None  # session-bound, not clock-bound
    RATELIMIT_ENABLED = _bool("SKVM_RATELIMIT", True)
    RATELIMIT_STORAGE_URI = os.environ.get("SKVM_RATELIMIT_STORAGE", "memory://")
    RATELIMIT_DEFAULT = os.environ.get("SKVM_RATELIMIT_DEFAULT", "600 per hour")
    RATELIMIT_LOGIN = os.environ.get("SKVM_RATELIMIT_LOGIN", "10 per minute")
    MAX_LOGIN_FAILURES = _int("SKVM_MAX_LOGIN_FAILURES", 8)
    LOGIN_LOCKOUT_SECONDS = _int("SKVM_LOGIN_LOCKOUT_SECONDS", 900)

    PASSWORD_MIN_LENGTH = _int("SKVM_PASSWORD_MIN_LENGTH", 10)
    ALLOW_REGISTRATION = _bool("SKVM_ALLOW_REGISTRATION", False)

    # ------------------------------------------------------------ storage
    DATA_DIR = _path("SKVM_DATA_DIR", "data")
    DB_PATH = _path("SKVM_DB_PATH", str(DATA_DIR / "skvm.db"))
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "SKVM_DATABASE_URI", f"sqlite:///{DB_PATH}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        # SQLite + background provisioning threads need a generous timeout.
        "connect_args": {"timeout": 30, "check_same_thread": False},
    }

    # Where root filesystems / instance state live.
    INSTANCES_DIR = _path("SKVM_INSTANCES_DIR", str(DATA_DIR / "instances"))
    IMAGES_DIR = _path("SKVM_IMAGES_DIR", str(DATA_DIR / "images"))
    BACKUP_DIR = _path("SKVM_BACKUP_DIR", str(DATA_DIR / "backups"))
    LOG_DIR = _path("SKVM_LOG_DIR", str(DATA_DIR / "logs"))
    RUN_DIR = _path("SKVM_RUN_DIR", str(DATA_DIR / "run"))
    TMP_DIR = _path("SKVM_TMP_DIR", str(DATA_DIR / "tmp"))
    CGROUP_ROOT = os.environ.get("SKVM_CGROUP_ROOT", "/sys/fs/cgroup/skvm")
    LXCFS_PATH = os.environ.get("SKVM_LXCFS_PATH", "/var/lib/lxcfs")

    LOG_LEVEL = os.environ.get("SKVM_LOG_LEVEL", "INFO")
    LOG_FORMAT = os.environ.get(
        "SKVM_LOG_FORMAT",
        "%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    )
    LOG_JSON = _bool("SKVM_LOG_JSON", True)
    LOG_MAX_BYTES = _int("SKVM_LOG_MAX_BYTES", 5 * 1024 * 1024)
    LOG_BACKUP_COUNT = _int("SKVM_LOG_BACKUP_COUNT", 5)

    # ------------------------------------------------------ provisioning
    # Comma separated priority list, e.g. "docker,lxc,namespace".
    PROVIDER_ORDER = [
        p.strip()
        for p in os.environ.get("SKVM_PROVIDERS", "docker,lxc,namespace").split(",")
        if p.strip()
    ]
    DEFAULT_PROVIDER = os.environ.get("SKVM_DEFAULT_PROVIDER", "auto")
    DOCKER_HOST = os.environ.get("DOCKER_HOST", "")
    DOCKER_SOCKET = os.environ.get("SKVM_DOCKER_SOCKET", "/var/run/docker.sock")
    LXC_PATH = os.environ.get("SKVM_LXC_PATH", "/var/lib/lxc")
    ALLOW_SUDO_HELPERS = _bool("SKVM_ALLOW_SUDO", True)

    OCI_REGISTRY = os.environ.get("SKVM_OCI_REGISTRY", "registry-1.docker.io")
    OCI_AUTH_HOST = os.environ.get("SKVM_OCI_AUTH_HOST", "auth.docker.io")
    OCI_PULL_TIMEOUT = _int("SKVM_OCI_TIMEOUT", 900)

    # Guard-rails against resource-limit bypass.
    MAX_VCPU = _int("SKVM_MAX_VCPU", 16)
    MAX_MEMORY_MB = _int("SKVM_MAX_MEMORY_MB", 32768)
    MAX_DISK_GB = _int("SKVM_MAX_DISK_GB", 200)
    MIN_MEMORY_MB = _int("SKVM_MIN_MEMORY_MB", 128)
    MIN_DISK_GB = _int("SKVM_MIN_DISK_GB", 1)
    MAX_INSTANCES_PER_USER = _int("SKVM_MAX_INSTANCES_PER_USER", 10)
    ALLOW_OVERCOMMIT = _bool("SKVM_ALLOW_OVERCOMMIT", True)

    TASK_POLL_SECONDS = _int("SKVM_TASK_POLL", 2)
    TASK_MAX_RETRIES = _int("SKVM_TASK_RETRIES", 2)
    TASK_TIMEOUT_SECONDS = _int("SKVM_TASK_TIMEOUT", 3600)
    CONSOLE_IDLE_TIMEOUT = _int("SKVM_CONSOLE_IDLE_TIMEOUT", 1800)
    CONSOLE_MAX_SESSIONS_PER_USER = _int("SKVM_CONSOLE_MAX_SESSIONS", 3)

    METRICS_CACHE_SECONDS = _int("SKVM_METRICS_CACHE", 3)
    BACKUP_MAX_MB = _int("SKVM_BACKUP_MAX_MB", 4096)

    JSON_SORT_KEYS = False
    TEMPLATES_AUTO_RELOAD = False

    @classmethod
    def ensure_dirs(cls) -> None:
        for path in (
            cls.DATA_DIR,
            cls.INSTANCES_DIR,
            cls.IMAGES_DIR,
            cls.BACKUP_DIR,
            cls.LOG_DIR,
            cls.RUN_DIR,
            cls.TMP_DIR,
            cls.DB_PATH.parent,
        ):
            Path(path).mkdir(parents=True, exist_ok=True)

    @classmethod
    def as_dict(cls) -> dict:
        """Non-secret view, safe to render in System Information."""
        return {
            "app_name": cls.APP_NAME,
            "version": cls.VERSION,
            "env": cls.ENV_NAME,
            "host": cls.HOST,
            "port": cls.PORT,
            "debug": cls.DEBUG,
            "data_dir": str(cls.DATA_DIR),
            "db_path": str(cls.DB_PATH),
            "instances_dir": str(cls.INSTANCES_DIR),
            "images_dir": str(cls.IMAGES_DIR),
            "backup_dir": str(cls.BACKUP_DIR),
            "log_dir": str(cls.LOG_DIR),
            "provider_order": cls.PROVIDER_ORDER,
            "default_provider": cls.DEFAULT_PROVIDER,
            "docker_socket": cls.DOCKER_SOCKET,
            "lxc_path": cls.LXC_PATH,
            "lxcfs_path": cls.LXCFS_PATH,
            "cgroup_root": cls.CGROUP_ROOT,
            "allow_sudo_helpers": cls.ALLOW_SUDO_HELPERS,
            "max_vcpu": cls.MAX_VCPU,
            "max_memory_mb": cls.MAX_MEMORY_MB,
            "max_disk_gb": cls.MAX_DISK_GB,
            "max_instances_per_user": cls.MAX_INSTANCES_PER_USER,
            "csrf": cls.WTF_CSRF_ENABLED,
            "ratelimit": cls.RATELIMIT_ENABLED,
            "registration_open": cls.ALLOW_REGISTRATION,
        }
