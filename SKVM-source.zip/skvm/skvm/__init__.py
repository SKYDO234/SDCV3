"""SKVM — a self-hosted VPS hosting panel.

The package is imported as ``skvm``; the application factory lives in
:mod:`skvm.app`.
"""
__version__ = "1.0.0"
APP_NAME = "SKVM"
