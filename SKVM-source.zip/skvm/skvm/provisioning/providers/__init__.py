"""Provider registry and selection."""
from __future__ import annotations

from .base import BaseProvider, CreateSpec, HostFacts, InstanceInfo, ProviderError
from .docker_provider import DockerProvider
from .lxc_provider import LXCProvider
from .namespace import NamespaceProvider

#: Declaration order == preference order when SKVM_DEFAULT_PROVIDER=auto.
PROVIDER_CLASSES: tuple[type[BaseProvider], ...] = (
    DockerProvider,
    LXCProvider,
    NamespaceProvider,
)

PROVIDERS_BY_NAME = {cls.name: cls for cls in PROVIDER_CLASSES}

__all__ = [
    "BaseProvider", "CreateSpec", "InstanceInfo", "ProviderError", "HostFacts",
    "DockerProvider", "LXCProvider", "NamespaceProvider",
    "PROVIDER_CLASSES", "PROVIDERS_BY_NAME",
    "build_provider_descriptors", "get_provider_class", "resolve_provider",
]


def build_provider_descriptors(caps: dict) -> list[dict]:
    """Capability descriptors for every provider, derived from the real probe."""
    return [cls.descriptor(caps) for cls in PROVIDER_CLASSES]


def get_provider_class(name: str) -> type[BaseProvider] | None:
    return PROVIDERS_BY_NAME.get(name)


def resolve_provider(config, profile, preferred: str = "auto", logger=None):
    """
    Pick the provider to use.

    Returns ``(provider_instance | None, diagnostics)``.  When nothing is
    available the diagnostics explain exactly why, so the UI can say the truth
    instead of failing silently.
    """
    diagnostics: list[dict] = []
    # `config` may be a Flask config mapping or the plain Config class.
    raw_order = (config["PROVIDER_ORDER"] if hasattr(config, "__getitem__")
                 else getattr(config, "PROVIDER_ORDER", None))
    order = list(raw_order or ("docker", "lxc", "namespace"))
    if preferred and preferred != "auto":
        order = [preferred] + [p for p in order if p != preferred]

    candidates = []
    for name in order:
        cls = PROVIDERS_BY_NAME.get(name)
        if cls is None:
            diagnostics.append({"name": name, "available": False,
                                "reason": "unknown provider"})
            continue
        try:
            provider = cls(config, profile, logger)
            available = provider.is_available()
        except Exception as exc:  # noqa: BLE001
            diagnostics.append({"name": name, "available": False,
                                "reason": f"{type(exc).__name__}: {exc}"})
            continue
        desc = cls.descriptor(profile.caps)
        diagnostics.append({
            "name": name, "label": desc["label"], "kind": desc["kind"],
            "available": available, "reason": desc.get("reason", ""),
            "remedy": desc.get("remedy", ""), "limitations": desc.get("limitations", []),
        })
        if available:
            candidates.append(provider)

    if not candidates:
        return None, diagnostics
    return candidates[0], diagnostics
