"""
Namespace provider — SKVM's built-in container runtime.

This is a genuine isolation backend, not a simulation.  Each instance gets:

  * a private **mount namespace** (own /proc, tmpfs /dev, /run, /tmp, devpts,
    read-only /sys) created by ``helpers/ns-launch``;
  * its own **PID namespace** (the instance cannot see host processes) with the
    supervisor as PID 1's parent;
  * its own **UTS namespace** (real hostname), **IPC namespace**;
  * a **user namespace** when running unprivileged;
  * a **network namespace** with a veth pair, a real IPv4 address, a default
    route and NAT egress — when the host permits it (verified, never assumed);
  * **cgroup v2** memory/cpu/pids limits when the hierarchy is writable, plus
    POSIX rlimits as a kernel-enforced floor in every case.

The root filesystem is materialised from real upstream OCI layers, so the
Ubuntu 20.04/22.04 and Debian 11/12 images are the genuine distributions.

Honesty rule: this provider creates *unprivileged/system containers*.  It never
reports an instance as a virtual machine, and it never reports running when the
supervisor is not actually alive.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import socket
import time
from pathlib import Path

from ..detect import is_admin, probe_sudo, run_privileged
from ..oci import RegistryClient, RegistryError
from ..runtime import (
    cgroup_destroy, cgroup_setup, cgroup_stats, helper_du, helper_json,
    helper_mkdir, helper_rm, helper_write_file, kill_tree, launch_namespace_container,
    netns_destroy, netns_setup, netns_stats, process_alive, read_state,
)
from .base import BaseProvider, CreateSpec, HostFacts, InstanceInfo, ProviderError

#: Where instances get their private IPv4 space.  Each instance receives a /30.
NET_POOL_PREFIX = "10.89"
NET_POOL_SECOND_MAX = 250
NET_POOL_THIRD_MAX = 250


class NamespaceProvider(BaseProvider):
    name = "namespace"
    kind = "container_namespace"
    label = "Namespace container (unprivileged)"

    # ------------------------------------------------------------------ desc
    @classmethod
    def descriptor(cls, caps: dict) -> dict:
        ns = caps.get("namespaces")
        priv = caps.get("privileges")
        netns = caps.get("netns")
        cg = caps.get("cgroups")
        ovl = caps.get("overlayfs")

        if ns is None or not ns.available:
            return {
                "name": cls.name,
                "label": cls.label,
                "kind": cls.kind,
                "available": False,
                "reason": (ns.reason if ns else "namespace support was not probed"),
                "remedy": (ns.remedy if ns else
                           "Linux user/PID/mount namespaces are required."),
                "limitations": [],
                "enforcement": [],
                "network": "none",
            }

        limitations = []
        if netns is None or not netns.available:
            limitations.append(
                "Instances share the host network namespace: a dedicated IP "
                "address cannot be assigned here."
            )
        if cg is None or not cg.available:
            limitations.append(
                "cgroup limits are read-only here — memory/CPU caps fall back to "
                "kernel-enforced rlimits (address space, CPU time, process count)."
            )
        if priv is not None and not priv.available:
            limitations.append(
                "Running unprivileged: mounts of /dev, /sys and devpts are "
                "best-effort inside the user namespace."
            )
        if ovl is None or not ovl.available:
            limitations.append(
                "No overlayfs: each instance keeps its own full copy of the "
                "root filesystem (slower provisioning, more disk)."
            )

        enforcement = []
        if ns.available:
            enforcement.append("Linux namespaces (PID, mount, UTS, IPC"
                               + (", network" if netns and netns.available else "")
                               + (", user" if priv and not priv.available else "") + ")")
        if cg is not None and cg.available:
            enforcement.append("cgroup v2 memory.max / cpu.max / pids.max")
        else:
            enforcement.append("POSIX rlimits (RLIMIT_AS, RLIMIT_CPU, RLIMIT_NPROC)")

        return {
            "name": cls.name,
            "label": cls.label,
            "kind": cls.kind,
            "available": True,
            "reason": "",
            "remedy": "",
            "limitations": limitations,
            "enforcement": enforcement,
            "network": ("veth + dedicated network namespace"
                        if netns and netns.available else "host network (shared)"),
        }

    # ----------------------------------------------------------------- state
    def is_available(self) -> bool:
        return bool(self.profile.available("namespaces"))

    def _state_file(self, instance) -> Path:
        return self.instance_dir(instance) / "state.json"

    def _log_file(self, instance) -> Path:
        return self.instance_dir(instance) / "runtime.log"

    def _meta_file(self, instance) -> Path:
        return self.instance_dir(instance) / "meta.json"

    def _rootfs(self, instance) -> Path:
        return self.instance_dir(instance) / "rootfs"

    def _cgroup_name(self, instance) -> str:
        return f"skvm-{instance.instance_id}"

    def _netns_name(self, instance) -> str:
        return f"skvm-{instance.instance_id}"[:63]

    def _veth_names(self, instance) -> tuple[str, str]:
        tail = instance.instance_id[-10:].lower().replace("_", "-")
        return f"vh{tail}"[:15], f"vc{tail}"[:15]

    # ------------------------------------------------------------- image ops
    def image_dir(self, slug: str) -> Path:
        return Path(self.config["IMAGES_DIR"]) / slug

    def image_ready(self, slug: str) -> bool:
        meta = self.image_dir(slug) / "meta.json"
        layers = self.image_dir(slug) / "layers"
        if not meta.exists():
            return False
        try:
            data = json.loads(meta.read_text())
        except (OSError, ValueError):
            return False
        expected = len(data.get("layers") or [])
        if expected == 0:
            return False
        have = [p for p in layers.glob("*") if p.suffix in (".gz", ".tar")]
        return len(have) >= expected

    def image_meta(self, slug: str) -> dict:
        try:
            return json.loads((self.image_dir(slug) / "meta.json").read_text())
        except (OSError, ValueError):
            return {}

    def pull_image(self, image: dict, progress) -> dict:
        """Download (and cache) every layer of an image.  Real network pull."""
        slug = image.get("slug") or image.get("name")
        reference = image.get("reference")
        if not reference:
            raise ProviderError("image has no registry reference", stage="pull")
        workdir = self.image_dir(slug)
        workdir.mkdir(parents=True, exist_ok=True)
        (workdir / "layers").mkdir(exist_ok=True)
        client = RegistryClient(
            registry=image.get("registry") or self.config["OCI_REGISTRY"],
            timeout=self.config["OCI_PULL_TIMEOUT"],
        )
        progress(f"pulling {reference} from {client.registry}", 5)
        try:
            result = client.fetch_image(
                reference, workdir,
                progress=lambda m: progress(m),
                allow_apply=False,
            )
        except RegistryError as exc:
            raise ProviderError(str(exc), stage="pull", retryable=True) from exc

        # Drop any previously applied rootfs at the image level (instances hold
        # their own copies).
        meta = {
            "reference": result["reference"],
            "friendly": result["friendly"],
            "digest": result["digest"],
            "platform": result["platform"],
            "config": result["config"],
            "total_bytes": result["total_bytes"],
            "layers": [{"index": l["index"], "digest": l["digest"],
                        "size": l["size"], "file": l["file"],
                        "media_type": l["media_type"]} for l in result["layers"]],
            "pulled_at": time.time(),
            "pulled_at_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        (workdir / "meta.json").write_text(json.dumps(meta, indent=2))
        progress(f"cached {len(meta['layers'])} layer(s) for {slug}", 100)
        return meta

    def materialize_rootfs(self, slug: str, rootfs: Path, progress) -> dict:
        """Apply cached layers into a fresh rootfs directory (as root)."""
        meta = self.image_meta(slug)
        if not meta:
            raise ProviderError(
                f"image '{slug}' has not been downloaded yet — pull it first",
                stage="image",
            )
        rootfs.mkdir(parents=True, exist_ok=True)
        created = helper_mkdir(rootfs, mode="0755")
        if not created.get("ok"):
            raise ProviderError(
                f"cannot create {rootfs}: {created.get('error')}",
                stage="image", retryable=True,
            )
        layers = sorted(meta.get("layers") or [], key=lambda l: l.get("index", 0))
        applied = 0
        for idx, layer in enumerate(layers, 1):
            archive = Path(layer["file"])
            if not archive.exists():
                raise ProviderError(
                    f"cached layer missing: {archive.name} — re-pull the image",
                    stage="image", retryable=True,
                )
            pct = int(idx / max(len(layers), 1) * 100)
            progress(f"applying layer {idx}/{len(layers)} ({archive.name})", pct)
            rc, out, err = self._apply(archive, rootfs)
            if rc != 0:
                raise ProviderError(
                    f"layer {idx} failed to apply: {(err or out)[:300]}",
                    stage="image", retryable=True,
                )
            applied += 1
        progress(f"rootfs materialised at {rootfs} ({applied} layers)", 100)
        return {"layers_applied": applied, "rootfs": str(rootfs),
                "image": meta.get("friendly"), "digest": meta.get("digest")}

    def _apply(self, archive: Path, rootfs: Path):
        from ..runtime import helper_apply_layer

        return helper_apply_layer(archive, rootfs, timeout=900)

    def image_size(self, slug: str) -> int:
        total = 0
        for p in (self.image_dir(slug) / "layers").glob("*"):
            try:
                total += p.stat().st_size
            except OSError:
                continue
        return total

    # ---------------------------------------------------------------- network
    def allocate_address(self, instance, used: set[str]) -> tuple[str, str]:
        """Pick a free /30 from the pool, deterministically per instance."""
        seed = int(hashlib.sha256(instance.instance_id.encode()).hexdigest(), 16)
        third = seed % NET_POOL_THIRD_MAX
        for offset in range(NET_POOL_THIRD_MAX):
            slot = (third + offset) % NET_POOL_THIRD_MAX
            for second in range(NET_POOL_SECOND_MAX):
                gateway = f"{NET_POOL_PREFIX}.{second}.{slot * 4 % 256}"
                if (slot * 4) // 256:
                    continue
                base = f"{NET_POOL_PREFIX}.{second}.{slot}"
                gw = f"{NET_POOL_PREFIX}.{second}.{slot * 4 + 1}"
                ip = f"{NET_POOL_PREFIX}.{second}.{slot * 4 + 2}"
                # /30 blocks are spaced 4 apart inside the third octet
                if slot * 4 + 3 > 255:
                    continue
                if gw in used or ip in used:
                    continue
                return ip, gw
        raise ProviderError(
            "the internal address pool is exhausted", stage="network"
        )

    def _resolv_conf(self) -> str:
        try:
            content = Path("/etc/resolv.conf").read_text()
            if "nameserver" in content:
                return content if content.endswith("\n") else content + "\n"
        except OSError:
            pass
        return "nameserver 1.1.1.1\nnameserver 8.8.8.8\n"

    def _prepare_rootfs(self, instance, spec: CreateSpec, progress) -> dict:
        """Write identity/network files into the instance rootfs (as root)."""
        rootfs = self._rootfs(instance)
        notes = []
        files = {
            "etc/hostname": f"{spec.hostname}\n",
            "etc/hosts": (
                "127.0.0.1\tlocalhost\n"
                "127.0.1.1\t" + spec.hostname + "\n"
                "::1\tlocalhost ip6-localhost ip6-loopback\n"
            ),
            "etc/resolv.conf": self._resolv_conf(),
            "etc/skvm-release": (
                f"SKVM instance {instance.instance_id}\n"
                f"name: {spec.name}\n"
                f"container: {self.kind}\n"
                f"image: {spec.image_reference}\n"
                f"created: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n"
            ),
            "etc/machine-id": hashlib.md5(
                instance.instance_id.encode()).hexdigest() + "\n",
        }
        for rel, content in files.items():
            target = rootfs / rel
            result = helper_write_file(target, content, mode="0644")
            if not result.get("ok"):
                notes.append(f"could not write /{rel}: {result.get('error')}")
        # A first-run MOTD so the console shows where it is (no fake data).
        motd = (
            "\n  SKVM instance: " + spec.name + "\n"
            "  Isolation: Linux namespaces (container, not a KVM virtual machine)\n"
            "  Type 'apt-get update' or drop files in the File Manager to begin.\n\n"
        )
        helper_write_file(rootfs / "etc/motd", motd, mode="0644")
        return {"notes": notes}

    # ------------------------------------------------------------------ create
    def preflight(self, spec: CreateSpec) -> tuple[bool, str]:
        if not self.is_available():
            return False, (
                "Linux namespaces are unavailable on this host, so the "
                "namespace provider cannot run an instance."
            )
        slug = spec.image.get("slug")
        if not slug:
            return False, "no operating system image was selected"
        if not self.image_ready(slug):
            # Not fatal: the create task pulls the image first.  But the
            # registry must be reachable.
            if not self.profile.available("registry"):
                cap = self.profile.cap("registry")
                return False, (
                    "the image has not been downloaded and the container "
                    f"registry is unreachable ({(cap.reason if cap else 'unknown')})"
                )
        return True, ""

    def create(self, instance, spec: CreateSpec, progress) -> InstanceInfo:
        inst_dir = self.instance_dir(instance)
        rootfs = self._rootfs(instance)
        runtime_notes: list[str] = []

        progress("preparing instance directory", 2)
        inst_dir.mkdir(parents=True, exist_ok=True)
        (inst_dir / "logs").mkdir(exist_ok=True)

        # 1) root filesystem from real upstream layers
        slug = spec.image["slug"]
        if not self.image_ready(slug):
            self.pull_image(spec.image, progress)
        else:
            progress(f"using cached image {slug} "
                     f"({self.image_size(slug) / 1048576:.1f} MiB)", 5)

        progress("materialising root filesystem", 20)
        info = self.materialize_rootfs(slug, rootfs, progress)

        progress("writing instance identity and network configuration", 45)
        prep = self._prepare_rootfs(instance, spec, progress)
        runtime_notes.extend(prep["notes"])

        # 2) cgroup limits
        memory_mb = spec.memory_mb
        disk_bps = max(5, spec.disk_gb) * 1024 * 1024  # ~5 MB/s per GiB, floor
        cgroup_path = ""
        if self.profile.available("cgroups"):
            cg = cgroup_setup(
                self._cgroup_name(instance), memory_mb=memory_mb, vcpu=spec.vcpu,
                pids=512, disk_bps=disk_bps,
            )
            if cg.get("ok"):
                cgroup_path = cg.get("cgroup", "")
                progress(f"cgroup limits applied: {', '.join(cg.get('applied', {}).keys())}"
                         or "cgroup created", 55)
                if cg.get("failed"):
                    runtime_notes.append(
                        "cgroup values that could not be set: "
                        + ", ".join(cg["failed"])
                    )
            else:
                runtime_notes.append(
                    f"cgroup setup failed ({cg.get('error')}); falling back to rlimits"
                )
        else:
            runtime_notes.append(
                "cgroup v2 is not writable here — using POSIX rlimits instead"
            )

        # 3) network namespace with a real address
        netns = ""
        internal_ip = ""
        gateway = ""
        if spec.want_networking and self.profile.available("netns"):
            host_veth, ctr_veth = self._veth_names(instance)
            used = self._used_addresses()
            try:
                ip, gateway = self.allocate_address(instance, used)
            except ProviderError as exc:
                runtime_notes.append(str(exc))
                ip = gateway = ""
            if ip:
                progress(f"creating network namespace {self._netns_name(instance)}", 62)
                result = netns_setup(
                    self._netns_name(instance), host_veth, ctr_veth, ip, gateway,
                    prefix=30, nat=True,
                )
                if result.get("ok"):
                    netns = self._netns_name(instance)
                    internal_ip = ip
                    if not result.get("nat"):
                        runtime_notes.append(
                            "veth is up but NAT could not be installed: the "
                            "instance can reach the host gateway only."
                        )
                    progress(f"instance address {ip}/30 via {host_veth}", 66)
                else:
                    runtime_notes.append(
                        f"network namespace setup failed: {result.get('error')}"
                    )
                    netns_setup(self._netns_name(instance), host_veth, ctr_veth,
                                ip, gateway, prefix=30, nat=False)
        elif spec.want_networking:
            cap = self.profile.cap("netns")
            runtime_notes.append(
                "no dedicated network namespace on this host — the instance "
                f"shares the host network ({(cap.reason if cap else 'unavailable')})"
            )

        # 4) choose the init process that actually exists inside the rootfs
        init_cmd = spec.init_command or self._default_init(rootfs, progress)

        # 5) launch
        progress(f"starting supervisor (init: {init_cmd})", 72)
        launched = launch_namespace_container(
            rootfs=rootfs,
            name=self._cgroup_name(instance),
            hostname=spec.hostname,
            state_file=self._state_file(instance),
            log_file=self._log_file(instance),
            init_cmd=init_cmd,
            netns=netns,
            cgroup_path=cgroup_path,
            memory_mb=memory_mb,
            vcpu=spec.vcpu,
            pids=512,
            fsize_gb=max(1, spec.disk_gb),
            unprivileged=not self.profile.available("privileges"),
        )
        if not launched.get("ok"):
            self._cleanup_network(instance)
            raise ProviderError(
                f"could not start the instance supervisor: {launched.get('error')}",
                stage="start", retryable=True,
            )

        # 6) verify it is really up
        progress("waiting for the instance to report ready", 85)
        ok, detail = self._wait_ready(instance, timeout=45)
        if not ok:
            log_tail = self._log_tail(instance)
            self._cleanup_network(instance)
            raise ProviderError(
                f"the instance did not reach a running state: {detail}",
                stage="start", retryable=True,
                detail=log_tail,
            )

        state = read_state(self._state_file(instance))
        (self._meta_file(instance)).write_text(json.dumps({
            "spec": {
                "vcpu": spec.vcpu, "memory_mb": spec.memory_mb,
                "disk_gb": spec.disk_gb, "hostname": spec.hostname,
                "image": spec.image_reference, "owner": spec.owner_username,
            },
            "runtime": {
                "kind": self.kind,
                "init_command": init_cmd,
                "netns": netns or None,
                "cgroup": cgroup_path or None,
                "internal_ip": internal_ip or None,
                "gateway": gateway or None,
                "supervisor_pid": launched.get("supervisor_pid"),
                "init_pid": state.get("init_pid"),
            },
            "notes": runtime_notes,
            "is_virtual_machine": False,
            "created_at": time.time(),
        }, indent=2))

        for note in runtime_notes:
            progress(f"note: {note}")
        progress(f"instance {spec.name} is running", 100)

        return InstanceInfo(
            runtime_id=str(state.get("init_pid") or launched.get("supervisor_pid") or ""),
            status="running",
            detail="; ".join(runtime_notes) if runtime_notes else "running",
            internal_ip=internal_ip,
            pid=state.get("init_pid"),
            boot_time=state.get("started_at"),
            extra={"layers_applied": info.get("layers_applied"),
                   "init_command": init_cmd,
                   "supervisor_pid": launched.get("supervisor_pid"),
                   "notes": runtime_notes},
        )

    #: keepalive used when the image ships no usable init system.  PID 1 must
    #: never exit, so a shell loop is the honest default for a container that
    #: shares the host kernel and often has no init installed at all.
    KEEPALIVE = "while :; do sleep 3600; done"

    def _default_init(self, rootfs: Path, progress) -> str:
        """
        Choose the process that becomes PID 1 inside the instance.

        Order of preference, each verified against the real root filesystem:

        1. an init system that is actually configured (``/etc/inittab``'s first
           program or ``systemd``), because then it really is the instance's init;
        2. a shell keepalive loop — deterministic and always available;
        3. ``sleep`` as a last resort.

        A bare ``/sbin/init`` is *not* used on its own: in minimal images it is
        BusyBox's init, which immediately exits when its inittab points at a
        program the image does not contain (Alpine's inittab runs OpenRC).
        """
        if self._init_is_configured(rootfs):
            progress("init process: /sbin/init (init system detected)")
            return "/sbin/init"

        for shell in ("bin/sh", "usr/bin/sh", "bin/bash", "usr/bin/bash"):
            if (rootfs / shell).exists():
                cmd = f"/{shell} -c '{self.KEEPALIVE}'"
                progress(f"init process: {cmd}")
                return cmd

        for sleep_bin in ("bin/sleep", "usr/bin/sleep"):
            if (rootfs / sleep_bin).exists():
                cmd = f"/{sleep_bin} 2147483647"
                progress(f"init process: {cmd}")
                return cmd

        raise ProviderError(
            "the image contains no usable init process (no shell or sleep "
            "binary), so an instance cannot be kept alive. Use an image that "
            "ships /bin/sh (Alpine, Debian, Ubuntu all do).",
            stage="image",
        )

    def _init_is_configured(self, rootfs: Path) -> bool:
        """Is there an init system whose first configured program exists?"""
        if not (rootfs / "sbin/init").exists():
            return False
        inittab = rootfs / "etc/inittab"
        if inittab.exists():
            try:
                for line in inittab.read_text(errors="replace").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split(":")
                    if len(parts) < 4:
                        continue          # e.g. "id:2:initdefault:"
                    program = parts[3].strip().split()[0] if parts[3].strip() else ""
                    if not program:
                        continue
                    program = program.lstrip("/")
                    # The *first* program the init runs decides whether it
                    # survives: Alpine's inittab starts OpenRC, which its base
                    # image does not ship, so /sbin/init exits immediately.
                    return (rootfs / program).exists()
            except OSError:
                return False
            return False
        # No inittab: only trust systemd if its binary is really there.
        return (rootfs / "lib/systemd/systemd").exists() or \
            (rootfs / "usr/lib/systemd/systemd").exists()

    def _used_addresses(self) -> set[str]:
        used: set[str] = set()
        try:
            proc = run_privileged(["ip", "-o", "addr", "show"], timeout=15)
            if proc[0] == 0:
                import re

                used.update(re.findall(r"inet (\d+\.\d+\.\d+\.\d+)", proc[1]))
        except Exception:
            pass
        return used

    def _wait_ready(self, instance, timeout: int = 45) -> tuple[bool, str]:
        state_file = self._state_file(instance)
        deadline = time.time() + timeout
        last: dict = {}
        while time.time() < deadline:
            last = read_state(state_file)
            status = last.get("status")
            if status == "running" and process_alive(last.get("init_pid")):
                return True, "running"
            if status in ("stopped", "error"):
                return False, (last.get("error") or "init exited during startup")
            time.sleep(0.4)
        return False, (last.get("error") or
                       f"no running state recorded within {timeout}s")

    def _log_tail(self, instance, lines: int = 25) -> str:
        try:
            content = self._log_file(instance).read_text(errors="replace")
        except OSError:
            return ""
        return "\n".join(content.splitlines()[-lines:])

    # ------------------------------------------------------------- lifecycle
    def inspect(self, instance) -> InstanceInfo:
        state = read_state(self._state_file(instance))
        init_pid = state.get("init_pid")
        supervisor = state.get("supervisor_pid")
        alive = process_alive(init_pid)
        sup_alive = process_alive(supervisor)

        if not state:
            return InstanceInfo(status="stopped",
                                detail="no runtime state on disk")
        if state.get("status") == "running" and alive:
            boot = state.get("started_at")
            return InstanceInfo(
                runtime_id=str(init_pid), status="running",
                detail="supervisor and init are alive",
                internal_ip=(state.get("internal_ip") or ""),
                pid=init_pid, boot_time=boot,
                extra={"supervisor_pid": supervisor, "netns": state.get("netns"),
                       "cgroup": state.get("cgroup"),
                       "rootfs": state.get("rootfs")},
            )
        if state.get("status") == "running" and not alive:
            return InstanceInfo(
                runtime_id=str(init_pid or ""), status="stopped",
                detail=("the init process is gone but the state file still says "
                        "running — reconciled as stopped"),
                extra={"reconciled": True},
            )
        code = state.get("exit_code")
        return InstanceInfo(
            runtime_id=str(init_pid or ""),
            status="stopped",
            detail=(f"init exited with status {code}" if code is not None
                    else "instance is not running"),
        )

    def stop(self, instance, progress, force: bool = False) -> InstanceInfo:
        state = read_state(self._state_file(instance))
        supervisor = state.get("supervisor_pid")
        init_pid = state.get("init_pid")
        progress("stopping instance supervisor")
        if supervisor and process_alive(supervisor):
            result = kill_tree(supervisor, "TERM")
            progress(f"sent SIGTERM to supervisor {supervisor}")
            deadline = time.time() + 20
            while time.time() < deadline and process_alive(supervisor):
                time.sleep(0.3)
            if process_alive(supervisor):
                progress("supervisor did not exit; sending SIGKILL")
                kill_tree(supervisor, "KILL")
        if init_pid and process_alive(init_pid):
            kill_tree(init_pid, "KILL" if force else "TERM")
            time.sleep(0.3)
        # Reap anything still inside the cgroup.
        if self.profile.available("cgroups"):
            cgroup_destroy(self._cgroup_name(instance))
        self._cleanup_network(instance)
        # Persist the stopped state so a panel restart shows the truth.
        try:
            payload = read_state(self._state_file(instance)) or {}
            payload.update({"status": "stopped",
                            "stopped_at": time.time(),
                            "stopped_at_iso": time.strftime(
                                "%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
            payload.pop("init_pid", None)
            self._state_file(instance).write_text(json.dumps(payload, indent=2))
        except OSError as exc:
            progress(f"warning: could not persist stopped state ({exc})")
        progress("instance stopped")
        return InstanceInfo(status="stopped", detail="stopped by request")

    def start(self, instance, progress) -> InstanceInfo:
        state = read_state(self._state_file(instance))
        if state.get("status") == "running" and process_alive(state.get("init_pid")):
            progress("instance is already running")
            return self.inspect(instance)

        rootfs = self._rootfs(instance)
        if not rootfs.is_dir():
            raise ProviderError(
                "the instance root filesystem is missing — rebuild the instance",
                stage="start",
            )
        meta = {}
        try:
            meta = json.loads(self._meta_file(instance).read_text())
        except (OSError, ValueError):
            pass
        runtime = meta.get("runtime", {})
        spec_meta = meta.get("spec", {})
        memory_mb = int(spec_meta.get("memory_mb") or instance.memory_mb or 1024)
        vcpu = int(spec_meta.get("vcpu") or instance.vcpu or 1)
        disk_gb = int(spec_meta.get("disk_gb") or instance.disk_gb or 5)
        hostname = spec_meta.get("hostname") or instance.hostname

        # Re-create the pieces that do not survive a stop.
        cgroup_path = ""
        if self.profile.available("cgroups"):
            cg = cgroup_setup(self._cgroup_name(instance), memory_mb=memory_mb,
                              vcpu=vcpu, pids=512,
                              disk_bps=max(5, disk_gb) * 1024 * 1024)
            if cg.get("ok"):
                cgroup_path = cg.get("cgroup", "")
            else:
                progress(f"cgroup could not be created ({cg.get('error')}); "
                         "rlimits only")

        netns = ""
        internal_ip = ""
        if self.profile.available("netns"):
            host_veth, ctr_veth = self._veth_names(instance)
            used = self._used_addresses()
            ip = runtime.get("internal_ip") or ""
            gateway = runtime.get("gateway") or ""
            if not ip:
                try:
                    ip, gateway = self.allocate_address(instance, used)
                except ProviderError:
                    ip = gateway = ""
            if ip:
                progress(f"re-creating network namespace with address {ip}")
                result = netns_setup(self._netns_name(instance), host_veth,
                                     ctr_veth, ip, gateway, prefix=30, nat=True)
                if result.get("ok"):
                    netns = self._netns_name(instance)
                    internal_ip = ip
                else:
                    progress(f"network namespace failed: {result.get('error')}")

        init_cmd = runtime.get("init_command") or self._default_init(rootfs, progress)
        progress("starting instance supervisor")
        launched = launch_namespace_container(
            rootfs=rootfs, name=self._cgroup_name(instance), hostname=hostname,
            state_file=self._state_file(instance),
            log_file=self._log_file(instance), init_cmd=init_cmd,
            netns=netns, cgroup_path=cgroup_path, memory_mb=memory_mb,
            vcpu=vcpu, pids=512, fsize_gb=max(1, disk_gb),
            unprivileged=not self.profile.available("privileges"),
        )
        if not launched.get("ok"):
            self._cleanup_network(instance)
            raise ProviderError(
                f"could not start: {launched.get('error')}", stage="start",
                retryable=True,
            )
        ok, detail = self._wait_ready(instance, timeout=45)
        if not ok:
            self._cleanup_network(instance)
            raise ProviderError(f"instance failed to start: {detail}",
                                stage="start", retryable=True,
                                detail=self._log_tail(instance))
        state = read_state(self._state_file(instance))
        progress("instance started")
        return InstanceInfo(runtime_id=str(state.get("init_pid", "")),
                            status="running", internal_ip=internal_ip,
                            pid=state.get("init_pid"),
                            boot_time=state.get("started_at"))

    def restart(self, instance, progress) -> InstanceInfo:
        self.stop(instance, progress)
        time.sleep(0.4)
        return self.start(instance, progress)

    def rebuild(self, instance, spec: CreateSpec, progress) -> InstanceInfo:
        """Wipe and re-materialise the rootfs from the (possibly new) image."""
        was_running = self.inspect(instance).status == "running"
        if was_running:
            self.stop(instance, progress)
        rootfs = self._rootfs(instance)
        backup = rootfs.with_name("rootfs.old")
        progress("archiving the current root filesystem")
        removed = helper_rm(backup, recursive=True)
        if rootfs.exists():
            try:
                if backup.exists():
                    helper_rm(backup, recursive=True)
                os.rename(rootfs, backup)
            except OSError as exc:
                progress(f"could not move aside the old rootfs ({exc}); removing it")
                result = helper_rm(rootfs, recursive=True)
                if not result.get("ok"):
                    raise ProviderError(
                        f"cannot clear the old root filesystem: {result.get('error')}",
                        stage="rebuild",
                    )
        progress("rebuilding from image")
        result = self.create(instance, spec, progress)
        helper_rm(backup, recursive=True)
        return result

    def destroy(self, instance, progress) -> None:
        progress("destroying instance")
        try:
            state = read_state(self._state_file(instance))
            if state.get("status") == "running":
                self.stop(instance, progress)
        except Exception as exc:  # noqa: BLE001 - cleanup must be best effort
            progress(f"stop during destroy reported: {exc}")
        if self.profile.available("cgroups"):
            cgroup_destroy(self._cgroup_name(instance))
        self._cleanup_network(instance)
        inst_dir = self.instance_dir(instance)
        if inst_dir.exists():
            result = helper_rm(inst_dir, recursive=True)
            if not result.get("ok"):
                progress(f"warning: {result.get('error')}")
            else:
                progress(f"removed {inst_dir}")
        progress("instance destroyed")

    def _cleanup_network(self, instance) -> None:
        if not self.profile.available("netns"):
            return
        host_veth, _ = self._veth_names(instance)
        try:
            netns_destroy(self._netns_name(instance), host_veth)
        except Exception:
            pass

    # ---------------------------------------------------------------- metrics
    def metrics(self, instance) -> dict:
        info = self.inspect(instance)
        if info.status != "running":
            return {"available": False, "reason": f"instance is {info.status}",
                    "status": info.status}
        out: dict = {
            "available": True,
            "source": [],
            "status": "running",
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        memory_mb = int(instance.memory_mb or 1024)
        vcpu = int(instance.vcpu or 1)

        # --- process-level truth (always available)
        pid = info.pid
        proc_stats = self._proc_metrics(pid)
        if proc_stats:
            out["source"].append("process accounting")
            out.update(proc_stats)
            out["process"] = {"pid": pid, "processes": proc_stats.get("processes")}

        # --- cgroup truth (authoritative when present)
        cg = cgroup_stats(self._cgroup_name(instance))
        if cg.get("ok") and cg.get("exists"):
            out["source"].append("cgroup v2")
            out["cgroup"] = {
                "path": cg.get("cgroup"),
                "memory_bytes": cg.get("memory_bytes"),
                "memory_limit_bytes": cg.get("memory_limit_bytes"),
                "pids": cg.get("pids_current"),
                "pids_limit": cg.get("pids_max"),
                "procs": cg.get("procs"),
                "stats": cg.get("memory_cgroup", {}),
                "cpu": cg.get("cpu_cgroup", {}),
                "io": cg.get("io", {}),
            }
            limit_bytes = cg.get("memory_limit_bytes") or memory_mb * 1048576
            used = cg.get("memory_bytes") or 0
            out["memory"] = {
                "used_mb": round(used / 1048576, 1),
                "limit_mb": round(limit_bytes / 1048576, 1),
                "percent": round(used / limit_bytes * 100, 1) if limit_bytes else 0.0,
                "swap_used_mb": 0.0,
            }
            cpu_stat = cg.get("cpu_cgroup") or {}
            usage_usec = cpu_stat.get("usage_usec")
            if usage_usec is not None:
                out["cpu_usage_usec_total"] = usage_usec
                out.setdefault("cpu", {})["cgroup_usage_usec"] = usage_usec
            throttled = cpu_stat.get("nr_throttled", 0)
            periods = cpu_stat.get("nr_periods", 0)
            if periods:
                out.setdefault("cpu", {})["throttled_percent"] = round(
                    throttled / periods * 100, 1)

        # --- network truth
        if self.profile.available("netns"):
            ns = netns_stats(self._netns_name(instance))
            if ns.get("ok") and ns.get("exists"):
                out.setdefault("source", []).append("network namespace counters")
                out["network"] = {
                    "addresses": ns.get("addresses", []),
                    "rx_bytes": ns.get("rx_bytes", 0),
                    "tx_bytes": ns.get("tx_bytes", 0),
                    "rx_mb": round((ns.get("rx_bytes") or 0) / 1048576, 2),
                    "tx_mb": round((ns.get("tx_bytes") or 0) / 1048576, 2),
                    "rx_rate_kbps": self._rate("rx", instance.instance_id,
                                               ns.get("rx_bytes") or 0),
                    "tx_rate_kbps": self._rate("tx", instance.instance_id,
                                               ns.get("tx_bytes") or 0),
                }

        # --- disk truth (rootfs usage)
        du = helper_du(self._rootfs(instance))
        if du.get("ok"):
            out["source"].append("filesystem accounting")
            used_mb = round((du.get("actual_bytes") or 0) / 1048576, 1)
            limit_gb = int(instance.disk_gb or 0)
            out["disk"] = {
                "used_mb": used_mb,
                "limit_mb": limit_gb * 1024,
                "percent": round(used_mb / (limit_gb * 1024) * 100, 1) if limit_gb else 0.0,
                "files": du.get("files"),
            }

        if "cpu" not in out:
            out["cpu"] = {}
        out["cpu"].setdefault("limit_vcpu", vcpu)
        out["memory"] = out.get("memory") or {
            "used_mb": None, "limit_mb": memory_mb, "percent": None,
            "reason": "no cgroup accounting available",
        }
        return out

    def _proc_metrics(self, pid: int | None) -> dict:
        """CPU% and RSS of the instance's process tree, measured over an interval."""
        if not pid:
            return {}
        try:
            import psutil

            root = psutil.Process(int(pid))
            procs = [root] + root.children(recursive=True)
            first = {}
            for p in procs:
                try:
                    first[p.pid] = p.cpu_times()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            time.sleep(0.35)
            cpu_percent = 0.0
            rss = 0
            threads = 0
            live = 0
            for p in procs:
                try:
                    t2 = p.cpu_times()
                    t1 = first.get(p.pid)
                    if t1:
                        cpu_percent += ((t2.user + t2.system) - (t1.user + t1.system))
                    mem = p.memory_info()
                    rss += mem.rss
                    threads += p.num_threads()
                    live += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            cpu_percent = round(min(cpu_percent * 100, 100.0 * max(1, len(procs))), 1)
            return {
                "cpu": {"percent": cpu_percent},
                "memory": {"used_mb": round(rss / 1048576, 1)},
                "processes": live,
                "threads": threads,
            }
        except Exception as exc:  # noqa: BLE001
            return {"process_error": f"{type(exc).__name__}: {exc}"}

    _rate_cache: dict = {}

    def _rate(self, key: str, iid: str, value: int) -> float:
        """Bytes/s since the previous sample (0.0 on the first sample)."""
        import time as _t

        cache_key = f"{iid}:{key}"
        now = _t.time()
        prev = self._rate_cache.get(cache_key)
        self._rate_cache[cache_key] = (now, value)
        if not prev:
            return 0.0
        prev_at, prev_val = prev
        delta_t = now - prev_at
        if delta_t <= 0.2 or value < prev_val:
            return 0.0
        return round((value - prev_val) / delta_t / 1024, 2)

    # ---------------------------------------------------------------- console
    def console_argv(self, instance, cols: int = 120, rows: int = 30) -> list[str] | None:
        info = self.inspect(instance)
        if info.status != "running" or not info.pid:
            return None
        rootfs = self._rootfs(instance)
        shell = None
        # Alpine provides BusyBox ash and may not install the conventional
        # /bin/sh symlink. Treat its real /bin/ash shell as a first-class
        # console target instead of claiming the running instance has no shell.
        for candidate in ("/bin/bash", "/usr/bin/bash", "/bin/sh",
                          "/bin/ash", "/usr/bin/ash"):
            if (rootfs / candidate.lstrip("/")).exists():
                shell = candidate
                break
        if not shell:
            return None
        argv = [
            "nsenter",
            "--target", str(info.pid),
            "--pid", "--mount", "--uts", "--ipc",
            "--root=" + str(rootfs),
            # --wdns changes cwd after switching to the target mount namespace.
            # --wd alone can leave the shell in the panel's host directory,
            # producing getcwd errors inside a perfectly healthy container.
            "--wdns=/",
        ]
        state = read_state(self._state_file(instance))
        if state.get("netns"):
            argv.append("--net")
        argv += ["--", shell, "-l"]
        return argv

    def exec_argv(self, instance, argv: list[str]) -> list[str] | None:
        info = self.inspect(instance)
        if info.status != "running" or not info.pid:
            return None
        prefix = [
            "nsenter", "--target", str(info.pid),
            "--pid", "--mount", "--uts", "--ipc",
            "--root=" + str(self._rootfs(instance)), "--wd=/",
        ]
        state = read_state(self._state_file(instance))
        if state.get("netns"):
            prefix.append("--net")
        return prefix + ["--", *argv]

    # ------------------------------------------------------------------ facts
    def host_facts(self) -> HostFacts:
        caps = self.profile.caps
        facts = HostFacts(
            provider=self.name,
            kind=self.kind,
            isolation="Linux namespaces (container — not a virtual machine)",
            resource_enforcement=[],
            network_model="",
        )
        if self.profile.available("cgroups"):
            facts.resource_enforcement.append("cgroup v2 (memory.max, cpu.max, pids.max)")
        facts.resource_enforcement.append(
            "POSIX rlimits (RLIMIT_AS, RLIMIT_CPU, RLIMIT_NPROC, RLIMIT_FSIZE)"
        )
        if self.profile.available("netns"):
            facts.network_model = ("dedicated network namespace with a veth pair, "
                                   "private /30 IPv4 address and NAT egress")
        else:
            facts.network_model = "host network namespace (shared)"
        facts.supports = {
            "start_stop": True,
            "restart": True,
            "rebuild": True,
            "delete": True,
            "console": True,
            "files": True,
            "snapshot": True,
            "resource_limits": self.profile.available("cgroups"),
            "dedicated_ip": self.profile.available("netns"),
            # SSH is only claimed when a real sshd exists *inside* an
            # instance's root filesystem — never as a bare promise.
            "ssh": False,
        }
        facts.limitations.append(
            "no port publishing: an sshd inside the instance is required before "
            "SSH can be offered (use the web console instead)"
        )
        return facts

    def _rootfs_has_sshd(self, instance=None) -> bool:
        """Does this instance's root filesystem actually contain sshd?"""
        if instance is None:
            return False
        rootfs = self._rootfs(instance)
        for candidate in ("usr/sbin/sshd", "usr/local/sbin/sshd", "sbin/sshd"):
            if (Path(rootfs) / candidate).exists():
                return True
        return False


def allocate_free_address(instance, used: set[str]) -> tuple[str, str]:
    return NamespaceProvider.allocate_address(None, instance, used)
