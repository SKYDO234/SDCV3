"""
Provider interface.

A provider is a concrete way of running an instance on this machine.  SKVM
ships three, in descending order of capability:

  docker     — talks to a real Docker daemon over the socket/TCP API
  lxc        — drives real LXC system containers through the lxc-* tools
  namespace  — SKVM's built-in unprivileged container runtime: user/PID/mount/
               UTS/IPC namespaces + cgroup v2 limits + an optional dedicated
               network namespace with a real veth-backed IP address

None of them is a hypervisor.  A provider may only report what it verified.
"""
from __future__ import annotations

import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Protocol


class ProgressFn(Protocol):
    def __call__(self, message: str, percent: int | None = None) -> None: ...


@dataclass
class CreateSpec:
    """Everything a provider needs to build one instance."""

    instance_id: str
    name: str
    hostname: str
    vcpu: int
    memory_mb: int
    disk_gb: int
    image: dict                       # OSImage.to_dict()
    owner_username: str = ""
    init_command: str = ""
    want_networking: bool = True
    want_ssh: bool = False
    labels: dict = field(default_factory=dict)

    @property
    def image_reference(self) -> str:
        return self.image.get("reference") or ""

    @property
    def image_slug(self) -> str:
        return self.image.get("slug") or self.name


@dataclass
class InstanceInfo:
    """What the provider observed after an operation."""

    runtime_id: str = ""
    status: str = "unknown"
    detail: str = ""
    internal_ip: str = ""
    public_ip: str = ""
    ssh_port: int | None = None
    ssh_user: str = ""
    boot_time: float | None = None
    pid: int | None = None
    extra: dict = field(default_factory=dict)


@dataclass
class HostFacts:
    """Per-provider facts surfaced in the UI (never invented)."""

    provider: str
    kind: str
    isolation: str
    resource_enforcement: list[str] = field(default_factory=list)
    network_model: str = ""
    supports: dict = field(default_factory=dict)
    limitations: list[str] = field(default_factory=list)


class ProviderError(RuntimeError):
    """Raised when a real operation failed; the message is the real reason."""

    # ------------------------------------------------------------------ config
    def cfg(self, key: str, default=None):
        """
        Read a setting from whatever config object the manager handed us.

        The provider can be constructed with the Flask config mapping, the
        plain ``skvm.config.Config`` class or a dict; this keeps those three
        cases in one place.  (Flask's config object supports ``[]`` but not
        attribute access, which used to break IMAGES_DIR lookups.)
        """
        config = self.config
        if config is None:
            return default
        try:
            if isinstance(config, dict):
                return config.get(key, default)
            return config[key]
        except (KeyError, TypeError, AttributeError):
            return getattr(config, key, default)

    def __init__(self, message: str, *, stage: str = "", retryable: bool = False,
                 detail: str = ""):
        super().__init__(message)
        self.stage = stage
        self.retryable = retryable
        self.detail = detail


class BaseProvider:
    #: short machine name, e.g. "namespace"
    name: str = "base"
    #: what the instance really is — never "vm_kvm" unless a hypervisor runs it
    kind: str = "container_unknown"
    label: str = "Generic provider"

    def __init__(self, config, profile, logger=None):
        self.config = config
        self.profile = profile
        self.log = logger

    # ------------------------------------------------------------- contract
    @classmethod
    def descriptor(cls, caps: dict) -> dict:
        """
        Static capability advertisement.  `available` must reflect a *verified*
        capability from the runtime probe, not an assumption.
        """
        return {
            "name": cls.name,
            "label": cls.label,
            "kind": cls.kind,
            "available": False,
            "reason": "not implemented",
            "remedy": "",
            "limitations": [],
        }

    def is_available(self) -> bool:
        raise NotImplementedError

    def preflight(self, spec: CreateSpec) -> tuple[bool, str]:
        """Cheap checks before doing expensive work."""
        return True, ""

    def create(self, spec: CreateSpec, progress: ProgressFn) -> InstanceInfo:
        raise NotImplementedError

    def start(self, instance, progress: ProgressFn) -> InstanceInfo:
        raise NotImplementedError

    def stop(self, instance, progress: ProgressFn, force: bool = False) -> InstanceInfo:
        raise NotImplementedError

    def restart(self, instance, progress: ProgressFn) -> InstanceInfo:
        raise NotImplementedError

    def destroy(self, instance, progress: ProgressFn) -> None:
        raise NotImplementedError

    def rebuild(self, instance, spec: CreateSpec, progress: ProgressFn) -> InstanceInfo:
        """Replace the root filesystem while keeping identity/network."""
        raise NotImplementedError

    def inspect(self, instance) -> InstanceInfo:
        """Current, freshly observed state."""
        raise NotImplementedError

    def metrics(self, instance) -> dict:
        """Real resource usage, or {} with a `reason` when unavailable."""
        raise NotImplementedError

    def console_argv(self, instance, cols: int, rows: int) -> list[str] | None:
        """
        Return an argv that opens an interactive shell *inside* the instance.

        The returned command is executed with a controlling PTY by the console
        service, so its stdout/stdin are the terminal.  Returning None means the
        provider cannot offer a console (the UI then says so).
        """
        return None

    def exec_argv(self, instance, argv: list[str]) -> list[str] | None:
        """Return an argv that runs `argv` inside the instance, or None."""
        return None

    def host_facts(self) -> HostFacts:
        return HostFacts(provider=self.name, kind=self.kind,
                         isolation=self.label)

    # ------------------------------------------------------------- helpers
    def instance_dir(self, instance) -> Path:
        return Path(self.config["INSTANCES_DIR"]) / instance.instance_id

    def _log(self, message: str, level: str = "info") -> None:
        if self.log:
            getattr(self.log, level, self.log.info)(
                f"[{self.name}] {message}"
            )

    @staticmethod
    def shell_join(argv: list[str]) -> str:
        return " ".join(shlex.quote(a) for a in argv)
