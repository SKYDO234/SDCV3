"""
LXC / Incus provider — real LXC system containers via the lxc-* tooling.

Only offered when the host genuinely permits privileged containers (verified at
startup).  LXCFS is used *only* for its documented purpose — virtualising
/proc/meminfo, /proc/cpuinfo, /proc/uptime and the cgroup files so a container
sees its own limits — never as a virtualization engine.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import time
from pathlib import Path

from .base import BaseProvider, CreateSpec, HostFacts, InstanceInfo, ProviderError


class LXCProvider(BaseProvider):
    name = "lxc"
    kind = "container_lxc"
    label = "LXC system container"

    @classmethod
    def descriptor(cls, caps: dict) -> dict:
        cap = caps.get("lxc")
        available = bool(cap and cap.available)
        lxcfs = caps.get("lxcfs")
        limitations = []
        if available:
            limitations.append(
                "LXC containers share the host kernel — they are system "
                "containers, not virtual machines."
            )
        notes = []
        if lxcfs and lxcfs.available:
            notes.append("LXCFS active: /proc/meminfo, /proc/cpuinfo and "
                         "/proc/uptime inside the instance report the "
                         "container's own limits.")
        elif lxcfs and lxcfs.reason:
            notes.append(f"LXCFS not active ({lxcfs.reason})")
        return {
            "name": cls.name,
            "label": cls.label,
            "kind": cls.kind,
            "available": available,
            "reason": "" if available else (cap.reason if cap else "not probed"),
            "remedy": "" if available else (cap.remedy if cap else ""),
            "limitations": limitations + notes,
            "enforcement": ["LXC cgroup limits (lxc.cgroup2.memory.max, cpu.max)"]
                           if available else [],
            "network": "lxcbr0 bridge / veth" if available else "none",
        }

    def is_available(self) -> bool:
        return bool(self.profile.available("lxc"))

    def _run(self, argv: list[str], timeout: int = 300, allow_fail: bool = False):
        from ..detect import run_privileged

        rc, out, err = run_privileged(argv, timeout=timeout)
        if rc != 0 and not allow_fail:
            raise ProviderError(
                f"{' '.join(argv)} failed ({rc}): {(err or out)[:300]}",
                stage=argv[0],
            )
        return rc, out, err

    def _name(self, instance) -> str:
        return f"skvm-{instance.instance_id}"

    def _rootfs(self, instance) -> Path:
        """LXC installs its own rootfs; use it when present."""
        lxc_path = Path(self.config["LXC_PATH"]) / self._name(instance)
        if (lxc_path / "rootfs").exists():
            return lxc_path / "rootfs"
        return self.instance_dir(instance) / "rootfs"

    # ---------------------------------------------------------------- create
    def preflight(self, spec: CreateSpec) -> tuple[bool, str]:
        if not self.is_available():
            cap = self.profile.cap("lxc")
            return False, (cap.reason if cap else "LXC is unavailable")
        if not shutil.which("lxc-create"):
            return False, "lxc-create is not installed"
        return True, ""

    def create(self, instance, spec: CreateSpec, progress) -> InstanceInfo:
        name = self._name(instance)
        reference = spec.image.get("reference", "")
        progress(f"creating LXC container {name}")

        # Map the OCI reference onto an LXC template when we can; LXC's own
        # download template needs network access to the distro mirrors.
        distro, release = self._distro_hint(spec.image)
        if distro:
            progress(f"using the LXC download template: {distro} {release}")
            self._run(["lxc-create", "--name", name, "--template", "download",
                       "--", "--dist", distro, "--release", release,
                       "--arch", "amd64"], timeout=1800, allow_fail=True)
        else:
            raise ProviderError(
                f"no LXC template mapping for image '{reference}'",
                stage="image",
            )

        config_path = Path(self.config["LXC_PATH"]) / name / "config"
        limits = [
            f"lxc.cgroup2.memory.max = {int(spec.memory_mb) * 1024 * 1024}",
            f"lxc.cgroup2.cpu.max = {int(spec.vcpu) * 100000} 100000",
            "lxc.cgroup2.pids.max = 512",
            f"lxc.uts.name = {spec.hostname}",
            "lxc.apparmor.profile = generated",
            "lxc.mount.auto = proc:mixed sys:ro cgroup:mixed",
        ]
        if self.profile.available("lxcfs"):
            lxcf = Path(self.config["LXCFS_PATH"])
            for rel in ("proc/meminfo", "proc/cpuinfo", "proc/uptime",
                        "proc/diskstats", "proc/swaps", "proc/slabinfo",
                        "sys/devices/system/cpu/online"):
                limits.append(
                    f"lxc.mount.entry = {lxcf}/{rel} {rel} none bind,create=file,optional 0 0"
                )
            progress("binding LXCFS files so the container sees its own limits")
        with open(config_path, "a") as fh:
            fh.write("\n# ---- SKVM managed limits ----\n")
            fh.write("\n".join(limits) + "\n")

        progress("starting the container")
        self._run(["lxc-start", "--name", name, "-d"], timeout=300)
        info = self.inspect(instance)
        if info.status != "running":
            raise ProviderError("lxc-start did not reach a running state",
                                stage="start")
        progress("container running")
        return info

    def _distro_hint(self, image: dict) -> tuple[str, str]:
        slug = (image.get("slug") or "").lower()
        version = image.get("version") or ""
        if "ubuntu" in slug:
            return "ubuntu", version or "22.04"
        if "debian" in slug:
            return "debian", version or "12"
        return "", ""

    # ------------------------------------------------------------- lifecycle
    def inspect(self, instance) -> InstanceInfo:
        name = self._name(instance)
        rc, out, err = self._run(["lxc-info", "--name", name], timeout=30,
                                 allow_fail=True)
        if rc != 0:
            return InstanceInfo(status="error",
                                detail=f"lxc-info failed: {(err or out)[:200]}")
        status = "unknown"
        ip = ""
        pid = None
        for line in out.splitlines():
            if line.startswith("State:"):
                status = line.split(":", 1)[1].strip().lower()
            elif line.startswith("IP:"):
                candidate = line.split(":", 1)[1].strip()
                if ":" not in candidate or candidate.count(".") == 3:
                    ip = candidate
            elif line.startswith("PID:"):
                try:
                    pid = int(line.split(":", 1)[1].strip())
                except ValueError:
                    pid = None
        mapped = {"running": "running", "stopped": "stopped", "frozen": "stopped",
                  "starting": "provisioning", "stopping": "restarting"}
        return InstanceInfo(runtime_id=name, status=mapped.get(status, "unknown"),
                            detail=status, internal_ip=ip, pid=pid,
                            ssh_user="root")

    def start(self, instance, progress) -> InstanceInfo:
        progress("lxc-start")
        self._run(["lxc-start", "--name", self._name(instance), "-d"], timeout=300)
        return self.inspect(instance)

    def stop(self, instance, progress, force: bool = False) -> InstanceInfo:
        progress("lxc-stop")
        args = ["lxc-stop", "--name", self._name(instance)]
        if force:
            args.append("--kill")
        else:
            args += ["--timeout", "15"]
        self._run(args, timeout=120)
        return self.inspect(instance)

    def restart(self, instance, progress) -> InstanceInfo:
        self.stop(instance, progress)
        time.sleep(0.5)
        return self.start(instance, progress)

    def destroy(self, instance, progress) -> None:
        name = self._name(instance)
        progress(f"destroying LXC container {name}")
        self._run(["lxc-stop", "--name", name, "--kill"], timeout=120, allow_fail=True)
        self._run(["lxc-destroy", "--name", name, "-f"], timeout=600, allow_fail=True)
        progress("container destroyed")

    def rebuild(self, instance, spec: CreateSpec, progress) -> InstanceInfo:
        self.destroy(instance, progress)
        return self.create(instance, spec, progress)

    # ---------------------------------------------------------------- metrics
    def metrics(self, instance) -> dict:
        name = self._name(instance)
        info = self.inspect(instance)
        if info.status != "running":
            return {"available": False, "reason": f"instance is {info.status}"}
        out: dict = {"available": True, "source": ["lxc-cgroup", "process accounting"],
                     "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        mem = self._cgroup_read(name, "memory.current")
        limit = self._cgroup_read(name, "memory.max")
        if mem is not None:
            limit_bytes = int(limit) if (limit and limit != "max") else \
                int(instance.memory_mb) * 1048576
            out["memory"] = {
                "used_mb": round(int(mem) / 1048576, 1),
                "limit_mb": round(limit_bytes / 1048576, 1),
                "percent": round(int(mem) / limit_bytes * 100, 1) if limit_bytes else 0,
            }
        cpu_stat = self._cgroup_read(name, "cpu.stat")
        if cpu_stat:
            for line in cpu_stat.splitlines():
                if line.startswith("usage_usec"):
                    out.setdefault("cpu", {})["cgroup_usage_usec"] = int(
                        line.split()[1])
        if info.pid:
            try:
                import psutil

                proc = psutil.Process(info.pid)
                children = [proc] + proc.children(recursive=True)
                rss = 0
                for p in children:
                    try:
                        rss += p.memory_info().rss
                    except Exception:
                        continue
                out.setdefault("memory", {})["used_mb"] = round(rss / 1048576, 1)
                out["processes"] = len(children)
                out["cpu"] = out.get("cpu") or {}
                out["cpu"]["percent"] = round(proc.cpu_percent(interval=0.3), 1)
            except Exception as exc:
                out["process_error"] = str(exc)
        return out

    def _cgroup_read(self, name: str, filename: str, timeout: int = 20):
        rc, out, _ = self._run(
            ["lxc-cgroup", "--name", name, filename], timeout=timeout, allow_fail=True
        )
        return out.strip() if rc == 0 and out.strip() else None

    # ---------------------------------------------------------------- console
    def console_argv(self, instance, cols: int = 120, rows: int = 30) -> list[str] | None:
        info = self.inspect(instance)
        if info.status != "running":
            return None
        return ["lxc-attach", "--name", self._name(instance), "--", "/bin/bash", "-l"]

    def exec_argv(self, instance, argv: list[str]) -> list[str] | None:
        info = self.inspect(instance)
        if info.status != "running":
            return None
        return ["lxc-attach", "--name", self._name(instance), "--", *argv]

    def host_facts(self) -> HostFacts:
        return HostFacts(
            provider=self.name, kind=self.kind,
            isolation="LXC system container (shared kernel — not a virtual machine)",
            resource_enforcement=["cgroup v2 via lxc.cgroup2.* keys",
                                  "AppArmor profile"],
            network_model="lxcbr0 bridge with veth; LXCFS virtualises /proc",
            supports={"start_stop": True, "restart": True, "rebuild": True,
                      "delete": True, "console": True, "files": True,
                      "snapshot": True, "resource_limits": True,
                      "dedicated_ip": True, "ssh": True},
        )
