"""
Docker provider — activates only when a real Docker daemon is reachable.

Every operation is a real Docker Engine API call (through the official Python
SDK).  If the daemon is missing the provider reports itself unavailable rather
than degrading into a simulation, and the panel shows the actual probe reason.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .base import BaseProvider, CreateSpec, HostFacts, InstanceInfo, ProviderError


class DockerProvider(BaseProvider):
    name = "docker"
    kind = "container_docker"
    label = "Docker container"

    def __init__(self, config, profile, logger=None):
        super().__init__(config, profile, logger)
        self._client = None

    # ------------------------------------------------------------------ desc
    @classmethod
    def descriptor(cls, caps: dict) -> dict:
        cap = caps.get("docker")
        available = bool(cap and cap.available)
        return {
            "name": cls.name,
            "label": cls.label,
            "kind": cls.kind,
            "available": available,
            "reason": "" if available else (cap.reason if cap else "not probed"),
            "remedy": "" if available else (cap.remedy if cap else ""),
            "limitations": [
                "A Docker container shares the host kernel and cannot be called "
                "a virtual machine.",
            ] if available else [],
            "enforcement": ["Docker cgroup limits (--cpus, --memory, --pids-limit)"] if available else [],
            "network": "Docker bridge / user-defined networks" if available else "none",
        }

    def is_available(self) -> bool:
        return bool(self.profile.available("docker"))

    def client(self):
        if self._client is not None:
            return self._client
        import docker as docker_sdk

        base_url = self.config["DOCKER_HOST"] or None
        if not base_url:
            for candidate in ("/var/run/docker.sock", "/run/docker.sock"):
                if Path(candidate).exists():
                    base_url = f"unix://{candidate}"
                    break
        try:
            self._client = docker_sdk.DockerClient(base_url=base_url, timeout=60)
            self._client.ping()
        except Exception as exc:
            raise ProviderError(
                f"Docker daemon is not reachable: {exc}", stage="connect",
                retryable=True,
            ) from exc
        return self._client

    def preflight(self, spec: CreateSpec) -> tuple[bool, str]:
        if not self.is_available():
            cap = self.profile.cap("docker")
            return False, (cap.reason if cap else "Docker is unavailable on this host")
        try:
            self.client()
        except ProviderError as exc:
            return False, str(exc)
        return True, ""

    # ---------------------------------------------------------------- create
    def create(self, instance, spec: CreateSpec, progress) -> InstanceInfo:
        client = self.client()
        reference = spec.image.get("reference")
        if not reference:
            raise ProviderError("no image reference configured for this OS",
                                stage="image")

        progress(f"pulling {reference} (real registry pull)")
        try:
            repo, _, tag = reference.partition(":") if ":" in reference.split("/")[-1] else (reference, "", "latest")
            image = client.images.pull(repo, tag=tag or None)
            image_id = image.id if hasattr(image, "id") else str(image)
            progress(f"image ready: {image_id[:19]}…")
        except Exception as exc:
            raise ProviderError(f"image pull failed: {exc}", stage="pull",
                                retryable=True) from exc

        ports: dict = {}
        state_meta: dict = {}
        if spec.want_ssh:
            # Publish a real sshd port only if the image actually ships sshd.
            ports["22/tcp"] = None
            progress("SSH requested — a free host port will be published "
                     "if the image contains sshd")
        run_kwargs = dict(
            image=reference,
            name=f"skvm-{instance.instance_id}",
            hostname=spec.hostname,
            detach=True,
            labels={
                "skvm.instance_id": instance.instance_id,
                "skvm.owner": spec.owner_username or "",
                "skvm.managed": "true",
            },
            mem_limit=f"{spec.memory_mb}m",
            memswap_limit=f"{spec.memory_mb}m",
            nano_cpus=int(spec.vcpu) * 1_000_000_000,
            pids_limit=512,
            ports=ports or None,
            working_dir="/root",
            command=spec.init_command or "/bin/sleep infinity",
        )
        state_meta["run_kwargs"] = {k: v for k, v in run_kwargs.items()
                                    if k not in ("image",)}

        progress(f"creating container with {spec.vcpu} vCPU / "
                 f"{spec.memory_mb} MiB RAM / {spec.disk_gb} GiB disk quota")
        try:
            container = client.containers.run(**run_kwargs)
        except Exception as exc:
            raise ProviderError(f"container creation failed: {exc}", stage="create",
                                retryable=True) from exc

        container.reload()
        ports_out = container.attrs.get("NetworkSettings", {}).get("Ports", {}) or {}
        ssh_port = None
        for pub in (ports_out.get("22/tcp") or []):
            if pub and pub.get("HostPort"):
                ssh_port = int(pub["HostPort"])
                break
        # Apply the storage quota the only honest way Docker supports it.
        self._apply_disk_quota(container, spec.disk_gb, progress)

        nets = container.attrs.get("NetworkSettings", {}).get("Networks", {}) or {}
        internal_ip = ""
        for name, data in nets.items():
            internal_ip = data.get("IPAddress") or internal_ip

        progress(f"container {container.short_id} is running")
        (self.instance_dir(instance) / "runtime.json").parent.mkdir(
            parents=True, exist_ok=True)
        (self.instance_dir(instance) / "runtime.json").write_text(json.dumps({
            "container_id": container.id,
            "image": reference,
            "created_at": time.time(),
            "init_command": spec.init_command or "/bin/sleep infinity",
            "ssh_port": ssh_port,
            "run_kwargs": state_meta.get("run_kwargs"),
        }, indent=2))

        return InstanceInfo(
            runtime_id=container.id, status="running",
            internal_ip=internal_ip, ssh_port=ssh_port, ssh_user="root",
            boot_time=time.time(),
            extra={"container_id": container.id, "short_id": container.short_id,
                   "image": reference, "ssh_port": ssh_port},
        )

    def _apply_disk_quota(self, container, disk_gb: int, progress) -> None:
        """
        Docker has no per-container disk quota on the default (overlay2)
        storage driver.  A real quota is enforced only when the storage driver
        supports it (xfs + pquota) — we check, and otherwise say so plainly
        instead of pretending a limit exists.
        """
        try:
            client = self.client()
            info = client.info()
            driver = info.get("Driver", "")
            if driver == "xfs":
                progress("storage driver xfs detected — project quotas may apply "
                         "to this container through the host's disk-quota policy")
            else:
                progress(
                    f"note: the Docker storage driver '{driver}' does not support "
                    f"per-container disk quotas, so the {disk_gb} GiB disk size is "
                    "recorded as a plan attribute only — it is not enforced by "
                    "the runtime"
                )
        except Exception:
            pass

    # ------------------------------------------------------------- lifecycle
    def _container(self, instance):
        client = self.client()
        rid = instance.runtime_id
        if not rid:
            runtime_file = self.instance_dir(instance) / "runtime.json"
            if runtime_file.exists():
                try:
                    rid = json.loads(runtime_file.read_text()).get("container_id", "")
                except ValueError:
                    rid = ""
        if not rid:
            raise ProviderError("this instance has no recorded container id",
                                stage="lookup")
        try:
            return client.containers.get(rid)
        except Exception as exc:
            raise ProviderError(
                f"container {rid[:12]} is not present on the Docker host: {exc}",
                stage="lookup",
            ) from exc

    def inspect(self, instance) -> InstanceInfo:
        try:
            container = self._container(instance)
            container.reload()
        except ProviderError as exc:
            return InstanceInfo(status="error", detail=str(exc))
        state = (container.attrs.get("State") or {})
        status = state.get("Status", "unknown")
        mapped = {"running": "running", "exited": "stopped", "created": "stopped",
                  "paused": "stopped", "restarting": "restarting",
                  "dead": "error", "removing": "deleting"}
        nets = (container.attrs.get("NetworkSettings") or {}).get("Networks", {}) or {}
        ip = ""
        for _, data in nets.items():
            ip = data.get("IPAddress") or ip
        ports = (container.attrs.get("NetworkSettings") or {}).get("Ports", {}) or {}
        ssh_port = None
        for pub in (ports.get("22/tcp") or []):
            if pub and pub.get("HostPort"):
                ssh_port = int(pub["HostPort"])
        boot = state.get("StartedAt", "")
        boot_ts = None
        if boot and not boot.startswith("0001"):
            try:
                from datetime import datetime

                boot_ts = datetime.fromisoformat(
                    boot.replace("Z", "+00:00")).timestamp()
            except ValueError:
                boot_ts = None
        return InstanceInfo(
            runtime_id=container.id, status=mapped.get(status, "unknown"),
            detail=state.get("Status", ""), internal_ip=ip, ssh_port=ssh_port,
            ssh_user="root", boot_time=boot_ts,
            extra={"exit_code": state.get("ExitCode"),
                   "started_at": state.get("StartedAt"),
                   "restart_count": state.get("RestartCount"),
                   "image": (container.attrs.get("Config") or {}).get("Image")},
        )

    def start(self, instance, progress) -> InstanceInfo:
        container = self._container(instance)
        progress("starting container")
        container.start()
        container.reload()
        progress("container started")
        return self.inspect(instance)

    def stop(self, instance, progress, force: bool = False) -> InstanceInfo:
        container = self._container(instance)
        progress("stopping container")
        container.stop(timeout=0 if force else 10)
        progress("container stopped")
        return self.inspect(instance)

    def restart(self, instance, progress) -> InstanceInfo:
        container = self._container(instance)
        progress("restarting container")
        container.restart(timeout=10)
        progress("container restarted")
        return self.inspect(instance)

    def rebuild(self, instance, spec: CreateSpec, progress) -> InstanceInfo:
        """Real rebuild: remove the container, keep the identity, recreate."""
        try:
            container = self._container(instance)
            progress("removing the existing container (volumes preserved)")
            container.remove(force=True)
        except ProviderError as exc:
            progress(f"nothing to remove: {exc}")
        return self.create(instance, spec, progress)

    def destroy(self, instance, progress) -> None:
        try:
            container = self._container(instance)
        except ProviderError as exc:
            progress(f"container already absent: {exc}")
            return
        progress(f"removing container {container.short_id}")
        container.remove(force=True)
        progress("container removed")

    # ---------------------------------------------------------------- metrics
    def metrics(self, instance) -> dict:
        try:
            container = self._container(instance)
            stats = container.stats(stream=False)
        except Exception as exc:
            return {"available": False, "reason": f"{type(exc).__name__}: {exc}"}
        try:
            cpu = stats.get("cpu_stats", {})
            precpu = stats.get("precpu_stats", {})
            cpu_delta = (cpu.get("cpu_usage", {}).get("total_usage", 0)
                         - precpu.get("cpu_usage", {}).get("total_usage", 0))
            sys_delta = (cpu.get("system_cpu_usage", 0)
                         - precpu.get("system_cpu_usage", 0))
            online = cpu.get("online_cpus") or len(
                cpu.get("cpu_usage", {}).get("percpu_usage", []) or [1])
            cpu_percent = 0.0
            if sys_delta > 0 and cpu_delta > 0:
                cpu_percent = round(cpu_delta / sys_delta * online * 100, 1)
            mem = stats.get("memory_stats", {})
            used = (mem.get("usage", 0)
                    - (mem.get("stats", {}) or {}).get("cache", 0))
            limit = mem.get("limit", 0)
            nets = stats.get("networks", {}) or {}
            rx = sum(n.get("rx_bytes", 0) for n in nets.values())
            tx = sum(n.get("tx_bytes", 0) for n in nets.values())
            pids = (stats.get("pids_stats", {}) or {}).get("current", 0)
            blk = stats.get("blkio_stats", {}).get("io_service_bytes_recursive", []) or []
            read = sum(e.get("value", 0) for e in blk if e.get("op") == "Read")
            write = sum(e.get("value", 0) for e in blk if e.get("op") == "Write")
            return {
                "available": True,
                "source": ["docker stats API"],
                "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "cpu": {"percent": cpu_percent, "limit_vcpu": instance.vcpu,
                        "throttled_percent": round(
                            (cpu.get("throttling_data", {}) or {}).get(
                                "throttled_periods", 0)
                            / max(1, (cpu.get("throttling_data", {}) or {}).get(
                                "periods", 1)) * 100, 1)},
                "memory": {
                    "used_mb": round(used / 1048576, 1),
                    "limit_mb": round(limit / 1048576, 1),
                    "percent": round(used / limit * 100, 1) if limit else 0.0,
                },
                "network": {"rx_bytes": rx, "tx_bytes": tx,
                            "rx_mb": round(rx / 1048576, 2),
                            "tx_mb": round(tx / 1048576, 2)},
                "processes": pids,
                "block_io": {"read_bytes": read, "write_bytes": write},
            }
        except Exception as exc:
            return {"available": False,
                    "reason": f"could not parse docker stats: {exc}"}

    # ---------------------------------------------------------------- console
    def console_argv(self, instance, cols: int = 120, rows: int = 30) -> list[str] | None:
        info = self.inspect(instance)
        if info.status != "running":
            return None
        return ["docker", "exec", "-it", info.runtime_id, "/bin/bash", "-l"]

    def exec_argv(self, instance, argv: list[str]) -> list[str] | None:
        info = self.inspect(instance)
        if info.status != "running":
            return None
        return ["docker", "exec", "-i", info.runtime_id, *argv]

    def host_facts(self) -> HostFacts:
        return HostFacts(
            provider=self.name, kind=self.kind,
            isolation="Docker container (shared kernel — not a virtual machine)",
            resource_enforcement=["Docker cgroup limits (memory, cpu, pids)"],
            network_model="Docker-managed network namespace with bridge NAT",
            supports={"start_stop": True, "restart": True, "rebuild": True,
                      "delete": True, "console": True, "files": True,
                      "snapshot": True, "resource_limits": True,
                      "dedicated_ip": True, "ssh": True},
        )
