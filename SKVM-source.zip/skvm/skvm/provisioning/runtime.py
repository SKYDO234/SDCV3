"""
Privileged runtime glue.

Every privileged operation the panel performs goes through this module, which
funnels into two audited entrypoints inside ``helpers/``:

  * ``helpers/skvm-helper``  — filesystem, cgroup and network plumbing
  * ``helpers/ns-launch``    — the namespace-container supervisor

Both never receive a shell string: arguments are passed as an argv list and the
helper re-validates everything it is given.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Iterable

from .detect import is_admin, probe_sudo, validate_argv

PROJECT_DIR = Path(__file__).resolve().parents[2]
HELPERS_DIR = PROJECT_DIR / "helpers"
HELPER_BIN = HELPERS_DIR / "skvm-helper"
LAUNCH_BIN = HELPERS_DIR / "ns-launch"


class HelperNotAvailable(RuntimeError):
    pass


def _ensure_helpers() -> None:
    for path in (HELPER_BIN, LAUNCH_BIN):
        if not path.exists():
            raise HelperNotAvailable(
                f"helper missing: {path}. Run ./install.sh to install SKVM."
            )
        if not os.access(path, os.X_OK):
            try:
                path.chmod(0o755)
            except OSError as exc:
                raise HelperNotAvailable(
                    f"helper not executable and could not be fixed: {path} ({exc})"
                ) from exc


def _wrap(argv: list[str], use_sudo: bool) -> tuple[list[str], bool]:
    """Prefix with sudo when needed. Returns (argv, used_sudo)."""
    if is_admin():
        return argv, False
    if use_sudo and probe_sudo().get("available"):
        # -n: never prompt.  --preserve-env is NOT used: helpers read nothing
        # from the caller's environment for their security decisions.
        return ["sudo", "-n", *argv], True
    return argv, False


def run_helper(args: Iterable[str], timeout: int = 120, use_sudo: bool = True,
               require_root: bool = True) -> tuple[int, str, str]:
    """
    Invoke skvm-helper.  Returns (rc, stdout, stderr).

    ``require_root`` controls whether we escalate with sudo; when the caller
    does not need root (e.g. reading stats) we try unprivileged first.
    """
    _ensure_helpers()
    argv = [str(HELPER_BIN), *[str(a) for a in args]]

    sudo_ok = probe_sudo().get("available") or is_admin()
    if require_root and not sudo_ok:
        return 1, "", ("root privileges are required for this operation and "
                       "passwordless sudo is unavailable in this environment")

    # Validate the *inner* argv the same way detect.py does, so the allowlist
    # is enforced in one place.  skvm-helper itself is the audit boundary.
    ok, why = validate_argv([HELPER_BIN.name, *[str(a) for a in list(args)[:1]]])
    if not ok:
        return 1, "", why

    wrapped, _ = _wrap(argv, use_sudo)
    try:
        proc = subprocess.run(wrapped, capture_output=True, text=True,
                              timeout=timeout)
        return proc.returncode, (proc.stdout or "").strip(), (proc.stderr or "").strip()
    except subprocess.TimeoutExpired:
        return 124, "", f"helper timed out after {timeout}s"
    except OSError as exc:
        return 1, "", f"could not execute helper: {exc}"


def helper_json(args: Iterable[str], timeout: int = 120, use_sudo: bool = True,
                require_root: bool = True) -> dict:
    """Run a helper subcommand that emits a JSON object."""
    rc, out, err = run_helper(args, timeout=timeout, use_sudo=use_sudo,
                              require_root=require_root)
    payload: dict = {}
    if out:
        # The helper prints exactly one JSON object; be tolerant of stray lines.
        for line in reversed(out.splitlines()):
            line = line.strip()
            if line.startswith("{"):
                try:
                    payload = json.loads(line)
                    break
                except ValueError:
                    continue
    if rc != 0 or not payload.get("ok", rc == 0):
        message = payload.get("error") or err or out or f"helper exited {rc}"
        payload = {**payload, "ok": False, "error": str(message)[:500], "rc": rc}
    return payload


# --------------------------------------------------------------------------
# thin typed wrappers
# --------------------------------------------------------------------------
def helper_apply_layer(layer_tar: Path, rootfs: Path, timeout: int = 600):
    return run_helper(["apply-layer", "--rootfs", str(rootfs),
                       "--layer", str(layer_tar)], timeout=timeout)


def helper_mkdir(path: Path, mode: str | None = None, owner: str | None = None) -> dict:
    args = ["mkdir", "--path", str(path)]
    if mode:
        args += ["--mode", mode]
    if owner:
        args += ["--owner", owner]
    return helper_json(args, timeout=30)


def helper_rm(path: Path, recursive: bool = True) -> dict:
    args = ["rm", "--path", str(path)]
    if recursive:
        args.append("--recursive")
    return helper_json(args, timeout=300)


def helper_chown(path: Path, owner: str, recursive: bool = False) -> dict:
    args = ["chown", "--path", str(path), "--owner", owner]
    if recursive:
        args.append("--recursive")
    return helper_json(args, timeout=600)


def helper_chmod(path: Path, mode: str) -> dict:
    return helper_json(["chmod", "--path", str(path), "--mode", mode], timeout=30)


def helper_write_file(path: Path, content: str, mode: str | None = None,
                      owner: str | None = None, append: bool = False) -> dict:
    """Write a file as root.  Content travels via a temp file, never argv."""
    tmp = Path("/tmp") / f"skvm-write-{os.getpid()}-{abs(hash(str(path))) % 10**8}.txt"
    tmp.write_text(content)
    try:
        args = ["write-file", "--path", str(path), "--content-file", str(tmp)]
        if mode:
            args += ["--mode", mode]
        if owner:
            args += ["--owner", owner]
        if append:
            args.append("--append")
        return helper_json(args, timeout=30)
    finally:
        tmp.unlink(missing_ok=True)


def helper_du(path: Path) -> dict:
    return helper_json(["du", "--path", str(path)], timeout=120, require_root=False)


def cgroup_setup(name: str, memory_mb: int, vcpu: int, pids: int = 512,
                 cpu_weight: int | None = None, disk_bps: int | None = None) -> dict:
    """Configure a cgroup v2 group.  cpu.max quota = vcpu * 100000us period."""
    args = ["cgroup-setup", "--name", name,
            "--memory-mb", str(int(memory_mb)),
            "--cpu-quota", str(int(vcpu) * 100000),
            "--pids", str(int(pids))]
    if cpu_weight:
        args += ["--cpu-weight", str(int(cpu_weight))]
    if disk_bps:
        args += ["--disk-bps", str(int(disk_bps))]
    return helper_json(args, timeout=60)


def cgroup_stats(name: str) -> dict:
    return helper_json(["cgroup-stats", "--name", name], timeout=30,
                       require_root=False)


def cgroup_destroy(name: str) -> dict:
    return helper_json(["cgroup-destroy", "--name", name], timeout=60)


def netns_setup(name: str, host_veth: str, ctr_veth: str, ip: str,
                gateway: str, prefix: int = 30, nat: bool = True) -> dict:
    return helper_json(["netns-setup", "--name", name,
                        "--host-veth", host_veth, "--ctr-veth", ctr_veth,
                        "--ip", ip, "--gateway", gateway,
                        "--prefix", str(prefix)] + (["--nat"] if nat else []),
                       timeout=120)


def veth_destroy(name: str) -> dict:
    """Delete a leftover host-side veth by name."""
    return helper_json(["veth-destroy", "--name", name], timeout=30)


def netns_list() -> dict:
    """Existing namespace containers on this host (names + host veths)."""
    return helper_json(["netns-list"], timeout=30)


def netns_destroy(name: str, host_veth: str) -> dict:
    return helper_json(["netns-destroy", "--name", name, "--host-veth", host_veth],
                       timeout=60)


def netns_stats(name: str) -> dict:
    return helper_json(["netns-stats", "--name", name], timeout=30,
                       require_root=False)


def kill_tree(pid: int, sig: str = "TERM") -> dict:
    return helper_json(["kill-tree", "--pid", str(int(pid)), "--signal", sig],
                       timeout=30)


def helper_version() -> dict:
    return helper_json(["version"], timeout=20, require_root=False)


# --------------------------------------------------------------------------
# namespace container supervisor
# --------------------------------------------------------------------------
def launch_namespace_container(
    rootfs: Path,
    name: str,
    hostname: str,
    state_file: Path,
    log_file: Path,
    init_cmd: str = "/bin/bash -l",
    netns: str = "",
    cgroup_path: str = "",
    memory_mb: int = 0,
    vcpu: int = 0,
    pids: int = 512,
    fsize_gb: int = 0,
    unprivileged: bool = False,
    detached: bool = True,
) -> dict:
    """
    Start the ns-launch supervisor.  When `detached`, the supervisor is started
    with setsid and survives the panel process (and restarts) by itself.
    """
    _ensure_helpers()
    argv = [
        str(LAUNCH_BIN),
        "--rootfs", str(rootfs),
        "--name", name,
        "--hostname", hostname,
        "--init-cmd", init_cmd,
        "--state-file", str(state_file),
        "--log-file", str(log_file),
        "--pids", str(max(32, int(pids))),
    ]
    if netns:
        argv += ["--netns", netns]
    if cgroup_path:
        argv += ["--cgroup", cgroup_path]
    if memory_mb:
        argv += ["--memory-mb", str(int(memory_mb))]
    if vcpu:
        argv += ["--vcpu", str(int(vcpu))]
    if fsize_gb:
        argv += ["--fsize-gb", str(int(fsize_gb))]
    if unprivileged:
        argv.append("--unprivileged")

    wrapped, used_sudo = _wrap(argv, use_sudo=True)

    if detached:
        setsid = shutil.which("setsid")
        prefix = [setsid, "--fork"] if setsid else []
        if not setsid:
            return {"ok": False, "error": "setsid is required to detach the "
                                          "instance supervisor"}
        cmd = [*prefix, *wrapped]
        log_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(log_file, "ab") as sink:
                proc = subprocess.Popen(
                    cmd,
                    stdin=subprocess.DEVNULL,
                    stdout=sink,
                    stderr=sink,
                    start_new_session=True,
                    close_fds=True,
                )
        except OSError as exc:
            return {"ok": False, "error": f"could not start supervisor: {exc}"}
        return {"ok": True, "supervisor_pid": proc.pid, "detached": True,
                "sudo": used_sudo, "log_file": str(log_file)}

    proc = subprocess.run(wrapped, capture_output=True, text=True, timeout=180)
    return {"ok": proc.returncode == 0, "rc": proc.returncode,
            "stdout": proc.stdout.strip(), "stderr": proc.stderr.strip(),
            "sudo": used_sudo}


def read_state(state_file: Path) -> dict:
    try:
        return json.loads(Path(state_file).read_text())
    except (OSError, ValueError):
        return {}


def process_alive(pid: int | None) -> bool:
    if not pid or pid <= 1:
        return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Exists but owned by root — a live process either way.
        return True
    except OSError:
        return False
    return True


def read_pid_start_time(pid: int) -> float | None:
    """Used to detect PID reuse (a real correctness concern for state files)."""
    try:
        stat = Path(f"/proc/{int(pid)}/stat").read_text()
        fields = stat.rsplit(")", 1)[1].split()
        return int(fields[19]) / float(os.sysconf("SC_CLK_TCK"))
    except (OSError, IndexError, ValueError):
        return None
