"""
ProvisioningManager — the bridge between the database and the real runtimes.

Responsibilities
  * resolve which provider can run instances here (from the live probe);
  * validate every request against quotas and guard-rails;
  * run provisioning / power / rebuild / delete / backup work as persisted tasks;
  * keep instance status and metrics in sync with reality;
  * refuse to claim anything it has not verified.
"""
from __future__ import annotations

import json
import logging
import os
import signal
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import psutil

from ..extensions import db
from ..models import (
    Backup, Node, OSImage, Task, TaskStatus, User, VPS, VPSStatus, utcnow,
)
from .detect import get_profile
from .oci import RegistryError, RegistryClient, export_rootfs_tar
from .providers import CreateSpec, ProviderError, resolve_provider
from .runtime import cgroup_destroy as helper_cgroup_destroy
from .runtime import helper_du, helper_rm, netns_destroy, netns_list, veth_destroy

logger = logging.getLogger("skvm.provisioning")


class QuotaError(ValueError):
    """Raised when a request would exceed an enforced limit."""


class ProvisioningManager:
    def __init__(self, app, runner):
        self.app = app
        self.config = app.config
        self.runner = runner
        self._provider_cache: dict = {"key": None, "provider": None, "at": 0}
        self._monitor_thread: threading.Thread | None = None
        self._monitor_stop = threading.Event()

    # ------------------------------------------------------------- providers
    def profile(self, force: bool = False):
        return get_profile(force=force)

    def provider(self, preferred: str | None = None, force: bool = False):
        """The active provider, resolved from the live capability probe."""
        if isinstance(self.config, dict):
            default_pref = self.config.get("DEFAULT_PROVIDER", "auto")
        else:
            default_pref = getattr(self.config, "DEFAULT_PROVIDER", "auto")
        pref = preferred or default_pref or "auto"
        profile = self.profile(force=force)
        key = (pref, profile.to_dict().get("probed_at_iso"))
        if self._provider_cache["key"] == key and not force:
            return self._provider_cache["provider"], self._provider_cache.get("diag", [])
        provider, diagnostics = resolve_provider(
            self.config, profile, preferred=pref, logger=logger
        )
        self._provider_cache = {"key": key, "provider": provider, "at": time.time(),
                                "diag": diagnostics}
        return provider, diagnostics

    def provider_for(self, instance, force: bool = False):
        """Provider that owns an existing instance (recorded at creation)."""
        if instance.provider:
            provider, _ = self.provider(preferred=instance.provider, force=force)
            if provider is not None:
                return provider
        provider, _ = self.provider(force=force)
        return provider

    def capabilities(self, force: bool = False) -> dict:
        profile = self.profile(force=force)
        provider, diagnostics = self.provider(force=force)
        data = profile.to_dict()
        data["providers"] = diagnostics or data.get("providers", [])
        data["active_provider"] = (
            {"name": provider.name, "label": provider.label, "kind": provider.kind}
            if provider else None
        )
        if provider:
            facts = provider.host_facts()
            data["active_facts"] = {
                "provider": facts.provider, "kind": facts.kind,
                "isolation": facts.isolation,
                "resource_enforcement": facts.resource_enforcement,
                "network_model": facts.network_model,
                "supports": facts.supports,
                "limitations": facts.limitations,
            }
        data["capabilities"] = {
            k: v.to_dict() if hasattr(v, "to_dict") else v
            for k, v in (data.get("capabilities") or {}).items()
        }
        data["summary"] = profile.summary
        data["can_provision"] = provider is not None
        return data

    # ------------------------------------------------------------ validation
    def validate_spec(self, owner: User, plan, vcpu: int, memory_mb: int,
                      disk_gb: int, image: OSImage | None,
                      existing: VPS | None = None) -> dict:
        cfg = self.config
        errors: list[str] = []

        def _int(value, name, minimum, maximum):
            try:
                value = int(value)
            except (TypeError, ValueError):
                errors.append(f"{name} must be a whole number")
                return minimum
            if value < minimum or value > maximum:
                errors.append(f"{name} must be between {minimum} and {maximum}")
                return max(minimum, min(maximum, value))
            return value

        vcpu = _int(vcpu, "vCPU count", 1, cfg["MAX_VCPU"])
        memory_mb = _int(memory_mb, "memory", cfg["MIN_MEMORY_MB"], cfg["MAX_MEMORY_MB"])
        disk_gb = _int(disk_gb, "disk", cfg["MIN_DISK_GB"], cfg["MAX_DISK_GB"])

        if not image:
            errors.append("select an operating system image")
        elif not image.is_active:
            errors.append(f"image '{image.name}' is disabled")

        # per-user quota (admin accounts are exempt from the per-user caps)
        if owner and not owner.is_admin:
            if memory_mb > owner.quota_memory_mb:
                errors.append(
                    f"memory exceeds your quota of {owner.quota_memory_mb} MiB")
            if vcpu > owner.quota_vcpu:
                errors.append(f"vCPU count exceeds your quota of {owner.quota_vcpu}")
            if disk_gb > owner.quota_disk_gb:
                errors.append(f"disk exceeds your quota of {owner.quota_disk_gb} GiB")
            active = VPS.query.filter(
                VPS.owner_id == owner.id,
                VPS.status != VPSStatus.DELETED,
            ).count()
            if existing is None and active >= min(owner.quota_instances,
                                                  cfg["MAX_INSTANCES_PER_USER"]):
                errors.append(
                    f"you have reached your limit of {owner.quota_instances} "
                    "instances")

        # host capacity
        profile = self.profile()
        res = profile.resources
        if not cfg["ALLOW_OVERCOMMIT"]:
            allocated_mem = db.session.query(
                db.func.coalesce(db.func.sum(VPS.memory_mb), 0)
            ).filter(VPS.status.in_([VPSStatus.RUNNING, VPSStatus.STOPPED,
                                     VPSStatus.PROVISIONING])).scalar() or 0
            if existing:
                allocated_mem -= existing.memory_mb
            if allocated_mem + memory_mb > res["memory"]["total_mb"]:
                errors.append(
                    f"only {res['memory']['total_mb']} MiB of host memory exists "
                    "and overcommit is disabled")

        return {
            "vcpu": vcpu, "memory_mb": memory_mb, "disk_gb": disk_gb,
            "image": image, "errors": errors,
        }

    def _unique_name(self, requested: str, hostname: str) -> tuple[str, str]:
        """Slugify and de-duplicate a requested instance name."""
        import re

        base = re.sub(r"[^a-z0-9-]+", "-", (requested or "").lower()).strip("-")
        base = re.sub(r"-{2,}", "-", base)[:40] or "instance"
        if not base[0].isalpha():
            base = "vps-" + base
        candidate = base
        suffix = 1
        while VPS.query.filter_by(name=candidate).first():
            suffix += 1
            candidate = f"{base}-{suffix}"
        host = hostname or candidate
        host = re.sub(r"[^a-zA-Z0-9.-]+", "-", host).strip("-")[:63] or candidate
        return candidate, host

    # --------------------------------------------------------------- create
    def create_instance(self, *, owner: User, name: str, hostname: str,
                        plan, vcpu: int, memory_mb: int, disk_gb: int,
                        image: OSImage | None, requested_by: User,
                        expires_days: int | None = None, node: Node | None = None,
                        init_command: str = "", want_networking: bool = True,
                        want_ssh: bool = False) -> tuple[VPS | None, Task | None, list[str]]:
        provider, diagnostics = self.provider()
        if provider is None:
            reasons = [f"{d['name']}: {d.get('reason') or 'unavailable'}"
                       for d in diagnostics]
            return None, None, [
                "No container runtime is available on this host, so an instance "
                "cannot be created. " + "; ".join(reasons)
            ]

        checked = self.validate_spec(owner, plan, vcpu, memory_mb, disk_gb, image)
        if checked["errors"]:
            return None, None, checked["errors"]

        ok, why = provider.preflight(CreateSpec(
            instance_id="preflight", name=name, hostname=hostname,
            vcpu=checked["vcpu"], memory_mb=checked["memory_mb"],
            disk_gb=checked["disk_gb"], image=image.to_dict(),
        ))
        if not ok:
            return None, None, [why]

        final_name, final_host = self._unique_name(name, hostname)

        local_node = node or Node.query.filter_by(is_local=True).first()
        if local_node is None:
            local_node = Node.query.first()

        vps = VPS(
            name=final_name,
            hostname=final_host,
            owner_id=owner.id,
            plan_id=plan.id if plan else None,
            node_id=local_node.id if local_node else None,
            image_id=image.id if image else None,
            provider=provider.name,
            kind=provider.kind,
            vcpu=checked["vcpu"],
            memory_mb=checked["memory_mb"],
            disk_gb=checked["disk_gb"],
            status=VPSStatus.PROVISIONING,
            status_message="waiting for a provisioning worker",
            os_name=image.name if image else "",
            os_version=image.version if image else "",
            os_reference=image.reference if image else "",
            expires_at=(utcnow() + timedelta(days=expires_days)
                        if expires_days else None),
            rootfs_path=str(Path(self.config["INSTANCES_DIR"])),
        )
        db.session.add(vps)
        db.session.flush()

        task = Task(
            kind="provision",
            title=f"Provision {vps.name} ({image.label if image else 'n/a'})",
            status=TaskStatus.QUEUED,
            vps_id=vps.id,
            requested_by_id=requested_by.id,
            payload=json.dumps({
                "name": vps.name, "hostname": vps.hostname,
                "vcpu": vps.vcpu, "memory_mb": vps.memory_mb,
                "disk_gb": vps.disk_gb, "image_id": image.id if image else None,
                "image_ref": image.reference if image else None,
                "provider": provider.name, "init_command": init_command,
                "want_networking": want_networking, "want_ssh": want_ssh,
                "owner": owner.username,
            }),
            max_retries=int(self.config["TASK_MAX_RETRIES"]),
        )
        db.session.add(task)
        db.session.commit()

        key = f"vps:{vps.id}"
        if not self.runner.reserve(key, task.task_id):
            vps.status = VPSStatus.ERROR
            vps.status_message = "another operation is already running"
            db.session.commit()
            return vps, task, ["another operation is already in progress for "
                               "this instance"]

        self.runner.submit(task, self._run_provision, vps.id, task.id)
        return vps, task, []

    def _cleanup_failed_attempt(self, provider, vps: VPS, log, task) -> None:
        """
        Tear down whatever a failed attempt left behind before retrying.

        Without this a retry re-extracts the OCI layers into a root filesystem
        that the previous attempt is still running from: the extraction dies
        with ETXTBSY ("Text file busy") on an executable such as bin/busybox,
        and every later retry fails the same way. Destroying the partial
        instance first removes the supervisor, the mounts, the netns/cgroup and
        the half-written rootfs, so the next attempt starts clean.
        """
        log("cleaning up the failed attempt before retrying")
        try:
            state = None
            try:
                state = provider.inspect(vps)
            except Exception:  # noqa: BLE001 - inspection is advisory here
                state = None
            if state is not None and getattr(state, "status", "") == "running":
                try:
                    provider.stop(vps, lambda m: log(f"cleanup: {m}"), force=True)
                except Exception as exc:  # noqa: BLE001
                    log(f"cleanup: stop reported {type(exc).__name__}: {exc}")
            provider.destroy(vps, lambda m: log(f"cleanup: {m}"))
            log("cleanup finished; the retry will start from a clean rootfs")
        except Exception as exc:  # noqa: BLE001 - never mask the original error
            log(f"cleanup could not complete ({type(exc).__name__}: {exc}); "
                f"the retry may fail again")

    def _spec_from_payload(self, payload: dict, vps: VPS) -> CreateSpec:
        image = db.session.get(OSImage, payload.get("image_id")) if payload.get(
            "image_id") else None
        image_dict = image.to_dict() if image else {
            "slug": (vps.os_reference or "unknown").replace(":", "-").replace("/", "-"),
            "reference": vps.os_reference, "name": vps.os_name or "unknown",
            "version": vps.os_version, "registry": self.config["OCI_REGISTRY"],
        }
        return CreateSpec(
            instance_id=vps.instance_id, name=vps.name, hostname=vps.hostname,
            vcpu=payload.get("vcpu", vps.vcpu),
            memory_mb=payload.get("memory_mb", vps.memory_mb),
            disk_gb=payload.get("disk_gb", vps.disk_gb),
            image=image_dict,
            owner_username=payload.get("owner") or (
                vps.owner.username if vps.owner else ""),
            init_command=payload.get("init_command", ""),
            want_networking=payload.get("want_networking", True),
            want_ssh=payload.get("want_ssh", False),
        )

    def _run_provision(self, task: Task, vps_id: int, task_id: int) -> None:
        from ..services.tasks import TaskLogger

        log = TaskLogger(task_id, self.app)
        vps = db.session.get(VPS, vps_id)
        if vps is None:
            raise RuntimeError("instance record vanished before provisioning")

        payload = task.payload_data()
        provider, diagnostics = self.provider(preferred=payload.get("provider"))
        if provider is None:
            raise ProviderError(
                "no container runtime is available on this host: "
                + "; ".join(f"{d['name']}: {d.get('reason')}" for d in diagnostics),
                stage="provider",
            )

        spec = self._spec_from_payload(payload, vps)
        retries = int(task.max_retries or 0)
        attempt = 0
        last_error: Exception | None = None

        while attempt <= retries:
            attempt += 1
            if attempt > 1:
                log(f"retry {attempt}/{retries + 1} after failure: {last_error}")
                task.retries = attempt - 1
                db.session.commit()
            try:
                vps.status = VPSStatus.PROVISIONING
                vps.provider = provider.name
                vps.kind = provider.kind
                vps.status_message = f"provisioning on {provider.label}"
                db.session.commit()

                info = provider.create(vps, spec, log)

                vps.runtime_id = info.runtime_id
                vps.status = VPSStatus.RUNNING
                vps.internal_ip = info.internal_ip or ""
                vps.public_ip = info.public_ip or ""
                vps.ssh_port = info.ssh_port
                vps.ssh_user = info.ssh_user or "root"
                vps.ssh_enabled = bool(info.ssh_port)
                vps.boot_at = (datetime.fromtimestamp(info.boot_time, timezone.utc).replace(tzinfo=None)
                               if info.boot_time else utcnow())
                vps.status_message = info.detail or "running"
                vps.last_error = ""
                vps.suspended = False if hasattr(vps, "suspended") else None
                db.session.commit()

                task.result = json.dumps({
                    "instance_id": vps.instance_id,
                    "provider": provider.name,
                    "kind": provider.kind,
                    "is_virtual_machine": False,
                    "runtime_id": info.runtime_id,
                    "internal_ip": vps.internal_ip or None,
                    "ssh_port": vps.ssh_port,
                    "attempts": attempt,
                    **(info.extra or {}),
                })
                log(f"instance {vps.name} is running "
                    f"({provider.label}, {provider.kind})")
                if info.extra.get("notes"):
                    for note in info.extra["notes"]:
                        log(f"note: {note}")
                return
            except ProviderError as exc:
                last_error = exc
                log.warning(f"attempt {attempt} failed at stage "
                            f"'{exc.stage}': {exc}")
                if exc.detail:
                    for line in str(exc.detail).splitlines()[-10:]:
                        log(f"  {line}")
                if not exc.retryable or attempt > retries:
                    break
                self._cleanup_failed_attempt(provider, vps, log, task)
                time.sleep(min(10, 2 ** attempt))
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                log.warning(f"attempt {attempt} raised "
                            f"{type(exc).__name__}: {exc}")
                if attempt > retries:
                    break
                time.sleep(2)

        # every attempt failed
        vps.status = VPSStatus.ERROR
        vps.status_message = str(last_error)[:240]
        vps.last_error = f"{type(last_error).__name__}: {last_error}"[:1000]
        db.session.commit()
        try:
            provider.destroy(vps, lambda m, p=None: log(f"cleanup: {m}"))
            log("partial resources cleaned up")
        except Exception as exc:  # noqa: BLE001
            log.warning(f"cleanup after failure reported: {exc}")
        raise ProviderError(
            f"provisioning failed after {attempt} attempt(s): {last_error}",
            stage="provision",
        )

    # ---------------------------------------------------------- power actions
    def submit_power(self, vps: VPS, action: str, user: User) -> tuple[Task, str]:
        if action not in ("start", "stop", "restart", "rebuild", "delete"):
            raise ValueError(f"unsupported action: {action}")
        key = f"vps:{vps.id}"
        busy = self.runner.busy(key)
        if busy:
            return None, f"another operation ({busy}) is already running for this instance"
        payload = {"action": action}
        if action == "rebuild":
            payload.update({
                "image_id": vps.image_id,
                "vcpu": vps.vcpu, "memory_mb": vps.memory_mb,
                "disk_gb": vps.disk_gb, "hostname": vps.hostname,
                "name": vps.name,
                "owner": vps.owner.username if vps.owner else "",
            })
        task = Task(
            kind=action, title=f"{action.title()} {vps.name}", vps_id=vps.id,
            requested_by_id=user.id, payload=json.dumps(payload),
            max_retries=1 if action in ("start", "stop", "restart") else 0,
        )
        db.session.add(task)
        if action == "delete":
            vps.status = VPSStatus.DELETING
            vps.status_message = "deletion in progress"
        elif action == "rebuild":
            vps.status = VPSStatus.REBUILDING
            vps.status_message = "rebuild in progress"
        elif action == "start":
            vps.status = VPSStatus.PROVISIONING
            vps.status_message = "starting"
        elif action == "stop":
            vps.status_message = "stopping"
        elif action == "restart":
            vps.status = VPSStatus.RESTARTING
            vps.status_message = "restarting"
        db.session.commit()
        if not self.runner.reserve(key, task.task_id):
            return None, "another operation is already running for this instance"
        self.runner.submit(task, self._run_action, vps.id, task.id, action)
        return task, ""

    def _run_action(self, task: Task, vps_id: int, task_id: int, action: str) -> None:
        from ..services.tasks import TaskLogger

        log = TaskLogger(task_id, self.app)
        vps = db.session.get(VPS, vps_id)
        if vps is None:
            raise RuntimeError("instance record not found")

        provider = self.provider_for(vps)
        if provider is None:
            # Deletion must still succeed locally even with no runtime.
            if action == "delete":
                log("no runtime is available; removing local records and files")
                self._finalize_delete(vps, log)
                return
            raise ProviderError(
                "no container runtime is available on this host", stage="provider")

        if action == "start":
            log("starting instance")
            info = provider.start(vps, log)
            vps.status = VPSStatus.RUNNING if info.status == "running" else VPSStatus.ERROR
            vps.boot_at = (datetime.fromtimestamp(info.boot_time, timezone.utc).replace(tzinfo=None)
                           if info.boot_time else utcnow())
            vps.stopped_by_user = False
        elif action == "stop":
            log("stopping instance")
            provider.stop(vps, log, force=False)
            vps.status = VPSStatus.STOPPED
            vps.stopped_by_user = True
            vps.boot_at = None
        elif action == "restart":
            log("restarting instance")
            info = provider.restart(vps, log)
            vps.status = VPSStatus.RUNNING if info.status == "running" else VPSStatus.ERROR
            vps.boot_at = utcnow()
        elif action == "rebuild":
            payload = task.payload_data()
            spec = self._spec_from_payload(payload, vps)
            log(f"rebuilding from {spec.image_reference}")
            info = provider.rebuild(vps, spec, log)
            vps.status = VPSStatus.RUNNING if info.status == "running" else VPSStatus.ERROR
            vps.runtime_id = info.runtime_id or vps.runtime_id
            vps.internal_ip = info.internal_ip or vps.internal_ip
            vps.boot_at = utcnow()
            vps.last_error = ""
        elif action == "delete":
            log("deleting instance and all of its data")
            provider.destroy(vps, log)
            self._finalize_delete(vps, log)
            return
        else:  # pragma: no cover
            raise ValueError(action)

        vps.status_message = ""
        db.session.commit()
        log(f"instance is now {vps.status}")

    def _finalize_delete(self, vps: VPS, log) -> None:
        # Remove any files the provider left behind and the instance directory.
        inst_dir = Path(self.config["INSTANCES_DIR"]) / vps.instance_id
        if inst_dir.exists():
            result = helper_rm(inst_dir, recursive=True)
            log(f"removed files: {result.get('ok')}")
        for backup in list(vps.backups):
            try:
                Path(backup.file_path).unlink(missing_ok=True)
            except OSError:
                pass
            db.session.delete(backup)
        vps.status = VPSStatus.DELETED
        vps.runtime_id = ""
        vps.status_message = "deleted"
        db.session.commit()
        # Keep the row for audit, but release the unique name so it can be reused.
        vps.name = f"{vps.name}-deleted-{vps.id}"
        db.session.commit()
        log("instance record archived as deleted")

    # -------------------------------------------------------------- backups
    def create_backup(self, vps: VPS, user: User, label: str = "") -> tuple[Backup, Task]:
        backup = Backup(
            vps_id=vps.id, label=label or f"snapshot {utcnow():%Y-%m-%d %H:%M}",
            status="creating", created_by_id=user.id,
        )
        db.session.add(backup)
        db.session.flush()
        task = Task(
            kind="backup", title=f"Backup {vps.name}", vps_id=vps.id,
            requested_by_id=user.id,
            payload=json.dumps({"backup_id": backup.id}),
        )
        db.session.add(task)
        db.session.commit()
        self.runner.reserve(f"vps:{vps.id}", task.task_id)
        self.runner.submit(task, self._run_backup, vps.id, backup.id, task.id)
        return backup, task

    def _run_backup(self, task: Task, vps_id: int, backup_id: int, task_id: int) -> None:
        from ..services.tasks import TaskLogger

        log = TaskLogger(task_id, self.app)
        vps = db.session.get(VPS, vps_id)
        backup = db.session.get(Backup, backup_id)
        if vps is None or backup is None:
            raise RuntimeError("instance or backup record not found")

        provider = self.provider_for(vps)
        rootfs = None
        if provider is not None and hasattr(provider, "_rootfs"):
            rootfs = provider._rootfs(vps)
        if rootfs is None or not Path(rootfs).is_dir():
            backup.status = "failed"
            backup.detail = "the root filesystem is not on this host, so a " \
                            "filesystem snapshot cannot be taken"
            db.session.commit()
            raise ProviderError(backup.detail, stage="backup")

        dest = Path(self.config["BACKUP_DIR"]) / f"{vps.instance_id}-{backup.backup_id}.tar.gz"
        log(f"archiving {rootfs} → {dest.name}")
        info = export_rootfs_tar(Path(rootfs), dest,
                                 progress=lambda m: log(m))
        backup.file_path = str(dest)
        backup.size_bytes = info["archive_bytes"]
        backup.status = "ready"
        backup.detail = f"{info['entries']} entries, {info['uncompressed_bytes']} bytes uncompressed"
        db.session.commit()
        log(f"backup ready: {info['archive_bytes'] / 1048576:.1f} MiB, "
            f"{info['entries']} entries")

    # ---------------------------------------------------------- image pulls
    def submit_image_pull(self, image: OSImage, user: User) -> tuple[Task, str]:
        running = Task.query.filter(
            Task.kind == "image_pull", Task.status.in_([TaskStatus.QUEUED,
                                                        TaskStatus.RUNNING])
        ).all()
        for t in running:
            if t.payload_data().get("image_id") == image.id:
                return None, "this image is already being downloaded"
        task = Task(
            kind="image_pull", title=f"Download {image.label}",
            requested_by_id=user.id,
            payload=json.dumps({"image_id": image.id, "reference": image.reference}),
        )
        db.session.add(task)
        image.status = "downloading"
        image.status_detail = "download queued"
        db.session.commit()
        if not self.runner.reserve(f"task:image_pull", task.task_id):
            return None, "another image download is already running"
        self.runner.submit(task, self._run_image_pull, image.id, task.id)
        return task, ""

    def _run_image_pull(self, task: Task, image_id: int, task_id: int) -> None:
        from ..services.tasks import TaskLogger

        log = TaskLogger(task_id, self.app)
        image = db.session.get(OSImage, image_id)
        if image is None:
            raise RuntimeError("image record not found")

        provider, _ = self.provider()
        client = RegistryClient(registry=image.registry or self.config["OCI_REGISTRY"],
                                timeout=self.config["OCI_PULL_TIMEOUT"])
        workdir = Path(self.config["IMAGES_DIR"]) / image.slug
        workdir.mkdir(parents=True, exist_ok=True)
        (workdir / "layers").mkdir(exist_ok=True)
        log(f"pulling {image.reference} from {client.registry}")
        try:
            result = client.fetch_image(image.reference, workdir,
                                        progress=lambda m: log(m), allow_apply=False)
        except RegistryError as exc:
            image.status = "error"
            image.status_detail = str(exc)[:500]
            db.session.commit()
            raise ProviderError(str(exc), stage="pull", retryable=True) from exc

        meta = {
            "reference": result["reference"], "friendly": result["friendly"],
            "digest": result["digest"], "platform": result["platform"],
            "config": result["config"], "total_bytes": result["total_bytes"],
            "layers": [{"index": l["index"], "digest": l["digest"], "size": l["size"],
                        "file": l["file"], "media_type": l["media_type"]}
                       for l in result["layers"]],
            "pulled_at": time.time(),
            "pulled_at_iso": result.get("pulled_at_iso") or
            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        (workdir / "meta.json").write_text(json.dumps(meta, indent=2))
        image.status = "ready"
        image.status_detail = (f"{len(meta['layers'])} layer(s), "
                               f"{result['total_bytes'] / 1048576:.1f} MiB cached")
        image.size_bytes = result["total_bytes"]
        image.digest = result["digest"]
        image.rootfs_path = str(workdir / "layers")
        image.pulled_at = utcnow()
        db.session.commit()
        task.result = json.dumps({"digest": result["digest"],
                                  "layers": len(meta["layers"]),
                                  "bytes": result["total_bytes"]})
        log(f"image {image.label} cached ({image.status_detail})")

    def reconcile_image_cache(self) -> dict:
        """
        Bring the OS image catalogue in line with what is really on disk.

        The database row is a cache of the truth, and the truth is the layer
        files (plus the verified ``meta.json`` written at pull time). This runs
        after a database reset, after a manual cache drop, or when a panel
        operator deletes ``data/images`` by hand, so every screen and API
        reports the same thing: what the host can actually deploy right now.

        A row is only promoted to ``ready`` when the provider confirms the full
        layer set is present, and it is demoted when the layers have vanished —
        the panel never claims a cache it cannot use.
        """
        provider, provider_name = self.provider()
        report = {"provider": provider_name, "checked": 0, "promoted": [],
                  "demoted": [], "ok": True}
        if provider is None:
            report["ok"] = False
            report["reason"] = "no container runtime is available to verify the cache"
            return report

        from datetime import datetime, timezone

        from ..extensions import db

        for image in OSImage.query.order_by(OSImage.id).all():
            report["checked"] += 1
            try:
                ready = provider.image_ready(image.slug)
                meta = provider.image_meta(image.slug) if ready else {}
                size = provider.image_size(image.slug) if ready else 0
            except Exception as exc:  # noqa: BLE001 - a broken cache is data too
                image.status = "error"
                image.status_detail = f"cache could not be verified: {exc}"[:500]
                db.session.commit()
                continue

            if ready and image.status != "ready":
                layers = len(meta.get("layers") or [])
                image.status = "ready"
                image.size_bytes = int(size or meta.get("total_bytes") or 0)
                image.digest = meta.get("digest") or image.digest or ""
                images_root = (self.config.get("IMAGES_DIR") if isinstance(
                    self.config, dict) else getattr(self.config, "IMAGES_DIR", ""))
                image.rootfs_path = str(Path(images_root) / image.slug / "layers")
                image.status_detail = (f"{layers} layer(s), "
                                       f"{image.size_bytes / 1048576:.1f} MiB verified on disk")
                pulled = meta.get("pulled_at")
                if pulled:
                    image.pulled_at = datetime.fromtimestamp(
                        float(pulled), timezone.utc).replace(tzinfo=None)
                elif image.pulled_at is None:
                    image.pulled_at = utcnow()
                report["promoted"].append(image.slug)
            elif not ready and image.status == "ready":
                image.status = "not_downloaded"
                image.size_bytes = 0
                image.status_detail = ("the cached layers are missing from disk; "
                                       "the next deployment will pull them again")
                report["demoted"].append(image.slug)
            db.session.commit()
        return report

    def import_local_image(self, image: OSImage, user: User) -> tuple[Task, str]:
        return self.submit_image_pull(image, user)

    # ------------------------------------------------------------- monitoring
    def refresh_instance(self, vps: VPS, collect_metrics: bool = False) -> VPS:
        """Re-read the truth about one instance from its runtime."""
        provider = self.provider_for(vps, force=False)
        if provider is None:
            if vps.status not in (VPSStatus.DELETED, VPSStatus.ERROR):
                vps.status = VPSStatus.UNKNOWN
                vps.status_message = "no container runtime is available to inspect this instance"
                db.session.commit()
            return vps
        try:
            info = provider.inspect(vps)
        except ProviderError as exc:
            vps.status_message = str(exc)[:240]
            db.session.commit()
            return vps
        except Exception as exc:  # noqa: BLE001
            vps.status_message = f"{type(exc).__name__}: {exc}"[:240]
            db.session.commit()
            return vps

        if vps.status in VPSStatus.TRANSIENT:
            db.session.commit()
            return vps

        if info.status == "running":
            if vps.status != VPSStatus.RUNNING:
                vps.status = VPSStatus.RUNNING
                vps.boot_at = vps.boot_at or utcnow()
            vps.status_message = info.detail or ""
            if info.internal_ip:
                vps.internal_ip = info.internal_ip
            if info.runtime_id:
                vps.runtime_id = info.runtime_id
            if info.ssh_port:
                vps.ssh_port = info.ssh_port
                vps.ssh_enabled = True
        elif info.status == "stopped":
            if vps.status in (VPSStatus.RUNNING, VPSStatus.UNKNOWN,
                              VPSStatus.ERROR):
                vps.status = VPSStatus.STOPPED
                vps.status_message = info.detail or ""
                vps.boot_at = None
        elif info.status == "error":
            vps.status = VPSStatus.ERROR
            vps.status_message = info.detail or "runtime reported an error"

        if collect_metrics:
            try:
                metrics = provider.metrics(vps)
                if metrics.get("available"):
                    vps.set_metrics(metrics)
            except Exception as exc:  # noqa: BLE001
                logger.debug("metrics failed for %s: %s", vps.name, exc)
        db.session.commit()
        return vps

    def refresh_all(self, collect_metrics: bool = True, limit: int = 200) -> dict:
        instances = VPS.query.filter(
            VPS.status != VPSStatus.DELETED
        ).order_by(VPS.id.desc()).limit(limit).all()
        counts = {"checked": 0, "running": 0, "stopped": 0, "errors": 0}
        for vps in instances:
            try:
                self.refresh_instance(vps, collect_metrics=collect_metrics)
                counts["checked"] += 1
                if vps.status == VPSStatus.RUNNING:
                    counts["running"] += 1
                elif vps.status == VPSStatus.STOPPED:
                    counts["stopped"] += 1
                elif vps.status == VPSStatus.ERROR:
                    counts["errors"] += 1
            except Exception as exc:  # noqa: BLE001
                logger.debug("refresh failed for %s: %s", vps.name, exc)
        return counts

    def refresh_local_node(self) -> Node:
        profile = self.profile(force=False)
        res = profile.resources
        node = Node.query.filter_by(is_local=True).first()
        if node is None:
            node = Node(name="local", is_local=True)
            db.session.add(node)
        node.hostname = profile.environment.get("hostname", "")
        if not node.address:
            node.address = "127.0.0.1"
        node.status = "online"
        node.last_seen_at = utcnow()
        node.agent_version = self.app.config["VERSION"]
        node.cpu_cores = res["cpu"]["cores_logical"]
        node.memory_mb = res["memory"]["total_mb"]
        node.disk_gb = int(res.get("disk", {}).get("total_gb", 0))
        node.metrics_json = json.dumps(profile.to_dict(), default=str)
        if not node.provider_hint or node.provider_hint == "auto":
            provider, _ = self.provider()
            node.provider_hint = provider.name if provider else "unavailable"
        db.session.commit()
        return node

    def local_node_address(self) -> str:
        """
        The address a *user* would connect to.  In a sandbox that is the
        forwarded preview host; on a real host it is the first public IPv4.
        Never invented: returns "" when nothing is known.
        """
        import socket

        configured = self.app.config.get("PUBLIC_HOST") or ""
        if configured:
            return configured
        try:
            profile = self.profile()
            egress = self.config["PUBLIC_ADDRESS_HINT"] if isinstance(
                self.config, dict) else ""
            if egress:
                return egress
            # Best effort: the address used for outbound traffic.
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(("1.1.1.1", 80))
                return s.getsockname()[0]
            finally:
                s.close()
        except Exception:
            return ""

    # ----------------------------------------------------------- background
    def start_monitor(self, interval: int = 15) -> None:
        """Continuously reconcile instance state with the real runtime."""
        if self._monitor_thread and self._monitor_thread.is_alive():
            return

        def loop():
            logger.info("instance monitor started (every %ss)", interval)
            try:
                with self.app.app_context():
                    orphans = self.cleanup_orphans()
                    if orphans["killed"]:
                        logger.warning("reaped %d orphan instance process(es) at "
                                       "startup", len(orphans["killed"]))
            except Exception as exc:  # noqa: BLE001
                logger.warning("orphan sweep failed: %s", exc)
            while not self._monitor_stop.is_set():
                try:
                    with self.app.app_context():
                        self.refresh_all(collect_metrics=True)
                        self.enforce_expiry()
                        self.cleanup_orphans()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("monitor iteration failed: %s", exc)
                self._monitor_stop.wait(interval)

        self._monitor_thread = threading.Thread(
            target=loop, name="skvm-monitor", daemon=True
        )
        self._monitor_thread.start()

    def stop_monitor(self) -> None:
        self._monitor_stop.set()

    def cleanup_orphans(self) -> dict:
        """
        Kill instance supervisors that no longer belong to a live instance.

        A crash or a failed provisioning attempt can leave an ``ns-launch``
        process (and its netns/cgroup) behind.  Orphans are detected from the
        real process list, then stopped through the provider so the network
        namespace, cgroup and filesystem are cleaned up together.
        """
        import glob
        import re as _re

        killed: list[str] = []
        instances_dir = Path(self.app.config["INSTANCES_DIR"])
        if not instances_dir.is_dir():
            return {"checked": 0, "killed": []}

        live = {v.instance_id: v for v in VPS.query.all()}
        # Match the supervisor command line: ns-launch --rootfs <dir> ...
        pattern = _re.compile(r"ns-launch .*--rootfs (\S+)")
        for proc in psutil.process_iter(["pid", "cmdline"]):
            try:
                cmdline = " ".join(proc.info.get("cmdline") or [])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            if "ns-launch" not in cmdline:
                continue
            match = pattern.search(cmdline)
            if not match:
                continue
            rootfs = Path(match.group(1))
            instance_id = rootfs.parent.name
            vps = live.get(instance_id)
            if vps is not None and vps.status not in (VPSStatus.DELETED,
                                                      VPSStatus.ERROR):
                continue
            provider = self.provider_for(vps) if vps is not None else self.provider()[0]
            logger.warning("cleaning up orphan supervisor pid %s (%s)",
                           proc.info["pid"], instance_id)
            killed.append(instance_id)
            if vps is not None and provider is not None:
                try:
                    provider.destroy(vps, lambda message: logger.info("%s", message))
                except Exception as exc:  # noqa: BLE001
                    logger.debug("provider destroy failed for %s: %s", instance_id, exc)
            else:
                # No database row left: stop the process group and drop the
                # cgroup / netns by name.
                try:
                    os.killpg(os.getpgid(proc.info["pid"]), signal.SIGTERM)
                except OSError:
                    try:
                        os.kill(proc.info["pid"], signal.SIGTERM)
                    except OSError:
                        pass
                for entry in glob.glob(f"/sys/fs/cgroup/skvm/skvm-{instance_id}"):
                    helper_cgroup_destroy(f"skvm-{instance_id}")
                    logger.info("removed leftover cgroup %s", entry)

        # Network namespaces, veths and cgroups can outlive the supervisor that
        # created them: if a provisioning task is killed (panel restart, OOM,
        # lost sandbox) nothing is left to notice, and the panel's own view of
        # the host stays wrong until the next reboot. Reap them by name.
        swept = []
        try:
            listing = netns_list()
        except Exception as exc:  # noqa: BLE001 - the sweep is best effort
            logger.warning("could not list namespaces for the orphan sweep: %s", exc)
            listing = {}
        keep = {v.instance_id for v in live.values()
                if v.status not in (VPSStatus.DELETED, VPSStatus.ERROR,
                                    VPSStatus.STOPPED, VPSStatus.SUSPENDED)}
        veths = list(listing.get("veths") or [])
        # Never touch the network of an instance the panel still considers live.
        keep_veths = {(f"vh{iid[-10:].lower().replace('_', '-')}"[:15], iid)
                      for iid in keep}
        keep_veth_names = {name for name, _ in keep_veths}
        for name in listing.get("netns") or []:
            instance_id = name[len("skvm-"):] if name.startswith("skvm-") else name
            if instance_id in keep:
                continue
            tail = instance_id[-10:].lower().replace("_", "-")
            host_veth = next((v for v in veths if v.endswith(tail)), f"vh{tail}"[:15])
            if host_veth in keep_veth_names:
                logger.debug("skipping %s: it belongs to a live instance", name)
                continue
            try:
                netns_destroy(name, host_veth)
                swept.append(name)
                logger.warning("removed orphan namespace %s (veth %s)",
                               name, host_veth)
                veths = [v for v in veths if v != host_veth]
            except Exception as exc:  # noqa: BLE001
                logger.warning("could not remove orphan namespace %s: %s", name, exc)
            try:
                helper_cgroup_destroy(name)
            except Exception:  # noqa: BLE001 - may simply not exist
                pass
        for veth in veths:
            if veth in keep_veth_names:
                continue
            try:
                veth_destroy(veth)
                swept.append(veth)
                logger.warning("removed orphan veth %s", veth)
            except Exception:  # noqa: BLE001
                pass
        return {"checked": len(live), "killed": killed, "swept": swept}

    def enforce_expiry(self) -> dict:
        """Suspend or stop expired instances — never silently delete data."""
        now = utcnow()
        expired = VPS.query.filter(
            VPS.expires_at.isnot(None), VPS.expires_at <= now,
            VPS.status.notin_([VPSStatus.DELETED, VPSStatus.SUSPENDED]),
        ).all()
        suspended = 0
        stopped = 0
        for vps in expired:
            if vps.suspend_on_expiry:
                if vps.status == VPSStatus.RUNNING:
                    provider = self.provider_for(vps)
                    if provider:
                        try:
                            provider.stop(vps, lambda m, p=None: None, force=False)
                            stopped += 1
                        except Exception as exc:  # noqa: BLE001
                            logger.warning("could not stop expired %s: %s",
                                           vps.name, exc)
                vps.status = VPSStatus.SUSPENDED
                vps.status_message = "suspended: the expiry date has passed"
                suspended += 1
        db.session.commit()
        return {"expired": len(expired), "suspended": suspended, "stopped": stopped}


def disk_usage_for(vps: VPS, config) -> int:
    """Real on-disk size of an instance rootfs (0 when it is not local)."""
    rootfs = Path(config["INSTANCES_DIR"]) / vps.instance_id / "rootfs"
    if not rootfs.exists():
        return 0
    result = helper_du(rootfs)
    return int(result.get("actual_bytes") or 0) if result.get("ok") else 0
