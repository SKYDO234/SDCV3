"""
Runtime / capability probing.

This module is the single source of truth for *what this host can actually do*.
Nothing in the panel may claim a capability that this probe did not verify.

It deliberately never guesses:
  * a provider is `available` only after a live check succeeded;
  * every negative result carries a human readable `reason` and a `remedy`.
"""
from __future__ import annotations

import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import psutil

# --------------------------------------------------------------------------
# sudo broker — strict allowlist, never a shell
# --------------------------------------------------------------------------
_SUDO_CACHE: dict[str, object] = {"checked": False, "available": False, "detail": ""}

#: Only these binaries may ever be executed through sudo by SKVM, and always
#: with an explicit argv list (``shell=False``).  This is the single choke
#: point that prevents command injection from reaching a privileged context.
SUDO_ALLOWLIST = {
    # SKVM's own audited entrypoints (the only ones that mutate the filesystem)
    "skvm-helper", "ns-launch",
    # namespace / networking plumbing
    "unshare", "nsenter", "mount", "umount", "ip", "sysctl", "kill",
    # container runtimes
    "docker", "lxc-start", "lxc-stop", "lxc-info", "lxc-attach",
    "lxc-create", "lxc-destroy", "lxc-ls", "lxcfs", "systemctl",
    # read-only inspection
    "ls", "stat", "readlink", "truncate",
    # filesystem helpers used with explicit argv only
    "mkdir", "rmdir", "chmod", "chown", "tee", "sh",
}

#: `sh -c` is allowed only for a fixed, audited set of one-liners.
SHELL_ALLOWED_PREFIXES = (
    "printf ", "test ", "exec ",
)

#: Never allow these arguments anywhere in a privileged argv.
FORBIDDEN_ARG_TOKENS = (";", "&&", "||", "`", "$(", "\n", ">", "<", "|")


def is_admin() -> bool:
    try:
        return os.geteuid() == 0
    except AttributeError:  # pragma: no cover - non POSIX
        return False


def _run(argv: list[str], timeout: int = 12, input_text: str | None = None):
    try:
        proc = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            input=input_text,
            check=False,
        )
        return proc.returncode, (proc.stdout or "").strip(), (proc.stderr or "").strip()
    except subprocess.TimeoutExpired:
        return 124, "", f"timed out after {timeout}s"
    except FileNotFoundError as exc:
        return 127, "", str(exc)
    except Exception as exc:  # pragma: no cover
        return 1, "", str(exc)


def probe_sudo(force: bool = False) -> dict:
    """Determine whether ``sudo -n`` works without a password."""
    if _SUDO_CACHE["checked"] and not force:
        return dict(_SUDO_CACHE)
    if is_admin():
        _SUDO_CACHE.update(checked=True, available=True, detail="already running as root")
        return dict(_SUDO_CACHE)
    if not shutil.which("sudo"):
        _SUDO_CACHE.update(checked=True, available=False, detail="sudo not installed")
        return dict(_SUDO_CACHE)
    rc, out, err = _run(["sudo", "-n", "true"], timeout=8)
    if rc == 0:
        _SUDO_CACHE.update(
            checked=True, available=True, detail="passwordless sudo verified"
        )
    else:
        reason = err or out or "sudo refused"
        _SUDO_CACHE.update(
            checked=True,
            available=False,
            detail=(
                f"passwordless sudo unavailable ({reason.splitlines()[0][:160]})"
                if reason else "passwordless sudo unavailable"
            ),
        )
    return dict(_SUDO_CACHE)


def validate_argv(argv: list[str]) -> tuple[bool, str]:
    """Reject an argv that could escape the allowlist."""
    if not argv:
        return False, "empty argv"
    binary = os.path.basename(argv[0])
    if binary not in SUDO_ALLOWLIST:
        return False, f"'{binary}' is not on the privileged allowlist"
    if binary == "sh":
        if len(argv) < 3 or argv[1] != "-c":
            return False, "sh may only be used as: sh -c '<audited snippet>'"
        snippet = argv[2]
        if not snippet.startswith(SHELL_ALLOWED_PREFIXES):
            return False, "shell snippet is not an audited, allowlisted snippet"
    for arg in argv[1:]:
        if any(tok in arg for tok in FORBIDDEN_ARG_TOKENS):
            return False, f"argument contains a forbidden shell token: {arg!r}"
    return True, ""


def run_privileged(argv: list[str], timeout: int = 30, use_sudo: bool = True):
    """Execute an allowlisted command, escalating via sudo only if required.

    Returns ``(rc, stdout, stderr)``.  Never raises, never uses a shell unless
    the binary itself is the audited ``sh -c`` form.
    """
    ok, why = validate_argv(argv)
    if not ok:
        return 1, "", f"privileged argv rejected: {why}"
    if is_admin():
        return _run(argv, timeout=timeout)
    if not use_sudo:
        return _run(argv, timeout=timeout)
    if not probe_sudo().get("available"):
        return 1, "", "privileges required but passwordless sudo is unavailable"
    return _run(["sudo", "-n", *argv], timeout=timeout)


# --------------------------------------------------------------------------
# individual capability checks
# --------------------------------------------------------------------------
@dataclass
class Capability:
    key: str
    label: str
    available: bool
    detail: str = ""
    reason: str = ""
    remedy: str = ""
    level: str = "info"  # ok | info | warn | blocked

    def to_dict(self) -> dict:
        return asdict(self)


def _cap(key, label, available, detail="", reason="", remedy="", level=None) -> Capability:
    if level is None:
        level = "ok" if available else ("warn" if remedy else "blocked")
    return Capability(key, label, bool(available), detail, reason, remedy, level)


def detect_environment() -> dict:
    """Identify the hosting environment we are running inside."""
    markers = {
        "e2b": bool(os.environ.get("E2B_SANDBOX") or os.environ.get("E2B_SANDBOX_ID")),
        "codesandbox": bool(
            os.environ.get("CSB_REPOSITORY") or os.environ.get("CODESANDBOX_SSE")
            or os.environ.get("CSB_SANDBOX")
        ),
        "gitpod": bool(os.environ.get("GITPOD_WORKSPACE_ID")),
        "devcontainer": Path("/.dockerenv").exists(),
        "replit": bool(os.environ.get("REPL_ID")),
        "heroku": bool(os.environ.get("DYNO")),
    }
    in_container = False
    detail = ""
    try:
        cgroup = Path("/proc/self/cgroup").read_text(errors="ignore")
        if "docker" in cgroup or "containerd" in cgroup or "kubepods" in cgroup:
            in_container = True
        if Path("/.dockerenv").exists() or Path("/run/.containerenv").exists():
            in_container = True
    except OSError:
        pass

    name = "dedicated host"
    if markers["e2b"]:
        name = "RigBox / E2B sandbox"
    elif markers["codesandbox"]:
        name = "CodeSandbox"
    elif markers["gitpod"]:
        name = "Gitpod"
    elif markers["replit"]:
        name = "Replit"
    elif in_container:
        name = "container (non-sandbox)"

    return {
        "name": name,
        "is_sandbox": any(v for k, v in markers.items() if k != "devcontainer") or in_container,
        "in_container": in_container,
        "markers": {k: v for k, v in markers.items() if v},
        "sandbox_id": os.environ.get("E2B_SANDBOX_ID", "") or os.environ.get("CSB_SANDBOX", ""),
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "kernel": platform.release(),
        "machine": platform.machine(),
        "python": sys.version.split()[0],
        "preview_host": os.environ.get("SKVM_PREVIEW_HOST", ""),
    }


def detect_virtualization() -> dict:
    """Detect whether we are inside a VM and whether /dev/kvm exists."""
    out = {"is_vm": False, "virt_type": "unknown", "kvm_device": False, "nested": None}
    try:
        rc, stdout, _ = _run(["systemd-detect-virt"], timeout=6)
        if rc == 0 and stdout:
            out["virt_type"] = stdout.strip()
            out["is_vm"] = stdout.strip() not in ("none",)
    except Exception:
        pass
    if out["virt_type"] == "unknown":
        try:
            cpuinfo = Path("/proc/cpuinfo").read_text(errors="ignore")
            if "GenuineIntel" in cpuinfo or "AuthenticAMD" in cpuinfo:
                out["virt_type"] = "bare-metal-or-hvm"
        except OSError:
            pass
    kvm = Path("/dev/kvm")
    if kvm.exists():
        out["kvm_device"] = os.access(str(kvm), os.R_OK | os.W_OK)
    return out


def cgroup_version() -> str:
    try:
        if Path("/sys/fs/cgroup/cgroup.controllers").exists():
            return "v2"
        stat = Path("/proc/self/cgroup").read_text(errors="ignore")
        return "v1" if stat.strip() else "none"
    except OSError:
        return "none"


def detect_cgroups() -> Capability:
    ver = cgroup_version()
    if ver == "none":
        return _cap(
            "cgroups", "Control groups", False,
            reason="no cgroup filesystem detected",
            remedy="Run on a Linux host with cgroup v1/v2 mounted.",
        )
    root = Path("/sys/fs/cgroup")
    writable_now = os.access(str(root), os.W_OK)
    sudo_info = probe_sudo()
    # Try a real, reversible write test through the privileged path.
    probe_dir = root / "skvm-probe"
    can_create = False
    detail = ""
    if writable_now:
        try:
            probe_dir.mkdir(exist_ok=True)
            can_create = True
        except OSError as exc:
            detail = str(exc)
    if not can_create and sudo_info.get("available"):
        rc, _, err = run_privileged(["mkdir", "-p", str(probe_dir)], timeout=8)
        can_create = rc == 0
        if rc != 0:
            detail = err
        else:
            run_privileged(["rmdir", str(probe_dir)], timeout=8)

    controllers = ""
    try:
        if ver == "v2":
            controllers = Path("/sys/fs/cgroup/cgroup.controllers").read_text().strip()
        else:
            controllers = ",".join(
                p.name for p in Path("/sys/fs/cgroup").iterdir() if p.is_dir()
            )
    except OSError:
        pass

    if can_create:
        return _cap(
            "cgroups", "Control groups", True,
            detail=f"cgroup {ver}; controllers: {controllers or 'n/a'}; writable "
                   f"({'direct' if writable_now else 'via sudo'})",
        )
    return _cap(
        "cgroups", "Control groups", False,
        detail=f"cgroup {ver}; controllers: {controllers or 'n/a'}",
        reason=detail or "cgroup hierarchy is read-only for this process",
        remedy="Resource limits fall back to POSIX rlimits (CPU time, address "
               "space, process count, file size) which are still kernel-enforced.",
    )


def detect_namespaces() -> Capability:
    """Live-test unprivileged user + PID + mount namespaces."""
    if platform.system() != "Linux":
        return _cap(
            "namespaces", "Linux namespaces", False,
            reason="not a Linux host", remedy="SKVM isolation requires Linux.",
        )
    unshare = shutil.which("unshare")
    if not unshare:
        return _cap(
            "namespaces", "Linux namespaces", False,
            reason="`unshare` (util-linux) is not installed",
            remedy="Install util-linux.",
        )
    # 1) unprivileged user namespace
    rc, out, err = _run([unshare, "-Ur", "--pid", "--fork", "--mount",
                         "true"], timeout=12)
    userns = rc == 0
    userns_err = err
    if not userns:
        return _cap(
            "namespaces", "Linux namespaces", False,
            reason=f"unprivileged user namespaces unavailable ({userns_err[:160]})",
            remedy="Enable kernel.unprivileged_userns_clone=1 / user.max_user_namespaces>0.",
        )
    # 2) full stack with a real payload
    secret = f"skvm-{int(time.time())}"
    rc2, out2, err2 = _run(
        [unshare, "-Ur", "--pid", "--fork", "--mount", "--uts", "--ipc",
         "/bin/sh", "-c", f"echo {secret}"],
        timeout=15,
    )
    full = rc2 == 0 and secret in out2
    if full:
        return _cap(
            "namespaces", "Linux namespaces", True,
            detail="user + PID + mount + UTS + IPC namespaces verified",
        )
    return _cap(
        "namespaces", "Linux namespaces", False,
        detail="user namespace works, full stack failed",
        reason=err2[:200] or "namespace stack did not start",
        remedy="Check seccomp/AppArmor policy for the sandbox.",
    )


def detect_network_namespace() -> Capability:
    rc, _, err = run_privileged(["unshare", "-n", "true"], timeout=10)
    if rc == 0:
        return _cap(
            "netns", "Network namespaces", True,
            detail="privileged network namespace creation verified",
        )
    sudo_info = probe_sudo()
    return _cap(
        "netns", "Network namespaces", False,
        reason=(err[:200] or "network namespace creation denied"),
        remedy=("Instances share the host network namespace. They keep working "
                "and bind ports on the host; they simply do not receive a "
                "dedicated IP."),
        level="info",
    )


def detect_docker() -> Capability:
    socket_path = os.environ.get("SKVM_DOCKER_SOCKET", "/var/run/docker.sock")
    dhost = os.environ.get("DOCKER_HOST", "")
    candidates = [dhost] if dhost else [f"unix://{socket_path}"]
    for extra in ("/var/run/docker.sock", "/run/docker.sock"):
        if f"unix://{extra}" not in candidates:
            candidates.append(f"unix://{extra}")

    reachable = None
    for cand in candidates:
        if cand.startswith("unix://"):
            path = cand[len("unix://"):]
            if Path(path).exists():
                reachable = cand
                break
        elif cand.startswith(("tcp://", "http://", "https://")):
            reachable = cand
            break

    if shutil.which("docker") and not reachable:
        # CLI exists; try to discover the active context endpoint.
        rc, out, _ = _run(["docker", "context", "inspect", "-f",
                           "{{.Endpoints.docker.Host}}"], timeout=8)
        if rc == 0 and out:
            reachable = out.strip()

    if not reachable:
        return _cap(
            "docker", "Docker engine", False,
            reason="no Docker daemon socket or DOCKER_HOST configured",
            remedy=("On a real host install Docker and expose /var/run/docker.sock. "
                    "Inside a restricted sandbox nested Docker is usually not "
                    "permitted — the panel reports this instead of pretending."),
        )
    try:
        import docker as docker_sdk

        client = docker_sdk.DockerClient(base_url=reachable, timeout=8)
        version = client.version()
        info = client.info()
        client.close()
        return _cap(
            "docker", "Docker engine", True,
            detail=(f"API {version.get('ApiVersion')}, engine "
                    f"{version.get('Version')} on {info.get('OperatingSystem', '')} "
                    f"({reachable})"),
        )
    except Exception as exc:
        return _cap(
            "docker", "Docker engine", False,
            detail=f"endpoint {reachable} present but unusable",
            reason=f"{type(exc).__name__}: {str(exc)[:200]}",
            remedy="Ensure the daemon is running and the socket is accessible.",
        )


def detect_lxc() -> Capability:
    binaries = {b: shutil.which(b) for b in ("lxc-start", "lxc-info", "lxc-ls")}
    missing = [b for b, p in binaries.items() if not p]
    if missing:
        return _cap(
            "lxc", "LXC / Incus", False,
            reason=f"missing binaries: {', '.join(missing)}",
            remedy="Install the `lxc` package on a host where privileged "
                   "containers are permitted.",
        )
    rc, out, err = run_privileged(["lxc-ls", "--version"], timeout=10)
    rc2, out2, err2 = run_privileged(["lxc-ls", "-1"], timeout=15)
    if rc == 0:
        return _cap(
            "lxc", "LXC / Incus", True,
            detail=f"{out or out2.splitlines()[0] if out2 else 'lxc available'}; "
                   f"{len([l for l in out2.splitlines() if l.strip()])} container(s) present",
        )
    return _cap(
        "lxc", "LXC / Incus", False,
        detail="binaries present but not usable",
        reason=(err2 or err or "lxc-ls failed")[:200],
        remedy="LXC requires root/CAP_SYS_ADMIN; inside an unprivileged sandbox "
               "this is expected to fail.",
    )


def detect_lxcfs() -> Capability:
    path = Path(os.environ.get("SKVM_LXCFS_PATH", "/var/lib/lxcfs"))
    binary = shutil.which("lxcfs")
    mounted = False
    mount_detail = ""
    try:
        for line in Path("/proc/self/mountinfo").read_text(errors="ignore").splitlines():
            if "lxcfs" in line:
                mounted = True
                mount_detail = line.split(" - ")[-1][:160]
                break
    except OSError:
        pass
    if not path.exists() and not binary:
        return _cap(
            "lxcfs", "LXCFS", False,
            reason="lxcfs is not installed",
            remedy=("LXCFS only virtualises /proc/meminfo, /proc/cpuinfo, "
                    "/proc/uptime and cgroup files so containers see their own "
                    "limits. It is not a virtualization engine; SKVM functions "
                    "without it and reads real cgroup/psutil data instead."),
            level="info",
        )
    if mounted or path.exists():
        procs = []
        for name in ("meminfo", "cpuinfo", "uptime"):
            p = path / "proc" / name
            if p.exists():
                procs.append(name)
        return _cap(
            "lxcfs", "LXCFS", True,
            detail=f"found at {path}"
                   + (f" (virtualises {', '.join(procs)})" if procs else "")
                   + (f"; {mount_detail}" if mount_detail else ""),
        )
    return _cap(
        "lxcfs", "LXCFS", False,
        detail=f"binary at {binary}",
        reason="binary present but not mounted",
        remedy="Mount lxcfs at /var/lib/lxcfs (systemctl start lxcfs).",
        level="info",
    )


def detect_overlayfs() -> Capability:
    try:
        filesystems = Path("/proc/filesystems").read_text(errors="ignore")
    except OSError:
        filesystems = ""
    if "overlay" in filesystems:
        return _cap("overlayfs", "Overlay filesystem", True,
                    detail="overlay2 storage driver usable")
    return _cap(
        "overlayfs", "Overlay filesystem", False,
        reason="overlay not listed in /proc/filesystems",
        remedy="SKVM falls back to plain directory root filesystems.",
        level="info",
    )


def detect_kvm() -> Capability:
    kvm = Path("/dev/kvm")
    if kvm.exists() and os.access(str(kvm), os.R_OK | os.W_OK):
        return _cap("kvm", "KVM hardware virtualization", True,
                    detail="/dev/kvm accessible")
    return _cap(
        "kvm", "KVM hardware virtualization", False,
        reason="/dev/kvm is absent or not accessible",
        remedy=("Without /dev/kvm no true virtual machine can be created. "
                "SKVM provisions containers and labels them as containers — it "
                "will never call a container a KVM VPS."),
        level="info",
    )


def detect_privileges() -> Capability:
    if is_admin():
        return _cap("privileges", "Root privileges", True, detail="process runs as uid 0")
    info = probe_sudo()
    if info.get("available"):
        return _cap("privileges", "Root privileges", True,
                    detail="not root, but passwordless sudo verified for "
                           "allowlisted helper commands")
    return _cap(
        "privileges", "Root privileges", False,
        reason=info.get("detail", "no root and no passwordless sudo"),
        remedy=("Unprivileged mode: instances still run with real user/PID/mount "
                "namespaces and kernel-enforced rlimits, but cgroup limits, extra "
                "network namespaces and host-level mounts are unavailable."),
        level="info",
    )


def detect_ports() -> Capability:
    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.laddr and conn.laddr.port == 2375:
                return _cap("docker_tcp", "Docker TCP endpoint", True,
                            detail="port 2375 listening")
    except Exception:
        pass
    return _cap("docker_tcp", "Docker TCP endpoint", False,
                reason="nothing listening on tcp/2375",
                level="info")


def detect_egress() -> Capability:
    """
    Prove the container registry is really usable for image pulls.

    A plain anonymous ``GET /v2/`` is *not* a valid probe: the Docker Registry
    HTTP API v2 answers unauthenticated requests with ``401`` plus a
    ``WWW-Authenticate: Bearer realm=…`` challenge by design, so treating that
    as an outage reports the registry as unavailable on a perfectly working
    host. The real test is the whole anonymous auth round-trip — a token for a
    public repository, which is exactly what ``oci.py`` does before a pull.
    """
    import json
    import urllib.error
    import urllib.parse
    import urllib.request

    challenge = ""
    probe_url = "https://registry-1.docker.io/v2/"
    try:
        with urllib.request.urlopen(  # noqa: S310
                urllib.request.Request(probe_url, method="GET"), timeout=8) as resp:
            return _cap("registry", "Container registry reachable", True,
                        detail=f"HTTP {resp.status} from registry-1.docker.io")
    except urllib.error.HTTPError as exc:
        challenge = exc.headers.get("WWW-Authenticate", "") if exc.headers else ""
        if exc.code not in (401, 403):
            return _cap(
                "registry", "Container registry reachable", False,
                reason=f"HTTP {exc.code} {exc.reason} from registry-1.docker.io",
                remedy="Image pulls require outbound HTTPS to registry-1.docker.io.",
            )
        if "Bearer" not in challenge:
            return _cap(
                "registry", "Container registry reachable", False,
                reason=f"HTTP {exc.code} with no Bearer challenge "
                       f"(WWW-Authenticate: {challenge or 'absent'})",
                remedy="The endpoint answered but is not a token-authenticated "
                       "registry; check for an intercepting proxy.",
            )
    except Exception as exc:  # noqa: BLE001 - DNS, TLS, timeouts…
        return _cap(
            "registry", "Container registry reachable", False,
            reason=f"{type(exc).__name__}: {str(exc)[:160]}",
            remedy="Image pulls require outbound HTTPS to registry-1.docker.io.",
        )

    # 401 + challenge: now complete the auth round-trip for a real repository.
    auth_host = "auth.docker.io"
    match = re.search(r'realm="https?://([^/"]+)', challenge)
    if match:
        auth_host = match.group(1)
    query = urllib.parse.urlencode({"service": "registry.docker.io",
                                    "scope": "repository:library/alpine:pull"})
    try:
        with urllib.request.urlopen(  # noqa: S310
                urllib.request.Request(f"https://{auth_host}/token?{query}",
                                       headers={"User-Agent": "SKVM/1.0"},
                                       method="GET"), timeout=8) as resp:
            payload = json.loads(resp.read().decode())
    except Exception as exc:  # noqa: BLE001
        return _cap(
            "registry", "Container registry reachable", False,
            reason=f"auth challenge received, but no token from {auth_host}: "
                   f"{type(exc).__name__}: {str(exc)[:120]}",
            remedy="The registry answered 401 and the token endpoint is "
                   "unreachable; image pulls will fail.",
        )
    token = payload.get("token") or payload.get("access_token") or ""
    if not token:
        return _cap(
            "registry", "Container registry reachable", False,
            reason=f"token endpoint {auth_host} returned no token",
            remedy="Anonymous pulls are refused by the registry.",
        )
    return _cap(
        "registry", "Container registry reachable", True,
        detail=f"anonymous pull token obtained from {auth_host} for "
               f"library/alpine ({len(token)} byte token)",
    )


def detect_ssh_capability() -> Capability:
    sshd = shutil.which("sshd") or shutil.which("/usr/sbin/sshd")
    if sshd:
        return _cap("sshd", "SSH server available", True, detail=sshd)
    return _cap(
        "sshd", "SSH server available", False,
        reason="no sshd binary on this host",
        remedy=("SSH access is offered only when a real sshd can be installed "
                "inside the instance. The panel never prints placeholder SSH "
                "credentials; use the web console instead."),
        level="info",
    )


def detect_tmate() -> Capability:
    binary = shutil.which("tmate")
    if binary:
        return _cap("tmate", "tmate sessions", True, detail=binary)
    return _cap(
        "tmate", "tmate sessions", False,
        reason="tmate is not installed",
        remedy="tmate sharing is hidden entirely rather than showing fake keys.",
        level="info",
    )


# --------------------------------------------------------------------------
# host resources
# --------------------------------------------------------------------------
def host_resources() -> dict:
    vm = psutil.virtual_memory()
    try:
        du = psutil.disk_usage("/")
        disk = {"total_gb": round(du.total / 1e9, 1),
                "used_gb": round(du.used / 1e9, 1),
                "free_gb": round(du.free / 1e9, 1),
                "percent": du.percent}
    except Exception:
        disk = {}
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except (OSError, AttributeError):
        load = []
    boot = psutil.boot_time()
    return {
        "cpu": {
            "cores_logical": psutil.cpu_count(logical=True) or 0,
            "cores_physical": psutil.cpu_count(logical=False) or 0,
            "percent": psutil.cpu_percent(interval=0.15),
            "load_avg": load,
        },
        "memory": {
            "total_mb": round(vm.total / 1048576),
            "used_mb": round((vm.total - vm.available) / 1048576),
            "available_mb": round(vm.available / 1048576),
            "percent": vm.percent,
            "swap_total_mb": round(psutil.swap_memory().total / 1048576),
        },
        "disk": disk,
        "boot_time": boot,
        "uptime_seconds": int(time.time() - boot),
    }


# --------------------------------------------------------------------------
# aggregate probe
# --------------------------------------------------------------------------
class RuntimeProfile:
    """Immutable snapshot of host capabilities."""

    def __init__(self, data: dict):
        self._d = data

    def __getattr__(self, item):
        try:
            return self._d[item]
        except KeyError as exc:  # pragma: no cover
            raise AttributeError(item) from exc

    def to_dict(self) -> dict:
        """
        A *copy* of the snapshot.

        Callers (the UI, the API) routinely reshape this payload — returning the
        live internal mapping would let them replace ``Capability`` objects with
        plain dicts and break later probes.
        """
        data = dict(self._d)
        data["capabilities"] = {
            key: (cap.to_dict() if hasattr(cap, "to_dict") else cap)
            for key, cap in (self._d.get("capabilities") or {}).items()
        }
        data["providers"] = [dict(p) for p in self._d.get("providers", [])]
        data["environment"] = dict(self._d.get("environment") or {})
        data["resources"] = dict(self._d.get("resources") or {})
        return data

    # -- convenience
    @property
    def caps(self) -> dict[str, Capability]:
        return self._d["capabilities"]

    def cap(self, key: str):
        c = self.caps.get(key)
        if isinstance(c, dict):          # already serialised — tolerate it
            return Capability(key=key, label=c.get("label", key),
                              available=bool(c.get("available")),
                              detail=c.get("detail", ""), reason=c.get("reason", ""),
                              remedy=c.get("remedy", ""),
                              level=c.get("level", "info"))
        return c

    def available(self, key: str) -> bool:
        c = self.cap(key)
        return bool(c and c.available)

    @property
    def providers(self) -> list[dict]:
        return self._d["providers"]

    def provider(self, name: str) -> dict | None:
        for p in self.providers:
            if p["name"] == name:
                return p
        return None

    @property
    def has_any_provider(self) -> bool:
        return any(p["available"] for p in self.providers)

    @property
    def summary(self) -> dict:
        total = len(self.providers)
        ok = len([p for p in self.providers if p["available"]])
        return {"providers_total": total, "providers_available": ok}

    def diagnostics(self) -> list[dict]:
        """Actionable list of what is missing and why."""
        out = []
        for cap in self.caps.values():
            if not cap.available and cap.reason:
                out.append({
                    "key": cap.key,
                    "label": cap.label,
                    "reason": cap.reason,
                    "remedy": cap.remedy,
                    "severity": "warning" if cap.remedy else "info",
                })
        return out


def full_probe(include_slow: bool = True) -> RuntimeProfile:
    """Run every capability check and build provider availability."""
    from .providers import build_provider_descriptors

    caps: dict[str, Capability] = {}
    env = detect_environment()
    virtual = detect_virtualization()

    caps["privileges"] = detect_privileges()
    caps["namespaces"] = detect_namespaces()
    caps["cgroups"] = detect_cgroups()
    caps["netns"] = detect_network_namespace()
    caps["overlayfs"] = detect_overlayfs()
    caps["kvm"] = detect_kvm()
    caps["docker"] = detect_docker()
    caps["lxc"] = detect_lxc()
    caps["lxcfs"] = detect_lxcfs()
    caps["sshd"] = detect_ssh_capability()
    caps["tmate"] = detect_tmate()
    if include_slow:
        caps["registry"] = detect_egress()

    providers = build_provider_descriptors(caps)

    data = {
        "environment": env,
        "virtualization": virtual,
        "cgroup_version": cgroup_version(),
        "resources": host_resources(),
        "capabilities": caps,
        "providers": providers,
        "probed_at": time.time(),
        "probed_at_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "has_any_provider": any(p["available"] for p in providers),
        # Honest top-level statements used by the UI banner.
        "isolation_note": (
            "SKVM provisions Linux containers. None of the available backends "
            "creates a KVM virtual machine."
        ),
    }
    profile = RuntimeProfile(data)
    data["summary"] = profile.summary
    return profile


_PROFILE_CACHE: dict[str, object] = {"profile": None, "at": 0.0}


def get_profile(force: bool = False, max_age: int = 60) -> RuntimeProfile:
    """Cached probe (default 60s) so dashboards stay fast."""
    now = time.time()
    cached = _PROFILE_CACHE.get("profile")
    if cached and not force and (now - float(_PROFILE_CACHE["at"])) < max_age:
        return cached  # type: ignore[return-value]
    profile = full_probe()
    _PROFILE_CACHE["profile"] = profile
    _PROFILE_CACHE["at"] = now
    return profile
