"""
Minimal but real OCI / Docker Registry v2 client.

Used to materialise instance root filesystems from genuine upstream images
(Ubuntu 20.04/22.04, Debian 11/12) when no Docker daemon is available.

It implements the actual protocol: anonymous token auth, manifest negotiation
(including multi-arch indexes), blob downloads with digest verification, and
OCI layer whiteout semantics (applied by the privileged helper).

No image content is ever fabricated: if the registry is unreachable the pull
fails loudly and the task records the HTTP error.
"""
from __future__ import annotations

import hashlib
import json
import platform
import shutil
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_REGISTRY = "registry-1.docker.io"
DOCKER_AUTH = "auth.docker.io"
USER_AGENT = "SKVM/1.0 (+https://github.com/skvm-panel)"

MANIFEST_TYPES = ", ".join([
    "application/vnd.oci.image.index.v1+json",
    "application/vnd.docker.distribution.manifest.list.v2+json",
    "application/vnd.oci.image.manifest.v1+json",
    "application/vnd.docker.distribution.manifest.v2+json",
])


class RegistryError(RuntimeError):
    """Raised for any pull failure, carrying the real upstream reason."""


@dataclass
class ImageRef:
    registry: str
    repository: str
    tag: str
    digest: str = ""

    @property
    def canonical(self) -> str:
        ref = f"{self.registry}/{self.repository}"
        return f"{ref}@{self.digest}" if self.digest else f"{ref}:{self.tag}"

    @property
    def friendly(self) -> str:
        repo = self.repository
        if repo.startswith("library/"):
            repo = repo[len("library/"):]
        suffix = f"@{self.digest[:19]}…" if self.digest else f":{self.tag}"
        return f"{repo}{suffix}"


def parse_reference(reference: str, default_registry: str = DEFAULT_REGISTRY) -> ImageRef:
    """
    Parse `ubuntu:22.04`, `library/debian:12`, `ghcr.io/org/img:tag`
    or `ubuntu@sha256:...` into an ImageRef.
    """
    ref = (reference or "").strip()
    if not ref:
        raise RegistryError("empty image reference")

    digest = ""
    if "@" in ref:
        ref, _, digest = ref.partition("@")

    registry = default_registry
    # A registry host is present when the first path element contains a dot
    # or colon, or is "localhost".
    if "/" in ref:
        head, rest = ref.split("/", 1)
        if "." in head or ":" in head or head == "localhost":
            registry = head
            repository = rest
        else:
            repository = ref
    else:
        repository = ref

    tag = "latest"
    if digest:
        pass
    elif ":" in repository.rsplit("/", 1)[-1]:
        repository, _, tag = repository.rpartition(":")

    if "/" not in repository and registry == DEFAULT_REGISTRY:
        repository = f"library/{repository}"

    if not repository:
        raise RegistryError(f"could not parse image reference: {reference!r}")
    return ImageRef(registry=registry, repository=repository, tag=tag, digest=digest)


def host_architecture() -> str:
    machine = platform.machine().lower()
    return {
        "x86_64": "amd64",
        "amd64": "amd64",
        "aarch64": "arm64",
        "arm64": "arm64",
        "armv7l": "arm",
        "ppc64le": "ppc64le",
        "s390x": "s390x",
    }.get(machine, machine or "amd64")


class RegistryClient:
    def __init__(self, registry: str = DEFAULT_REGISTRY, timeout: int = 60,
                 auth_host: str = DOCKER_AUTH, auth_service: str = "registry.docker.io"):
        self.registry = registry
        self.timeout = timeout
        self.auth_host = auth_host
        self.auth_service = auth_service
        self._tokens: dict[str, str] = {}

    # ------------------------------------------------------------- plumbing
    def _url(self, path: str) -> str:
        return f"https://{self.registry}{path}"

    def _request(self, url: str, headers: dict | None = None,
                 method: str = "GET") -> urllib.request.Request:
        hdrs = {"User-Agent": USER_AGENT, "Accept": "*/*"}
        if headers:
            hdrs.update(headers)
        return urllib.request.Request(url, headers=hdrs, method=method)

    def _open(self, request: urllib.request.Request, retries: int = 3):
        last: Exception | None = None
        for attempt in range(retries):
            try:
                return urllib.request.urlopen(request, timeout=self.timeout)  # noqa: S310
            except urllib.error.HTTPError as exc:
                body = ""
                try:
                    body = exc.read(400).decode("utf-8", "replace")
                except Exception:
                    pass
                if exc.code in (401, 403):
                    raise RegistryError(
                        f"HTTP {exc.code} from {self.registry} ({exc.reason}). "
                        f"{body[:200]}"
                    ) from exc
                if exc.code == 404:
                    raise RegistryError(
                        f"HTTP 404 — image or tag not found on {self.registry}. "
                        f"{body[:200]}"
                    ) from exc
                last = RegistryError(f"HTTP {exc.code}: {exc.reason} {body[:200]}")
                if exc.code < 500:
                    raise last
            except Exception as exc:  # network errors
                last = exc
            time.sleep(1.5 * (attempt + 1))
        raise RegistryError(f"request to {request.full_url} failed: {last}")

    def _token(self, repository: str) -> str:
        if repository in self._tokens:
            return self._tokens[repository]
        query = urllib.parse.urlencode({
            "service": self.auth_service,
            "scope": f"repository:{repository}:pull",
        })
        url = f"https://{self.auth_host}/token?{query}"
        try:
            with self._open(self._request(url)) as resp:
                payload = json.loads(resp.read().decode())
            token = payload.get("token") or payload.get("access_token") or ""
        except RegistryError as exc:
            # Public images on some registries need no token at all.
            if self.registry != DEFAULT_REGISTRY:
                token = ""
            else:
                raise RegistryError(
                    f"could not obtain a registry token from {self.auth_host}: {exc}"
                ) from exc
        self._tokens[repository] = token
        return token

    def _auth_headers(self, repository: str) -> dict:
        token = self._token(repository)
        return {"Authorization": f"Bearer {token}"} if token else {}

    # -------------------------------------------------------------- manifest
    def get_manifest(self, ref: ImageRef) -> tuple[dict, str, str]:
        """Return (manifest, digest, media_type), resolving indexes."""
        path = f"/v2/{ref.repository}/manifests/{ref.digest or ref.tag}"
        headers = {**self._auth_headers(ref.repository), "Accept": MANIFEST_TYPES}
        req = self._request(self._url(path), headers)
        with self._open(req) as resp:
            raw = resp.read()
            digest = resp.headers.get("Docker-Content-Digest", "")
            media_type = resp.headers.get("Content-Type", "").split(";")[0]
        try:
            manifest = json.loads(raw.decode())
        except ValueError as exc:
            raise RegistryError(f"registry returned a non-JSON manifest: {exc}") from exc
        if not digest:
            digest = "sha256:" + hashlib.sha256(raw).hexdigest()

        if manifest.get("manifests"):  # multi-arch index
            want_arch = host_architecture()
            chosen = None
            variants = []
            for entry in manifest["manifests"]:
                plat = entry.get("platform", {}) or {}
                if entry.get("annotations", {}).get("vnd.docker.reference.type"):
                    continue  # attestation manifests
                variants.append(f"{plat.get('os', '?')}/{plat.get('architecture', '?')}")
                if plat.get("os") == "linux" and plat.get("architecture") == want_arch:
                    chosen = entry
                    break
            if chosen is None and manifest["manifests"]:
                chosen = manifest["manifests"][0]
            if chosen is None:
                raise RegistryError(
                    f"no usable platform manifest for {ref.canonical} "
                    f"(available: {', '.join(variants) or 'none'})"
                )
            sub = ImageRef(registry=ref.registry, repository=ref.repository,
                           tag=ref.tag, digest=chosen["digest"])
            sub_manifest, sub_digest, sub_type = self.get_manifest(sub)
            sub_manifest.setdefault("_platform", chosen.get("platform", {}))
            return sub_manifest, sub_digest, sub_type

        return manifest, digest, media_type

    def get_blob(self, ref: ImageRef, digest: str, dest: Path,
                 expected_size: int | None = None, progress=None) -> Path:
        """Download a blob to `dest`, verifying its digest."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists() and dest.stat().st_size > 0:
            if expected_size is None or dest.stat().st_size == expected_size:
                if _verify_digest(dest, digest):
                    if progress:
                        progress(f"blob {digest[7:19]} already cached")
                    return dest
        url = self._url(f"/v2/{ref.repository}/blobs/{digest}")
        headers = {**self._auth_headers(ref.repository), "Accept": "*/*"}
        tmp = dest.with_suffix(dest.suffix + ".part")
        hasher = hashlib.sha256()
        written = 0
        with self._open(self._request(url, headers)) as resp, open(tmp, "wb") as fh:
            total = int(resp.headers.get("Content-Length") or expected_size or 0)
            last_report = 0.0
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                fh.write(chunk)
                hasher.update(chunk)
                written += len(chunk)
                now = time.time()
                if progress and total and now - last_report > 1.0:
                    last_report = now
                    progress(
                        f"downloading {digest[7:19]} — "
                        f"{written / 1048576:.1f}/{total / 1048576:.1f} MiB "
                        f"({written * 100 // max(total, 1)}%)"
                    )
        computed = "sha256:" + hasher.hexdigest()
        if computed != digest:
            tmp.unlink(missing_ok=True)
            raise RegistryError(
                f"digest mismatch for layer {digest}: downloaded {computed}. "
                "The download was corrupt; retry the pull."
            )
        tmp.replace(dest)
        if progress:
            progress(f"blob {digest[7:19]} verified ({written / 1048576:.1f} MiB)")
        return dest

    # ---------------------------------------------------------------- pull
    def fetch_image(self, reference: str, workdir: Path, progress=None,
                    allow_apply: bool = True) -> dict:
        """
        Download every layer of `reference` into `workdir/layers/` and (when
        `allow_apply`) extract them into `workdir/rootfs/` using the privileged
        helper.  Returns a metadata dict describing what really happened.
        """
        ref = parse_reference(reference)
        layers_dir = workdir / "layers"
        rootfs = workdir / "rootfs"

        def say(msg: str) -> None:
            if progress:
                progress(msg)

        say(f"resolving {ref.canonical}")
        manifest, digest, media_type = self.get_manifest(ref)
        platform_info = manifest.get("_platform") or {
            "os": "linux", "architecture": host_architecture()
        }
        config_digest = (manifest.get("config") or {}).get("digest", "")
        layers = manifest.get("layers") or []
        if not layers:
            raise RegistryError(
                f"manifest for {ref.canonical} contains no layers "
                f"(media type {media_type or 'unknown'})"
            )
        say(f"manifest {digest[:19]}… ({media_type or 'unknown'}), "
            f"{len(layers)} layer(s), platform "
            f"{platform_info.get('os')}/{platform_info.get('architecture')}")

        config = {}
        if config_digest:
            cfg_path = workdir / "config.json"
            try:
                self.get_blob(ref, config_digest, cfg_path,
                              expected_size=None, progress=None)
                config = json.loads(cfg_path.read_text())
            except (RegistryError, ValueError) as exc:
                say(f"image config unavailable ({exc}); using defaults")

        total_bytes = sum(int(l.get("size") or 0) for l in layers)
        say(f"total download size {total_bytes / 1048576:.1f} MiB")

        downloaded: list[dict] = []
        for index, layer in enumerate(layers, 1):
            ldigest = layer.get("digest")
            if not ldigest:
                raise RegistryError(f"layer {index} has no digest")
            suffix = ".tar.gz"
            mt = layer.get("media_type", "")
            if mt.endswith("tar"):
                suffix = ".tar"
            elif mt.endswith("zstd"):
                suffix = ".tar.zst"
            target = layers_dir / f"{index:03d}-{ldigest.split(':')[-1][:16]}{suffix}"
            say(f"layer {index}/{len(layers)}: {ldigest[7:19]}… "
                f"({(int(layer.get('size') or 0)) / 1048576:.1f} MiB)")
            self.get_blob(ref, ldigest, target,
                          expected_size=int(layer.get("size") or 0) or None,
                          progress=None)

            info = {"index": index, "digest": ldigest, "size": target.stat().st_size,
                    "media_type": mt, "file": str(target), "applied": False,
                    "detail": ""}
            if allow_apply:
                info.update(self._apply_layer(target, rootfs, mt, say))
            downloaded.append(info)

        applied = [d for d in downloaded if d.get("applied")]
        result = {
            "reference": ref.canonical,
            "friendly": ref.friendly,
            "digest": digest,
            "media_type": media_type,
            "platform": platform_info,
            "layers": downloaded,
            "layers_applied": len(applied),
            "total_bytes": sum(d["size"] for d in downloaded),
            "rootfs": str(rootfs),
            "config": {
                "env": config.get("config", {}).get("Env", []) or [],
                "cmd": config.get("config", {}).get("Cmd", []) or [],
                "entrypoint": config.get("config", {}).get("Entrypoint", []) or [],
                "working_dir": config.get("config", {}).get("WorkingDir", "") or "",
                "user": config.get("config", {}).get("User", "") or "",
            },
            "created": (config.get("created") or ""),
        }
        say(f"pull complete: {ref.friendly}, {result['layers_applied']} layer(s) applied")
        return result

    # --------------------------------------------------------- layer apply
    def _apply_layer(self, archive: Path, rootfs: Path, media_type: str, say) -> dict:
        """Extract one layer using the audited privileged helper."""
        if media_type.endswith("zstd"):
            return {"applied": False,
                    "detail": "zstd layers are not supported by this build"}
        plain = archive
        if archive.suffix == ".gz" or media_type in (
            "application/vnd.docker.image.rootfs.diff.tar.gzip",
            "application/vnd.oci.image.layer.v1.tar+gzip",
        ) or _is_gzip(archive):
            plain = archive.with_suffix(".tar")
            if not plain.exists() or plain.stat().st_mtime < archive.stat().st_mtime:
                say(f"decompressing {archive.name}")
                with tarfile.open(archive, "r:gz") as tar:
                    with open(plain, "wb") as out:
                        # Streamed decompress without holding the tar in memory.
                        import gzip

                        with gzip.open(archive, "rb") as gz:
                            shutil.copyfileobj(gz, out, 1 << 20)
                del tar
        try:
            import sys

            sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
            from helpers import helper_client  # type: ignore  # noqa: F401
        except Exception:
            pass

        from .runtime import helper_apply_layer

        rc, out, err = helper_apply_layer(plain, rootfs)
        if rc != 0:
            raise RegistryError(
                f"failed to extract layer {archive.name}: "
                f"{(err or out or 'unknown error')[:300]}"
            )
        try:
            info = json.loads(out.splitlines()[-1]) if out.strip() else {}
        except ValueError:
            info = {}
        say(f"layer {archive.name} applied "
            f"({info.get('extracted', '?')} files, {info.get('whiteouts', 0)} whiteouts)")
        return {"applied": True, "detail": json.dumps(info),
                "files": info.get("extracted"), "whiteouts": info.get("whiteouts")}


def _is_gzip(path: Path) -> bool:
    try:
        with open(path, "rb") as fh:
            return fh.read(2) == b"\x1f\x8b"
    except OSError:
        return False


def _verify_digest(path: Path, digest: str) -> bool:
    if not digest.startswith("sha256:"):
        return True
    hasher = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                hasher.update(chunk)
    except OSError:
        return False
    return hasher.hexdigest() == digest.split(":", 1)[1]


def export_rootfs_tar(rootfs: Path, dest: Path, progress=None) -> dict:
    """Create a real tar.gz snapshot of an instance rootfs (used by backups)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    total = 0
    import gzip

    with tarfile.open(dest, "w:gz", compresslevel=1) as tar:
        for base, dirs, files in __import__("os").walk(rootfs, onerror=lambda e: None):
            rel = __import__("os").path.relpath(base, rootfs)
            if rel.startswith(("proc", "sys", "dev", "run")):
                dirs[:] = []
                continue
            for name in dirs + files:
                full = __import__("os").path.join(base, name)
                arc = __import__("os").path.relpath(full, rootfs)
                try:
                    tar.add(full, arcname=arc, recursive=False)
                    st = __import__("os").lstat(full)
                    total += st.st_size
                    count += 1
                except (OSError, ValueError):
                    continue
                if progress and count % 2000 == 0:
                    progress(f"archived {count} entries")
    return {"entries": count, "uncompressed_bytes": total,
            "archive_bytes": dest.stat().st_size, "path": str(dest)}
