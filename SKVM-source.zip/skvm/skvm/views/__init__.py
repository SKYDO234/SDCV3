"""HTML view blueprints: auth, setup, dashboards, instances, profile."""
from __future__ import annotations

import logging

from flask import (
    Blueprint, abort, current_app, flash, redirect, render_template, request,
    session, url_for,
)
from flask_login import current_user, login_required, login_user, logout_user

from ..extensions import db, limiter
from ..models import (
    ApiToken, Backup, ConsoleSession, LoginAttempt, Node, OSImage, Plan,
    Role, Setting, Task, TaskStatus, User, VPS, VPSStatus, utcnow,
)
from ..security import (
    ValidationError, check_origin, client_ip, hash_token, validate_email,
    validate_password, validate_username,
)
from ..services import audit, settings_service
from ..services.bootstrap import admin_exists, create_admin

logger = logging.getLogger("skvm.views")

auth_bp = Blueprint("auth", __name__)
main_bp = Blueprint("main", __name__)
admin_bp = Blueprint("admin", __name__, url_prefix="/admin")
instance_bp = Blueprint("instance", __name__, url_prefix="/vps")
profile_bp = Blueprint("profile", __name__, url_prefix="/profile")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def manager():
    return current_app.extensions["skvm_manager"]


def runner():
    return current_app.extensions["skvm_runner"]


def console_manager():
    return current_app.extensions["skvm_console"]


def accessible_instances(user=None):
    """Instances the current user may see.  Enforced in one place."""
    user = user or current_user
    query = VPS.query.filter(VPS.status != VPSStatus.DELETED)
    if user.can_view_all:
        return query
    return query.filter(VPS.owner_id == user.id)


def get_instance_or_404(instance_id: str) -> VPS:
    vps = VPS.query.filter_by(instance_id=instance_id).first()
    if vps is None:
        abort(404, description="No such instance")
    if not (current_user.can_access(vps) and vps.status != VPSStatus.DELETED):
        # The attempt is recorded, but the browser is told 404: a 403 would
        # confirm that somebody else's instance exists under that id.
        audit.record("instance.access_denied",
                     f"user {current_user.username} tried to open {vps.name}",
                     category="security", level="warning", target=vps.name)
        abort(404, description="No such instance")
    return vps


def get_operable_instance_or_404(instance_id: str) -> VPS:
    vps = get_instance_or_404(instance_id)
    if not current_user.can_operate(vps):
        abort(403, description="Your role cannot modify this instance")
    return vps


def parse_dt(value: str):
    from datetime import datetime

    if not value:
        return None
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


# --------------------------------------------------------------------------
# setup / auth
# --------------------------------------------------------------------------
@auth_bp.route("/setup", methods=["GET", "POST"])
@limiter.limit("20 per minute")
def setup():
    """One-time administrator creation, gated by the install-time token."""
    if admin_exists():
        return redirect(url_for("auth.login"))

    token_expected = current_app.config.get("SETUP_TOKEN") or ""
    prefill = current_app.config.get("BOOTSTRAP_ADMIN_USERNAME") or ""
    errors: list[str] = []

    if request.method == "POST":
        submitted = (request.form.get("setup_token") or "").strip()
        bootstrap_ok = False
        if token_expected:
            import hmac

            bootstrap_ok = hmac.compare_digest(submitted, token_expected)
        else:
            bootstrap_ok = True  # token was not configured by install.sh
        username = (request.form.get("username") or "").strip()
        email = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm") or ""
        full_name = (request.form.get("full_name") or "").strip()

        if not bootstrap_ok:
            errors.append("The setup token does not match the one printed by "
                          "install.sh.")
        errors += validate_username(username)
        errors += validate_email(email)
        errors += validate_password(password, username, email)
        if password != confirm:
            errors.append("The two passwords do not match.")
        if User.query.filter_by(username=username).first():
            errors.append("That username is already taken.")
        if User.query.filter_by(email=email).first():
            errors.append("That email is already registered.")

        if not errors:
            try:
                user = create_admin(username, email, password, full_name)
                settings_service.set_value("registration_enabled", False)
                audit.record("setup.completed",
                             f"initial administrator '{username}' created",
                             category="security", level="warning", actor=user)
                current_app.config["SETUP_TOKEN"] = ""  # consume it
                login_user(user)
                flash("Administrator account created. Welcome to SKVM.", "success")
                return redirect(url_for("main.dashboard"))
            except Exception as exc:  # noqa: BLE001
                logger.exception("setup failed")
                errors.append(f"Could not create the account: {exc}")

    return render_template("auth/setup.html", errors=errors,
                           token_configured=bool(token_expected),
                           prefill_username=prefill), (400 if errors else 200)


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("20 per minute", methods=["POST"])
def login():
    if not admin_exists():
        return redirect(url_for("auth.setup"))
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    error = None
    username = ""
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        remember = bool(request.form.get("remember"))
        ip = client_ip()
        user = User.query.filter(
            db.or_(User.username == username, User.email == username)
        ).first()

        attempt = LoginAttempt(username=username[:64], ip=ip,
                               user_agent=request.headers.get("User-Agent", "")[:255])

        if user is None:
            attempt.success = False
            db.session.add(attempt)
            db.session.commit()
            error = "Invalid credentials."
            audit.record("auth.login_failed", f"unknown account '{username}' from {ip}",
                         category="security", level="warning", commit=True)
        elif user.is_locked:
            error = (f"This account is locked until "
                     f"{user.locked_until:%Y-%m-%d %H:%M} UTC after too many "
                     "failed attempts.")
            audit.record("auth.login_locked", f"locked account '{username}' tried "
                                              f"to sign in from {ip}",
                         category="security", level="warning", actor=user)
        elif not user.is_active_flag:
            error = "This account has been suspended. Contact an administrator."
            audit.record("auth.login_suspended",
                         f"suspended account '{username}' attempted sign in",
                         category="security", level="warning", actor=user)
        elif not user.check_password(password):
            user.failed_login_count = (user.failed_login_count or 0) + 1
            limit = int(settings_service.get("max_login_failures", 8) or 8)
            if user.failed_login_count >= limit:
                from datetime import timedelta

                minutes = int(settings_service.get("lockout_minutes", 15) or 15)
                user.locked_until = utcnow() + timedelta(minutes=minutes)
                user.failed_login_count = 0
                audit.record("auth.account_locked",
                             f"'{username}' locked for {minutes} minutes after "
                             "repeated failures", category="security",
                             level="warning", actor=user)
            attempt.success = False
            db.session.add(attempt)
            db.session.commit()
            error = "Invalid credentials."
            audit.record("auth.login_failed", f"wrong password for '{username}' "
                                              f"from {ip}", category="security",
                         level="warning", actor=user)
        else:
            user.failed_login_count = 0
            user.locked_until = None
            user.last_login_at = utcnow()
            user.last_login_ip = ip
            attempt.success = True
            db.session.add(attempt)
            db.session.commit()
            login_user(user, remember=remember)
            session.permanent = True
            audit.record("auth.login", f"{user.username} signed in from {ip}",
                         category="security", actor=user)
            target = request.args.get("next") or url_for("main.dashboard")
            if not target.startswith("/"):
                target = url_for("main.dashboard")
            return redirect(target)

    return render_template("auth/login.html", error=error, username=username,
                           registration_open=bool(settings_service.get(
                               "registration_enabled", False)),
                           admin_present=True,
                           session_hours=int(
                               current_app.config["PERMANENT_SESSION_LIFETIME"]
                               // 3600))


@auth_bp.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    if request.method == "POST" or request.args.get("confirm") == "1":
        username = current_user.username
        audit.record("auth.logout", f"{username} signed out", category="security")
        console_manager().close_all("user signed out")
        logout_user()
        flash("You have been signed out.", "info")
        return redirect(url_for("auth.login"))
    return render_template("auth/logout.html")


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("10 per hour", methods=["POST"])
def register():
    if not settings_service.get("registration_enabled", False):
        abort(403, description="Self-registration is disabled on this panel.")
    if not admin_exists():
        return redirect(url_for("auth.setup"))
    errors: list[str] = []
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        email = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""
        full_name = (request.form.get("full_name") or "").strip()
        errors += validate_username(username)
        errors += validate_email(email)
        errors += validate_password(password, username, email)
        if password != (request.form.get("confirm") or ""):
            errors.append("The two passwords do not match.")
        if User.query.filter_by(username=username).first():
            errors.append("That username is already taken.")
        if User.query.filter_by(email=email).first():
            errors.append("That email is already registered.")
        if not errors:
            role = settings_service.get("default_role", "user")
            user = User(username=username, email=email, full_name=full_name,
                        role=role if role in Role.ALL else Role.USER,
                        quota_vcpu=2, quota_memory_mb=2048, quota_disk_gb=20,
                        quota_instances=2)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            audit.record("user.self_registered", f"{username} created an account",
                         category="auth", actor=user)
            login_user(user)
            flash("Welcome to SKVM.", "success")
            return redirect(url_for("main.dashboard"))
    return render_template("auth/register.html", errors=errors)


# --------------------------------------------------------------------------
# dashboards
# --------------------------------------------------------------------------
@main_bp.route("/")
@login_required
def dashboard():
    mgr = manager()
    instances_query = accessible_instances()
    instances = instances_query.order_by(VPS.id.desc()).limit(50).all()

    stats = {
        "instances": instances_query.count(),
        "running": instances_query.filter(VPS.status == VPSStatus.RUNNING).count(),
        "stopped": instances_query.filter(VPS.status == VPSStatus.STOPPED).count(),
        "errors": instances_query.filter(VPS.status == VPSStatus.ERROR).count(),
        "provisioning": instances_query.filter(
            VPS.status == VPSStatus.PROVISIONING).count(),
    }
    if current_user.can_view_all:
        stats.update({
            "users": User.query.count(),
            "active_users": User.query.filter_by(is_active_flag=True).count(),
            "plans": Plan.query.filter_by(is_active=True).count(),
            "images_ready": OSImage.query.filter_by(status="ready").count(),
            "images_total": OSImage.query.count(),
            "tasks_running": Task.query.filter(
                Task.status == TaskStatus.RUNNING).count(),
            "tasks_failed": Task.query.filter(
                Task.status == TaskStatus.FAILED).count(),
            "allocation": {
                "vcpu": db.session.query(
                    db.func.coalesce(db.func.sum(VPS.vcpu), 0)).filter(
                    VPS.status != VPSStatus.DELETED).scalar() or 0,
                "memory_mb": db.session.query(
                    db.func.coalesce(db.func.sum(VPS.memory_mb), 0)).filter(
                    VPS.status != VPSStatus.DELETED).scalar() or 0,
                "disk_gb": db.session.query(
                    db.func.coalesce(db.func.sum(VPS.disk_gb), 0)).filter(
                    VPS.status != VPSStatus.DELETED).scalar() or 0,
            },
        })

    try:
        capabilities = mgr.capabilities()
    except Exception as exc:  # noqa: BLE001
        logger.warning("capability probe failed: %s", exc, exc_info=True)
        capabilities = {"can_provision": False, "providers": [],
                        "error": str(exc)}

    expiring = instances_query.filter(
        VPS.expires_at.isnot(None),
        VPS.expires_at <= utcnow() + __import__("datetime").timedelta(days=7),
        VPS.status != VPSStatus.SUSPENDED,
    ).order_by(VPS.expires_at).limit(10).all()

    recent_tasks = Task.query.order_by(Task.id.desc()).limit(8).all()
    audit_entries = (audit.recent(limit=10) if current_user.can_view_all else [])

    return render_template(
        "dashboard.html", stats=stats, instances=instances,
        capabilities=capabilities, expiring=expiring, recent_tasks=recent_tasks,
        audit_entries=audit_entries,
        host=mgr.profile().resources,
    )


@main_bp.route("/maintenance")
@login_required
def maintenance_page():
    state = settings_service.maintenance()
    return render_template("errors/maintenance.html", state=state), 503


# --------------------------------------------------------------------------
# admin pages
# --------------------------------------------------------------------------
def _admin_guard(f):
    """Administrator-only HTML pages (operators get read-only infra pages)."""

    import functools

    @functools.wraps(f)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user.is_admin:
            abort(403, description="Administrator privileges are required.")
        return f(*args, **kwargs)

    return wrapper


def _operator_guard(f):
    import functools

    @functools.wraps(f)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user.can_manage_infra:
            abort(403, description="You do not have permission for this page.")
        return f(*args, **kwargs)

    return wrapper


@admin_bp.route("/users")
@_admin_guard
def users():
    page = max(1, request.args.get("page", 1, type=int))
    search = (request.args.get("q") or "").strip()
    role = request.args.get("role") or ""
    status = request.args.get("status") or ""
    per_page = 20

    query = User.query
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(User.username.ilike(like),
                                    User.email.ilike(like),
                                    User.full_name.ilike(like)))
    if role in Role.ALL:
        query = query.filter(User.role == role)
    if status == "active":
        query = query.filter(User.is_active_flag.is_(True))
    elif status == "suspended":
        query = query.filter(User.is_active_flag.is_(False))

    total = query.count()
    users_list = (query.order_by(User.id.desc())
                  .offset((page - 1) * per_page).limit(per_page).all())
    return render_template(
        "admin/users.html", users=users_list, total=total, page=page,
        per_page=per_page, pages=max(1, (total + per_page - 1) // per_page),
        search=search, role_filter=role, status_filter=status,
        instance_counts={u.id: VPS.query.filter(
            VPS.owner_id == u.id, VPS.status != VPSStatus.DELETED).count()
            for u in users_list},
    )


@admin_bp.route("/vps")
@login_required
def all_vps():
    if not current_user.can_view_all:
        abort(403, description="You do not have permission to view all instances.")
    page = max(1, request.args.get("page", 1, type=int))
    search = (request.args.get("q") or "").strip()
    status = request.args.get("status") or ""
    owner_filter = request.args.get("owner", type=int)
    provider = request.args.get("provider") or ""
    per_page = 20

    query = VPS.query.filter(VPS.status != VPSStatus.DELETED)
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(VPS.name.ilike(like), VPS.hostname.ilike(like),
                                    VPS.instance_id.ilike(like),
                                    VPS.internal_ip.ilike(like)))
    if status in VPSStatus.ALL:
        query = query.filter(VPS.status == status)
    if owner_filter:
        query = query.filter(VPS.owner_id == owner_filter)
    if provider:
        query = query.filter(VPS.provider == provider)

    total = query.count()
    instances = (query.order_by(VPS.id.desc())
                 .offset((page - 1) * per_page).limit(per_page).all())
    return render_template(
        "admin/vps.html", instances=instances, total=total, page=page,
        per_page=per_page, pages=max(1, (total + per_page - 1) // per_page),
        search=search, status_filter=status, owner_filter=owner_filter,
        provider_filter=provider,
        users=User.query.order_by(User.username).all(),
        providers=manager().capabilities().get("providers", []),
        counts={s: VPS.query.filter(VPS.status == s).count()
                for s in VPSStatus.ALL},
    )


@admin_bp.route("/vps/create")
@_admin_guard
def create_vps():
    mgr = manager()
    capabilities = mgr.capabilities()
    plans = Plan.query.filter_by(is_active=True).order_by(Plan.sort_order).all()
    images = OSImage.query.filter_by(is_active=True).order_by(
        OSImage.sort_order).all()
    users_list = User.query.filter_by(is_active_flag=True).order_by(
        User.username).all()
    nodes_list = Node.query.order_by(Node.name).all()
    return render_template(
        "admin/create_vps.html", plans=plans, images=images, users=users_list,
        nodes=nodes_list, capabilities=capabilities,
        defaults=settings_service.as_dict(),
        quota_map={u.id: {"vcpu": u.quota_vcpu, "memory_mb": u.quota_memory_mb,
                          "disk_gb": u.quota_disk_gb,
                          "instances": u.quota_instances,
                          "role": u.role} for u in users_list},
    )


@admin_bp.route("/expiring")
@login_required
def expiring():
    if not current_user.can_view_all:
        abort(403, description="Permission denied.")
    now = utcnow()
    soon = (VPS.query.filter(VPS.expires_at.isnot(None),
                             VPS.expires_at <= now + __import__("datetime")
                             .timedelta(days=30),
                             VPS.status != VPSStatus.DELETED)
            .order_by(VPS.expires_at).all())
    buckets = {"expired": [], "7_days": [], "30_days": []}
    for vps in soon:
        if vps.expires_at <= now:
            buckets["expired"].append(vps)
        elif vps.expires_at <= now + __import__("datetime").timedelta(days=7):
            buckets["7_days"].append(vps)
        else:
            buckets["30_days"].append(vps)
    return render_template("admin/expiring.html", buckets=buckets,
                           total=len(soon), now=now)


@admin_bp.route("/plans")
@_operator_guard
def plans():
    return render_template("admin/plans.html",
                           plans=Plan.query.order_by(Plan.sort_order, Plan.id).all(),
                           usage={p.id: VPS.query.filter(
                               VPS.plan_id == p.id,
                               VPS.status != VPSStatus.DELETED).count()
                               for p in Plan.query.all()})


@admin_bp.route("/nodes")
@_operator_guard
def nodes():
    local = manager().refresh_local_node()
    return render_template("admin/nodes.html",
                           nodes=Node.query.order_by(Node.id).all(),
                           local_metrics=local.metrics,
                           capabilities=manager().capabilities())


@admin_bp.route("/images")
@_operator_guard
def images():
    mgr = manager()
    mgr.reconcile_image_cache()          # same reconcile the API uses
    provider, _ = mgr.provider()
    rows = OSImage.query.order_by(OSImage.sort_order, OSImage.id).all()
    details = {}
    for image in rows:
        ready = bool(provider and provider.image_ready(image.slug))
        meta = provider.image_meta(image.slug) if (provider and ready) else {}
        details[image.id] = {
            "cached": ready,
            "cached_bytes": provider.image_size(image.slug) if (provider and ready) else 0,
            "digest": meta.get("digest", image.digest),
            "pulled_at": meta.get("pulled_at_iso", ""),
            "layers": len(meta.get("layers") or []),
        }
    return render_template("admin/images.html", images=rows, details=details,
                           capabilities=mgr.capabilities())


@admin_bp.route("/settings")
@_admin_guard
def settings_page():
    groups: dict[str, list] = {}
    for row in settings_service.all_rows():
        groups.setdefault(row.group, []).append(row)
    return render_template("admin/settings.html", groups=groups,
                           maintenance=settings_service.maintenance(),
                           capabilities=manager().capabilities(),
                           config=current_app.config)


@admin_bp.route("/system")
@login_required
def system_info():
    if not current_user.can_view_all:
        abort(403, description="Permission denied.")
    mgr = manager()
    profile = mgr.profile(force=True)
    return render_template("admin/system.html", profile=profile,
                           capabilities=mgr.capabilities(),
                           config_view=current_app.config)


@admin_bp.route("/logs")
@_operator_guard
def logs():
    import json as _json

    log_file = current_app.config["LOG_DIR"] / "skvm.log"
    lines = []
    if log_file.exists():
        raw = log_file.read_text(errors="replace").splitlines()[-500:]
        for line in reversed(raw):
            entry = {"raw": line, "level": "info", "logger": "", "ts": ""}
            try:
                parsed = _json.loads(line)
                entry.update({
                    "level": parsed.get("level", "info").lower(),
                    "logger": parsed.get("logger", ""),
                    "ts": parsed.get("ts", ""),
                    "message": parsed.get("message", ""),
                })
            except ValueError:
                entry["message"] = line
            lines.append(entry)
    level = request.args.get("level") or ""
    component = (request.args.get("component") or "").strip().lower()
    if level:
        lines = [l for l in lines if l["level"] == level.lower()]
    if component:
        lines = [l for l in lines if component in (l.get("logger") or "").lower()
                 or component in (l.get("message") or "").lower()]
    entries = audit.recent(limit=200,
                           level=request.args.get("audit_level") or None,
                           category=request.args.get("category") or None)
    tasks = Task.query.order_by(Task.id.desc()).limit(40).all()
    return render_template("admin/logs.html", lines=lines[:400],
                           audit_entries=entries, tasks=tasks,
                           log_file=str(log_file), level=level,
                           component=component)


@admin_bp.route("/backups")
@login_required
def backups():
    if not current_user.can_view_all:
        abort(403, description="Permission denied.")
    mine = Backup.query.join(VPS, Backup.vps_id == VPS.id).order_by(
        Backup.id.desc()).limit(300).all()
    total_bytes = sum(b.size_bytes or 0 for b in mine)
    service = current_app.extensions["skvm_backups"]
    storage = service.storage()
    return render_template("admin/backups.html", backups=mine,
                           total_bytes=total_bytes,
                           usage={"free": storage["free_bytes"],
                                  "percent": (round(100 - storage["free_bytes"] / 1e9 /
                                                     (storage["free_bytes"] / 1e9 + 1) * 100)
                                              if storage["free_bytes"] else 0)},
                           storage=storage,
                           backup_dir=storage["root"])


@admin_bp.route("/maintenance")
@_admin_guard
def maintenance():
    state = settings_service.maintenance()
    running = VPS.query.filter(VPS.status == VPSStatus.RUNNING).count()
    active_consoles = console_manager().active()
    pending = Task.query.filter(Task.status.in_([TaskStatus.QUEUED,
                                                 TaskStatus.RUNNING])).all()
    return render_template("admin/maintenance.html", state=state,
                           running=running, consoles=active_consoles,
                           pending_tasks=pending,
                           capabilities=manager().capabilities())


@admin_bp.route("/api-management")
@_admin_guard
def api_management():
    tokens = ApiToken.query.order_by(ApiToken.id.desc()).all()
    new_token = session.pop("new_api_token", None)
    return render_template("admin/api_management.html", tokens=tokens,
                           new_token=new_token,
                           scopes=["read", "write", "provision", "admin"],
                           base_url=request.host_url.rstrip("/"))


# --------------------------------------------------------------------------
# instances (user facing)
# --------------------------------------------------------------------------
@instance_bp.route("/")
@login_required
def list_instances():
    query = accessible_instances()
    search = (request.args.get("q") or "").strip()
    status = request.args.get("status") or ""
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(VPS.name.ilike(like), VPS.hostname.ilike(like),
                                    VPS.os_name.ilike(like)))
    if status in VPSStatus.ALL:
        query = query.filter(VPS.status == status)
    instances = query.order_by(VPS.id.desc()).all()
    return render_template("instances/list.html", instances=instances,
                           search=search, status_filter=status,
                           capabilities=manager().capabilities())


@instance_bp.route("/<instance_id>")
@login_required
def detail(instance_id):
    vps = get_instance_or_404(instance_id)
    manager().refresh_instance(vps, collect_metrics=True)
    provider = manager().provider_for(vps)
    facts = provider.host_facts().__dict__ if provider else {}
    tasks = Task.query.filter_by(vps_id=vps.id).order_by(Task.id.desc()).limit(12).all()
    backups = Backup.query.filter_by(vps_id=vps.id).order_by(Backup.id.desc()).all()
    return render_template("instances/detail.html", vps=vps, facts=facts,
                           tasks=tasks, backups=backups,
                           metrics=vps.metrics,
                           provider_name=provider.label if provider else "unavailable")


@instance_bp.route("/<instance_id>/console")
@login_required
def console(instance_id):
    vps = get_operable_instance_or_404(instance_id)
    manager().refresh_instance(vps)
    provider = manager().provider_for(vps)
    supported = bool(provider and provider.console_argv(vps)) if vps.is_running else None
    return render_template("instances/console.html", vps=vps,
                           provider_name=provider.label if provider else "unavailable",
                           console_supported=supported is not False)


@instance_bp.route("/<instance_id>/files")
@login_required
def files(instance_id):
    vps = get_operable_instance_or_404(instance_id)
    manager().refresh_instance(vps)
    return render_template("instances/files.html", vps=vps,
                           max_upload_mb=int(settings_service.get(
                               "file_manager_max_upload_mb", 256)))


@instance_bp.route("/<instance_id>/usage")
@login_required
def usage(instance_id):
    vps = get_instance_or_404(instance_id)
    manager().refresh_instance(vps, collect_metrics=True)
    return render_template("instances/usage.html", vps=vps, metrics=vps.metrics)


@instance_bp.route("/<instance_id>/ssh")
@login_required
def ssh_info(instance_id):
    vps = get_instance_or_404(instance_id)
    manager().refresh_instance(vps, collect_metrics=True)
    profile = manager().profile()
    capabilities = manager().capabilities()
    manager_address = manager().local_node_address()
    host_caps = {k: v.to_dict() for k, v in profile.caps.items()}
    return render_template(
        "instances/ssh.html", vps=vps, capabilities=capabilities,
        host_caps=host_caps, host_address=manager_address,
        sshd_available=profile.available("sshd"),
        tmate_available=profile.available("tmate"),
    )


# --------------------------------------------------------------------------
# profile
# --------------------------------------------------------------------------
@profile_bp.route("/")
@login_required
def index():
    tokens = (ApiToken.query.filter_by(user_id=current_user.id)
              .order_by(ApiToken.id.desc()).all() if current_user.is_admin else [])
    instances = accessible_instances().order_by(VPS.id.desc()).limit(20).all()
    used = {
        "instances": len(instances),
        "vcpu": sum(i.vcpu for i in instances),
        "memory_mb": sum(i.memory_mb for i in instances),
        "disk_gb": sum(i.disk_gb for i in instances),
    }
    sessions = [s for s in console_manager().active()
                if s["user"] == current_user.username]
    return render_template("profile/index.html", user=current_user, tokens=tokens,
                           instances=instances, used=used, sessions=sessions)


@profile_bp.route("/security")
@login_required
def security():
    from ..models import LoginAttempt

    attempts = (LoginAttempt.query
                .filter(db.or_(LoginAttempt.username == current_user.username,
                               LoginAttempt.ip == client_ip()))
                .order_by(LoginAttempt.id.desc()).limit(30).all())
    entries = (audit.recent(limit=40))
    entries = [e for e in entries if e.actor_username == current_user.username]
    return render_template("profile/security.html", attempts=attempts,
                           entries=entries)


# --------------------------------------------------------------------------
def register_views(app):
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(instance_bp)
    app.register_blueprint(profile_bp)

    @app.route("/favicon.ico")
    def favicon():
        from flask import send_from_directory

        return send_from_directory(str(app.static_folder), "favicon.svg",
                                   mimetype="image/svg+xml")


__all__ = [
    "auth_bp", "main_bp", "admin_bp", "instance_bp", "profile_bp",
    "register_views", "manager", "runner", "console_manager",
    "accessible_instances", "get_instance_or_404",
    "get_operable_instance_or_404", "parse_dt",
]
