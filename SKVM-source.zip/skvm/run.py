#!/usr/bin/env python3
"""
SKVM development/self-hosted entry point.

    python3 run.py                 # honours HOST/PORT from .env (0.0.0.0:5555)
    PORT=8080 python3 run.py

This uses Flask's built-in server with threading enabled.  Werkzeug is also the
only WSGI server that speaks WebSocket without an extra worker class, which is
what the interactive console needs — see README.md for the gunicorn/gevent
alternative used when you want multiple worker processes.
"""
from __future__ import annotations

import logging
import os
import signal
import sys

from skvm.app import create_app
from skvm.config import Config


def main() -> int:
    app = create_app()
    host = os.environ.get("HOST") or app.config["HOST"]
    port = int(os.environ.get("PORT") or app.config["PORT"])
    debug = bool(app.config.get("DEBUG"))

    log = logging.getLogger("skvm.run")
    log.info("listening on http://%s:%s (bind address %s)", host, port, host)

    # A real, printable URL — 0.0.0.0 is not something you can click.
    display_host = host if host not in ("0.0.0.0", "::") else "127.0.0.1"
    public = app.config.get("PUBLIC_HOST") or ""
    if public:
        display_host = public
    print(f"\n  {app.config['APP_NAME']} {app.config['VERSION']} — "
          f"http://{display_host}:{port}\n"
          f"  health: http://{display_host}:{port}/healthz\n"
          f"  bound to {host}:{port} (0.0.0.0 = all interfaces)\n", flush=True)

    def _bye(signum, _frame):  # pragma: no cover - signal path
        log.info("received signal %s, shutting down", signum)
        sys.exit(0)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _bye)
        except (ValueError, OSError):
            pass

    app.run(host=host, port=port, debug=debug, threaded=True,
            use_reloader=False, passthrough_errors=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
