#!/usr/bin/env python3
"""Discord LXD VPS hosting bot — all application logic in this file.

SETUP FILES: bot.py, .env, requirements.txt. Optional install.sh automates host setup.
No other source/config module is needed.
Runtime creates data/bot.sqlite3 (plus SQLite WAL files), temporary image-build
files and LXD/Docker resources. Back up the database; do not publish .env.

QUICK START (on an ALREADY CONFIGURED real Linux LXD host):
    python3 -m venv .venv
    .venv/bin/pip install -r requirements.txt
    # Edit .env: DISCORD_TOKEN, GUILD_ID, ADMIN_IDS and your host settings.
    chmod 600 .env
    .venv/bin/python bot.py

HOST SETUP (recommended: fresh Ubuntu 24.04 full VM/dedicated server):
    sudo apt update
    sudo apt install -y python3 python3-venv curl ca-certificates lxcfs
    sudo snap install lxd                 # skip if already installed
    sudo lxd init                        # do not reinitialize production storage
Create/select a quota-capable storage pool (default name: vpspool) and a
managed NAT bridge (default: lxdbr0). Never format a disk containing your data.
The bot refuses dir storage. Prefer ZFS; test actual quota enforcement.
    sudo /snap/bin/lxc project create vpsbot -c features.images=true \
        -c features.profiles=true -c features.networks=false \
        -c features.storage.volumes=true
Give the service account access to the lxd group. If Docker fallback is enabled,
install docker.io, enable its daemon and grant the account docker group access.
Both groups are effectively HOST ROOT access. Run only one bot process per
project/database. Never expose daemon sockets or the host's remote API to users.

LOCAL IMAGES:
    sudo /snap/bin/lxc --project vpsbot image copy ubuntu:24.04 local: \
        --alias vpsbot-ubuntu-24.04
Repeat for needed releases: 20.04, 22.04, 24.04, 26.04. Availability is checked
at runtime, not guaranteed by the allowlist. Missing local aliases use the
matching official Docker Hub Ubuntu tag when DOCKER_FALLBACK=true. This file
contains the system-image conversion code; no Docker helper script is needed.
Existing local-image boot failures are retained for diagnosis, not hidden.

DISCORD:
Enable Message Content and Server Members intents. Grant View Channels, Send
Messages, Embed Links, Read Message History; additionally View Audit Log and
Manage Roles for antinuke, Ban Members/Kick Members for moderation. Bot role
must outrank targets. ADMIN_IDS are the bootstrap bot admins (comma-separated
user IDs), not role IDs. Hosting commands only work in GUILD_ID. Use Shelp.
    Screatevps demo 2 20gb 2 24.04 @member
    Smanage <returned-id>
No terminal is generated at creation. SSH/SSHX buttons generate credentials and
DM the requester. These are root relay sessions, NOT private SSH keys. Third-
party relay access and upstream SSHX installer execution require your trust.

IMPORTANT OPERATING LIMITS:
- LXCFS must function on the HOST. Installing it only inside a VPS is not enough.
  Host cgroups/storage enforce limits; LXCFS virtualizes selected proc reporting.
- Reinstall/delete/reset destroy files and need confirmation. Reset only removes
  bot-marked project containers and database contents. .env/bootstrap admins,
  cached base images, infrastructure, logs and external backups survive.
- Antinuke is best-effort audit-triggered dangerous-role removal, NOT prevention
  or rollback. Owner/out-ranking/integration roles cannot be contained reliably.
- NAT is NOT tenant isolation. Configure/test ACLs/firewall rules blocking
  unwanted tenant-to-host/private/metadata access and tenant-to-tenant traffic.
- Containers share the host kernel. This is not a hardened public-hosting stack.
  No billing, backups, bandwidth caps, public-IP allocation or capacity scheduler.
- Timeouts can leave LXD daemon operations active. Inspect lxc operation list,
  lxc list, and lxc info <id> --show-log before retrying/resetting. Error records
  are retained; inspect before deleting or reinstalling. Jobs are not replayed.
- Code/unit checks do not prove live provisioning. Test all releases, quotas,
  LXCFS mounts, permissions, DMs, SSH/SSHX, deletion/reinstall and reset in a
  disposable project/guild before production. Image builds can be slow.
"""
import asyncio
import collections
import json
import logging
import os
import platform
import re
import sqlite3
import tarfile
import tempfile
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit

import discord
from discord.ext import commands
from dotenv import dotenv_values

OS_VERSIONS = ('22.04', '24.04', '20.04', '26.04')
BASE = Path(__file__).resolve().parent

# ==================== Configuration, persistence and LXD ====================

class SafeError(Exception):
    """An error safe to display in Discord (no subprocess output or access secrets)."""

def read_environment(path=BASE / '.env'):
    """Read .env without executing/interpolating it. Process env takes precedence."""
    values = {key: value for key, value in dotenv_values(path, interpolate=False).items()
              if value is not None}
    return {**values, **os.environ}


def load_config(path=BASE / '.env'):
    env = read_environment(path)

    def value(name, default=''):
        return str(env.get(name, default)).strip()

    def number(name, default):
        raw = value(name, str(default))
        if not re.fullmatch(r'[0-9]+', raw) or int(raw) < 1:
            raise ValueError(f'{name} must be a positive whole number in .env')
        return int(raw)

    def boolean(name, default):
        raw = value(name, 'true' if default else 'false').lower()
        if raw not in ('true', 'false', '1', '0', 'yes', 'no', 'on', 'off'):
            raise ValueError(f'{name} must be true or false in .env')
        return raw in ('true', '1', 'yes', 'on')

    def csv(name):
        return [item.strip() for item in value(name).split(',') if item.strip()]

    c = {
        'guild_id': value('GUILD_ID'),
        'admin_ids': csv('ADMIN_IDS'),
        'prefix': 'S',
        'database': value('DATABASE', 'data/bot.sqlite3'),
        'lxc_binary': value('LXC_BINARY', '/snap/bin/lxc'),
        'project': value('LXD_PROJECT', 'vpsbot'),
        'storage_pool': value('LXD_STORAGE_POOL', 'vpspool'),
        'network': value('LXD_NETWORK', 'lxdbr0'),
        'local_image_prefix': value('LOCAL_IMAGE_PREFIX', 'vpsbot-ubuntu-'),
        'docker_fallback': boolean('DOCKER_FALLBACK', True),
        'docker_binary': value('DOCKER_BINARY', '/usr/bin/docker'),
        'max_ram_gb': number('MAX_RAM_GB', 32),
        'max_disk_gb': number('MAX_DISK_GB', 500),
        'max_cpu': number('MAX_CPU', 16),
        'max_vps_per_user': number('MAX_VPS_PER_USER', 5),
        'max_total_vps': number('MAX_TOTAL_VPS', 30),
        'antinuke_threshold': number('ANTINUKE_THRESHOLD', 5),
        'antinuke_window_seconds': number('ANTINUKE_WINDOW_SECONDS', 20),
        'audit_channel_id': value('AUDIT_CHANNEL_ID'),
        'allowed_panel_hosts': csv('ALLOWED_PANEL_HOSTS'),
    }
    if (not re.fullmatch(r'[1-9][0-9]*', c['guild_id']) or not c['admin_ids']
            or not all(re.fullmatch(r'[1-9][0-9]*', uid) for uid in c['admin_ids'])):
        raise ValueError('Set GUILD_ID and comma-separated ADMIN_IDS in .env first.')
    if c['audit_channel_id'] and not re.fullmatch(r'[1-9][0-9]*', c['audit_channel_id']):
        raise ValueError('AUDIT_CHANNEL_ID must be empty or a numeric channel ID.')
    for key in ('project', 'storage_pool', 'network', 'local_image_prefix'):
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}', c[key]):
            raise ValueError(f'Invalid {key} in .env')
    if c['project'] == 'default':
        raise ValueError('Use a dedicated LXD_PROJECT, never default.')
    for key in ('database', 'lxc_binary', 'docker_binary'):
        if not c[key] or '\x00' in c[key]:
            raise ValueError(f'Invalid {key} in .env')
    return c

def validate_spec(c, name, ram, disk, cpu, version):
    if not re.fullmatch(r'[a-z][a-z0-9-]{0,39}', name):
        raise SafeError('Name must start with a lowercase letter; use 1–40 lowercase letters, digits or hyphens.')
    def amount(value, maximum, label, suffix=False):
        value = str(value).lower()
        if suffix:
            value = re.sub(r'(gib|gb)$', '', value)
        if not value.isdecimal() or not 1 <= int(value) <= maximum:
            raise SafeError(f'{label} must be a whole number from 1 to {maximum}.')
        return int(value)
    ram = amount(ram, c['max_ram_gb'], 'RAM (GiB)')
    disk = amount(disk, c['max_disk_gb'], 'Disk (GiB)', True)
    cpu = amount(cpu, c['max_cpu'], 'CPU cores')
    if disk < 4:
        raise SafeError('Use at least 4 GiB disk for Ubuntu and updates.')
    if version not in OS_VERSIONS:
        raise SafeError('OS must be one of: ' + ', '.join(OS_VERSIONS))
    return ram, disk, cpu

def panel_url(value, allowed):
    p = urlsplit(value)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or any(x.isspace() for x in value):
        raise SafeError('Use an HTTPS panel URL without credentials or whitespace.')
    if allowed and p.hostname.lower() not in [x.lower() for x in allowed]:
        raise SafeError('This panel hostname is not allowed by .env.')
    return value

class Store:
    def __init__(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(path)
        os.chmod(path, 0o600)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        PRAGMA journal_mode=WAL;
        PRAGMA secure_delete=ON;
        CREATE TABLE IF NOT EXISTS vps (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, owner TEXT NOT NULL,
          ram INTEGER NOT NULL, disk INTEGER NOT NULL, cpu INTEGER NOT NULL,
          os TEXT NOT NULL, state TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS admins (id TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS panels (name TEXT PRIMARY KEY, url TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        ''')
    def run(self, sql, args=()):
        result = self.db.execute(sql, args)
        self.db.commit()
        return result
    def get(self, ident):
        row = self.db.execute('SELECT * FROM vps WHERE id=?', (ident,)).fetchone()
        if not row:
            raise SafeError('Unknown VPS ID. Use Smyvps to find yours.')
        return dict(row)
    def rows(self, owner=None):
        if owner is None:
            return [dict(x) for x in self.db.execute('SELECT * FROM vps ORDER BY id')]
        return [dict(x) for x in self.db.execute('SELECT * FROM vps WHERE owner=? ORDER BY id', (str(owner),))]
    def admin(self, uid, seeds):
        return str(uid) in map(str, seeds) or self.db.execute('SELECT 1 FROM admins WHERE id=?', (str(uid),)).fetchone() is not None
    def setting(self, key, default='0'):
        row = self.db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return row[0] if row else default
    def set(self, key, value):
        self.run('INSERT OR REPLACE INTO settings VALUES (?,?)', (key, value))
    def wipe(self):
        self.db.executescript('DELETE FROM vps; DELETE FROM admins; DELETE FROM panels; DELETE FROM settings;')
        self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        self.db.execute('VACUUM')

async def process(*args, timeout=60):
    """Kill and reap timed-out clients. Daemon-side LXD jobs may still need reconciliation."""
    try:
        p = await asyncio.create_subprocess_exec(*map(str, args), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    except (OSError, ValueError):
        raise SafeError('A required host executable is missing or inaccessible.') from None
    try:
        out, err = await asyncio.wait_for(p.communicate(), timeout)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        try:
            p.kill()
        except ProcessLookupError:
            pass
        await p.communicate()
        raise
    if p.returncode:
        # Never log stdout/stderr: session credentials can appear in either.
        raise SafeError('Host operation failed. Check LXD/project/storage/network and host logs. No command output is exposed for security.')
    return out.decode(errors='replace').strip()

PROVISION = r'''
set -eu
export DEBIAN_FRONTEND=noninteractive
# Host LXCFS supplies the virtual /proc mounts; do not start a nested FUSE daemon.
apt-get -o Acquire::Retries=3 update
apt-get -o Acquire::Retries=3 install -y ca-certificates curl tmate openssh-client procps util-linux lxcfs
systemctl disable --now lxcfs.service >/dev/null 2>&1 || true
systemctl mask lxcfs.service >/dev/null 2>&1 || true
install -d -m 700 /run/vpsbot
'''
TMATE = r'''
set -eu
install -d -m 700 /run/vpsbot
sock=/run/vpsbot/tmate.sock
if [ -S "$sock" ]; then tmate -S "$sock" kill-server || true; fi
rm -f "$sock"
tmate -S "$sock" new-session -d -s vpsbot
tmate -S "$sock" wait tmate-ready
tmate -S "$sock" display -p '#{tmate_ssh}'
'''
SSHX = r'''
set -eu
umask 077
install -d -m 700 /run/vpsbot
if ! command -v sshx >/dev/null 2>&1; then
  curl --proto '=https' --tlsv1.2 -fsS --max-time 90 https://sshx.io/get -o /run/vpsbot/sshx-install.sh
  sh /run/vpsbot/sshx-install.sh >/dev/null 2>&1
  rm -f /run/vpsbot/sshx-install.sh
fi
binary=$(command -v sshx)
systemctl stop vpsbot-sshx.service >/dev/null 2>&1 || true
systemctl reset-failed vpsbot-sshx.service >/dev/null 2>&1 || true
: > /run/vpsbot/sshx.log
systemd-run --quiet --collect --unit=vpsbot-sshx /bin/sh -c 'exec "$1" > /run/vpsbot/sshx.log 2>&1' sh "$binary"
for i in $(seq 1 30); do
  link=$(grep -Eo 'https://sshx\.io/s/[A-Za-z0-9_/#?=&.%~-]+' /run/vpsbot/sshx.log | head -n 1 || true)
  if [ -n "$link" ]; then printf '%s\n' "$link"; exit 0; fi
  sleep 1
done
exit 1
'''

class Backend:
    def __init__(self, c):
        self.c = c
    async def lxc(self, *args, timeout=90):
        return await process(self.c['lxc_binary'], '--project', self.c['project'], *args, timeout=timeout)
    async def listing(self):
        return json.loads(await self.lxc('list', '--format=json'))
    async def checked(self, ident):
        data = next((x for x in await self.listing() if x['name'] == ident), None)
        if not data or data.get('config', {}).get('user.vpsbot.managed') != 'true':
            raise SafeError('VPS is absent or lacks the bot ownership marker. Ask an administrator to reconcile it.')
        return data
    async def preflight(self):
        await self.lxc('project', 'show', self.c['project'])
        pool = json.loads(await self.lxc('query', f"/1.0/storage-pools/{self.c['storage_pool']}"))
        if pool.get('driver') not in ('zfs', 'btrfs', 'lvm', 'ceph'):
            raise SafeError('Use a quota-capable storage pool: zfs, btrfs, lvm or ceph; dir pools are refused.')
        await self.lxc('network', 'show', self.c['network'])
    async def image(self, version):
        alias = self.c['local_image_prefix'] + version
        # Listing distinguishes a missing alias from general CLI/service failures.
        images = json.loads(await self.lxc('image', 'list', '--format=json'))
        if any(alias == a['name'] for im in images for a in im.get('aliases', [])):
            return alias
        if not self.c['docker_fallback']:
            raise SafeError(f'Local image {alias} is missing. Import it or enable docker_fallback.')
        await build_image(version, self.c)
        return alias
    async def initialize(self, r):
        image = await self.image(r['os'])
        await self.lxc('init', image, r['id'], '--no-profiles', '--storage', self.c['storage_pool'],
                       '--network', self.c['network'],
                       '-c', 'user.vpsbot.managed=true', '-c', f"user.vpsbot.owner={r['owner']}",
                       '-c', f"limits.memory={r['ram']}GiB", '-c', 'limits.memory.swap=false',
                       '-c', f"limits.cpu={r['cpu']}", '-c', 'limits.processes=2048',
                       '-c', 'security.privileged=false', '-c', 'security.nesting=false',
                       '-c', 'security.idmap.isolated=true', '-c', 'boot.autostart=false', timeout=300)
        await self.lxc('config', 'device', 'set', r['id'], 'root', f"size={r['disk']}GiB", timeout=180)
        await self.lxc('start', r['id'], timeout=180)
        # Network readiness, with finite retries. Container package operations are not atomic.
        await self.lxc('exec', r['id'], '--', '/bin/sh', '-c',
                       'for i in $(seq 1 60); do getent hosts archive.ubuntu.com >/dev/null && exit 0; sleep 2; done; exit 1', timeout=135)
        await self.lxc('exec', r['id'], '--', '/bin/bash', '-c', PROVISION, timeout=900)
        await self.lxc('exec', r['id'], '--', '/bin/sh', '-c',
                       "for p in meminfo cpuinfo stat; do findmnt -n -o FSTYPE --target /proc/$p | grep -q lxcfs || exit 1; done")
        meminfo = await self.lxc('exec', r['id'], '--', 'cat', '/proc/meminfo')
        match = re.search(r'^MemTotal:\s+(\d+)\s+kB', meminfo, re.M)
        if not match or int(match[1]) > r['ram'] * 1024 * 1024 * 1.05:
            raise SafeError('RAM reporting check failed: repair host LXCFS integration. VPS retained in error state; no access credentials issued.')
        data = await self.checked(r['id'])
        actual = data.get('expanded_devices', {}).get('root', {}).get('size')
        if actual != f"{r['disk']}GiB":
            raise SafeError('Root disk quota did not match the requested allocation.')
    async def remove(self, ident, allow_missing=False):
        data = next((x for x in await self.listing() if x['name'] == ident), None)
        if data is None and allow_missing:
            return
        if data is None or data.get('config', {}).get('user.vpsbot.managed') != 'true':
            raise SafeError('Refusing to delete an absent or unmarked instance.')
        await self.lxc('delete', ident, '--force', timeout=240)
    async def action(self, ident, action):
        data = await self.checked(ident)
        if action == 'start' and data['status'] == 'Running':
            return
        if action == 'stop' and data['status'] == 'Stopped':
            return
        if action not in ('start', 'stop', 'restart'):
            raise SafeError('Invalid operation.')
        extra = ['--timeout=45'] if action in ('stop', 'restart') else []
        await self.lxc(action, ident, *extra, timeout=100)
    async def access(self, ident, kind):
        data = await self.checked(ident)
        if data['status'] != 'Running':
            raise SafeError('Start this VPS first.')
        text = await self.lxc('exec', ident, '--', '/bin/bash', '-c', TMATE if kind == 'ssh' else SSHX, timeout=180)
        if kind == 'ssh':
            matches = re.findall(r'^ssh (?:-p \d+ )?[A-Za-z0-9_.-]+@[A-Za-z0-9_.-]+$', text, re.M)
        else:
            matches = re.findall(r'https://sshx\.io/s/[A-Za-z0-9_/#?=&.%~-]+', text)
        if not matches:
            raise SafeError('Session did not return a recognized credential. Check outbound connectivity to the relay.')
        return matches[-1]
    async def revoke(self, ident, kind):
        await self.checked(ident)
        script = 'tmate -S /run/vpsbot/tmate.sock kill-server' if kind == 'ssh' else 'systemctl stop vpsbot-sshx.service'
        await self.lxc('exec', ident, '--', '/bin/sh', '-c', script)
    async def stats(self, ident):
        data = await self.checked(ident)
        state = json.loads(await self.lxc('query', f"/1.0/instances/{ident}/state?project={self.c['project']}"))
        def gib(n):
            return f'{(n or 0) / 1024**3:.2f} GiB'
        return (f"State: **{data['status']}**\nRAM used: {gib(state.get('memory', {}).get('usage'))}\n"
                f"Root disk used: {gib(state.get('disk', {}).get('root', {}).get('usage'))}\n"
                f"Processes: {state.get('processes', 0)}\n"
                f"CPU time (cumulative): {state.get('cpu', {}).get('usage', 0) / 1e9:.1f}s")

# ==================== In-file Docker-to-LXD image conversion ====================

DOCKERFILE = '''FROM ubuntu:{version}
ENV DEBIAN_FRONTEND=noninteractive
RUN apt-get update && apt-get install -y systemd systemd-sysv systemd-resolved dbus iproute2 iputils-ping ca-certificates curl tmate openssh-client procps lxcfs && apt-get clean && rm -rf /var/lib/apt/lists/*
RUN mkdir -p /etc/systemd/network /etc/systemd/system/multi-user.target.wants /etc/systemd/system/sockets.target.wants && printf '[Match]\\nName=eth* en*\\n[Network]\\nDHCP=yes\\n' > /etc/systemd/network/10-container.network && systemctl enable systemd-networkd systemd-resolved && systemctl mask lxcfs.service && rm -f /etc/machine-id /var/lib/dbus/machine-id && touch /etc/machine-id && rm -f /etc/resolv.conf && ln -s /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf
CMD ["/sbin/init"]
'''

async def build_image(version, c):
    if version not in OS_VERSIONS:
        raise SafeError('Unsupported Ubuntu release.')
    docker = c['docker_binary']
    token = uuid.uuid4().hex[:12]
    tag, name = f'vpsbot-image:{token}', f'vpsbot-export-{token}'
    arch = {'x86_64': 'x86_64', 'aarch64': 'aarch64'}.get(platform.machine())
    if not arch:
        raise SafeError('Automatic Docker conversion supports x86_64 and aarch64 hosts only.')
    work = BASE / 'data' / 'image-work'
    work.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        with tempfile.TemporaryDirectory(dir=work) as tmp:
            tmp = Path(tmp)
            (tmp / 'Dockerfile').write_text(DOCKERFILE.format(version=version))
            await process(docker, 'build', '--pull', '--tag', tag, str(tmp), timeout=1000)
            await process(docker, 'create', '--name', name, tag, timeout=120)
            await process(docker, 'export', '--output', str(tmp / 'rootfs.tar'), name, timeout=180)
            # JSON is a valid YAML document. LXD expects metadata.yaml at archive root.
            metadata = {'architecture': arch, 'creation_date': int(time.time()),
                        'properties': {'os': 'Ubuntu', 'release': version,
                                       'description': f'Ubuntu {version} system image converted from Docker Hub'}}
            (tmp / 'metadata.yaml').write_text(json.dumps(metadata))
            with tarfile.open(tmp / 'metadata.tar', 'w') as tar:
                tar.add(tmp / 'metadata.yaml', arcname='metadata.yaml')
            await process(c['lxc_binary'], '--project', c['project'], 'image', 'import',
                          str(tmp / 'metadata.tar'), str(tmp / 'rootfs.tar'),
                          '--alias', c['local_image_prefix'] + version, timeout=180)
    finally:
        for args in [('rm', '--force', name), ('image', 'rm', '--force', tag)]:
            try:
                await process(docker, *args, timeout=60)
            except Exception:
                pass


# ==================== Discord commands, views and moderation ====================

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
log = logging.getLogger('vpsbot')

class HostingBot(commands.Bot):
    def __init__(self, config):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.moderation = True
        super().__init__(command_prefix=config['prefix'], case_insensitive=True, help_command=None,
                         intents=intents, allowed_mentions=discord.AllowedMentions.none())
        self.cfg = config
        self.store = Store(BASE / config['database'])
        self.backend = Backend(config)
        # One serialized mutation stream; reset cannot race create, access or a button.
        self.mutation = asyncio.Lock()
        self.nuke_events = collections.defaultdict(collections.deque)
        self.audit_seen = collections.deque(maxlen=2000)
        self.add_check(self.allowed_guild)
    async def allowed_guild(self, ctx):
        if not ctx.guild or ctx.guild.id != int(self.cfg['guild_id']):
            raise commands.CheckFailure('Use commands inside the configured Discord server, not in DMs.')
        return True
    def is_admin(self, uid):
        return self.store.admin(uid, self.cfg['admin_ids'])
    def require_admin(self, uid):
        if not self.is_admin(uid):
            raise SafeError('Only a configured bot administrator can do that.')
    def require_seed(self, uid):
        if str(uid) not in map(str, self.cfg['admin_ids']):
            raise SafeError('Only a bootstrap administrator in .env can reset the bot.')
    def authorized(self, uid, ident, admin_override=False):
        row = self.store.get(ident)
        if str(uid) != row['owner'] and not (admin_override and self.is_admin(uid)):
            raise SafeError('You do not own this VPS.')
        return row
    async def audit(self, text):
        # Only non-secret lifecycle text reaches log/audit channel.
        log.info('%s', text)
        cid = self.cfg.get('audit_channel_id')
        channel = self.get_channel(int(cid)) if str(cid).isdigit() else None
        if channel:
            try:
                await channel.send(text[:1900])
            except discord.HTTPException:
                log.warning('Could not write Discord audit message')
    async def setup_hook(self):
        await self.backend.preflight()
        # Jobs are deliberately not replayed blindly following a crash.
        self.store.run("UPDATE vps SET state='error' WHERE state IN ('creating','reinstalling','deleting')")
    async def on_ready(self):
        log.info('Online as %s; project=%s', self.user, self.cfg['project'])
    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        await ctx.send(f'⚠️ {safe_error(error)}')
    async def on_audit_log_entry_create(self, entry):
        if entry.guild.id != int(self.cfg['guild_id']) or self.store.setting('antinuke') != '1':
            return
        watched = {discord.AuditLogAction.channel_delete, discord.AuditLogAction.role_delete,
                   discord.AuditLogAction.ban, discord.AuditLogAction.kick}
        if entry.action not in watched or entry.id in self.audit_seen:
            return
        self.audit_seen.append(entry.id)
        uid = entry.user_id
        if not uid or uid in (self.user.id, entry.guild.owner_id):
            return
        # Ignore stale/replayed audit events after gateway reconnects.
        now = discord.utils.utcnow()
        if abs((now - entry.created_at).total_seconds()) > self.cfg['antinuke_window_seconds']:
            return
        key = (entry.guild.id, uid)
        times = self.nuke_events[key]
        stamp = now.timestamp()
        times.append(stamp)
        while times and stamp - times[0] > self.cfg['antinuke_window_seconds']:
            times.popleft()
        if len(times) < self.cfg['antinuke_threshold']:
            return
        times.clear()
        try:
            member = entry.guild.get_member(uid) or await entry.guild.fetch_member(uid)
            danger = ('administrator', 'manage_guild', 'manage_channels', 'manage_roles',
                      'manage_webhooks', 'ban_members', 'kick_members')
            roles = [r for r in member.roles if not r.is_default() and not r.managed
                     and any(getattr(r.permissions, p) for p in danger)]
            removable = [r for r in roles if r < entry.guild.me.top_role]
            if removable:
                await member.remove_roles(*removable, reason='VPS bot antinuke: action-rate threshold exceeded', atomic=True)
            await self.audit(f'ANTINUKE: actor {uid}; removed {len(removable)} dangerous roles. '
                             f'{len(roles) - len(removable)} roles blocked by hierarchy. Review audit logs immediately; no automatic rollback.')
        except discord.HTTPException:
            await self.audit(f'ANTINUKE: could not contain actor {uid}; check role hierarchy and permissions immediately.')


def safe_error(error):
    error = getattr(error, 'original', error)
    if isinstance(error, SafeError):
        return str(error)
    if isinstance(error, commands.CommandOnCooldown):
        return f'Try again in {error.retry_after:.0f} seconds.'
    if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument, commands.TooManyArguments)):
        return 'Invalid arguments. Use Shelp for syntax; mention a member or use their numeric ID.'
    if isinstance(error, commands.CheckFailure):
        return 'You do not have permission for this action.'
    if isinstance(error, discord.Forbidden):
        return 'Discord blocked this action. Check bot permissions, role hierarchy and whether DMs are enabled.'
    if isinstance(error, discord.HTTPException):
        return 'Discord request failed. Try again shortly.'
    if isinstance(error, asyncio.TimeoutError):
        return 'Host operation timed out. It may still be running in LXD; ask an administrator to inspect it before retrying.'
    log.error('Operation failed (%s); command output intentionally not logged', type(error).__name__)
    return 'Operation failed. Ask an administrator to inspect the host and bot state.'


def box(title, description):
    return discord.Embed(title=title[:256], description=description[:4096], color=0x5865F2)

async def access_dm(bot, actor, row, kind):
    if row['state'] != 'ready':
        raise SafeError('VPS is not ready. Ask an admin to inspect or reinstall it.')
    # Probe DMs before opening a root terminal; never send a credential in a server.
    message = await actor.send(f'Preparing a new {kind.upper()} session for `{row["id"]}`…')
    credential = None
    try:
        credential = await bot.backend.access(row['id'], kind)
        await message.edit(content=(f'🔑 **{row["name"]}** (`{row["id"]}`) — {kind.upper()}\n'
                                    f'```\n{credential}\n```\n'
                                    'This grants root terminal access. Keep it private. '
                                    'Generating another session of this type disconnects the previous one. '
                                    'Reboot/stop also ends the session. This uses a third-party relay, not a permanent SSH password.'))
    except Exception:
        # Best-effort revoke even when a parser/timing failure hid the new credential.
        try:
            await bot.backend.revoke(row['id'], kind)
        except Exception:
            await bot.audit(f'Access delivery failed and revocation was not confirmed for {row["id"]}; stop the VPS to revoke.')
        try:
            await message.edit(content='Session setup/delivery failed. No credential is posted in the server. Contact the administrator.')
        except discord.HTTPException:
            pass
        raise
    await bot.audit(f'Access session rotated: {row["id"]}, {kind}, requested by {actor.id}; secret omitted.')

class Confirm(discord.ui.View):
    def __init__(self, bot, uid, operation):
        super().__init__(timeout=60)
        self.bot, self.uid, self.operation = bot, uid, operation
        self.used = False
    async def interaction_check(self, interaction):
        if interaction.user.id != self.uid or interaction.guild_id != int(self.bot.cfg['guild_id']):
            await interaction.response.send_message('This confirmation is not yours.', ephemeral=True)
            return False
        return True
    @discord.ui.button(label='Confirm permanently', style=discord.ButtonStyle.danger)
    async def confirm(self, interaction, button):
        if self.used:
            await interaction.response.send_message('Already submitted.', ephemeral=True)
            return
        self.used = True
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(content='Confirmed. Working…', view=self, embed=None)
        try:
            async with self.bot.mutation:
                result = await self.operation()
        except Exception as exc:
            result = '⚠️ ' + safe_error(exc)
        try:
            await interaction.edit_original_response(content=result, view=None)
        except discord.HTTPException:
            # Slow image builds can outlive Discord's interaction token.
            try:
                await interaction.user.send(result)
            except discord.HTTPException:
                await self.bot.audit(f'Could not deliver long-operation result to {self.uid}; inspect bot/LXD state.')
        self.stop()
    @discord.ui.button(label='Cancel', style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        self.used = True
        self.stop()
        await interaction.response.edit_message(content='Cancelled. Nothing changed.', view=None, embed=None)

async def destructive(bot, actor, ident, action, override=False):
    row = bot.authorized(actor.id, ident, override)
    # Backend checks the ownership marker if present. Missing partial creations
    # can be deleted/reinstalled too; an unmarked existing instance is never touched.
    bot.store.run('UPDATE vps SET state=? WHERE id=?', ('deleting' if action == 'delete' else 'reinstalling', ident))
    try:
        await bot.backend.remove(ident, allow_missing=True)
        if action == 'delete':
            bot.store.run('DELETE FROM vps WHERE id=?', (ident,))
        else:
            # Reinstall preserves owner, name, ID, OS and quotas, but destroys the root disk.
            await bot.backend.initialize(row)
            bot.store.run("UPDATE vps SET state='ready' WHERE id=?", (ident,))
    except Exception:
        bot.store.run("UPDATE vps SET state='error' WHERE id=?", (ident,))
        raise
    await bot.audit(f'{action.upper()}: {ident}, requested by {actor.id}')
    return f'✅ {ident}: {action} completed.'

class Manage(discord.ui.View):
    def __init__(self, bot, uid, ident, override=False):
        super().__init__(timeout=600)
        self.bot, self.uid, self.ident, self.override = bot, uid, ident, override
        buttons = [('🔄', 'REINSTALL', 'reinstall', 0, discord.ButtonStyle.danger),
                   ('▶️', 'START', 'start', 0, discord.ButtonStyle.success),
                   ('⏸️', 'STOP', 'stop', 0, discord.ButtonStyle.secondary),
                   ('🔄', 'RESTART', 'restart', 1, discord.ButtonStyle.primary),
                   ('🗑️', 'Delete VPS', 'delete', 1, discord.ButtonStyle.danger),
                   ('🔑', 'SSH', 'ssh', 2, discord.ButtonStyle.primary),
                   ('🌐', 'SSHX', 'sshx', 2, discord.ButtonStyle.primary),
                   ('📊', 'Stats', 'stats', 2, discord.ButtonStyle.secondary)]
        for emoji, label, action, row, style in buttons:
            button = discord.ui.Button(label=label, emoji=emoji, row=row, style=style)
            async def callback(interaction, action=action):
                await self.handle(interaction, action)
            button.callback = callback
            self.add_item(button)
    async def interaction_check(self, interaction):
        if interaction.user.id != self.uid or interaction.guild_id != int(self.bot.cfg['guild_id']):
            await interaction.response.send_message('Run Smanage for your own management menu.', ephemeral=True)
            return False
        try:
            self.bot.authorized(interaction.user.id, self.ident, self.override)
        except Exception as exc:
            await interaction.response.send_message(safe_error(exc), ephemeral=True)
            return False
        return True
    async def handle(self, interaction, action):
        try:
            if action in ('reinstall', 'delete'):
                async def operation():
                    return await destructive(self.bot, interaction.user, self.ident, action, self.override)
                await interaction.response.send_message(
                    f'⚠️ **{action.upper()} {self.ident}?** All files on this VPS will be permanently deleted. '
                    'No backup is created. Confirmation expires in 60 seconds.',
                    view=Confirm(self.bot, interaction.user.id, operation), ephemeral=True)
                return
            await interaction.response.defer(ephemeral=True, thinking=True)
            async with self.bot.mutation:
                row = self.bot.authorized(interaction.user.id, self.ident, self.override)
                if action in ('ssh', 'sshx'):
                    await access_dm(self.bot, interaction.user, row, action)
                    text = '✅ Your private access session has been sent by DM.'
                elif action == 'stats':
                    text = await self.bot.backend.stats(self.ident)
                else:
                    await self.bot.backend.action(self.ident, action)
                    text = f'✅ {self.ident}: {action} completed.'
                    await self.bot.audit(f'{action.upper()}: {self.ident}, requested by {interaction.user.id}')
            await interaction.followup.send(text, ephemeral=True)
        except Exception as exc:
            if interaction.response.is_done():
                await interaction.followup.send('⚠️ ' + safe_error(exc), ephemeral=True)
            else:
                await interaction.response.send_message('⚠️ ' + safe_error(exc), ephemeral=True)


def register(bot):
    @bot.command(name='ping')
    async def ping(ctx):
        await ctx.send(f'🏓 Gateway latency: {bot.latency * 1000:.0f} ms')

    async def listing(ctx, rows, title):
        if not rows:
            await ctx.send('No VPS records found.')
            return
        # Bounded embeds, even when the host has many VPSes.
        for start in range(0, len(rows), 10):
            text = '\n\n'.join(f'**{r["name"]}** — `{r["id"]}`\n'
                               f'{r["ram"]} GiB RAM · {r["disk"]} GiB disk · {r["cpu"]} CPU · Ubuntu {r["os"]}\n'
                               f'Owner: {r["owner"]} · Provisioning state: {r["state"]}' for r in rows[start:start+10])
            await ctx.send(embed=box(title, text))

    @bot.command(name='myvps')
    async def myvps(ctx):
        await listing(ctx, bot.store.rows(ctx.author.id), 'Your VPSes')

    async def management(ctx, ident, override=False):
        row = bot.authorized(ctx.author.id, ident, override)
        await ctx.send(embed=box(row['name'], f'ID: `{ident}`\nUbuntu {row["os"]} · {row["ram"]} GiB RAM · '
                                f'{row["disk"]} GiB disk · {row["cpu"]} CPU\n'
                                f'Provisioning state: {row["state"]}\nSSH/SSHX credentials go only to the requesting user’s DM.\n'
                                'Menu expires after 10 minutes or a bot restart. Use Smanage again.'),
                       view=Manage(bot, ctx.author.id, ident, override))

    @bot.command(name='manage')
    async def manage(ctx, vps_id: str):
        await management(ctx, vps_id)

    @bot.command(name='managevps')
    async def managevps(ctx, vps_id: str = None):
        bot.require_admin(ctx.author.id)
        if vps_id:
            await management(ctx, vps_id, True)
        else:
            await listing(ctx, bot.store.rows(), 'All managed VPSes — Smanagevps <id> to manage')

    @bot.group(name='new', invoke_without_command=True)
    async def new(ctx):
        await ctx.send('Use `Snew ssh <vps_id>` or `Snew sshx <vps_id>`.')

    async def rotate(ctx, ident, kind):
        async with bot.mutation:
            row = bot.authorized(ctx.author.id, ident)
            async with ctx.typing():
                await access_dm(bot, ctx.author, row, kind)
        await ctx.send('✅ New access session sent by DM. The previous session of this type was revoked.')

    @new.command(name='ssh')
    @commands.cooldown(1, 20, commands.BucketType.user)
    async def newssh(ctx, vps_id: str):
        await rotate(ctx, vps_id, 'ssh')

    @new.command(name='sshx')
    @commands.cooldown(1, 20, commands.BucketType.user)
    async def newsshx(ctx, vps_id: str):
        await rotate(ctx, vps_id, 'sshx')

    @bot.command(name='panel')
    async def panel(ctx):
        rows = bot.store.db.execute('SELECT name,url FROM panels ORDER BY name').fetchall()
        if not rows:
            await ctx.send('No panels have been added yet.')
        for row in rows:
            await ctx.send(embed=box(row['name'], row['url']))

    @bot.command(name='addpanel')
    async def addpanel(ctx, name: str, url: str):
        bot.require_admin(ctx.author.id)
        if not 1 <= len(name) <= 80 or len(url) > 1000:
            raise SafeError('Use a name up to 80 characters and a URL up to 1000 characters.')
        url = panel_url(url, bot.cfg.get('allowed_panel_hosts', []))
        async with bot.mutation:
            bot.require_admin(ctx.author.id)
            bot.store.run('INSERT OR REPLACE INTO panels VALUES (?,?)', (name, url))
        await ctx.send('✅ Panel saved. This stores a link; it does not install a hosting panel.')

    @bot.command(name='addadmin')
    async def addadmin(ctx, member: discord.Member):
        bot.require_admin(ctx.author.id)
        if member.bot:
            raise SafeError('Bot accounts cannot be hosting administrators.')
        async def operation():
            bot.require_admin(ctx.author.id)
            bot.store.run('INSERT OR IGNORE INTO admins VALUES (?)', (str(member.id),))
            await bot.audit(f'ADMIN ADDED: {member.id}, by {ctx.author.id}')
            return f'✅ {member.id} is now a bot administrator.'
        await ctx.send(f'Grant `{member.id}` control over all managed VPSes, panel links and moderation? '
                       'This also lets them grant access to other admins. Reset remains restricted to .env admins.',
                       view=Confirm(bot, ctx.author.id, operation))

    @bot.command(name='createvps')
    async def createvps(ctx, name: str, ram: str, disk: str, cpu: str, os_image: str, owner: discord.Member):
        bot.require_admin(ctx.author.id)
        ram, disk, cpu = validate_spec(bot.cfg, name, ram, disk, cpu, os_image)
        if owner.bot:
            raise SafeError('Choose a human owner.')
        status = await ctx.send('⏳ Queued. First-time Docker image conversion may take 10–25 minutes. No SSH session will be opened during creation.')
        async with bot.mutation:
            bot.require_admin(ctx.author.id)
            if len(bot.store.rows(owner.id)) >= bot.cfg['max_vps_per_user'] or len(bot.store.rows()) >= bot.cfg['max_total_vps']:
                raise SafeError('Configured VPS count limit reached.')
            ident = 'vps-' + uuid.uuid4().hex[:12]
            bot.store.run('INSERT INTO vps VALUES (?,?,?,?,?,?,?,?)',
                          (ident, name, str(owner.id), ram, disk, cpu, os_image, 'creating'))
            row = bot.store.get(ident)
            try:
                await status.edit(content=f'⏳ Creating `{ident}` for user `{owner.id}`. Please wait…')
                await bot.backend.initialize(row)
                bot.store.run("UPDATE vps SET state='ready' WHERE id=?", (ident,))
            except Exception:
                bot.store.run("UPDATE vps SET state='error' WHERE id=?", (ident,))
                await status.edit(content=f'⚠️ Provisioning failed for `{ident}`. Record and any partial container are retained for inspection. No access session issued.')
                raise
            await bot.audit(f'CREATED: {ident}, owner {owner.id}, admin {ctx.author.id}')
        await status.edit(content=f'✅ **{name}** is ready: `{ident}`. Owner: `{owner.id}`.\n'
                                 f'Run `Smanage {ident}`, then click **SSH** or **SSHX**. No key was generated during creation.')
        try:
            await owner.send(f'Your VPS **{name}** is ready. ID: `{ident}`.\nIn the server run `Smanage {ident}`, then click SSH or SSHX to generate access.')
        except discord.HTTPException:
            await ctx.send('ℹ️ The owner’s DMs are closed. VPS is ready; they must enable DMs before requesting SSH/SSHX.')

    @bot.command(name='deletevps')
    async def deletevps(ctx, vps_id: str):
        bot.require_admin(ctx.author.id)
        bot.store.get(vps_id)
        async def operation():
            bot.require_admin(ctx.author.id)
            return await destructive(bot, ctx.author, vps_id, 'delete', True)
        await ctx.send(f'⚠️ Permanently delete `{vps_id}` and all of its files?', view=Confirm(bot, ctx.author.id, operation))

    @bot.group(name='create', invoke_without_command=True)
    async def create(ctx):
        await ctx.send('Use `Screate embed <text>`.')

    @create.command(name='embed')
    async def embed(ctx, *, text: str):
        bot.require_admin(ctx.author.id)
        if len(text) > 4000:
            raise SafeError('Embed text must be 4000 characters or fewer.')
        await ctx.send(embed=box('Announcement', text))

    @bot.group(name='enable', invoke_without_command=True)
    async def enable(ctx):
        await ctx.send('Use `Senable antinuke`.')

    @bot.group(name='disable', invoke_without_command=True)
    async def disable(ctx):
        await ctx.send('Use `Sdisable antinuke`.')

    @enable.command(name='antinuke')
    async def enable_antinuke(ctx):
        bot.require_admin(ctx.author.id)
        perms = ctx.guild.me.guild_permissions
        if not (perms.view_audit_log and perms.manage_roles):
            raise SafeError('Antinuke needs View Audit Log and Manage Roles, plus a bot role above roles to be removed.')
        async with bot.mutation:
            bot.require_admin(ctx.author.id)
            bot.store.set('antinuke', '1')
        await ctx.send(f'✅ Antinuke enabled: {bot.cfg["antinuke_threshold"]} combined channel/role deletions, bans or kicks '
                       f'in {bot.cfg["antinuke_window_seconds"]} seconds triggers dangerous-role removal. '
                       'Best effort only: cannot stop the guild owner, out-rank roles, or restore deleted resources.')

    @disable.command(name='antinuke')
    async def disable_antinuke(ctx):
        bot.require_admin(ctx.author.id)
        async with bot.mutation:
            bot.require_admin(ctx.author.id)
            bot.store.set('antinuke', '0')
            bot.nuke_events.clear()
        await ctx.send('Antinuke disabled.')

    async def moderate(ctx, member, reason, action):
        bot.require_admin(ctx.author.id)
        if member.id in (ctx.author.id, bot.user.id, ctx.guild.owner_id):
            raise SafeError('Cannot target yourself, this bot, or the server owner.')
        if member.top_role >= ctx.guild.me.top_role:
            raise SafeError('The bot must have a role above the target.')
        if ctx.author.id != ctx.guild.owner_id and member.top_role >= ctx.author.top_role:
            raise SafeError('Your Discord role must be above the target.')
        if not getattr(ctx.guild.me.guild_permissions, 'ban_members' if action == 'ban' else 'kick_members'):
            raise SafeError('The bot is missing the required moderation permission.')
        async def operation():
            bot.require_admin(ctx.author.id)
            # Re-read target and actor: role hierarchy can change during confirmation.
            target = await ctx.guild.fetch_member(member.id)
            actor = await ctx.guild.fetch_member(ctx.author.id)
            if target.top_role >= ctx.guild.me.top_role or (actor.id != ctx.guild.owner_id and target.top_role >= actor.top_role):
                raise SafeError('Role hierarchy no longer permits this action.')
            why = f'VPS bot {action} by {actor.id}: {reason}'[:500]
            if action == 'ban':
                await target.ban(reason=why, delete_message_seconds=0)
            else:
                await target.kick(reason=why)
            await bot.audit(f'{action.upper()}: member {member.id}, actor {actor.id}')
            return f'✅ {member.id}: {action} completed. Their VPSes are unchanged.'
        await ctx.send(f'Confirm **{action}** for `{member.id}`? This does not delete their VPSes.', view=Confirm(bot, ctx.author.id, operation))

    @bot.command(name='ban')
    async def ban(ctx, member: discord.Member, *, reason: str = 'No reason supplied'):
        await moderate(ctx, member, reason, 'ban')

    @bot.command(name='kick')
    async def kick(ctx, member: discord.Member, *, reason: str = 'No reason supplied'):
        await moderate(ctx, member, reason, 'kick')

    @bot.command(name='reset')
    async def reset(ctx):
        bot.require_seed(ctx.author.id)
        async def operation():
            bot.require_seed(ctx.author.id)
            instances = await bot.backend.listing()
            names = sorted(x['name'] for x in instances if x.get('config', {}).get('user.vpsbot.managed') == 'true')
            # Stop on the first failure and preserve database for operator recovery.
            for name in names:
                await bot.backend.remove(name)
                bot.store.run('DELETE FROM vps WHERE id=?', (name,))
            bot.store.wipe()
            bot.nuke_events.clear()
            await bot.audit(f'RESET by bootstrap admin {ctx.author.id}: {len(names)} bot-managed containers deleted; application data cleared.')
            return ('✅ Reset completed. Bot-managed containers and database contents were deleted. '
                    '.env bootstrap admins remain. Shared host containers, cached OS images, config and Discord history were not deleted.')
        await ctx.send('🚨 **RESET ALL BOT-MANAGED VPSes?** This permanently deletes every bot-managed container in the dedicated project, '
                       'all VPS files, panel links, added admins and antinuke settings. No backup is created. '
                       'Unmanaged host containers, cached base images, .env and Discord messages are not erased. '
                       'Only a bootstrap admin can confirm. Expires in 60 seconds.', view=Confirm(bot, ctx.author.id, operation))

    @bot.command(name='help')
    async def help_command(ctx):
        await ctx.send(embed=box('VPS hosting · user commands',
            '`Smyvps` — your VPS IDs and allocations\n'
            '`Sping` — gateway latency\n'
            '`Snew ssh <id>` — rotate tmate SSH access; DM only\n'
            '`Snew sshx <id>` — rotate SSHX link; DM only\n'
            '`Smanage <id>` — reinstall/start/stop/restart/delete/SSH/SSHX/stats\n'
            '`SPanel` — admin-added panel links\n'
            '`Shelp` — this help\n\n'
            'Credentials grant root access and use third-party relays. Enable server DMs first. '
            'Reinstall and delete require confirmation and destroy VPS files.'))
        if bot.is_admin(ctx.author.id):
            await ctx.send(embed=box('Administrator commands',
                '`Screatevps <name> <ram> <disk> <cpu> <os> <@user>`\n'
                'Example: `Screatevps demo 2 20gb 2 24.04 @member`\n'
                'RAM: whole GiB; disk: whole number, GB or GiB suffix; CPU: whole core count.\n'
                'OS: `22.04`, `24.04`, `20.04`, `26.04` (image availability checked at runtime).\n'
                '`Sdeletevps <id>`\n`Smanagevps [id]`\n'
                '`Saddpanel "Panel Name" https://panel.example.com`\n'
                '`Saddadmin @member`\n`Screate embed <text>`\n'
                '`Senable antinuke` / `Sdisable antinuke`\n'
                '`Sban @member [reason]` / `Skick @member [reason]`\n'
                '`Sreset` — bootstrap admins only, explicit confirmation.'))


def main():
    config = load_config()
    token = read_environment().get('DISCORD_TOKEN', '').strip()
    if not token or token.startswith('REPLACE_'):
        raise SystemExit('Set DISCORD_TOKEN in .env; never put a bot token in .env or source control.')
    bot = HostingBot(config)
    register(bot)
    bot.run(token, log_handler=None)

if __name__ == '__main__':
    main()
