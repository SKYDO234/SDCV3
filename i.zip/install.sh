#!/usr/bin/env bash
# Installer for the single-file Discord LXD bot. Run alongside bot.py,
# requirements.txt and .env. Never downloads or executes a remote installer.
# Targets Ubuntu 22.04/24.04/26.04 with systemd on a full VM/dedicated server.
# No physical disks are formatted; existing LXD resources are not reinitialized.
set -Eeuo pipefail
umask 027

APP=/opt/lxc-hosting-bot
BOT_USER=vpsbot
BOT_HOME=/home/vpsbot
SERVICE=vpsbot.service
POOL_SIZE=40GiB
YES=false
START=false
SETTINGS_FILE=''
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"

log() { printf '\n[install] %s\n' "$*"; }
warn() { printf '\n[warning] %s\n' "$*" >&2; }
die() { printf '\n[error] %s\n' "$*" >&2; exit 1; }
cleanup() { if [[ -n "$SETTINGS_FILE" ]]; then rm -f -- "$SETTINGS_FILE"; fi; }
trap cleanup EXIT
trap 'printf "\n[error] Installer stopped at line %s. No automatic rollback was attempted. Fix the error and rerun; existing .env/data are preserved.\n" "$LINENO" >&2' ERR

usage() {
    cat <<'HELP'
Usage: sudo bash install.sh [--yes] [--start] [--pool-size 40GiB]

  --yes              Accept package/service changes and NEW loop-backed pool /
                     NAT bridge / dedicated project creation without prompts.
  --start            Enable and start the bot ONLY if token/config validation
                     succeeds. Without this, the bot is left stopped.
  --pool-size SIZE   Use a value such as 40GiB (minimum 10GiB). Only used for a
                     NEW Btrfs loop-backed pool; NEVER resizes an existing pool.
  --help             Print help; makes no changes and does not require root.

Place this file beside bot.py, .env and requirements.txt. Installs to
/opt/lxc-hosting-bot. Existing installed .env is never overwritten.
All host settings come from .env, read as data, NEVER sourced as shell code.
Supported host: Ubuntu 22.04, 24.04 or 26.04 with systemd, full VM/dedicated.

Installs Python/venv, snapd, LXD (if absent), distro LXCFS, Btrfs tools,
and Docker when DOCKER_FALLBACK=true. Python dependencies install into a venv.
If its configured pool is absent, creates a loop file through LXD (no block
source parameter). Loop pools are for small/test installs, not production
capacity planning. Pre-create a suitable production pool for production use.
LXD/Docker group access is effectively HOST ROOT. Only run trusted bot code.
Does not install tenant firewall rules, format physical disks, expose LXD's API,
or create customer VPSes. Docker/LXD themselves may change forwarding rules.
Installer is not transactional: successful earlier steps remain if a step fails.
HELP
}

while (($#)); do
    case "$1" in
        --yes) YES=true; shift ;;
        --start) START=true; shift ;;
        --pool-size) [[ $# -ge 2 ]] || die '--pool-size requires a value such as 40GiB'; POOL_SIZE=$2; shift 2 ;;
        --help|-h) usage; exit 0 ;;
        *) die "Unknown option: $1. Use --help." ;;
    esac
done

[[ "$POOL_SIZE" =~ ^[1-9][0-9]{0,4}GiB$ ]] || die 'Pool size must be a whole GiB value, for example 40GiB.'
POOL_GIB=${POOL_SIZE%GiB}
((POOL_GIB >= 10)) || die 'The new loop pool must be at least 10GiB.'
[[ $EUID -eq 0 ]] || die 'Run with sudo bash install.sh (do not run it as the bot account).'
[[ -f /etc/os-release ]] || die 'Cannot identify the operating system.'
# /etc/os-release is root-controlled OS metadata, not the application .env.
# shellcheck disable=SC1091
. /etc/os-release
[[ "${ID:-}" == ubuntu ]] || die 'This installer supports Ubuntu hosts only.'
case "${VERSION_ID:-}" in
    22.04|24.04|26.04) ;;
    *) die "Unsupported Ubuntu version: ${VERSION_ID:-unknown}. Use 22.04, 24.04 or 26.04." ;;
esac
[[ -d /run/systemd/system ]] || die 'A running systemd host is required.'
if systemd-detect-virt --container --quiet; then
    die 'A nested container was detected. Use a full VM/dedicated server, not Docker/OpenVZ/LXC bot hosting.'
fi
[[ -d /sys/fs/cgroup ]] || die 'Host cgroups are required.'
for file in bot.py requirements.txt; do
    [[ -f "$SOURCE_DIR/$file" && ! -L "$SOURCE_DIR/$file" ]] || die "Missing regular source file: $file. Extract the whole bundle first."
done
[[ ! -L "$APP" && ! -L "$APP/.env" && ! -L "$APP/data" && ! -L "$BOT_HOME" ]] || die 'Refusing a symlink at an application/config/data/home destination.'
[[ -f "$APP/.env" || -f "$SOURCE_DIR/.env" ]] || die 'Place the supplied .env beside install.sh, or keep an existing installed .env.'
if [[ ! -f "$APP/.env" && -L "$SOURCE_DIR/.env" ]]; then
    die 'Refusing a symlinked source .env.'
fi

confirm() {
    local reply
    if "$YES"; then return; fi
    [[ -t 0 ]] || die 'Interactive confirmation required. Review --help, then use --yes for unattended setup.'
    read -r -p "$1 [y/N] " reply
    [[ "$reply" == y || "$reply" == Y || "$reply" == yes || "$reply" == YES ]] || die 'Cancelled.'
}

cat <<PLAN
This will install/update packages, deploy trusted bot code to $APP,
create/use the $BOT_USER service account, and configure $SERVICE.
An existing running bot service will be stopped before its files are updated.
Your installed .env and database are retained; no physical disk is formatted.
Missing LXD resources require a separate confirmation (or explicit --yes).
No server reboot is performed.
PLAN
confirm 'Proceed with installation?'

# Serialize installers to avoid apt/service/project races.
command -v flock >/dev/null || die 'flock (util-linux) is required on the host.'
exec 9>/run/lock/vpsbot-install.lock
flock -n 9 || die 'Another copy of this installer is running.'

log 'Installing base host packages'
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip ca-certificates curl \
    snapd lxcfs btrfs-progs kmod uidmap util-linux dbus

log 'Creating/checking the dedicated service account'
if id "$BOT_USER" >/dev/null 2>&1; then
    ENTRY=$(getent passwd "$BOT_USER")
    IFS=: read -r _ _ USER_UID _ _ USER_HOME USER_SHELL <<< "$ENTRY"
    [[ "$USER_UID" != 0 && "$USER_HOME" == "$BOT_HOME" ]] || die 'Existing vpsbot user has an unexpected UID/home. Resolve manually.'
    case "$USER_SHELL" in */nologin|*/false) ;; *) die 'Existing vpsbot user is an interactive account; choose a dedicated non-login account first.' ;; esac
    getent group "$BOT_USER" >/dev/null || die 'Expected vpsbot primary group is missing.'
else
    useradd --system --user-group --create-home --home-dir "$BOT_HOME" --shell /usr/sbin/nologin "$BOT_USER"
fi
install -d -m 0750 -o "$BOT_USER" -g "$BOT_USER" "$BOT_HOME"
if systemctl is-active --quiet "$SERVICE"; then
    log 'Stopping the existing bot for the update'
    systemctl stop "$SERVICE"
fi
install -d -m 0750 -o root -g "$BOT_USER" "$APP"
install -d -m 0700 -o "$BOT_USER" -g "$BOT_USER" "$APP/data"

# Do not follow pre-existing deployment-file symlinks when operating as root.
for file in bot.py requirements.txt install.sh .venv; do
    [[ ! -L "$APP/$file" ]] || die "Refusing symlinked deployment path: $APP/$file"
done
for file in bot.py requirements.txt install.sh; do
    if [[ "$SOURCE_DIR" != "$APP" ]]; then
        install -m 0640 -o root -g "$BOT_USER" "$SOURCE_DIR/$file" "$APP/$file"
    else
        chown root:"$BOT_USER" "$APP/$file"
        chmod 0640 "$APP/$file"
    fi
done
chmod 0750 "$APP/install.sh"
if [[ ! -f "$APP/.env" ]]; then
    install -m 0640 -o root -g "$BOT_USER" "$SOURCE_DIR/.env" "$APP/.env"
else
    log "Preserving existing $APP/.env (settings in the source bundle will not overwrite it)"
    chown root:"$BOT_USER" "$APP/.env"
    chmod 0640 "$APP/.env"
fi

log 'Installing Python dependencies into the application virtual environment'
python3 -m venv "$APP/.venv"
"$APP/.venv/bin/python" -m pip install --upgrade pip
"$APP/.venv/bin/python" -m pip install -r "$APP/requirements.txt"
# Application and venv are operator-owned, but readable/executable by the service
# group. With umask 027, leaving the venv root:root would block the service user.
chown -R --no-dereference root:"$BOT_USER" "$APP/.venv"
chmod -R u=rwX,g=rX,o= "$APP/.venv"

# Parse a fixed set of non-secret host settings. NEVER eval/source .env.
# A real temporary file ensures Python failures are not hidden by process substitution.
SETTINGS_FILE=$(mktemp)
chmod 0600 "$SETTINGS_FILE"
"$APP/.venv/bin/python" - "$APP" > "$SETTINGS_FILE" <<'PY'
import re
import sys
from pathlib import Path
from dotenv import dotenv_values
root = Path(sys.argv[1])
e = dotenv_values(root / '.env', interpolate=False)
def value(key, default):
    return str(e.get(key) if e.get(key) is not None else default).strip()
settings = [value('LXC_BINARY', '/snap/bin/lxc'), value('LXD_PROJECT', 'vpsbot'),
            value('LXD_STORAGE_POOL', 'vpspool'), value('LXD_NETWORK', 'lxdbr0'),
            value('DOCKER_FALLBACK', 'true').lower(), value('DOCKER_BINARY', '/usr/bin/docker')]
if settings[0] != '/snap/bin/lxc':
    raise SystemExit('This installer manages snap LXD; set LXC_BINARY=/snap/bin/lxc or configure the host manually.')
for v in settings[1:4]:
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}', v):
        raise SystemExit('Invalid LXD project/pool/network name in the installed .env.')
if settings[1] == 'default':
    raise SystemExit('Use a dedicated LXD_PROJECT, not default.')
if settings[4] not in ('true', 'false', '1', '0', 'yes', 'no', 'on', 'off'):
    raise SystemExit('DOCKER_FALLBACK must be true or false.')
settings[4] = 'true' if settings[4] in ('true', '1', 'yes', 'on') else 'false'
if settings[4] == 'true' and settings[5] != '/usr/bin/docker':
    raise SystemExit('This installer expects DOCKER_BINARY=/usr/bin/docker.')
database = Path(value('DATABASE', 'data/bot.sqlite3'))
resolved = (root / database).resolve()
if database.is_absolute() or not resolved.is_relative_to(root / 'data') or resolved == root / 'data':
    raise SystemExit('For this installer, DATABASE must be a file beneath data/, such as data/bot.sqlite3.')
if any('\n' in v or '\r' in v for v in settings):
    raise SystemExit('Multiline host settings are not allowed.')
print('\n'.join(settings))
PY
mapfile -t SETTINGS < "$SETTINGS_FILE"
[[ ${#SETTINGS[@]} -eq 6 ]] || die 'Unexpected host settings output.'
LXC=${SETTINGS[0]}
PROJECT=${SETTINGS[1]}
POOL=${SETTINGS[2]}
NETWORK=${SETTINGS[3]}
DOCKER_ENABLED=${SETTINGS[4]}
rm -f -- "$SETTINGS_FILE"
SETTINGS_FILE=''

log 'Installing/checking LXD'
systemctl enable --now snapd.socket
snap wait system seed.loaded
if ! snap list lxd >/dev/null 2>&1; then
    if command -v lxd >/dev/null 2>&1; then
        die 'A non-snap LXD installation was found. Refusing to install a second daemon; configure it manually.'
    fi
    snap install lxd
fi
snap start lxd
[[ -x "$LXC" ]] || die 'The snap lxc executable is not available.'
getent group lxd >/dev/null || groupadd --system lxd
usermod -aG lxd "$BOT_USER"

if "$DOCKER_ENABLED"; then
    log 'Installing/checking Docker for missing-image conversion'
    if ! command -v docker >/dev/null 2>&1; then
        apt-get install -y docker.io
    fi
    [[ -x /usr/bin/docker ]] || die 'Docker exists at an unexpected location; configure it manually.'
    systemctl enable --now docker
    /usr/bin/docker info >/dev/null
    getent group docker >/dev/null || groupadd --system docker
    usermod -aG docker "$BOT_USER"
    warn 'Docker can change host forwarding rules. Verify LXD DNS/outbound traffic; this installer does not weaken your firewall to work around conflicts.'
else
    log 'Docker fallback disabled: Docker installation/group access skipped. Preload every needed LXD image before creating VPSes.'
fi

lxc_host() { "$LXC" --project default "$@"; }
log 'Waiting for the local LXD API (up to two minutes)'
READY=false
DEADLINE=$((SECONDS + 120))
while ((SECONDS < DEADLINE)); do
    if timeout 5 "$LXC" --project default query /1.0 >/dev/null 2>&1; then READY=true; break; fi
    sleep 2
done
"$READY" || die 'LXD API is not ready. Check snap services lxd and journalctl before retrying.'

POOLS=$(lxc_host storage list --format=csv -c n)
if ! grep -Fxq -- "$POOL" <<< "$POOLS"; then
    warn "Storage pool '$POOL' is missing. Proposed: a NEW ${POOL_SIZE} Btrfs loop-file pool. No physical device will be formatted. Production hosting should use a properly planned pool instead."
    confirm "Create the new loop-backed pool '$POOL'?"
    # LXD's snap data location is checked for capacity, not the source-code filesystem.
    [[ -d /var/snap/lxd/common ]] || die 'LXD data directory was not found.'
    AVAILABLE=$(df -B1 --output=avail /var/snap/lxd/common | tail -n 1 | tr -d '[:space:]')
    REQUIRED=$(((POOL_GIB + 5) * 1024 * 1024 * 1024))
    [[ "$AVAILABLE" =~ ^[0-9]+$ ]] || die 'Could not determine storage capacity.'
    ((AVAILABLE >= REQUIRED)) || die "Not enough free space: need ${POOL_GIB}GiB plus 5GiB headroom. Use a smaller --pool-size or an existing quota-capable pool."
    modprobe btrfs || grep -qw btrfs /proc/filesystems || die 'Host kernel Btrfs support is unavailable; provide an existing quota-capable pool.'
    # Intentionally no source=/dev/... option. LXD creates its own loop file.
    lxc_host storage create "$POOL" btrfs "size=$POOL_SIZE"
else
    log "Using existing storage pool '$POOL'; it will not be resized or reinitialized"
fi
lxc_host query "/1.0/storage-pools/$POOL" | python3 -c '
import json,sys
p=json.load(sys.stdin)
if p.get("driver") not in ("zfs","btrfs","lvm","ceph"):
    sys.exit("Existing pool is not quota-capable for this bot. Choose zfs/btrfs/lvm/ceph; dir is refused.")
'

NETWORKS=$(lxc_host network list --format=csv -c n)
if ! grep -Fxq -- "$NETWORK" <<< "$NETWORKS"; then
    confirm "Create managed NAT bridge '$NETWORK' with an automatically selected IPv4 subnet?"
    lxc_host network create "$NETWORK" ipv4.address=auto ipv4.nat=true ipv6.address=none
else
    log "Using existing network '$NETWORK'; network settings and firewall policy are unchanged"
fi
lxc_host query "/1.0/networks/$NETWORK" | python3 -c '
import json,sys
n=json.load(sys.stdin)
if not n.get("managed"):
    sys.exit("The selected network is not LXD-managed. Choose an existing managed network or a new bridge name.")
'

PROJECTS=$(lxc_host project list --format=csv -c n)
if ! grep -Fxq -- "$PROJECT" <<< "$PROJECTS"; then
    confirm "Create dedicated LXD project '$PROJECT'?"
    lxc_host project create "$PROJECT" -c features.images=true -c features.profiles=true \
        -c features.networks=false -c features.storage.volumes=true
else
    log "Checking existing project '$PROJECT'; no project settings will be changed"
fi
lxc_host query "/1.0/projects/$PROJECT" | python3 -c '
import json,sys
c=json.load(sys.stdin).get("config",{})
if c.get("features.networks", "false") != "false":
    sys.exit("Existing project has private networks. This installer expects features.networks=false; do not change a production project blindly.")
if c.get("features.images", "true") != "true" or c.get("features.profiles", "true") != "true":
    sys.exit("Use a dedicated project with features.images=true and features.profiles=true.")
'

as_bot() {
    runuser -u "$BOT_USER" -- env -i --chdir="$APP" HOME="$BOT_HOME" USER="$BOT_USER" LOGNAME="$BOT_USER" \
        PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin "$@"
}
log 'Checking host access as the actual service account'
as_bot "$LXC" --project "$PROJECT" list --format=json >/dev/null
if "$DOCKER_ENABLED"; then as_bot /usr/bin/docker info >/dev/null; fi
# Use the same Backend preflight as the bot, even when Discord placeholders remain.
as_bot "$APP/.venv/bin/python" -B - "$APP" <<'PY'
import asyncio
import sys
from dotenv import dotenv_values
sys.path.insert(0, sys.argv[1])
from bot import Backend
from pathlib import Path
e = dotenv_values(Path(sys.argv[1]) / '.env', interpolate=False)
c = {key: e.get(env) or default for key, env, default in (
    ('lxc_binary', 'LXC_BINARY', '/snap/bin/lxc'),
    ('project', 'LXD_PROJECT', 'vpsbot'),
    ('storage_pool', 'LXD_STORAGE_POOL', 'vpspool'),
    ('network', 'LXD_NETWORK', 'lxdbr0'))}
asyncio.run(Backend(c).preflight())
PY

log 'Installing the systemd service'
[[ ! -L "/etc/systemd/system/$SERVICE" ]] || die 'Refusing to overwrite a symlinked systemd unit.'
cat > "/etc/systemd/system/$SERVICE" <<'UNIT'
[Unit]
Description=Discord LXD VPS hosting bot
Wants=network-online.target
After=network-online.target snap.lxd.daemon.service docker.service
StartLimitIntervalSec=120
StartLimitBurst=5

[Service]
Type=simple
User=vpsbot
Group=vpsbot
WorkingDirectoc-hosting-bot/bot.py
Restart=on-failure
RestartSec=15
TimeoutStopSec=60
UMask=0077
PrivateTmp=true
# .env is read by bot.py, not interpreted by a shell or systemd EnvironmentFile.
# Snap's launcher may need privilege transitions/writable runtime paths.
# LXD/Docker group access is host-root-equivalent; this unit is not an isolation boundary.

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 "/etc/systemd/system/$SERVICE"
systemctl daemon-reload

CONFIGURED=false
if as_bot "$APP/.venv/bin/python" -B - "$APP" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
from bot import load_config, read_environment
try:
    load_config()
    token = read_environment().get('DISCORD_TOKEN', '').strip()
    if not token or token.startswith('REPLACE_'):
        raise ValueError('Set DISCORD_TOKEN in the installed .env.')
except ValueError as exc:
    print('Configuration incomplete: ' + str(exc), file=sys.stderr)
    sys.exit(1)
print('Local configuration checks passed (Discord token validity is not verified here).')
PY
then
    CONFIGURED=true
fi

if "$START" && "$CONFIGURED"; then
    log 'Enabling and starting the bot'
    systemctl enable --now "$SERVICE"
    log 'Start requested. Check the journal to confirm Discord login; active service alone does not prove it.'
else
    log 'Installation completed. The bot has NOT been started.'
    if "$START"; then warn '--start was requested, but configuration is incomplete. Fill in the installed .env first.'; fi
fi
cat <<INSTALL_FINISHED

NEXT STEPS
  1. Edit the installed settings (the source copy is not used by the service):
       sudo nano $APP/.env
  2. Enable Discord Message Content and Server Members intents, invite the bot,
     and set its permissions/role hierarchy. Never share your token.
  3. Start, then inspect logs:
       sudo systemctl enable --now $SERVICE
       sudo journalctl -u $SERVICE -f
     After later .env edits: sudo systemctl restart $SERVICE

OS images are resolved on demand, not pre-downloaded by this installer.
If Docker fallback is disabled, preload each required image, for example:
  sudo $LXC --project $PROJECT image copy ubuntu:24.04 local: --alias vpsbot-ubuntu-24.04
(Use LOCAL_IMAGE_PREFIX from .env if you changed it.)

IMPORTANT
- LXD snap supplies its own LXCFS integration; installing distro lxcfs alone is
  not proof of working guest mounts. Test a disposable VPS before handing out access.
- Test quota enforcement, RAM/CPU reporting, bridge DNS, and both relay sessions.
- NAT does not isolate tenants. Configure/test firewall/ACL and abuse controls.
- Existing root-owned database files may need an operator to adjust ownership
  for $BOT_USER; the installer does not recursively rewrite existing data.
- No host resources or customer containers are removed by this installer.
- Host package installation is not an end-to-end provisioning/security test.
INSTALL_FINISHED
